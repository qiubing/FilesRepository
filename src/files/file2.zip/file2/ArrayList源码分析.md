## ArrayList源码分析
[TOC]

ArrayList是基于**数组**实现的。

### 构造方法
```
    /**
     * 构造一个容量为10的空集合
     */
    public ArrayList() {
        this.elementData = DEFAULTCAPACITY_EMPTY_ELEMENTDATA;
    }
    
    
    /**
     * 构造一个指定容量为initialCapability的空集合
     *
     * @param  initialCapacity  the initial capacity of the list
     * @throws IllegalArgumentException if the specified initial capacity
     *         is negative
     */
    public ArrayList(int initialCapacity) {
        if (initialCapacity > 0) {
            this.elementData = new Object[initialCapacity];
        } else if (initialCapacity == 0) {
            this.elementData = EMPTY_ELEMENTDATA;
        } else {
            throw new IllegalArgumentException("Illegal Capacity: "+
                                               initialCapacity);
        }
    }
    
    //保存ArrayList元素值
    transient Object[] elementData;
    
```
为什么elementData是transient，因为ArrayList是可序列化的，用transient关键字修饰elementData，说明不希望elementData被序列化。原因如下：因为elementData未必是满的，例如容量为10的ArrayList，其中只保留了3个元素。那么就没有必要把所有的元素都需要序列化，在ArrayList的writeObject方法中就是这样的处理：

```
    /**
     * Save the state of the <tt>ArrayList</tt> instance to a stream (that
     * is, serialize it).
     *
     * @serialData The length of the array backing the <tt>ArrayList</tt>
     *             instance is emitted (int), followed by all of its elements
     *             (each an <tt>Object</tt>) in the proper order.
     */
    private void writeObject(java.io.ObjectOutputStream s)
        throws java.io.IOException{
        // Write out element count, and any hidden stuff
        int expectedModCount = modCount;
        s.defaultWriteObject();

        // Write out size as capacity for behavioural compatibility with clone()
        s.writeInt(size);

        // Write out all elements in the proper order.
        for (int i=0; i<size; i++) {
            //只序列化elementData中保存的元素
            s.writeObject(elementData[i]);
        }

        if (modCount != expectedModCount) {
            throw new ConcurrentModificationException();
        }
    }
```

每次序列化的时候调用这个方法，先调用defaultWriteObject()方法序列化ArrayList中的非transient元素，elementData不去序列化它，然后遍历elementData，只序列化那些有的元素，这样：

1、加快了序列化的速度

2、减小了序列化之后的文件大小


### 添加元素

```
    /**
     * Appends the specified element to the end of this list.
     *
     * @param e element to be appended to this list
     * @return <tt>true</tt> (as specified by {@link Collection#add})
     */
    public boolean add(E e) {
        //先确保存储集合元素容量
        ensureCapacityInternal(size + 1);  // Increments modCount!!
        //将元素保存在elementData数组中
        elementData[size++] = e;
        return true;
    }
    
    private void ensureCapacityInternal(int minCapacity) {
        if (elementData == DEFAULTCAPACITY_EMPTY_ELEMENTDATA) {
            minCapacity = Math.max(DEFAULT_CAPACITY, minCapacity);
        }

        ensureExplicitCapacity(minCapacity);
    }
    
    private void ensureExplicitCapacity(int minCapacity) {
        modCount++;

        // 如果还未达到数组的容量，则直接返回，如果超出了数组的容量，则增加数组的容量
        if (minCapacity - elementData.length > 0)
            grow(minCapacity);
    }
    
    
    /**
     * 
     * 增加容量，确保它能至少保存minCapability个元素
     * @param minCapacity the desired minimum capacity
     */
    private void grow(int minCapacity) {
        int oldCapacity = elementData.length;
        //将新的容量设为原来容量的1.5倍
        int newCapacity = oldCapacity + (oldCapacity >> 1);
        //如果新容量小于minCapability，则将新容量设为minCapability
        if (newCapacity - minCapacity < 0)
            newCapacity = minCapacity;
        if (newCapacity - MAX_ARRAY_SIZE > 0)
            newCapacity = hugeCapacity(minCapacity);
        // 将elementData数组的元素拷贝到一个新的容量为newCapacity的数组中
        elementData = Arrays.copyOf(elementData, newCapacity);
    }
    
    public static <T> T[] copyOf(T[] original, int newLength) {
        return (T[]) copyOf(original, newLength, original.getClass());
    }
    
    public static <T,U> T[] copyOf(U[] original, int newLength, Class<? extends T[]> newType) {
        @SuppressWarnings("unchecked")
        T[] copy = ((Object)newType == (Object)Object[].class)
            ? (T[]) new Object[newLength]
            : (T[]) Array.newInstance(newType.getComponentType(), newLength);
        System.arraycopy(original, 0, copy, 0,
                         Math.min(original.length, newLength));
        return copy;
    }
```

### 获取一个元素

```
    /**
     * Returns the element at the specified position in this list.
     *
     * @param  index index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException {@inheritDoc}
     */
    public E get(int index) {
        //检查索引位置
        rangeCheck(index);
        
        return elementData(index);
    }
    
    E elementData(int index) {
        return (E) elementData[index];
    }
```

### 删除元素

```
    /**
     * Removes the element at the specified position in this list.
     * Shifts any subsequent elements to the left (subtracts one from their
     * indices).
     *
     * @param index the index of the element to be removed
     * @return the element that was removed from the list
     * @throws IndexOutOfBoundsException {@inheritDoc}
     */
    public E remove(int index) {
        rangeCheck(index);

        modCount++;
        //获取移除前的值
        E oldValue = elementData(index);
        //计算需要移动的元素值
        int numMoved = size - index - 1;
        if (numMoved > 0)
            //将index+1后面的元素都向前移动一个位置
            System.arraycopy(elementData, index+1, elementData, index,
                             numMoved);
        //最后释放最后一个元素，让垃圾回收器可以回收它
        elementData[--size] = null; // clear to let GC do its work

        return oldValue;
    }
```


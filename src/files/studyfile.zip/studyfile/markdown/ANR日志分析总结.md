## ANR日志分析

ANR日志产生的地方在appNotResponding()方法中，该方法在AppErrors.java类中实现。具体的步骤过程如下：

1. 记录ANR发生的时间anrTime；
2. 如果在监控CPU的状态使用，则更新CPU的使用状态信息；
3. 在Event日志中，记录ANR发生的相关日志信息，记录关键字为“**am_anr**”；
4. 打印主线程MessageQueue中最近执行的30个Message信息，打印的信息包含Message执行的时间delay，消息分发的时间，Message的callback、Message的arg1，arg2，obj参数，以及Message的target。具体的实现原理是在IApplicationThread接口中，添加一个打印消息的方法，dumpMessageHistory();然后在应用主线程ActivityThread中，实现该dumpMessageHistory()方法。在dumpMessageHistory方法中，主要是dump最近30条message记录。此时会在main日志中打印“**dumpMessageHistory in mainLooper**”日志。最后是调用到Looper中的dumpMessageHistory()方法，它首先打印当前正在分发的消息，然后打印历史记录的30条消息。在MainLooper分发消息的时候，即在执行Looper.loop()方法时，会循环从消息队列中取出消息，然后记录消息分发前的时间start，并把消息相关的信息拷贝到DispatcheringMsg中，等待消息处理完成，然后记录消息执行完成时的时间now，并将消息执行时间delay=now-start更新到消息中，最后将该消息添加到History消息队列中，该消息队列中，最多可以添加30个消息记录。总结一下：当ANR发生时，调用主线程ActivityThread中的dumpMessageHistory()方法，最终调用到Looper的dumpMessageHistory()方法，将主线程最近执行的30个消息打印出来。每个打印出来的消息里包含了消息的执行时间，开始分发时间，以及消息执行的一些参数，例如消息的接收者，处理方法等。例如一个具体的消息如下：

	04-12 11:22:12.000  3026  3095 D nubialog:   Message[6]: { delay=2ms dispatching=-172ms sending=-175ms callback=com.android.incallui.CallTimer$CallTimerCallback arg1=1958 obj=com.android.internal.os.SomeArgs target=android.hardware.display.DisplayManagerGlobal$DisplayListenerDelegate }


5. 打印完最近主线程执行的消息后，将发生ANR的进程添加到应用进程集合，firstPids.add(app.pid)。之后，如果发生ANR的进程与当前进程不一样，则把当前进程添加进firstPids集合中，firstPids.add(MY_PID)。
6. 将ActivityManagerService中LruProcesses集合的进程添加到firstPids和lastPids中，添加的顺序是按执行时间的顺序来添加的，最近执行的最先添加，最早执行的后添加。
7. 在system日志中，添加ANR日志信息，主要包含有发生ANR的进程、Activity的包名以及类名，进程号PID，ANR产生的原因，父Activity的信息（如果有），CPU使用的状态信息（ANR发生前的CPU状态和ANR发生后的状态）。
8. 将native进程以及java进程的堆栈信息打印出来，即写入到trace.txt文件中。具体是通过AMS的dumpStackTraces，将进程的堆栈信息dump到trace.txt文件中。将firstPids集合、lastPids集合以及nativePids集合中的进程堆栈信息输出到trace文件中。native进程包含在/system/bin/目录下的进程：

	/system/bin/audioservier

	/system/bin/cameraservier

	/system/bin/mediadrmservier

	/system/bin/sdcard	

	/system/bin/surfaceflinger

> dumpStackTraces()文件的具体流程如下：
> 
	1.根据trace.txt文件的路径，创建trace.txt文件；
	2.如果需要清除以前的trace文件，则将原来的trace文件删除，并创建一个新的trace文件。
	3.设置trace文件的权限。
	4.首先dump Binder传输信息到trace文件中，具体是将system/kernel/debug/binder/transaction文件内容dump到trace.txt文件中。
	5.dump进程的堆栈信息到trace.txt文件中。首先收集最重要pids的堆栈信息，其中先查看firstPids集合中的进程堆栈信息，这里保存的是比较重要进程的堆栈信息。接着调用Process.sendSignal()方法来将Process.SIGNAL_QUIT信号发送给指定的进程，即firstPid集合中的进程。
	6.在Process中有几类常用的信号，如SIGNAL_KILL、SIGNAL_QUIT、SIGNAL_USER1信号。最终会调用到android_util_Process.cpp文件中的方法，在main日志中打印“I Process : Sending signal. PID: 3026 SIG: 3”日志，里面包含PID信息以及SIG信号名字。最后是调用到kill(pid,signal)方法。
	7.SIGNAL_QUIT的缺省操作是终止进程并进行内核映像转储（dump core），内核映像转储是指将进程数据在内存的映像和进程在内核结构中的部分内容以一定格式转储到文件系统，并且进程退出执行。
	8.dump完firstPid集合中的进程信息后，开始收集native进程的信息，调用Debug类的dumpNativeBacktraceToFile方法将native进程的信息dump到trace文件中。
	9.接着衡量CPU的使用情况，初始化ProcessCpuTracker，并且调用System.gc(等价于Runtime.getRuntime.gc方法)方法进行垃圾回收，然后调用ProcessCpuTracker.update方法读取/proc/stat/文件，获取CPU的使用状态，隔500ms更新一个CPU状态。
	10.从lastPids集合中取出最近使用CPU的5个进程，并通过发送SIGNAL_QUIT信号来记录进程的堆栈信息。
		
总结一下dumpStackTraces函数的流程如下：

> 
1. 通过SIGNAL_QUIT信号来dump firstPid集合中函数的堆栈信息；
2. 通过Debug类的dumpNativeBacktraceToFile来记录native进程的堆栈信息；
3. 通过SIGNAL_QUIT信号来dump lastPids集合中最近使用CPU的5个进程的堆栈信息。


9.记录完trace日志文件后，更新统计CPU的状态信息，并输出到system日志中。

10.将ANR错误信息写入到Drop Box中。

11.将ANR信息反馈到后台中。

12.将trace文件进行重命名，避免把其他进程的trace文件覆盖，trace文件的命名规则是app name + current date。

13.最后是发送ANR Dialog通知到界面显示。

关于CPU采样，主要是调用AMS的updateCpuStatsNow方法，在该方法中，会首先去获取最近更新CPU状态的时间mLastCputime，然后判断当前时间与mLastCputime间隔至少是否是5s以上，如果是5s以上，则开始另外更新CPU的状态信息，否则不更新CPU状态信息。所以在ANR发生时，如果在5s前已经更新过CPU状态信息了，则会再更新ANR发生前的CPU状态信息；如果在ANR发生的5s内已经更新了CPU状态，则不会再更新ANR发生前的CPU状态信息，只会更新ANR发生后的CPU状态信息。所以有时只能看到ANR发生后的CPU状态信息。统计ANR前的CPU状态信息是“CPU usage from ** to ** ago”,而统计ANR后的CPU状态信息是“CPU usage from ** to ** later”。


### trace文件组成

第一部分是binder transactions，每个进程使用Binder传输的数据类型。

第二部分是dump firstPids集合中进程的堆栈信息。

第三部分是dump native集合中进程的堆栈信息。

第四部分是dump lastPids集合中进程的堆栈信息。

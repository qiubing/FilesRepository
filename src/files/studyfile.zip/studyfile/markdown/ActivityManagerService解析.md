## ActivityManagerService解析

### 概述
ActivityManagerService（AMS）是Android提供的一个用于管理**Activity（和其他组件）**运行状态的**系统进程**。
AMS也是寄存于SystemServer中的。它会在系统启动时，创建一个线程来循环处理客户的请求。

在SystemServer.java类中，创建AMS并启动AMS。

	 /**
     * Starts the small tangle of critical services that are needed to get
     * the system off the ground.  These services have complex mutual dependencies
     * which is why we initialize them all in one place here.  Unless your service
     * is also entwined in these dependencies, it should be initialized in one of
     * the other functions.
     */
    private void startBootstrapServices() {
        // Wait for installd to finish starting up so that it has a chance to
        // create critical directories such as /data/user with the appropriate
        // permissions.  We need this to complete before we initialize other services.
        Installer installer = mSystemServiceManager.startService(Installer.class);

        // Activity manager runs the show.
		// 创建ActivityManagerService服务
        mActivityManagerService = mSystemServiceManager.startService(
                ActivityManagerService.Lifecycle.class).getService();
        mActivityManagerService.setSystemServiceManager(mSystemServiceManager);
        mActivityManagerService.setInstaller(installer);

		.......

        // Set up the Application instance for the system process and get started.
		//把AMS的一些服务注册到ServiceManager中
        mActivityManagerService.setSystemProcess();
    }

可以看到，AMS是在SystemServer中创建的，并把相应的服务注册到ServiceManager中。

创建AMS的过程如下所示：

	/**
     * Creates and starts a system service. The class must be a subclass of
     * {@link com.android.server.SystemService}.
     *
     * @param serviceClass A Java class that implements the SystemService interface.
     * @return The service instance, never null.
     * @throws RuntimeException if the service fails to start.
     */
    @SuppressWarnings("unchecked")
    public <T extends SystemService> T startService(Class<T> serviceClass) {
        try {
			//获取需要创建的SystemService类的名字
            final String name = serviceClass.getName();
            Slog.i(TAG, "Starting " + name);
            Trace.traceBegin(Trace.TRACE_TAG_SYSTEM_SERVER, "StartService " + name);

            // Create the service.
            if (!SystemService.class.isAssignableFrom(serviceClass)) {
                throw new RuntimeException("Failed to create " + name
                        + ": service must extend " + SystemService.class.getName());
            }
            final T service;
			//通过反射方法构建SystemService子类实例
            try {
                Constructor<T> constructor = serviceClass.getConstructor(Context.class);
                service = constructor.newInstance(mContext);
            } catch (InstantiationException ex) {
                ....
            }

            // Register it.
			//将服务添加到服务列表中
            mServices.add(service);

            // Start it.
			//启动服务，调用onStart()方法
            try {
                service.onStart();
            } catch (RuntimeException ex) {
                throw new RuntimeException("Failed to start service " + name
                        + ": onStart threw an exception", ex);
            }
            return service;
        } finally {
            Trace.traceEnd(Trace.TRACE_TAG_SYSTEM_SERVER);
        }
    }

	 /**
     * Called when the dependencies listed in the @Service class-annotation are available
     * and after the chosen start phase.
     * When this method returns, the service should be published.
     */
    public abstract void onStart();//抽象方法，由SystemService子类实现

AMS的内部类Lifecycle继承了SystemService类，里面实现了具体启动服务的方法onStart()。

	public static final class Lifecycle extends SystemService {
        private final ActivityManagerService mService;

        public Lifecycle(Context context) {
            super(context);
			//创建AMS
            mService = new ActivityManagerService(context);
        }

        @Override
        public void onStart() {
			//调用AMS的start()方法来启动服务
            mService.start();
        }

        public ActivityManagerService getService() {
			//返回AMS服务
            return mService;
        }
    }
	
可以看到Lifecycle内部类主要是用来实现SystemService类中的抽象方法，并创建AMS，通过onStart()方法启动AMS服务。AMS的构造过程如下：

	 // Note: This method is invoked on the main thread but may need to attach various
    // handlers to other threads.  So take care to be explicit about the looper.
    public ActivityManagerService(Context systemContext) {
        mContext = systemContext;
		//工厂模式
        mFactoryTest = FactoryTest.getMode();
		//系统线程
        mSystemThread = ActivityThread.currentActivityThread();

        Slog.i(TAG, "Memory class: " + ActivityManager.staticGetMemoryClass());

        mHandlerThread = new ServiceThread(TAG,
                android.os.Process.THREAD_PRIORITY_FOREGROUND, false /*allowIo*/);
        mHandlerThread.start();
		//创建子线程Hanlder来处理事件,线程优先级是FOREGROUND
        mHandler = new MainHandler(mHandlerThread.getLooper());
		//Ui线程Hanlder
        mUiHandler = new UiHandler();

        /* static; one-time init here */
		//创建子线程Handler来处理事件，线程优先级是BACKGROUND
        if (sKillHandler == null) {
            sKillThread = new ServiceThread(TAG + ":kill",
                    android.os.Process.THREAD_PRIORITY_BACKGROUND, true /* allowIo */);
            sKillThread.start();
            sKillHandler = new KillHandler(sKillThread.getLooper());
        }

		//前台广播队列，超时时间为10s
        mFgBroadcastQueue = new BroadcastQueue(this, mHandler,
                "foreground", BROADCAST_FG_TIMEOUT, false);
		//后台广播队列，超时时间为60s
        mBgBroadcastQueue = new BroadcastQueue(this, mHandler,
                "background", BROADCAST_BG_TIMEOUT, true);
        mBroadcastQueues[0] = mFgBroadcastQueue;
        mBroadcastQueues[1] = mBgBroadcastQueue;
		
		// Service相关
        mServices = new ActiveServices(this);
		// Provider相关
        mProviderMap = new ProviderMap(this);
		//处理APP错误，包括ANR处理
        mAppErrors = new AppErrors(mContext, this);

        //创建system目录，存放系统应用
        File dataDir = Environment.getDataDirectory();
        File systemDir = new File(dataDir, "system");
        systemDir.mkdirs();
        ....
	
		//进程状态统计
        mProcessStats = new ProcessStatsService(this, new File(systemDir, "procstats"));
		
		//权限控制相关
        mAppOpsService = new AppOpsService(new File(systemDir, "appops.xml"), mHandler);
        mAppOpsService.startWatchingMode(AppOpsManager.OP_RUN_IN_BACKGROUND, null,
                new IAppOpsCallback.Stub() {
                    @Override public void opChanged(int op, int uid, String packageName) {
                        if (op == AppOpsManager.OP_RUN_IN_BACKGROUND && packageName != null) {
                            if (mAppOpsService.checkOperation(op, uid, packageName)
                                    != AppOpsManager.MODE_ALLOWED) {
                                runInBackgroundDisabled(uid);
                            }
                        }
                    }
                });

        

        //CPU状态统计
        mProcessCpuTracker.init();

        mCompatModePackages = new CompatModePackages(this, systemDir, mHandler);
        mIntentFirewall = new IntentFirewall(new IntentFirewallInterface(), mHandler);
		//Activity相关
        mStackSupervisor = new ActivityStackSupervisor(this);
        mActivityStarter = new ActivityStarter(this, mStackSupervisor);
        mRecentTasks = new RecentTasks(this, mStackSupervisor);

		//统计CPU状态的线程
        mProcessCpuThread = new Thread("CpuTracker") {
            @Override
            public void run() {
                while (true) {
                    try {
                        try {
                            synchronized(this) {
                                final long now = SystemClock.uptimeMillis();
                                long nextCpuDelay = (mLastCpuTime.get()+MONITOR_CPU_MAX_TIME)-now;
                                long nextWriteDelay = (mLastWriteTime+BATTERY_STATS_TIME)-now;
                                .....
                                if (nextWriteDelay < nextCpuDelay) {
                                    nextCpuDelay = nextWriteDelay;
                                }
                                if (nextCpuDelay > 0) {
                                    mProcessCpuMutexFree.set(true);
                                    this.wait(nextCpuDelay);
                                }
                            }
                        } catch (InterruptedException e) {
                        }
                        updateCpuStatsNow();
                    } catch (Exception e) {
                        Slog.e(TAG, "Unexpected exception collecting process stats", e);
                    }
                }
            }
        };

        Watchdog.getInstance().addMonitor(this);
        Watchdog.getInstance().addThread(mHandler);
    }

可以看到，在创建AMS的过程中，做了以下几件事情：

1. 初始化了管理四大组件的相关类：Activity相关类、Service相关类、Provider相关类、Broadcast相关类。
2. 创建了几个Hanlder来处理事件，包括1个主线程Handler以及2个子线程Handler。
3. 初始化了进程状态统计、CPU状态统计相关类。


创建完AMS后，添加到SystemServiceManager后，就启动AMS服务。具体是通过调用start()方法来启动服务的：

    private void start() {
		// 移除所有进程组，native方法
        Process.removeAllProcessGroups();
		// 统计更新CPU状态
        mProcessCpuThread.start();
		
		// 发布电池统计服务
        mBatteryStatsService.publish(mContext);
		// 发布APP权限管理服务
        mAppOpsService.publish(mContext);
        Slog.d("AppOps", "AppOpsService published");
		// 将AMS服务添加到本地服务中
        LocalServices.addService(ActivityManagerInternal.class, new LocalService());
    }

	 /**
     * Adds a service instance of the specified interface to the global registry of local services.
     */
    public static <T> void addService(Class<T> type, T service) {
        synchronized (sLocalServiceObjects) {
            if (sLocalServiceObjects.containsKey(type)) {
                throw new IllegalStateException("Overriding service registration");
            }
			//将服务添加到一个Map中，key值为服务的类名，value值为服务
            sLocalServiceObjects.put(type, service);
        }
    }

	
	private final class LocalService extends ActivityManagerInternal {
        
		....
 
        @Override
        public int startActivitiesAsPackage(String packageName, int userId, Intent[] intents,
                Bundle bOptions) {
            Preconditions.checkNotNull(intents, "intents");
            final String[] resolvedTypes = new String[intents.length];
            for (int i = 0; i < intents.length; i++) {
                resolvedTypes[i] = intents[i].resolveTypeIfNeeded(mContext.getContentResolver());
            }

            // UID of the package on user userId.
            // "= 0" is needed because otherwise catch(RemoteException) would make it look like
            // packageUid may not be initialized.
            int packageUid = 0;
            try {
                packageUid = AppGlobals.getPackageManager().getPackageUid(
                        packageName, PackageManager.MATCH_DEBUG_TRIAGED_MISSING, userId);
            } catch (RemoteException e) {
                // Shouldn't happen.
            }

            synchronized (ActivityManagerService.this) {
                return startActivitiesInPackage(packageUid, packageName, intents, resolvedTypes,
                        /*resultTo*/ null, bOptions, userId);
            }
        }

        @Override
        public int getUidProcessState(int uid) {
            return getUidState(uid);
        }
    }

可以看到，在AMS的start方法中，将电池状态服务以及APP权限管理服务进行发布，并将ActivityManagerInternal服务添加到本地服务中。


在SystemServer的最后，会调用AMS的setSystemProcess()，将注册一些系统服务。

	public void setSystemProcess() {
        try {
			//注册一些系统服务，例如activity服务，procstat服务,meminfo服务，gfxinfo服务，dbinfo服务，cpuinfo服务
            ServiceManager.addService(Context.ACTIVITY_SERVICE, this, true);
            ServiceManager.addService(ProcessStats.SERVICE_NAME, mProcessStats);
            ServiceManager.addService("meminfo", new MemBinder(this));
            ServiceManager.addService("gfxinfo", new GraphicsBinder(this));
            ServiceManager.addService("dbinfo", new DbBinder(this));
            if (MONITOR_CPU_USAGE) {
                ServiceManager.addService("cpuinfo", new CpuBinder(this));
            }
            ServiceManager.addService("permission", new PermissionController(this));
            ServiceManager.addService("processinfo", new ProcessInfoService(this));

            ApplicationInfo info = mContext.getPackageManager().getApplicationInfo(
                    "android", STOCK_PM_FLAGS | MATCH_SYSTEM_ONLY);
			//注册系统服务信息
            mSystemThread.installSystemApplicationInfo(info, getClass().getClassLoader());

            synchronized (this) {
				//创建AMS进程的ProcessRecord，并更新CPU状态，更新OomAdj
                ProcessRecord app = newProcessRecordLocked(info, info.processName, false, 0);
                app.persistent = true;
                app.pid = MY_PID;
                app.maxAdj = ProcessList.SYSTEM_ADJ;
                app.makeActive(mSystemThread.getApplicationThread(), mProcessStats);
                synchronized (mPidsSelfLocked) {
                    mPidsSelfLocked.put(app.pid, app);
                }
                updateLruProcessLocked(app, false, null);
                updateOomAdjLocked();
            }
        } catch (PackageManager.NameNotFoundException e) {
            throw new RuntimeException(
                    "Unable to find android system package", e);
        }
    }


	 /**
     * Place a new @a service called @a name into the service
     * manager.
     * 
     * @param name the name of the new service
     * @param service the service object
     * @param allowIsolated set to true to allow isolated sandboxed processes
     * to access this service
     */
    public static void addService(String name, IBinder service, boolean allowIsolated) {
        try {
            getIServiceManager().addService(name, service, allowIsolated);
        } catch (RemoteException e) {
            Log.e(TAG, "error in addService", e);
        }
    }


从上面的代码流程可以看到，AMS是在SystemServer进程中创建并启动的，在创建AMS的时候，会初始化四大组件管理相关类，处理事件的Hanlder，以及一些状态统计服务。

在启动AMS服务的时候，会发布电池、APP权限管理服务，以及将AMS服务添加到本地服务中。

最后，在SystemServer中，会注册一些binder服务到ServiceManager中。

### ActivityStack——管理当前系统中Activity的状态
ActivityStack是Activity的记录者与管理者，同时也为AMS管理系统运行情况提供了基础。

ActivityStack有几个关键成员来管理Activity：

1. **ActivityStack**
	
	/**
 	* State and management of a single stack of activities.
 	*/
	final class ActivityStack {
		//一个Activity可能经历的所有状态
		enum ActivityState {
        	INITIALIZING,//正在初始化
        	RESUMED,//恢复
        	PAUSING,//正在暂停
        	PAUSED,//已经暂停
        	STOPPING,//正在停止
        	STOPPED,//已经停止
        	FINISHING,//正在完成
        	DESTROYING,//正在销毁
        	DESTROYED//已经销毁
    	}
	}

2. **ArrayList**

ActivityStack中还有一系列不同功能的ArrayList成员变量，他们的共同点在于列表元素都是ActivityRecord，ActivityRecord这个负责记录每个Activity的运行信息。

	 /**
     * The back history of all previous (and possibly still
     * running) activities.  It contains #TaskRecord objects.
     */
	//所有的Activity信息都在这里有记录，直到它被destroyed
    private final ArrayList<TaskRecord> mTaskHistory = new ArrayList<>();

    /**
     * Used for validating app tokens with window manager.
     */
    final ArrayList<TaskGroup> mValidateAppTokens = new ArrayList<>();

    /**
     * List of running activities, sorted by recent usage.
     * The first entry in the list is the least recently used.
     * It contains HistoryRecord objects.
     */
	//正在运行的Activity的列表集合，以最近的使用情况来排序，即队头元素是最近使用最少的元素
    final ArrayList<ActivityRecord> mLRUActivities = new ArrayList<>();

    /**
     * Animations that for the current transition have requested not to
     * be considered for the transition animation.
     */
	//列表中的Activity不考虑状态间迁移动画
    final ArrayList<ActivityRecord> mNoAnimActivities = new ArrayList<>();

    /**
     * When we are in the process of pausing an activity, before starting the
     * next one, this variable holds the activity that is currently being paused.
     */
	// 当前正在被暂停的Activity
    ActivityRecord mPausingActivity = null;

    /**
     * This is the last activity that we put into the paused state.  This is
     * used to determine if we need to do an activity transition while sleeping,
     * when we normally hold the top activity paused.
     */
	// 上一个暂停的Activity
    ActivityRecord mLastPausedActivity = null;

    /**
     * Activities that specify No History must be removed once the user navigates away from them.
     * If the device goes to sleep with such an activity in the paused state then we save it here
     * and finish it later if another activity replaces it on wakeup.
     */
    ActivityRecord mLastNoHistoryActivity = null;

    /**
     * Current activity that is resumed, or null if there is none.
     */
	// 当前被恢复的Activity，可以为null
    ActivityRecord mResumedActivity = null;

    /**
     * This is the last activity that has been started.  It is only used to
     * identify when multiple activities are started at once so that the user
     * can be warned they may not be in the activity they think they are.
     */
	// 最近一次被启动的Activity
    ActivityRecord mLastStartedActivity = null;


AMS是通过ActivityStack(和其他数据结构）来记录、管理系统中Activity(和其他组件)状态，并提供查询功能的一个系统服务。

1. AMS的主要工作就是管理、记录、查询。
2. AMS是系统进程的一部分(确切地说它运行于一个独立的线程中)
	
从内核的角度来看，AMS其实也是普通进程中的一部分，只不过是它提供的全局性的系统服务。**AMS的任务只是负责保管Activity(及其他组件)的状态信息**，而像Activity中描述的UI界面显示则是WindowMangerService和SurfaceFlinger来实现。


### startActivity流程



### ActivityTask——完成同一任务的“集合”

Android系统中应用程序的一大特色是可以装载众多的系统组件，而且可以把这些组件跨进程地组成ActivityTask。这个特性使得每个应用都不是孤立的，从而最大限度地实现资源复用。
	
#### 管理ActivityTask

应用程序可以通过两种方式来影响Activity Task的默认行为；

1. 方法1：在<activity>标签中指定属性。

相关的标签属性如下所示：

- android:taskAffinity

在默认的情况下，同一个应用程序的所有Activity拥有共同的Affinity，也可以在<application>中使用taskAffinity标签属性来指定整个应用的Affinity。

- android:launchMode

用于指定Activity被启动的方式。主要包含两部分内容：**即Activity是否为单例**，以及**Activity归属的Task**。

无论是何种方式，最终被启动的Activity通常情况下都要位于Activity Task的栈顶。

![Activity LanchMode]()


2. 方法2：使用Intent标志

除了在标签中声明task属性外，我们也可以在启动一个Activity的时候，通过Intent来动态指定所需要的task属性值。如果动态指定的task属性值与静态标签属性值冲突了，则以动态指定的task属性值为准。

- FLAG_ACTIVITY_NEW_TASK

这个和前面的singleTask启动模式的作用是一样的。

- FLAG_ACTIVITY_SINGLE_TOP

这个和前面的singleTop启动模式的作用是一样的。







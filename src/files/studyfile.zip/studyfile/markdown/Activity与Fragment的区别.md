## Activity与Fragment的区别
Fragment是Android3.0以后引入的，在没有Fragment之前，一个屏幕只能放一个Activity。

**Activity代表一个屏幕的主体，而Fragment可以作为Activity的一个组成元素。一个Activity可以有若干个（0或n）Fragment构成。**你可以把Fragment想象成Activity中的一个控件，只不过相对于一般控件，Fragment与Activity联系更为紧密。随着Activity的生命周期变化，Fragment也随之调用相应不同的生命周期函数。

Fragment从功能上来讲相当于一个子Activity，它可以让多个Activity放在一个屏幕上，可以做到**对用户界面和功能的复用**。

Fragment有自己的视图层级结构，有自己的生命周期，可以像Activity一样响应后退按钮，Fragment还有一个用作其初始化参数的包（Bundle），类似于Activity，Fragment也可以由系统自动保存并在以后还原，当系统还原Fragment时，它调用默认的构造函数（没有参数），然后将此Bundle还原到新创建的Fragment中，所以无论新建还是还原Fragment，都要经过两个步骤：

1. 调用默认构造函数；
2. 传入新的或保存起来的Bundle；

一个Activity可以运行多个Fragment，Fragment切换时，由FragmentTransaction执行，切换时，上一个Fragment可以保存在后退栈中（Back Stack），这里的后退栈由FragmentManager来管理。注意，Fragment和Activity的后退栈是有区别的：**Activity的后退栈由系统管理，而Fragment的后退栈由所在的Activity管理。**

Fragment不能脱离Activity而存在，只有Activity才能作为接收intent的载体，两者之间的关系是载体和组成元素的关系。

Fragment的生命周期函数如下：

![](http://img2.tuicool.com/EviINb.png!web)


Activity的生命周期函数如下：

![](http://img2.tuicool.com/jyuMZve.png!web)


Fragment与Activity之间的区别：

1. Fragment显示更加灵活，可以直接在XML文件中添加Fragment元素，而Activity则不行。
2. Fragment可以在一个界面上灵活的替换一部分页面，而Activity不可以，做不到。Fragment替换的时候，注意将这个Fragment放在返回栈上。
3. Fragment与Activity之间的通信：

	- Fragment控制Fragment：得到一个Activity，然后通过这个Activity的getFragmentManager()获取该Fragment的实例。
	- Fragment控制Activity：每个Fragment都有getActivity()得到一个Activity。
	- Activity控制Fragment： xxxFragment xxx = getFragmentManager().findFragmentById();
	- Activity控制Activity：这个是通过Intent来完成通信的。


### Fragment的使用
#### 1. Fragment的产生与介绍
Fragment出现是为了适应各种各样的设备。你可以把Fragment当成Activity的一个界面的一个组成部分，甚至Activity的界面可以完成由不同的Fragment组成。更重要的是Fragment拥有自己的生命周期和接收、处理用户的事件，这样就不必在Activity中写一堆控件的事件处理代码，另外，你可以动态的添加、替换和移除某个Fragment。

#### 2. Fragment的生命周期
Fragment必须是依存于Activity而存在的，因此Activity的生命周期会直接影响到Fragment的生命周期。Activity与Fragment生命周期函数对比如下：

![](http://img.blog.csdn.net/20140719225005356?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvbG1qNjIzNTY1Nzkx/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

可以看到Fragment比Activity多了几个额外的生命周期回调方法：

**onAttach(Activity)**

当Fragment与Activity发生关联时调用。

**onCreateView(LayoutInflater,ViewGroup,Bundle)**

创建该Fragment的视图

**onViewCreated(Bundle)**

当Activity的onCreate方法返回时调用

**onDestroyView()**

与onCreateView相对应，当该Fragment的视图被移除时调用

**onDetach()**

与onAttach相对应，当该Fragment的视图被移除时调用。

注意：**除了onCreateView，其他的所有方法如果你重写的，必须调用父类对该方法的实现**。

#### 3.静态的使用Fragment

这是使用Fragment最简单的一种方式，把Fragment当成普通的控件，直接写在Activity的布局文件中。步骤：

1. **继承Fragment，重写onCreateView决定Fragment的布局**
2. **在Activity中声明此Fragment，将当和普通的View一样**

#### 4.动态的使用Fragment
Fragment的动态加载、删除以及更新是通过FragmentManager来实现的。

Fragment替换的大致流程如下：

	FragmentManager fm = getFragmentManager();  
    FragmentTransaction transaction = fm.beginTransaction();  
    mWeixin = new ContentFragment();  
    transaction.replace(R.id.id_content, mWeixin);  
    transaction.commit();  

#### 5. Fragment家族常用的API
Fragment常用的三个类：
android.app.Fragment 主要用于定义Fragment
android.app.FragmentManager 主要用于在Activity中操作Fragment
android.app.FragmentTransaction 保证一些Fragment操作的原子性，事务。

**a、获取FragmentManage的方式：**

getFragmentManager() // v4中，getSupportFragmentManager

**b、主要的操作都是FragmentTransaction的方法**

FragmentTransaction transaction = fm.benginTransatcion();//开启一个事务

- **transaction.add()**
 
往Activity中添加一个Fragment

- **transaction.remove()** 

从Activity中移除一个Fragment，如果被移除的Fragment没有添加到回退栈（回退栈后面会详细说），这个Fragment实例将会被销毁。

- **transaction.replace()**

使用另一个Fragment替换当前的，实际上就是remove()然后add()的合体~

- **transaction.hide()**

隐藏当前的Fragment，仅仅是设为不可见，并不会销毁

- **transaction.show()**

显示之前隐藏的Fragment

- **detach()**

会将view从UI中移除,和remove()不同,此时fragment的状态依然由
FragmentManager维护。

- **attach()**

重建view视图，附加到UI上并显示。

- **transatcion.commit()**//提交一个事务

注意：常用Fragment的哥们，可能会经常遇到这样Activity状态不一致：State loss这样的错误。主要是因为：commit方法一定要在Activity.onSaveInstance()之前调用。

上述，基本是操作Fragment的所有的方式了，在一个事务开启到提交可以进行多个的添加、移除、替换等操作。


#### 6. 管理Fragment回退栈
类似与Android系统为Activity维护一个任务栈，我们也可以通过Activity维护一个**回退栈**来保存每次Fragment事务发生的变化，如果将Fragment任务添加到回退栈，当用户点击后退按钮时，将看到上一次保存的Fragment。一旦Fragment完全从后退栈中弹出，用户再次点击回退键，则退出当前Activity。

如何添加一个Fragment事务到回退栈：

	FragmentTransaction.addToBackStack(String)

我们知道replace方法是remove与add的合体，并且如果不添加事务到回退栈，前一个Fragment实例会被销毁。当通过FragmentTransaction.addToBackStack(null)，将当前事务添加到回退栈，当前Fragment**实例不会被销毁，但视图层依然会被销毁**，即会调用**onDestroyView和onCreateView**。

#### 7. Fragment与Activity通信
因为所有的Fragment都依赖于Activity的，所以通信并不复杂，大概归纳为：

a、**如果Activity中包含自己管理的Fragment的引用，可以通过引用直接访问所有的Fragment的public方法。**

b、**如果Activity中未保存任何Fragment的引用，那么没有关系，每个Fragment都有一个唯一的TAG或者ID，可以通过getFragmentManager.findFragmentByTag()或者findFragmentById()获得任何Fragment实例，然后进行操作。**

c、**在Fragment中可以通过getActivity得到当前绑定的Activity实例，然后进行操作。**

注意：如果在Fragment中需要Context，可以通过调用**getActivity()，如果该Context需要在Activity被销毁后还存在，则使用getActivity().getApplicationContext()**。


和Activity类似，Fragment也有onSaveInstanceState方法，在此方法中进行保存数据，然后在onCreate或者onCreateView或者onActivityCreated方法中进行恢复。


#### 8.没有布局文件的Fragment的作用
没有布局文件的Fragment实际上是为了当Activity重启时，保存大量数据。


#### 9.实例

参考文章：

[Android Fragment 真正的完全解析上](http://blog.csdn.net/lmj623565791/article/details/37970961)

[Android Fragment 真正的完全解析下](http://blog.csdn.net/lmj623565791/article/details/37992017)

[Android Fragment 你应该知道的一切](http://blog.csdn.net/lmj623565791/article/details/42628537)



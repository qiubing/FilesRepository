## Activity的4种启动模式
[TOC]

![Activity的4种启动模式](http://orbohk5us.bkt.clouddn.com/17-10-19/10620560.jpg)

Activity的启动方式有4种，分别是：

- standard；
- singleTop；
- singleTask；
- singleInstance；

可以根据实际的需求为Activity设置对应的启动模式，从而可以避免创建**大量重复**的Activity等问题。

设置Activity的启动模式，只需要在AndroidManifest.xml里对应的<activity>标签设置android:launchMode属性，例如：

	<activity  
    android:name=".MainActivity"  
    android:launchMode="standard" />  

当我们多次启动同一个Activity时，系统会创建多个实例，并把它们按照先进后出的原则——放入任务栈中，当我们按back键时，就会有一个activity从任务栈顶移除，重复下去，直到任务栈为空，系统就会回收这个任务栈。但是这样以来，系统多次启动同一个Activity时就会重复创建多个实例，这种做法显然不合理，为了能够优化这个问题，Android提供四种启动模式来修改系统这一默认行为。 


### Task概念

Activity是Android应用程序的基础组件之一，在应用程序中，每一个Activity代表一个用户操作。**用户为了完成某个功能而执行的一系列操作就形成了一个Activity序列，这个序列在Android应用程序中就称之为任务。**它是从用户体验的角度出发，把一组相关的Activity组织在一起而抽象出来的概念。

任务——**一个Activity序列**，把一组相关的Activity组织在一起而抽象出来的概念。

### standard——标准模式

这个模式是默认的启动模式，即标准模式。在不指定启动模式的情况下，系统默认使用该模式启动Activity，每次启动一个Activity，都会重新创建一个新的实例，不管这个实例是否存在。在这种模式下，谁启动了该模式的Activity，该Activity就属于启动它的Activity的任务栈中。这个Activity的onCreate()、onStart()、onResume()方法都会被调用。

**配置形式：**

	<activity android:name=".standard.StandardActivity" android:launchMode="standard" >

### singleTop——栈顶复用模式

在这个模式下，如果新的Activity已经位于**栈顶**了，那么这个Activity不会被重新创建，同时它的onNewIntent()方法会被调用。

如果栈顶不存在该Activity的实例，则情况与standard模式相同。需要注意的是这个Activity的onCreate()、onStart()方法不会被调用，因为它并没有发生改变。

**配置形式**：

	<activity android:name=".singletop.SingleTopActivity" android:launchMode="singleTop">

standard启动模式是默认的启动模式，每次启动一个Activity都会创建一个实例，不管栈中是否已经有该Activity的实例。

**singleTop模式分为3种情况**：

1. 当前栈中已有该Activity的实例并且该实例位于栈顶时，不会新建实例，而是复用栈顶的实例，并且会将Intent对象传入，回调onNewIntent方法；
2. 当前栈中已有该Activity的实例但是该实例不在栈顶时，其行为和standard启动模式一样，依然会创建一个新的实例；
3. 当前栈中不存在该Activity的实例时，其行为同standard启动模式；


 standard和singleTop启动模式都是在原任务栈中新建Activity实例，不会启动新的Task，即使你指定了**taskAffinity属性**。

### taskAffinity属性

taskAffinity属性是什么？

> taskAffinity可以简单的理解为任务相关性。

- 这个参数标识了一个Activity所需任务栈的名字。默认情况下，所有Activity所需的任务栈的名字为应用的包名。
- 我们可以单独指定每一个Activity的taskAffinity属性来覆盖默认值。
- 一个任务的affinity取决于这个任务的根activity（root activity）的taskAffinity
- 在概念上，具有相同的affinity的activity（即设置了相同taskAffinity属性的activity）属于同一个任务
- 为一个activity的taskAffinity设置一个空字符串，表明这个activity不属于任何task

taskAffinity属性不对standard和singleTop模式有任何影响，即使你指的了该属性为不同的值，**这两种启动模式下不会创建新的task**。

### singleTask——栈内复用模式

在这个模式下，如果栈中存在这个Activity的实例，就会复用这个Activity，不管它是否位于栈顶。复用时，会将它上面的Activity全面出栈，并且会回调该实例的onNewIntent方法。

其实这个过程还存在一个任务栈的匹配，因为这个模式启动时，会在自己需要的任务栈中寻找实例，这个任务栈就是通过taskAffinity属性指定。如果这个任务栈不存在，则会创建这个任务栈。

**配置形式**:

	<activity android:name=".singleTask.SingleTaskActivity" android:launchMode="singleTask" >

当启动一个singleTask模式的Activity时，如果没有指定taskAffinity属性，这说明和默认值一样，也就是应用的包名。它首先会寻找需要的任务栈是否存在，也就是taskAffinity属性指定的值，如果发现存在，就不在创建新的task，而是直接使用。当该task中存在该Activity实例时，就会复用该实例，这就是栈内复用模式。

singleTask启动模式启动Activity时，首先会根据taskAffinity属性值去寻找当前是否存在一个对应名字的任务栈。

- 如果不存在，则会创建一个新的Task，并创建新的Activity实例入栈到新创建的Task中去；
- 如果存在，则得到该任务栈，查找该任务栈中是否存在该Activity实例
	- 如果存在实例，则将它上面的Activity实例都出栈，然后回调启动的Activity实例的onNewIntent方法
	- 如果不存在该实例，则新建的Activity，并入栈；


### SingleInstance——全局唯一模式

在该模式下，Activity会单独占用一个Task栈，具有全局唯一性，即整个系统中就这么一个实例。由于栈内复用的特性，后续的请求均不会创建新的Activity实例，除非这个特殊的任务栈被销毁了。以singleInstance模式启动的Activity在整个系统中是单例的，如果启动这样的Activity时，已经存在了一个实例，那么就会把它所在的任务调度到前台，复用这个实例。

**配置模式**：

	<activity android:name=".singleinstance.SingleInstanceActivity" android:launchMode="singleInstance" >

SingleInstance模式启动的Activity在系统中具有全局唯一性。



参考：

[彻底弄懂Activity四大启动模式](http://blog.csdn.net/mynameishuangshuai/article/details/51491074)

[解开Android应用程序组件Activity的"singleTask"之谜](http://blog.csdn.net/luoshengyang/article/details/6714543)

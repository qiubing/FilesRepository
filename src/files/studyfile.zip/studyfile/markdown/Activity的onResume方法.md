## Activity的onResume方法

### 1.源码分析

1.ActivityThread.handleResumeActivity

	 final void handleResumeActivity(IBinder token,
            boolean clearHide, boolean isForward, boolean reallyResume, int seq, String reason) {
		ActivityClientRecord r = mActivities.get(token);
		r = performResumeActivity(token, clearHide, reason);

		
	} 

##Activity的onSaveInstanceState源码解析

当后台的Activity被系统自动回收的时候，如何保存Activity的状态，等下次再次进入该Activity时，恢复状态。可以通过Activity的onSaveInstanceState方法保存Activity的状态。

### 使用示例

	public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.e("qiubing","onCreate()...savedInstanceState = " + savedInstanceState);
        if (savedInstanceState != null){
            Log.e("qiubing","savedInstanceState = " + savedInstanceState.getString("name"));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("qiubing","onDestroy()...");
    }

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putString("name", "qiubing");
        Log.e("qiubing", "onSaveInstanceState()...bundle = " + bundle);
    }

    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        Log.e("qiubing","onRestoreInstanceState()...bundle = " + bundle);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("qiubing","onPause()...");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("qiubing","onStop()...");
    }
	}

输出：

	07-04 09:42:00.489  18310-18310/? E/qiubing﹕ onCreate()...savedInstanceState = null
	07-04 09:42:44.035  18310-18310/? E/qiubing﹕ onPause()...
	07-04 09:42:44.037  18310-18310/? E/qiubing﹕ onSaveInstanceState()...bundle = Bundle[{android:viewHierarchyState=Bundle[{android:views={16908290=android.view.AbsSavedState$1@53b52a5}}], name=qiubing}]
	07-04 09:42:44.037  18310-18310/? E/qiubing﹕ onStop()...
	07-04 09:42:44.088  18310-18310/? E/qiubing﹕ onDestroy()...
	07-04 09:42:44.215  18310-18310/? E/qiubing﹕ onCreate()...savedInstanceState = Bundle[{android:viewHierarchyState=Bundle[{android:views={16908290=android.view.AbsSavedState$1@53b52a5}}], name=qiubing}]
	07-04 09:42:44.215  18310-18310/? E/qiubing﹕ savedInstanceState = qiubing
	07-04 09:42:44.219  18310-18310/? E/qiubing﹕ onRestoreInstanceState()...bundle = Bundle[{android:viewHierarchyState=Bundle[{android:views={16908290=android.view.AbsSavedState$1@53b52a5}}], name=qiubing}]


### 源码分析

	 /**
     * Called to retrieve per-instance state from an activity before being killed
     * so that the state can be restored in {@link #onCreate} or
     * {@link #onRestoreInstanceState} (the {@link Bundle} populated by this method
     * will be passed to both).
     *
     * <p>This method is called before an activity may be killed so that when it
     * comes back some time in the future it can restore its state.  For example,
     * if activity B is launched in front of activity A, and at some point activity
     * A is killed to reclaim resources, activity A will have a chance to save the
     * current state of its user interface via this method so that when the user
     * returns to activity A, the state of the user interface can be restored
     * via {@link #onCreate} or {@link #onRestoreInstanceState}.
     *
     * <p>Do not confuse this method with activity lifecycle callbacks such as
     * {@link #onPause}, which is always called when an activity is being placed
     * in the background or on its way to destruction, or {@link #onStop} which
     * is called before destruction.  One example of when {@link #onPause} and
     * {@link #onStop} is called and not this method is when a user navigates back
     * from activity B to activity A: there is no need to call {@link #onSaveInstanceState}
     * on B because that particular instance will never be restored, so the
     * system avoids calling it.  An example when {@link #onPause} is called and
     * not {@link #onSaveInstanceState} is when activity B is launched in front of activity A:
     * the system may avoid calling {@link #onSaveInstanceState} on activity A if it isn't
     * killed during the lifetime of B since the state of the user interface of
     * A will stay intact.
     *
     * <p>The default implementation takes care of most of the UI per-instance
     * state for you by calling {@link android.view.View#onSaveInstanceState()} on each
     * view in the hierarchy that has an id, and by saving the id of the currently
     * focused view (all of which is restored by the default implementation of
     * {@link #onRestoreInstanceState}).  If you override this method to save additional
     * information not captured by each individual view, you will likely want to
     * call through to the default implementation, otherwise be prepared to save
     * all of the state of each view yourself.
     *
     * <p>If called, this method will occur before {@link #onStop}.  There are
     * no guarantees about whether it will occur before or after {@link #onPause}.
     *
     * @param outState Bundle in which to place your saved state.
     *
     * @see #onCreate
     * @see #onRestoreInstanceState
     * @see #onPause
     */
    protected void onSaveInstanceState(Bundle outState) {
		//保存窗口层级状态
        outState.putBundle(WINDOW_HIERARCHY_TAG, mWindow.saveHierarchyState());
		//获取Fragment的状态
        Parcelable p = mFragments.saveAllState();
        if (p != null) {
            outState.putParcelable(FRAGMENTS_TAG, p);
        }
		//调用Activity生命周期回调接口
        getApplication().dispatchActivitySaveInstanceState(this, outState);
    }

从代码可以看到，在Activity的onSaveInstanceState中，主要保存了Window的层级状态以及Fragment的状态，并回调Activity的生命周期接口。

	/** {@inheritDoc} */
    @Override
    public Bundle saveHierarchyState() {
        Bundle outState = new Bundle();
		//如果内容为空，则直接返回
        if (mContentParent == null) {
            return outState;
        }

        SparseArray<Parcelable> states = new SparseArray<Parcelable>();
		//保存ContentParent View的状态到states中
        mContentParent.saveHierarchyState(states);
		//将states状态保存到“android:views”标签中
        outState.putSparseParcelableArray(VIEWS_TAG, states);

        // Save the focused view ID.
        final View focusedView = mContentParent.findFocus();
		//保存获取焦点的View到“android:views”标签中
        if (focusedView != null && focusedView.getId() != View.NO_ID) {
            outState.putInt(FOCUSED_ID_TAG, focusedView.getId());
        }

        // save the panels
        SparseArray<Parcelable> panelStates = new SparseArray<Parcelable>();
        savePanelState(panelStates);
		//保存面板的状态到"android:Panels"标签中
        if (panelStates.size() > 0) {
            outState.putSparseParcelableArray(PANELS_TAG, panelStates);
        }
        //将ActionBar状态保存到"android:ActionBar"中
        if (mDecorContentParent != null) {
            SparseArray<Parcelable> actionBarStates = new SparseArray<Parcelable>();
            mDecorContentParent.saveToolbarHierarchyState(actionBarStates);
            outState.putSparseParcelableArray(ACTION_BAR_TAG, actionBarStates);
        }

        return outState;
    }

在Window的saveHierarchyState()方法中，保存了ContentParent View的状态、Focus View的状态、面板panel状态、ActionBar的状态。

	 /**
     * Store this view hierarchy's frozen state into the given container.
     *
     * @param container The SparseArray in which to save the view's state.
     *
     * @see #restoreHierarchyState(android.util.SparseArray)
     * @see #dispatchSaveInstanceState(android.util.SparseArray)
     * @see #onSaveInstanceState()
     */
    public void saveHierarchyState(SparseArray<Parcelable> container) {
        dispatchSaveInstanceState(container);
    }

	 /**
     * Called by {@link #saveHierarchyState(android.util.SparseArray)} to store the state for
     * this view and its children. May be overridden to modify how freezing happens to a
     * view's children; for example, some views may want to not store state for their children.
     *
     * @param container The SparseArray in which to save the view's state.
     *
     * @see #dispatchRestoreInstanceState(android.util.SparseArray)
     * @see #saveHierarchyState(android.util.SparseArray)
     * @see #onSaveInstanceState()
     */
    protected void dispatchSaveInstanceState(SparseArray<Parcelable> container) {
		//View的id不为空，则保存其状态
        if (mID != NO_ID && (mViewFlags & SAVE_DISABLED_MASK) == 0) {
            mPrivateFlags &= ~PFLAG_SAVE_STATE_CALLED;
			//调用子类的onSaveInstanceState方法，可以自定义需要保存的状态，默认实现是不保存状态
            Parcelable state = onSaveInstanceState();
            if ((mPrivateFlags & PFLAG_SAVE_STATE_CALLED) == 0) {
                throw new IllegalStateException(
                        "Derived class did not call super.onSaveInstanceState()");
            }
			//将对应View的状态，保存到ID中
            if (state != null) {
                // Log.i("View", "Freezing #" + Integer.toHexString(mID)
                // + ": " + state);
                container.put(mID, state);
            }
        }
    }

	 /**
     * Hook allowing a view to generate a representation of its internal state
     * that can later be used to create a new instance with that same state.
     * This state should only contain information that is not persistent or can
     * not be reconstructed later. For example, you will never store your
     * current position on screen because that will be computed again when a
     * new instance of the view is placed in its view hierarchy.
     * <p>
     * Some examples of things you may store here: the current cursor position
     * in a text view (but usually not the text itself since that is stored in a
     * content provider or other persistent storage), the currently selected
     * item in a list view.
     *
     * @return Returns a Parcelable object containing the view's current dynamic
     *         state, or null if there is nothing interesting to save. The
     *         default implementation returns null.
     * @see #onRestoreInstanceState(android.os.Parcelable)
     * @see #saveHierarchyState(android.util.SparseArray)
     * @see #dispatchSaveInstanceState(android.util.SparseArray)
     * @see #setSaveEnabled(boolean)
     */
    @CallSuper
    protected Parcelable onSaveInstanceState() {
		//修改标志位
        mPrivateFlags |= PFLAG_SAVE_STATE_CALLED;
        if (mStartActivityRequestWho != null) {
            BaseSavedState state = new BaseSavedState(AbsSavedState.EMPTY_STATE);
            state.mStartActivityRequestWhoSaved = mStartActivityRequestWho;
            return state;
        }
		//默认是返回空状态
        return BaseSavedState.EMPTY_STATE;
    }

子View可以实现该onSaveInstanceState方法来保存其状态，默认实现是返回空状态。

### 总结

当需要Activity在后台被回收后，仍然可以保存其状态，可以使用onSaveInstanceState()来保存其状态，然后在onCreate()或者onRestoreInstanceState()方法中，进行状态的恢复。
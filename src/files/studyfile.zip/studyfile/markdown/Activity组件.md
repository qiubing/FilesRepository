## Activity组件
[TOC]

### 1.简介


### 2.启动流程

#### 2.1 默认Activity的启动流程
默认Activity的启动流程可以分为五个阶段：

1. Launcher通过Binder进程间通信机制通知ActivityManagerService，它要启动一个Activity；
2. ActivityManagerService通过Binder进程间通信机制，通知Launcher进入Paused状态；
3. Launcher通过Binder进程间通信机制，通知ActivityManagerService，它已经准备就绪进入paused状态，于是ActivityManagerService就创建一个新的进程，用来启动一个ActivityThread实例，即将要启动的Activity就是在这个ActivityThread实例中运行。
4. ActivityThread通过Binder进程间通信机制，将一个ApplicationThread类型的Binder对象传递给ActivityManagerService，以便以后ActivityManagerService能够通过这个Binder对象和它通信。
5. ActivityManagerService通过Binder进程间通信机制通知ActivityThread，现在一切准备就绪，它可以真正执行Activity的启动操作。




![Activity启动整体流程](http://gityuan.com/images/activity/start_activity_process.jpg)

启动流程：

1. 点击桌面App图标，Launcher进程采用Binder IPC向system_server进程发起startActivity请求；
2. system_server进程接收到请求后，向zygote进程发送创建进程的请求；
3. Zygote进程fork出新的子进程，即App进程；
4. App进程，通过Binder IPC向sytem_server进程发起attachApplication请求；
5. system_server进程在收到请求后，进行一系列准备工作后，再通过binder IPC向App进程发送scheduleLaunchActivity请求；
6. App进程的binder线程（ApplicationThread）在收到请求后，通过handler向主线程发送LAUNCH_ACTIVITY消息；
7. 主线程在收到Message后，通过发射机制创建目标Activity，并回调Activity.onCreate()等方法。



#### 2.2 应用程序内部启动Activity流程

在应用程序内部启动新的Activity的流程可以分为四个阶段：

1. 应用程序的MainActivity通过Binder通信机制通知ActivityManagerService，它要启动一个新的Activity。
2. ActivityManagerService通过Binder进程间通信机制通知MainActivity进入paused状态；
3. MainActivity通过Binder进程间通信机制通知ActivityManagerService，它已经准备就绪进入paused状态，于是ActivityManagerService就准备要在MainActivity所在的进程和任务中启动新的Activity了；
4. ActivityManagerService通过Binder进程间通信机制通知MainActivity所在的ActivityThread，现在一切准备就绪，它可以真正执行Activity的启动操作了；

### 3.Activity的生命周期

#### 3.1 进程间通信

对于App来说，其Activity的生命周期执行是与系统进程中的ActivityManagerService有一定关系的。

**system_server进程是系统进程**，Java framework框架的核心载体，里面运行了大量的系统服务，比如这里提供ApplicationThreadProxy（简称ATP），ActivityManagerService（简称AMS），这个两个服务都运行在system_server进程的不同线程中，由于ATP和AMS都是基于IBinder接口，都是binder线程，binder线程的创建与销毁都是由binder驱动来决定的。

**App进程是应用程序所在进程**，主线程主要负责Activity/Service等组件的生命周期以及UI相关操作都运行在这个线程； 另外，每个App进程中至少会有两个binder线程 ApplicationThread(简称AT)和ActivityManagerProxy（简称AMP），除了下图中所示的线程，其实还有很多线程，比如signal catcher线程等。

![](http://gityuan.com/images/activity/app_process.jpg)

Binder用于不同进程之间通信，由一个进程的Binder客户端向另一个进程的服务端发送事件，比如图中线程2向线程4发送事务；而handler用于同一个进程中不同线程的通信，比如图中线程4向主线程发送消息。


![Activity生命周期图](http://gityuan.com/images/lifecycle/activity.png)

当Activity A 启动 Activity B时，两个activity都有自个的生命周期。Activity A暂停或者停止，Activity B被创建。记住，在Activity B创建之前，Activity A并不会完全停止，流程如下：

1. Activity A 进入onPause();
2. Activity B 依次 onCreate(), onStart(), onResume()。（此时Activity B得到了用户焦点）
3. 如果Activity A不再可见，则进入onStop().

### 4.Activity状态
Activity只有下面的三个状态是静态的，可以存在较长时间内保持状态不变，其他的状态都只是过渡状态，系统会快速执行并切换到下一个状态：

- **运行状态(Resumed)**：
	- 当前activity在最上方，用户可以与它进行交互；
	- 此状态由onResume()进入，由onPause()退出；
	
- **暂停(Paused)**：
	- 当前activity仍然是可见的。但被另一个activity处在最上方，最上方的activity是半透明的，或者是部分覆盖整个屏幕。被暂停的activity不会再接受用户的输入；
	- 处于活着的状态（Activity对象存留在内存，保持着所有的状态和成员信息，仍然吸附在window manager）；
	- 当处于极度低内存的状态时，系统会杀掉该activity，释放相应资源；
	- 此状态由onPause()进入，可能由onResume()退出或者onCreate()重新唤醒软件，或者被onStop()杀掉；
	
- **停止(Stopped)**：
- 当前activity完全被隐藏，不被用户可见，可以认为是处于在后台；
- 处于活着的状态（Activity对象存留在内存，保持着所有的状态和成员信息，不再吸附在window manager）；
- 由于对用户不再可见，只要有内存的需要，系统就会杀掉该activity来释放资源；
- 该状态由onStop()进入，或onRestart()或者onCreate()重新唤醒软件，或者被onDestroy()彻底死亡；

其他状态(Created和Started)都是短暂的，系统会快速的执行那些回调函数。

![Activity状态图](http://gityuan.com/images/activity/activity_lifecycle.jpg)

### 5. APP主线程

每个APP都有一个主线程，ActivityThread运行在主线程中，充当着主线程的职责。

对于Linux来说，**进程和线程都是一个task_struct结构体**，除了是否有独立资源，并没有什么区别。本质上来说，**主线程是APP首次启动时创建的进程**。在CPU看来，进程或线程无非就是一段可执行的代码，CPU采用CFS调度算法，保证每个task都尽可能公平的享有CPU时间片。

[Android中为什么主线程不会因为Looper.loop()里的死循环卡死？](https://www.zhihu.com/question/34652589)

Android应用程序的主线程在进入消息循环过程前，会在内部创建一个Linux管道（Pipe），这个管道的作用是使得Android应用程序主线程在消息队列为空时可以进入空闲等待状态，并且使得当前应用程序的消息队列有消息需要处理时，唤醒应用程序的主线程。

1. Android应用程序的消息处理机制由消息循环、消息发送和消息处理三部分组成。
2. Android应用程序的主线程在进入消息循环过程前，会在内部创建一个Linux管道（Pipe），这个管道的作用是使得Android应用程序主线程在消息队列为空时可以进入空闲等待状态，并且使得当前应用程序的消息队列有消息需要处理时，唤醒应用程序的主线程。
3. Android应用程序的主线程进入空闲等待状态的方式实际上就是在管道的读端等待管道中有新的内容可读，具体来说，就是通过Linux系统的Epoll机制中的epoll_wait函数进行的。
4. 当往Android应用程序的消息队列中加入新的消息时，会同时往管道中的写端写入内容，通过这种方式就可以唤醒正在等待消息到来的应用程序主线程。
5. 当应用程序主线程在进入空闲等待之前，会认为当前线程处于空闲状态，于是就会调用那些已经注册了的IdleHandler接口，使得应用程序有机会在空闲的时候处理一些事情。

### 6.Activity与Window的关系

ActivityManagerService(AMS)负责管理系统四大组件以及进程管理，其中包括Activity的各种栈以及状态切换等管理。

WindowManagerService(WMS)是管理Activity所对应的窗口系统(系统窗口以及嵌套的子窗口)。

SurfaceFlinger则是将应用UI绘制到FrameBuffer(帧缓冲区)，最终由硬件完成渲染到屏幕上。

Activity对象的常见成员：

- mWindow：数据类型PhoneWindow，继承于Window对象；
- mWindowManager：数据类型为WindowManagerImpl，实现了WindowManager接口；
- mMainThread：数据类型为ActivityThread，并非真正的线程，只是运行在主线程的对象；
- mUiThread：数据类型为Thread，当前activity所在线程，即主线程；
- mHandler：数据类型为Handler，当前主线程的handler；
- mDecor：数据类型为View，Activity执行完Resume之后创建的视图对象；

ViewRootImpl对象是View树层级的管理者，用于衔接View和WindowManager。重要的成员变量：

- mWindowSession: 数据类型为IWindowSession, 同一进程中所有的ViewRootImpl对象只对应唯一相同的Session代理对象。
- mWindow: 数据类型为IWindow.Stub，每个创建对应一个该对象。
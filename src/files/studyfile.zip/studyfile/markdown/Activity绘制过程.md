## Android应用程序窗口（Activity）的测量（Measure）、布局（Layout）和绘制（Draw）过程

### 1.简介

绘制UI图形到屏幕上需要经历以下过程:

1. Android应用程序窗口请求SurfaceFlinger服务创建了一个绘图表面(Surface)；
2. 请求为该绘图表面Surface创建**图形缓冲区**；
3. 往图形缓冲区填充UI数据；
4. 请求SurfaceFlinger服务将它们渲染到硬件帧缓冲区中去；
5. 屏幕显示应用程序窗口UI；

Android应用程序窗口一般不会**直接去操作**分配给它的图形缓冲区，而是通过一些图形库API来操作。

- 对于C++开发的动画应用程序bootanimation，它是通过**OpenGL提供的API**来绘制UI的。
- 对于Java开发的Android应用程序来说，它们一般是使用**Skia图形库提供的API**来绘制UI的。

在Skia图形库中，所有的UI都是绘制在**画布(Canvas)**上的。因此，Android应用程序窗口需要将它的**图像缓冲区封装在一块画布(Canvas)**里面，然后才可以使用Skia库提供的API来绘制UI。

一个Android应用程序窗口里面包含了很多UI元素，这些UI元素是以**树形结构**来组织的，即它们存在着**父子关系**。其中，子UI元素位于父UI元素里面，因此，在绘制一个Android应用程序窗口的UI之前，我们首先要确定它里面的**各个子UI元素在父UI元素里面的大小以及位置**。确定各个子UI元素在父UI元素里面的大小以及位置的过程又称为**测量过程**和**布局过程**。因此，Android应用程序窗口的UI渲染过程可以分为**测量**、**布局**和**绘制**三个阶段。

![Android应用程序窗口渲染三步曲](http://img.my.csdn.net/uploads/201212/23/1356275187_5515.jpg)

Android应用程序窗口的顶层视图是一个类型为**DecorView**的UI元素,这个顶层视图最终是由ViewRootImpl类的成员函数**performTraversals**来启动**测量、布局和绘制**操作的。这三个操作分别由DecorView类的成员函数measure和layout以及ViewRootImpl类的成员函数draw来实现的。

### 2.Android应用程序窗口的测量过程

MeasureSpec的值由两部分内容组成：测量模式与测量值。

最高2位表示一个测量模式，而低30位表示一个宽度值或者高度值。测量模式有三种：

- MeasureSpec.AT_MOST：表示当前视图的大小等于参数size和参数measureSpec所指定的值中的较小值；
- MeasureSpec.EXACTLY：表示当前视图的大小等于参数measureSpec中所指定的值；
- MeasureSpec.UNSPECIFIED：表示当前视图没有指定它的大小测量模式，这时候就使用参数size的值；

测量过程主要是通过覆写onMeasure()函数来完成的，在onMeasure()函数中，需要调用setMeasuredDimension()函数。

### 3.Android应用程序窗口的布局过程

onLayout()用来重新布局当前视图的子视图的布局。

View类的成员函数onLayout是由子类来重写的，并且只有当该子类描述的是一个容器视图时，它才会重写父类View的成员函数onLayout。

### 4.Android应用程序窗口的绘制过程

ViewRootImpl类的成员函数draw()首先会创建一块**画布Canvas**，接着再在画布上绘制Android应用程序窗口的UI，最后再将画布的内容交给SurfaceFlinger服务来**渲染**。

绘图表面对应的画布Canvas对象的获取，是通过Surface对象的lockCanvas()来创建的。

	private boolean drawSoftware(Surface surface, AttachInfo attachInfo, int xoff, int yoff,
            boolean scalingRequired, Rect dirty) {
		final Canvas canvas;
		try {
			.....
			canvas = mSurface.lockCanvas(dirty);//1.创建画布Canvas
			.....
		}catch(Surface.OutOfResourcesException e){
			......
		}

		try{
			.....
			mView.draw(canvas);//2.绘制UI数据到画布Canvas上
			.....
		}finnally{
			.....
			surface.unlockCanvasAndPost(canvas);//3.请求SurfaceFlinger渲染数据
			.....
		}
	}

绘制应用程序窗口UI是通过View的成员函数draw()绘制到画布Canvas上。绘制完成之后，应用程序窗口的UI就都体现在前面所创建的画布canvas上。

渲染的过程是通过Surface对象的unlockCanvasAndPost()方法来实现的。


通过C++层的Surface对象的lock函数来获取一个**图形缓冲区**。获得图形缓冲区之后，我们就可以在上面绘制应用程序窗口的UI了。由于Java层的应用程序是通过SKia图形库API来绘制应用程序窗口的UI，而Skia图形库在绘制UI时，是需要一块**画布的**。因此，需要将所获得的**图形缓冲区封装在一块画布**中。


每一个Java层的Surface对象内部都有一块画布，这块画布是通过它的成员变量mCanvas所指向的一个Java层的CompatibleCanvas对象来描述的。



### 5.小结

1. 渲染Android应用程序窗口UI需要经过三步曲：**测量**、**布局**、**绘制**。
2. Android应用程序窗口UI首先是使用Skia图形库API来绘制在一块**画布Canvas**上，实际上是绘制在这块画布里面的一个**图形缓冲区**中，这个图形缓冲区最终会交给**SurfaceFlinger服务**，而SurfaceFlinger服务再使用OpenGL图形库API来将这个图形缓冲区渲染到**硬件帧缓冲区**中。



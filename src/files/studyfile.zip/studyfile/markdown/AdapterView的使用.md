## AdapterView机制

### 1.AdapterView简介

AdapterView是一个抽象类，其子类具有如下共同特征:

- AdapterView**继承了ViewGroup**，它的本质是容器。
- AdapterView可以包含多个列表项，并将多个列表项以合适的方式显示出来。
- AdapterView显示的多个列表项由Adapter提供，调用AdapterView的setAdapter方法来设置Adapter即可。


ListView、GridView、Spinner等AdapterView都只是容器，而Adapter负责提供每个列表项组件，AdapterView则负责用合适的方式显示这些列表项。

AdapterView的类图如下：

![AdapterView的类图](http://orbohk5us.bkt.clouddn.com/17-9-1/86591365.jpg)

AdapterView是那种专门用来处理内容元素很多，手机屏幕无法展示出所有内容的情况。ListView可以使用列表的形式来展示内容，超出屏幕部分的内容只需要通过手指滑动就可以移动到屏幕内了。


控件的作用就是为了交互和展示数据用的，只不过ListView更加特殊，它是为了展示很多很多数据用的，但ListView只是负责数据的展示和交互工作而已，具体的数据来源则不关心。我们知道使用AdapterView时的数据源可以为数组、List列表或者查询的Cursor数据等，那么该由谁来适配数据源与显示呢？**答案是Adapter**。



### 2.Adapter接口及实现类

Adapter本身只是一个接口，它派生了ListAdapter和SpinnerAdapter两个子接口，其中ListAdapter为AbsListView提供列表项，而SpinnerAdapter为AbsSpinner提供列表项。

BaseAdapter同时实现了ListAdapter和SpinnerAdapter两个接口，因此BaseAdapter及其子类可以同时为AbsListView、AbsSpinner提供列表项。

Adapter常用实现类如下：

- ArrayAdapter

	简单、易用的Adapter，通常用于将数组或List集合的多个值包装成多个列表；


- SimpleAdapter

	用于将List集合的多个对象包装成多个列表项；可以将List中的Map数据映射到对应的XML资源文件中定义的控件View上。

- SimpleCursorAdapter

	用于包装Cursor提供的数据；Cursor必须包含有“_id”的列，否则该Adapter不起作用。

Adapter的类图如下：

![Adapter类图](http://orbohk5us.bkt.clouddn.com/17-9-1/79623093.jpg)


Adapter在ListView和数据源之间起到了一个中间桥梁的作用，ListView不会直接和数据源打交道，而是通过Adapter去访问真正的数据源。

Adapter是一个接口，它可以实现各种各样的子类，每个子类都可以完成与特定的数据源适配操作。例如ArrayAdapter可以用于数组和List类型的数据源适配，SimpleCursorAdapter可以用于Cursor类型的数据源适配。


### 3.RecycleBin复用机制

RecycleBin可以促进View的复用。RecycleBin有两个数组：ActiveViews和ScrapViews。

ActiveViews其实就是在UI屏幕上可见的视图(onScreenView)，也是与用户进行交互的View，那么这些View会通过RecycleBin直接存储到mActiveViews数组当中。

ScrapView是当我们滑动ListView时，有些View被滑动到屏幕之外(offScreen)View，那么这些View就成为了ScrapView，也就是废弃的View。这些View已经无法与用户进行交互了，这样当UI视图改变时，就没有绘制这些无用视图的必要了。存储在mScrapView数组中的View，没有被销毁掉，可以被二次复用。

当新的View需要显示的时候，先判断mActiveView中是否存在，如果存在那么我们就可以直接从mActiveView数组当中取出复用，也就是直接复用，否则从mScrapView数组当中进行判断，如果存在，那么二次复用当前的视图，如果不存在，那么就需要inflate View了。


![](http://images2015.cnblogs.com/blog/734980/201612/734980-20161206165621272-894185943.png)


	class RecycleBin {
		// 当View被放置到ScrapViews中时，接收一个新的通知
		private RecyclerListener mRecyclerListener;
		// 存储在mActiveViews中的第一个View的位置
		private int mFirstActivePosition;

		private View[] mActiveViews = new View[0];
		
		// 被废弃的View
		private ArrayList<View>[] mScrapViews;

		// View的类型数
		private int mViewTypeCount;
		
		private ArrayList<View> mCurrentScrap;
		private ArrayList<View> mSkippedScrap;

	}

RecycleBin的几个关键方法：

1.fillActiveViews（）

	void fillActiveViews(int childCount, int firstActivePosition) {
            if (mActiveViews.length < childCount) {
                mActiveViews = new View[childCount];
            }
			// 保留存储在ActiveView数组中的第一个View的位置
            mFirstActivePosition = firstActivePosition;

            final View[] activeViews = mActiveViews;
			// 依次将childCount个View保存在mActiveViews数组中
            for (int i = 0; i < childCount; i++) {
                View child = getChildAt(i);
                AbsListView.LayoutParams lp = (AbsListView.LayoutParams) child.getLayoutParams();
                if (lp != null && lp.viewType != ITEM_VIEW_TYPE_HEADER_OR_FOOTER) {
                   
                    activeViews[i] = child;
                  
                    lp.scrappedFromPosition = firstActivePosition + i;
                }
            }
        }

fillActiveViews()方法的主要作用是将ListView中指定元素存储到mActiveViews数组当中。第一个参数表示要存储的view的数量，第二个参数表示ListView中第一个可见元素的position值。
	
2.getActiveView（）

	// 返回指定位置相关的View，如果找到了该View，则会从mActiveViews中移除该View
	View getActiveView(int position) {
            int index = position - mFirstActivePosition;//计算数组索引值
            final View[] activeViews = mActiveViews;
            if (index >=0 && index < activeViews.length) {
                final View match = activeViews[index];
                activeViews[index] = null;//将找到的View置为空
                return match;
            }
            return null;
        }

getActiveView()方法的主要作用是从mActiveViews数组中查找对应的View。如果找到该View，返回该View，并将相应位置的View置为空。这样下次返回相同位置时，将返回null，即mActiveViews里面的View是不能被重复利用的。

3.addScrapView（）

	// 将一个View添加到ScrapView集合中
	void addScrapView(View scrap, int position) {
			// 获取View的布局参数
            final AbsListView.LayoutParams lp = (AbsListView.LayoutParams) scrap.getLayoutParams();
			// 如果参数为空，则直接返回
            if (lp == null) {
                return;
            }
            // 记录View从废弃View移除时的位置
            lp.scrappedFromPosition = position;

			// 获取View的类型
            final int viewType = lp.viewType;
			// 如果View是头或尾部View，或者是不能被重复利用的View，则跳过添加该View
            if (!shouldRecycleViewType(viewType)) {
                // 不能被回收利用，则直接跳过Scrap heap,将该View从ListView中分离出来
                if (viewType != ITEM_VIEW_TYPE_HEADER_OR_FOOTER) {
                    getSkippedScrap().add(scrap);
                }
                return;
            }
            
			// 该View暂时从ListView中detach分离
            scrap.dispatchStartTemporaryDetach();
			
      
            notifyViewAccessibilityStateChangedIfNeeded(
                    AccessibilityEvent.CONTENT_CHANGE_TYPE_SUBTREE);

			// 不废弃那些拥有短暂状态的View
            final boolean scrapHasTransientState = scrap.hasTransientState();
            if (scrapHasTransientState) {
                if (mAdapter != null && mAdapterHasStableIds) {
              		// 如果Adapter有stable ID，我们可以复用相同数据的View
                    if (mTransientStateViewsById == null) {
                        mTransientStateViewsById = new LongSparseArray<>();
                    }
                    mTransientStateViewsById.put(lp.itemId, scrap);
                } else if (!mDataChanged) {
                    // 如果数据没有发生改变，则我们可以在原来的位置上复用View
                    if (mTransientStateViews == null) {
                        mTransientStateViews = new SparseArray<>();
                    }
                    mTransientStateViews.put(position, scrap);
                } else {
                    // 移除该Scrap View
                    getSkippedScrap().add(scrap);
                }
            } else {
				// 如果只有一种View类型，则将该Scrap View添加到mCurrentScrap集合中，否则的话，添加到对应ViewType的数组中
                if (mViewTypeCount == 1) {
                    mCurrentScrap.add(scrap);
                } else {
                    mScrapViews[viewType].add(scrap);
                }
                // 如果定义而来RecyclerListener，则通过回调方法通知添加了ScrapView
                if (mRecyclerListener != null) {
                    mRecyclerListener.onMovedToScrapHeap(scrap);
                }
            }
        }

addScrapView()方法的主要作用是将一个废弃的View进行缓存，如果只有一种ViewType类型，则使用mCurrentScrap数组来保存废弃的View；如果有多种ViewType类型的View，则使用mScrapViews数组来保存废弃的View，每一种ViewType都对应一个数组来保存废弃的View。

4.getScrapView（）

	View getScrapView(int position) {
			// 返回指定position对应的ViewType类型
            final int whichScrap = mAdapter.getItemViewType(position);
			// 如果ViewType类型小于0，则直接返回null
            if (whichScrap < 0) {
                return null;
            }
			// 如果只有一种ViewType类型，则从mCurrentScrap数组中返回View，否则的从mScrapViews数组中返回
            if (mViewTypeCount == 1) {
                return retrieveFromScrap(mCurrentScrap, position);
            } else if (whichScrap < mScrapViews.length) {
                return retrieveFromScrap(mScrapViews[whichScrap], position);
            }
            return null;
        }

getScrapView()方法的主要作用是从指定ScrapView集合上返回相应的Scarp View，返回的顺序是不定的，只是简单的从数组的尾部返回一个Scrap View。

5.setViewTypeCount()

	public void setViewTypeCount(int viewTypeCount) {
            if (viewTypeCount < 1) {
                throw new IllegalArgumentException("Can't have a viewTypeCount < 1");
            }
            // 根据ViewType类型的个数来创建数组
            ArrayList<View>[] scrapViews = new ArrayList[viewTypeCount];
            for (int i = 0; i < viewTypeCount; i++) {
                scrapViews[i] = new ArrayList<View>();
            }
			// 保存ViewType数量个数
            mViewTypeCount = viewTypeCount;
			// mCurrentScrap指向第一个数组
            mCurrentScrap = scrapViews[0];
            mScrapViews = scrapViews;
        }
setViewTypeCount()方法的主要作用就是为每种类型的数据项都单独启用一个RecycleBin缓存机制。该方法对应于Adapter中的getViewTypeCount()方法。


### 4.ListView的工作机制

ListView继承自ViewGroup，因此也具有View的三个流程，onMeasure()、onLayout()、onDraw()。其主要执行的是onLayout()方法。

1.AbsListView.onLayout()

	@Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);

        mInLayout = true;
		// 获取child的数量
        final int childCount = getChildCount();
        if (changed) {
            for (int i = 0; i < childCount; i++) {
                getChildAt(i).forceLayout();
            }
            mRecycler.markChildrenDirty();
        }
		//给子View布局
        layoutChildren();

        mOverscrollMax = (b - t) / OVERSCROLL_LIMIT_DIVISOR;
        
        if (mFastScroll != null) {
            mFastScroll.onItemCountChanged(getChildCount(), mItemCount);
        }
        mInLayout = false;
    }

	protected void layoutChildren() {
    }

在onLayout方法中，主要是调用layoutChildren()方法，该方法是一个抽象的方法，由子类来实现。

2.ListView.layoutChildren()

	@Override
    protected void layoutChildren() {
		 .......
			
		 try {
            super.layoutChildren();

            invalidate();
			// Adapter为空，则直接返回
            if (mAdapter == null) {
                resetList();
                invokeOnItemScrollListener();
                return;
            }
			// ListView的子View的顶部距离
			final int childrenTop = mListPadding.top;
			// ListView的子View的底部距离
            final int childrenBottom = mBottom - mTop - mListPadding.bottom;
			// 子View的数量，第一次返回为0
            final int childCount = getChildCount();

			int index = 0;
            int delta = 0;

			View sel;
            View oldSel = null;
            View oldFirst = null;
            View newSel = null;
			
			// 根据Layout模式，来执行相应的代码
			switch (mLayoutMode) {
             ....
			 // 默认模式
			 default:
     			// 记录先前选择的选项
                index = mSelectedPosition - mFirstPosition;
                if (index >= 0 && index < childCount) {
                    oldSel = getChildAt(index);
                }

                // 记录先前第一个子View
                oldFirst = getChildAt(0);

                if (mNextSelectedPosition >= 0) {
                    delta = mNextSelectedPosition - mSelectedPosition;
                }

                newSel = getChildAt(index + delta);
			}
			// 如果数据发生变化，则处理数据变化
			boolean dataChanged = mDataChanged;
            if (dataChanged) {
                handleDataChanged();
            }
			......
			
			setSelectedPositionInt(mNextSelectedPosition);
			......
			
			final int firstPosition = mFirstPosition;
            final RecycleBin recycleBin = mRecycler;
			// 数据源是否发生了变化
            if (dataChanged) {
                for (int i = 0; i < childCount; i++) {
                    recycleBin.addScrapView(getChildAt(i), firstPosition+i);
                }
            } else {
				// 1.将子View进行缓存
                recycleBin.fillActiveViews(childCount, firstPosition);
            }
			// 将所有子View从父View中分离
			detachAllViewsFromParent();
			// 移除被忽略的废弃View
            recycleBin.removeSkippedScrap();
			// 根据布局模式，执行相应的代码
			switch (mLayoutMode) {
				....
				// 默认模式
				default:
					// 第一次时，childCount的数量为0
					if (childCount == 0) {
					// 是否从底部开始布局
                    if (!mStackFromBottom) {
                        final int position = lookForSelectablePosition(0, true);
                        setSelectedPositionInt(position);
						// 2.从顶部开始布局
                        sel = fillFromTop(childrenTop);
                    } else {
                        final int position = lookForSelectablePosition(mItemCount - 1, false);
                        setSelectedPositionInt(position);
						// 从底部开始布局
                        sel = fillUp(mItemCount - 1, childrenBottom);
                    }
                } else {
                    if (mSelectedPosition >= 0 && mSelectedPosition < mItemCount) {
                        sel = fillSpecific(mSelectedPosition,
                                oldSel == null ? childrenTop : oldSel.getTop());
                    } else if (mFirstPosition < mItemCount) {
                        sel = fillSpecific(mFirstPosition,
                                oldFirst == null ? childrenTop : oldFirst.getTop());
                    } else {
                        sel = fillSpecific(0, childrenTop);
                    }
                }
                break;
			}
			
			// 清空上面中没有使用到缓存View
			recycleBin.scrapActiveViews();
			....
	}

可以看到，在layoutChildren()方法中，首先获取Child View的数量，然后将Child View添加到ActiveView数组中。

3.ListView.fillFromTop()
	
	 // 从上到下填充ListView，从第一个位置开始
	 private View fillFromTop(int nextTop) {
		// 获取第一个位置
        mFirstPosition = Math.min(mFirstPosition, mSelectedPosition);
        mFirstPosition = Math.min(mFirstPosition, mItemCount - 1);
        if (mFirstPosition < 0) {
            mFirstPosition = 0;
        }
        return fillDown(mFirstPosition, nextTop);
    }

	private View fillDown(int pos, int nextTop) {
        View selectedView = null;
		// 底部与顶部的距离
        int end = (mBottom - mTop);
        if ((mGroupFlags & CLIP_TO_PADDING_MASK) == CLIP_TO_PADDING_MASK) {
            end -= mListPadding.bottom;
        }
		
		// 循环中顶部开始添加View
        while (nextTop < end && pos < mItemCount) {
            // 是否为选中的View
            boolean selected = pos == mSelectedPosition;
            View child = makeAndAddView(pos, nextTop, true, mListPadding.left, selected);
			
			// 下一个View的具体ListView顶部的距离
            nextTop = child.getBottom() + mDividerHeight;
            if (selected) {
                selectedView = child;
            }
			// 更新选择的数量
            pos++;
        }

        setVisibleRangeHint(mFirstPosition, mFirstPosition + getChildCount() - 1);
        return selectedView;
    }

fillDown()方法的主要作用是从ListView的顶部开始，添加View，循环结束的条件是nextTop < end && pos < mItemCount，即nextTop < end确保了我们只要将新增的子View能够覆盖ListView的界面就可以了，比如ListView的高度最多显示10个子View，我们没必要向ListView中加入11个子View。pos < mItemCount确保了我们新增的子View在Adapter中都有对应的数据源item，比如ListView的高度最多显示10个子View，但是我们Adapter中一共才有5条数据，这种情况下只能向ListView中加入5个子View，从而不能填充满ListView的全部高度。

4.ListView.makeAndAddView()
	
	// 创建View，并把View添加到数组中
	private View makeAndAddView(int position, int y, boolean flow, int childrenLeft,
            boolean selected) {
		
        if (!mDataChanged) {
            // 1.首先从该位置中获取一个已经存在的ActiveView
            final View activeView = mRecycler.getActiveView(position);
			
            if (activeView != null) {
                // 2.复用已经存在的View
                setupChild(activeView, position, y, flow, childrenLeft, selected, true);
                return activeView;
            }
        }

        // 3.如果在Position位置不存在View，则从ScrapView数组中查找缓存的View
        final View child = obtainView(position, mIsScrap);

        setupChild(child, position, y, flow, childrenLeft, selected, mIsScrap[0]);

        return child;
    }

makeAndAddView()方法的主要作用是首先从mActiveView数组中查询对应的position中是否有对应的View，如果有的话，则直接复用该View。如果在mActiveView数组中找不到对应的View，则从mScrapView数组中，如果找到，则复用该View。否则的话，则直接创建出一个新的子View。

5.AbsListView.obtainView()


	// 获取一个View，并显示指定位置对应的数据
	View obtainView(int position, boolean[] outMetadata) {
        Trace.traceBegin(Trace.TRACE_TAG_VIEW, "obtainView");

        outMetadata[0] = false;
		
		// 1.从mScrapView数组中获取position位置的View
        final View scrapView = mRecycler.getScrapView(position);
		// 2.从Adapter中获取子View
        final View child = mAdapter.getView(position, scrapView, this);
        
        if (scrapView != null) {
            if (child != scrapView) {
				// 如果返回的View不是ScrapView，则将该ScrapView返回到数组中
                mRecycler.addScrapView(scrapView, position);
            } else if (child.isTemporarilyDetached()) {
                outMetadata[0] = true;
                child.dispatchFinishTemporaryDetach();
            }
        }
		
		....
		// 设置child View的参数
        setItemViewLayoutParams(child, position);
        Trace.traceEnd(Trace.TRACE_TAG_VIEW);
        return child;
    }

obtainView()方法的主要作用是获取一个View，并将相关position对应的数据显示出来。该方法主要是在我们发现RecycleBin中没有可用的View复用时调用该方法。剩下的选择就是将一个旧的View进行转换或者创建一个新的View。

6.Adapter.getView()

	View getView(int position, View convertView, ViewGroup parent);

Adapter.getView()方法是一个接口方法，有具体的Adapter子类实现。我们一般会这样定义getView()方法.

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
    	if(convertView == null){
        	convertView = View.inflate(context, R.layout.list_item_layout, null);
    	}
    	return convertView;
	}

这样当convertView不为空的时候，即ScrapView不为空时，我们可以复用ScrapView。如果convertView为空时，则需要自己从XML文件中进行加载View，这通常只存在于第一次加载ListView时。


7.ListView.setupChild()

	// 添加一个View，并让该View能够正确的测量以及布局
	private void setupChild(View child, int position, int y, boolean flowDown, int childrenLeft,
            boolean selected, boolean isAttachedToWindow) {
		.....
		AbsListView.LayoutParams p = (AbsListView.LayoutParams) child.getLayoutParams();
        if (p == null) {
            p = (AbsListView.LayoutParams) generateDefaultLayoutParams();
        }
        p.viewType = mAdapter.getItemViewType(position);
        p.isEnabled = mAdapter.isEnabled(position);
		......
		if ((isAttachedToWindow && !p.forceAdd) || (p.recycledHeaderFooter
                && p.viewType == AdapterView.ITEM_VIEW_TYPE_HEADER_OR_FOOTER)) {
			// 1.将该view依附到Parent View中
            attachViewToParent(child, flowDown ? -1 : 0, p);

            if (isAttachedToWindow
                    && (((AbsListView.LayoutParams) child.getLayoutParams()).scrappedFromPosition)
                            != position) {
                child.jumpDrawablesToCurrentState();
            }
        } else {
            p.forceAdd = false;
            if (p.viewType == AdapterView.ITEM_VIEW_TYPE_HEADER_OR_FOOTER) {
                p.recycledHeaderFooter = true;
            }
			// 2.将View添加到ViewGroup中
            addViewInLayout(child, flowDown ? -1 : 0, p, true);
            child.resolveRtlPropertiesIfNeeded();
        }
		
		// 执行测量工作
		if (needToMeasure) {
            final int childWidthSpec = ViewGroup.getChildMeasureSpec(mWidthMeasureSpec,
                    mListPadding.left + mListPadding.right, p.width);
            final int lpHeight = p.height;
            final int childHeightSpec;
            if (lpHeight > 0) {
                childHeightSpec = MeasureSpec.makeMeasureSpec(lpHeight, MeasureSpec.EXACTLY);
            } else {
                childHeightSpec = MeasureSpec.makeSafeMeasureSpec(getMeasuredHeight(),
                        MeasureSpec.UNSPECIFIED);
            }
            child.measure(childWidthSpec, childHeightSpec);
        } else {
            cleanupLayoutState(child);
        }

		// 执行布局工作
		if (needToMeasure) {
            final int childRight = childrenLeft + w;
            final int childBottom = childTop + h;
            child.layout(childrenLeft, childTop, childRight, childBottom);
        } else {
            child.offsetLeftAndRight(childrenLeft - child.getLeft());
            child.offsetTopAndBottom(childTop - child.getTop());
        }

        if (mCachingStarted && !child.isDrawingCacheEnabled()) {
            child.setDrawingCacheEnabled(true);
        }

	}

8.ListView.fillSpecific()

	// 在指定的位置上添加一个特定的item，然后加载该View往上和往下的其他子View
	private View fillSpecific(int position, int top) {
        boolean tempIsSelected = position == mSelectedPosition;
        
        View temp = makeAndAddView(position, top, true, mListPadding.left, tempIsSelected);
        mFirstPosition = position;

        View above;
        View below;

        final int dividerHeight = mDividerHeight;
		// 从顶部开始
        if (!mStackFromBottom) {
			// 从该View位置以上的位置开始添加
            above = fillUp(position - 1, temp.getTop() - dividerHeight);
           
            adjustViewsUpOrDown();

			// 从该View位置以下的位置开始添加
            below = fillDown(position + 1, temp.getBottom() + dividerHeight);
            int childCount = getChildCount();
            if (childCount > 0) {
                correctTooHigh(childCount);
            }
        } else {
            below = fillDown(position + 1, temp.getBottom() + dividerHeight);
            adjustViewsUpOrDown();
            above = fillUp(position - 1, temp.getTop() - dividerHeight);
            int childCount = getChildCount();
            if (childCount > 0) {
                 correctTooLow(childCount);
            }
        }

        if (tempIsSelected) {
            return temp;
        } else if (above != null) {
            return above;
        } else {
            return below;
        }
    }
fillSpecific方法与fillUp和fillDown差不多，只是优先将指定位置的子View加载到屏幕上，然后再加载该子View往上以及往下的其他子View。

### 5.滑动加载更多的数据

滑动部分在AbsListView的onTouchEvent()这个方法中，我们知道该方法主要是用来处理触摸事件的。

1.AbsListView.onTouchEvent()

	@Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (!isEnabled()) {
            return isClickable() || isLongClickable();
        }

        if (mPositionScroller != null) {
            mPositionScroller.stop();
        }
		
		// 如果已经分离了，则直接返回
        if (mIsDetaching || !isAttachedToWindow()) {
            return false;
        }

        startNestedScroll(SCROLL_AXIS_VERTICAL);

        if (mFastScroll != null && mFastScroll.onTouchEvent(ev)) {
            return true;
        }

        initVelocityTrackerIfNotExists();
        final MotionEvent vtev = MotionEvent.obtain(ev);

        final int actionMasked = ev.getActionMasked();
        if (actionMasked == MotionEvent.ACTION_DOWN) {
            mNestedYOffset = 0;
        }
        vtev.offsetLocation(0, mNestedYOffset);
        switch (actionMasked) {
            case MotionEvent.ACTION_DOWN: {
                onTouchDown(ev);
                break;
            }

            // 处理MOVE事件
            case MotionEvent.ACTION_MOVE: {
                onTouchMove(ev, vtev);
                break;
            }

            case MotionEvent.ACTION_UP: {
                onTouchUp(ev);
                break;
            }

            case MotionEvent.ACTION_CANCEL: {
                onTouchCancel();
                break;
            }
		}
            ....
        return true;
    }

2.AbsListView.onTouchMove()

	private void onTouchMove(MotionEvent ev, MotionEvent vtev) {
        if (mHasPerformedLongPress) {
            return;
        }

        int pointerIndex = ev.findPointerIndex(mActivePointerId);
        if (pointerIndex == -1) {
            pointerIndex = 0;
            mActivePointerId = ev.getPointerId(pointerIndex);
        }

		// 如果数据发生了变化，则重新同步
        if (mDataChanged) {
            layoutChildren();
        }

		// 获取触摸点的y轴位置
        final int y = (int) ev.getY(pointerIndex);

        switch (mTouchMode) {
            .....// 拖动模式
            case TOUCH_MODE_SCROLL:
            case TOUCH_MODE_OVERSCROLL:
                scrollIfNeeded((int) ev.getX(pointerIndex), y, vtev);
                break;
        }
    }
当手指滑动时，TouchMode是等于TOUCH_MODE_SCROLL这个值的。

3.AbsListView.scrollIfNeeded()

	private void scrollIfNeeded(int x, int y, MotionEvent vtev) {
		......
		final int deltaY = rawDeltaY;
        int incrementalDeltaY =
                mLastY != Integer.MIN_VALUE ? y - mLastY + scrollConsumedCorrection : deltaY;
		if (mTouchMode == TOUCH_MODE_SCROLL) {
			.....
			boolean atEdge = false;
                if (incrementalDeltaY != 0) {
                    atEdge = trackMotionScroll(deltaY, incrementalDeltaY);
                }
			.....

		} else if (mTouchMode == TOUCH_MODE_OVERSCROLL) {
			......
			trackMotionScroll(incrementalDeltaY, incrementalDeltaY);
			......
		}
	}


4.AbsListView.trackMotionScroll()

	boolean trackMotionScroll(int deltaY, int incrementalDeltaY) {
		final int childCount = getChildCount();
		final boolean down = incrementalDeltaY < 0;
		if (down) {
            int top = -incrementalDeltaY;
            if ((mGroupFlags & CLIP_TO_PADDING_MASK) == CLIP_TO_PADDING_MASK) {
                top += listPadding.top;
            }
            for (int i = 0; i < childCount; i++) {
                final View child = getChildAt(i);
                if (child.getBottom() >= top) {
                    break;
                } else {
                    count++;
                    int position = firstPosition + i;
                    if (position >= headerViewsCount && position < footerViewsStart) {
                        child.clearAccessibilityFocus();
						// 将View添加到ScrapView数组中
                        mRecycler.addScrapView(child, position);
                    }
                }
            }
        } else {
            int bottom = getHeight() - incrementalDeltaY;
            if ((mGroupFlags & CLIP_TO_PADDING_MASK) == CLIP_TO_PADDING_MASK) {
                bottom -= listPadding.bottom;
            }
            for (int i = childCount - 1; i >= 0; i--) {
                final View child = getChildAt(i);
                if (child.getTop() <= bottom) {
                    break;
                } else {
                    start = i;
                    count++;
                    int position = firstPosition + i;
                    if (position >= headerViewsCount && position < footerViewsStart) {
                        child.clearAccessibilityFocus();
						// 将View添加到ScrapView数组中
                        mRecycler.addScrapView(child, position);
                    }
                }
            }
        }

		if (count > 0) {
			// 从添加到ScrapView数组中的View从parent View中分离出来
            detachViewsFromParent(start, count);
			// 移除被忽略的View
            mRecycler.removeSkippedScrap();
        }

		......
		// 让ListView中的所有View偏移incrementalDeltaY距离
		offsetChildrenTopAndBottom(incrementalDeltaY);

		final int absIncrementalDeltaY = Math.abs(incrementalDeltaY);
        if (spaceAbove < absIncrementalDeltaY || spaceBelow < absIncrementalDeltaY) {
            fillGap(down);
        }
		
	}

5.ListView.fillGap()

	@Override
    void fillGap(boolean down) {
        final int count = getChildCount();
		// 往下滑动
        if (down) {
            int paddingTop = 0;
            if ((mGroupFlags & CLIP_TO_PADDING_MASK) == CLIP_TO_PADDING_MASK) {
                paddingTop = getListPaddingTop();
            }
			// 获取偏移量
            final int startOffset = count > 0 ? getChildAt(count - 1).getBottom() + mDividerHeight :
                    paddingTop;
			// 从上往下开始填充
            fillDown(mFirstPosition + count, startOffset);
            correctTooHigh(getChildCount());
        } else {
            int paddingBottom = 0;
            if ((mGroupFlags & CLIP_TO_PADDING_MASK) == CLIP_TO_PADDING_MASK) {
                paddingBottom = getListPaddingBottom();
            }
            final int startOffset = count > 0 ? getChildAt(0).getTop() - mDividerHeight :
                    getHeight() - paddingBottom;
            fillUp(mFirstPosition - 1, startOffset);
            correctTooLow(getChildCount());
        }
    }

该方法的主要作用是填充由拖动滑动留下来的空隙。在滑动的过程中，在屏幕上显示的View移动相应的位置，没有显示的则被丢弃。


### 总结

AdapterView的工作大致有以下几个过程：

1.在ListView的第一次Layout过程中，在屏幕上显示的所有子View都是通过调用LayoutInflater的inflate()方法加载出来的。

2.将通过inflate出来的子View添加到ViewGroup集合中。

3.在ListView的第二次Layout过程中，会将在屏幕上显示的所有子View缓存到RecycleBin中的mActiveView数组中。

4.将第一次Layout过程中产生的所有子View全部分离detach，避免第二次Layout时产生重复的子View。

5.从mActiveView数组中获取缓存的View，将其重新attach到ViewGroup中。

6.经历了一次detach后，有attach的过程，ListView中的所有子View都可以正常显示处理了；

7.当ListView进行滑动时，当子View划出了屏幕时，会将该子View添加到RecycleBin的mScrapView数组中；

8.将所有移出屏幕的子View全都从ViewGroup中detach分离。

9.由于mActiveView数组里面的View只能被复用一次，之前已经被复用过一次了，所以需要从mScrapView数组中获取缓存的View。

10.将从缓存中获取到的View重新attach到ViewGroup中，进行显示。


### 参考文章
[Android ListView工作原理完全解析，带你从源码的角度彻底理解](http://blog.csdn.net/guolin_blog/article/details/44996879)

[Android学习笔记之ListView复用机制](http://www.cnblogs.com/RGogoing/p/5554086.html)



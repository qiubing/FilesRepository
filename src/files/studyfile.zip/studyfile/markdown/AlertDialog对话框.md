## AlertDialog对话框
### 简介

AlertDialog是Dialog的子类，可以用来显示一个、两个或者三个按钮，如果你想在Dialog中显示一个字符串，则可以通过setMessage()方法.如果你想显示一个更加复杂的View，可以先找出custom的FrameLayout，然后将你的View添加进custom的FrameLayout中。

例如：

	FrameLayout fl = (FrameLayout) findViewById(android.R.id.custom);
 	fl.addView(myView, new LayoutParams(MATCH_PARENT, WRAP_CONTENT));


### AlertDialog对话框的基本用法
1.创建基本AlertDialog

	AlertDialog.Builder builder = new AlertDialog.Builder(context);
	....
	builder.create();
	builder.show();
使用示例：

	AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setIcon(R.mipmap.ic_launcher);//设置图标
        builder.setTitle("基础Dialog");//设置标题
        builder.setMessage("hello base dialog");//设置弹窗的内容
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(context, "确定按钮被点击了", Toast.LENGTH_LONG).show();
            }
        });//添加确定按钮

        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(context, "取消按钮被点击了", Toast.LENGTH_LONG).show();
            }
        });//添加取消按钮

        builder.setNeutralButton("中间", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(context, "中间按钮被点击了", Toast.LENGTH_LONG).show();
            }
        });//添加中间按钮

        // 静态构建自定义布局
        //View customView = LayoutInflater.from(context).inflate(R.layout.custom_dialog_view,null);
        // 动态构建自定义布局
        View customView = createCustomView(context);
        builder.setView(customView);//设置自定义View
        builder.show();
2.创建列表Dialog

	builder.setItems(CharSequence[] items, DialogInterface.OnClickListener listener)  
	builder.setItems(int itemsId, DialogInterface.OnClickListener listener)
	
使用示例：

	 AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setTitle("列表Dialog");
        // 设置列表选项
        /*String[] items = {"item0","item1","item2","item3","item4","item5","item6"};
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(context,"clicked: " + i,Toast.LENGTH_LONG).show();
            }
        });*/
        builder.setItems(R.array.dialog_items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(context,"clicked: " + i,Toast.LENGTH_LONG).show();
            }
        });
        builder.show(); 

### 自定义AlertDialog

使用示例：

	public class CustomDialog extends Dialog {

    private Context mContext;
    public CustomDialog(Context context) {
        super(context);
        mContext = context;
    }

    public CustomDialog(Context context,int theme){
        super(context,theme);
        mContext = context;
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View customDialogView = LayoutInflater.from(mContext).inflate(R.layout.custom_dialog,null);
        this.setContentView(customDialogView);
    }
	}

### AlertDialog源码分析

1.构造函数

	AlertDialog(Context context, @StyleRes int themeResId, boolean createContextThemeWrapper) {
        super(context, createContextThemeWrapper ? resolveDialogTheme(context, themeResId) : 0,
                createContextThemeWrapper);

        mWindow.alwaysReadCloseOnTouchAttr();
        mAlert = AlertController.create(getContext(), this, getWindow());
    }
调用Dialog的构造函数：

	Dialog(@NonNull Context context, @StyleRes int themeResId, boolean createContextThemeWrapper) {
        if (createContextThemeWrapper) {
            if (themeResId == 0) {
                final TypedValue outValue = new TypedValue();
                context.getTheme().resolveAttribute(R.attr.dialogTheme, outValue, true);
                themeResId = outValue.resourceId;
            }
            mContext = new ContextThemeWrapper(context, themeResId);
        } else {
            mContext = context;
        }

		// 创建WindowManager
        mWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		
		// Window的实现为PhoneWindow
        final Window w = new PhoneWindow(mContext);
        mWindow = w;
		// 设置CallBack回调
        w.setCallback(this);
		// 设置Dismiss回调
        w.setOnWindowDismissedCallback(this);
        w.setOnWindowSwipeDismissedCallback(() -> {
            if (mCancelable) {
                cancel();
            }
        });
        w.setWindowManager(mWindowManager, null, null);
        // 设置窗口的gravity为中间，所以Dialog显示在中间位置
		w.setGravity(Gravity.CENTER);

        mListenersHandler = new ListenersHandler(this);
    }

CallBack接口定义如下：

	/**
     * API from a Window back to its caller.  This allows the client to
     * intercept key dispatching, panels and menus, etc.
     */
    public interface Callback {
		// 处理key事件
		public boolean dispatchKeyEvent(KeyEvent event);
		// 处理Touch事件
		public boolean dispatchTouchEvent(MotionEvent event);
        // 内容发生变化时调用
		public void onContentChanged();
		// 窗口焦点发生变化时调用
		public void onWindowFocusChanged(boolean hasFocus);
		// 窗口被添加到WindowManager时调用
		public void onAttachedToWindow();
        // 窗口从WindowManager中分离时被调用
		public void onDetachedFromWindow();
		
	}
	// 当一个View被依附到一个Window时调用该方法。此时它有一个surface并且将开始drawing。该函数必须保证在onDraw方法之前调用。
	protected void onAttachedToWindow() {}

ListenersHandler的定义如下：

	private static final class ListenersHandler extends Handler {
        private final WeakReference<DialogInterface> mDialog;

        public ListenersHandler(Dialog dialog) {
            mDialog = new WeakReference<>(dialog);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
				// 消失
                case DISMISS:
                    ((OnDismissListener) msg.obj).onDismiss(mDialog.get());
                    break;
				// 取消
                case CANCEL:
                    ((OnCancelListener) msg.obj).onCancel(mDialog.get());
                    break;
				// 显示
                case SHOW:
                    ((OnShowListener) msg.obj).onShow(mDialog.get());
                    break;
            }
        }
    }

2.AlertDialog的显示

Dialog的显示是通过show方法来显示的。

	public void show() {
		// 如果已经在显示了，则直接返回
        if (mShowing) {
            if (mDecor != null) {
                if (mWindow.hasFeature(Window.FEATURE_ACTION_BAR)) {
                    mWindow.invalidatePanelMenu(Window.FEATURE_ACTION_BAR);
                }
                mDecor.setVisibility(View.VISIBLE);
            }
            return;
        }

        mCanceled = false;
        // 如果还没有被创建，则先创建该Dialog
        if (!mCreated) {
            dispatchOnCreate(null);
        } else {
			// 填充装饰ViewDecorView
            final Configuration config = mContext.getResources().getConfiguration();
            mWindow.getDecorView().dispatchConfigurationChanged(config);
        }
		// 调用onStart()方法
        onStart();
		// 获取装饰的View
        mDecor = mWindow.getDecorView();

        if (mActionBar == null && mWindow.hasFeature(Window.FEATURE_ACTION_BAR)) {
            final ApplicationInfo info = mContext.getApplicationInfo();
            mWindow.setDefaultIcon(info.icon);
            mWindow.setDefaultLogo(info.logo);
            mActionBar = new WindowDecorActionBar(this);
        }
		// 获取窗口的参数
        WindowManager.LayoutParams l = mWindow.getAttributes();
        if ((l.softInputMode
                & WindowManager.LayoutParams.SOFT_INPUT_IS_FORWARD_NAVIGATION) == 0) {
            WindowManager.LayoutParams nl = new WindowManager.LayoutParams();
            nl.copyFrom(l);
            nl.softInputMode |=
                    WindowManager.LayoutParams.SOFT_INPUT_IS_FORWARD_NAVIGATION;
            l = nl;
        }
		// 将DecorView添加到窗口管理器中
        mWindowManager.addView(mDecor, l);
        mShowing = true;
		// 发送显示msg
        sendShowMessage();
    }
该方法启动一个Dialog，并把它显示到屏幕上。该Window被放置在应用层并且不透明。该方法不能被覆盖，而应该实现onStart方法。

	private void sendShowMessage() {
        if (mShowMessage != null) {
            // Obtain a new message so this dialog can be re-used
            Message.obtain(mShowMessage).sendToTarget();
        }
    }

	public void setOnShowListener(@Nullable OnShowListener listener) {
        if (listener != null) {
            mShowMessage = mListenersHandler.obtainMessage(SHOW, listener);
        } else {
            mShowMessage = null;
        }
    }
在前面介绍了ListenerHandler的定义，可以看到最终会调用到onShow(DialogInterface dialog);







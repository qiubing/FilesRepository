## Java Crash
[TOC]

### 1.概述

App Crash(全称Application Crash)，对于Crash可分为Native Crash和framework Crash（包含app Crash ）。

上层什么时候产生Crash？

系统如何处理Crash呢？

在app中可以通过try...catch语句，来捕获异常。如果没有被catch的exception，就会导致应用crash，系统便会来进行捕获。

在Zygote进程孵化SystemServer进程和应用进程时，会设置未捕获异常的处理器，当系统抛出未捕获的异常时，最终都交给异常处理。异常处理器在RuntimeInit.java的commonInit方法中设置UncaughtHandler，用于处理未捕获异常。

### 2.源码分析
当出现未捕获的异常时，会交由系统设置的未捕获异常处理器来处理。捕获异常的处理器在RuntimeInit.java的commonInit方法中设置。

1.RuntimeInit.commonInit()方法

	protected static final void commonInit() {

        /*
         * set handlers; these apply to all threads in the VM. Apps can replace
         * the default handler, but not the pre handler.
         */
        Thread.setUncaughtExceptionPreHandler(new LoggingHandler());
		//设置默认的未捕获异常处理器
        Thread.setDefaultUncaughtExceptionHandler(new KillApplicationHandler());

        ........
    }

LoggingHandler的定义如下：
	
	 /**
     * Logs a message when a thread encounters an uncaught exception. By
     * default, {@link KillApplicationHandler} will terminate this process later,
     * but apps can override that behavior.
     */
	// 打印Crash的一些信息，主要包含有FATAL EXCEPTION以及进程信息
    private static class LoggingHandler implements Thread.UncaughtExceptionHandler {
        @Override
        public void uncaughtException(Thread t, Throwable e) {
            // Don't re-enter if KillApplicationHandler has already run
            if (mCrashing) return;
            if (mApplicationObject == null) {
                // The "FATAL EXCEPTION" string is still used on Android even though
                // apps can set a custom UncaughtExceptionHandler that renders uncaught
                // exceptions non-fatal.
                Clog_e(TAG, "*** FATAL EXCEPTION IN SYSTEM PROCESS: " + t.getName(), e);
            } else {
				// 打印异常信息
                StringBuilder message = new StringBuilder();
                // The "FATAL EXCEPTION" string is still used on Android even though
                // apps can set a custom UncaughtExceptionHandler that renders uncaught
                // exceptions non-fatal.
                message.append("FATAL EXCEPTION: ").append(t.getName()).append("\n");
                final String processName = ActivityThread.currentProcessName();
                if (processName != null) {
                    message.append("Process: ").append(processName).append(", ");
                }
                message.append("PID: ").append(Process.myPid());
                Clog_e(TAG, message.toString(), e);
            }
        }
    }

KillApplicationHandler定义如下：

	/**
     * Handle application death from an uncaught exception.  The framework
     * catches these for the main threads, so this should only matter for
     * threads created by applications.  Before this method runs,
     * {@link LoggingHandler} will already have logged details.
     */
    private static class KillApplicationHandler implements Thread.UncaughtExceptionHandler {
        public void uncaughtException(Thread t, Throwable e) {
            try {
                // Don't re-enter -- avoid infinite loops if crash-reporting crashes.
				// 避免重入执行
                if (mCrashing) return;
                mCrashing = true;

				// 尝试停止分析器
                if (ActivityThread.currentActivityThread() != null) {
					//停止分析器
                    ActivityThread.currentActivityThread().stopProfiling();
                }

                // Bring up crash dialog, wait for it to be dismissed
				// 显示Crash Dialog
                ActivityManagerNative.getDefault().handleApplicationCrash(
                        mApplicationObject, new ApplicationErrorReport.CrashInfo(e));
            } catch (Throwable t2) {
               ....
            } finally {
                // Try everything to make sure this process goes away.
				// 杀死该进程，退出该进程
                Process.killProcess(Process.myPid());
                System.exit(10);
            }
        }
    }

2.ActivityManagerService.handleApplicationCrash()

	 /**
     * Used by {@link com.android.internal.os.RuntimeInit} to report when an application crashes.
     * The application process will exit immediately after this call returns.
     * @param app object of the crashing app, null for the system server
     * @param crashInfo describing the exception
     */
    public void handleApplicationCrash(IBinder app, ApplicationErrorReport.CrashInfo crashInfo) {
		// 寻找app对应的ProcessRecord记录
        ProcessRecord r = findAppProcess(app, "Crash");
        final String processName = app == null ? "system_server"
                : (r == null ? "unknown" : r.processName);

        handleApplicationCrashInner("crash", r, processName, crashInfo);
    }

	/* Native crash reporting uses this inner version because it needs to be somewhat
     * decoupled from the AM-managed cleanup lifecycle
     */
    void handleApplicationCrashInner(String eventType, ProcessRecord r, String processName,
            ApplicationErrorReport.CrashInfo crashInfo) {
		// 将crash信息写入Event日志中，可以在event日志中，搜索am_crash关键字
        EventLog.writeEvent(EventLogTags.AM_CRASH, Binder.getCallingPid(),
                UserHandle.getUserId(Binder.getCallingUid()), processName,
                r == null ? -1 : r.info.flags,
                crashInfo.exceptionClassName,
                crashInfo.exceptionMessage,
                crashInfo.throwFileName,
                crashInfo.throwLineNumber);

		// 将Crash信息写入到DropBox中
        addErrorToDropBox(eventType, r, processName, null, null, null, null, null, crashInfo);
		//显示Crash Dialog信息
        mAppErrors.crashApplication(r, crashInfo);
    }

在ActivityManagerService的handleApplicationCrash方法中，主要是处理了以下几件事：
- 找到Crash进程的ProcessRecord信息；
- 将Crash日志写入到Event日志中；
- 将Crash信息写入到DropBox中，crash信息的输出到目录/data/system/dropbox
- 调用AppErrors显示Crash Dialog信息；

3.ActivityManagerService.addErrorToDropBox方法

	/**
     * Write a description of an error (crash, WTF, ANR) to the drop box.
     * @param eventType to include in the drop box tag ("crash", "wtf", etc.)
     * @param process which caused the error, null means the system server
     * @param activity which triggered the error, null if unknown
     * @param parent activity related to the error, null if unknown
     * @param subject line related to the error, null if absent
     * @param report in long form describing the error, null if absent
     * @param dataFile text file to include in the report, null if none
     * @param crashInfo giving an application stack trace, null if absent
     */
    public void addErrorToDropBox(String eventType,
            ProcessRecord process, String processName, ActivityRecord activity,
            ActivityRecord parent, String subject,
            final String report, final File dataFile,
            final ApplicationErrorReport.CrashInfo crashInfo) {
        //获取dropbox标签，可取的值为system_server/system_app/data_app
        final String dropboxTag = processClass(process) + "_" + eventType;
		//获取DropBoxManager
        final DropBoxManager dbox = (DropBoxManager)
                mContext.getSystemService(Context.DROPBOX_SERVICE);

        // Exit early if the dropbox isn't configured to accept this report type.
        if (dbox == null || !dbox.isTagEnabled(dropboxTag)) return;

		// 限制收集log的频率，当前是10s内收集5个log
        final long now = SystemClock.elapsedRealtime();
        if (now - mWtfClusterStart > 10 * DateUtils.SECOND_IN_MILLIS) {
            mWtfClusterStart = now;
            mWtfClusterCount = 1;
        } else {
            if (mWtfClusterCount++ >= 5) return;
        }

        final StringBuilder sb = new StringBuilder(1024);
		// 添加进程信息到DropBox的头部
        appendDropBoxProcessHeaders(process, processName, sb);
		// 后续利用StringBuilder记录信息
        if (process != null) {
            sb.append("Foreground: ")
                    .append(process.isInterestingToUserLocked() ? "Yes" : "No")
                    .append("\n");
        }
        if (activity != null) {
            sb.append("Activity: ").append(activity.shortComponentName).append("\n");
        }
        if (parent != null && parent.app != null && parent.app.pid != process.pid) {
            sb.append("Parent-Process: ").append(parent.app.processName).append("\n");
        }
        if (parent != null && parent != activity) {
            sb.append("Parent-Activity: ").append(parent.shortComponentName).append("\n");
        }
        if (subject != null) {
            sb.append("Subject: ").append(subject).append("\n");
        }
        sb.append("Build: ").append(Build.FINGERPRINT).append("\n");
        if (Debug.isDebuggerConnected()) {
            sb.append("Debugger: Connected\n");
        }
        sb.append("\n");

        // Do the rest in a worker thread to avoid blocking the caller on I/O
        // (After this point, we shouldn't access AMS internal data structures.)
		// 创建一个工作线程
        Thread worker = new Thread("Error dump: " + dropboxTag) {
            @Override
            public void run() {
                if (report != null) {
                    sb.append(report);
                }

                String setting = Settings.Global.ERROR_LOGCAT_PREFIX + dropboxTag;
                int lines = Settings.Global.getInt(mContext.getContentResolver(), setting, 0);
                int maxDataFileSize = DROPBOX_MAX_SIZE - sb.length()
                        - lines * RESERVED_BYTES_PER_LOGCAT_LINE;

                if (dataFile != null && maxDataFileSize > 0) {
                    try {
                        sb.append(FileUtils.readTextFile(dataFile, maxDataFileSize,
                                    "\n\n[[TRUNCATED]]"));
                    } catch (IOException e) {
                        Slog.e(TAG, "Error reading " + dataFile, e);
                    }
                }
				// 将Crash添加到StringBuilder中
                if (crashInfo != null && crashInfo.stackTrace != null) {
                    sb.append(crashInfo.stackTrace);
                }

                if (lines > 0) {
                    sb.append("\n");

                    // Merge several logcat streams, and take the last N lines
                    InputStreamReader input = null;
                    try {
                        java.lang.Process logcat = new ProcessBuilder(
                                "/system/bin/timeout", "-k", "15s", "10s",
                                "/system/bin/logcat", "-v", "threadtime", "-b", "events", "-b", "system",
                                "-b", "main", "-b", "crash", "-t", String.valueOf(lines))
                                        .redirectErrorStream(true).start();

                        try { logcat.getOutputStream().close(); } catch (IOException e) {}
                        try { logcat.getErrorStream().close(); } catch (IOException e) {}
                        input = new InputStreamReader(logcat.getInputStream());

                        int num;
                        char[] buf = new char[8192];
                        while ((num = input.read(buf)) > 0) sb.append(buf, 0, num);
                    } catch (IOException e) {
                        Slog.e(TAG, "Error running logcat", e);
                    } finally {
                        if (input != null) try { input.close(); } catch (IOException e) {}
                    }
                }
				
				// 调用DropBoxManager的addText方法，将StringBuilder信息添加到DropBoxManager中
                dbox.addText(dropboxTag, sb.toString());
            }
        };

        if (process == null) {
            // If process is null, we are being called from some internal code
            // and may be about to die -- run this synchronously.
            worker.run();
        } else {
            worker.start();//启动线程
        }
    }
可以看到，在addErrorToDropBox方法中，主要是通过StringBuilder收集Crash的信息，然后通过一个工作线程，调用DropBoxManager的addText方法记录到DropBox中。

4.DropBoxManager.addText方法

	/**
     * Stores human-readable text.  The data may be discarded eventually (or even
     * immediately) if space is limited, or ignored entirely if the tag has been
     * blocked (see {@link #isTagEnabled}).
     *
     * @param tag describing the type of entry being stored
     * @param data value to store
     */
    public void addText(String tag, String data) {
        try {
            mService.add(new Entry(tag, 0, data));
        } catch (RemoteException e) {
            if (e instanceof TransactionTooLargeException
                    && mContext.getApplicationInfo().targetSdkVersion < Build.VERSION_CODES.N) {
                Log.e(TAG, "App sent too much data, so it was ignored", e);
                return;
            }
            throw e.rethrowFromSystemServer();
        }
    }

	/** Create a new Entry with plain text contents. */
    public Entry(String tag, long millis, String text) {
            if (tag == null) throw new NullPointerException("tag == null");
            if (text == null) throw new NullPointerException("text == null");

            mTag = tag;
            mTimeMillis = millis;
            mData = text.getBytes();
            mFileDescriptor = null;
            mFlags = IS_TEXT;
    }

	private final IDropBoxManagerService mService;

可以看到DropBoxManager最终调用的是IDropBoxManagerService的接口，来记录信息。

5.DropBoxManagerService.add()方法

	/**
 	* Implementation of {@link IDropBoxManagerService} using the filesystem.
 	* Clients use {@link DropBoxManager} to access this service.
 	*/
	public final class DropBoxManagerService extends SystemService {
		
		public void add(DropBoxManager.Entry entry) {
        File temp = null;
        InputStream input = null;
        OutputStream output = null;
		// 获取DropBox的标签
        final String tag = entry.getTag();
        try {
			//获取内容标志，是否是TEXT还是GZIP
            int flags = entry.getFlags();
            if ((flags & DropBoxManager.IS_EMPTY) != 0) throw new IllegalArgumentException();
            
			//初始化操作，删除一些无效的文件 
            init();
			// 如果DropBox的标签是禁用的，则直接返回
            if (!isTagEnabled(tag)) return;
            long max = trimToFit();
            long lastTrim = System.currentTimeMillis();

            byte[] buffer = new byte[mBlockSize];
			// 返回保存信息的字节流
            input = entry.getInputStream();

            // First, accumulate up to one block worth of data in memory before
            // deciding whether to compress the data or not.
			
			// 先计算字节大小，决定是否需要压缩
            int read = 0;
            while (read < buffer.length) {
                int n = input.read(buffer, read, buffer.length - read);
                if (n <= 0) break;
                read += n;
            }

            // If we have at least one block, compress it -- otherwise, just write
            // the data in uncompressed form.

            temp = new File(mDropBoxDir, "drop" + Thread.currentThread().getId() + ".tmp");
            int bufferSize = mBlockSize;
            if (bufferSize > 4096) bufferSize = 4096;
            if (bufferSize < 512) bufferSize = 512;
            FileOutputStream foutput = new FileOutputStream(temp);
            output = new BufferedOutputStream(foutput, bufferSize);
            // 压缩输出流
			if (read == buffer.length && ((flags & DropBoxManager.IS_GZIPPED) == 0)) {
                output = new GZIPOutputStream(output);
                flags = flags | DropBoxManager.IS_GZIPPED;
            }

            do {
				//写入到输出流
                output.write(buffer, 0, read);

                long now = System.currentTimeMillis();
                if (now - lastTrim > 30 * 1000) {
                    max = trimToFit();  // In case data dribbles in slowly
                    lastTrim = now;
                }

                read = input.read(buffer);
                if (read <= 0) {
                    FileUtils.sync(foutput);
                    output.close();  // Get a final size measurement
                    output = null;
                } else {
                    output.flush();  // So the size measurement is pseudo-reasonable
                }

                long len = temp.length();
                if (len > max) {
                    Slog.w(TAG, "Dropping: " + tag + " (" + temp.length() + " > " + max + " bytes)");
                    temp.delete();
                    temp = null;  // Pass temp = null to createEntry() to leave a tombstone
                    break;
                }
            } while (read > 0);

			// 将临时文件另存为最终的log文件，并且等级它，返回的当前时间
            long time = createEntry(temp, tag, flags);
            temp = null;

			//构建DropBox Intent
            final Intent dropboxIntent = new Intent(DropBoxManager.ACTION_DROPBOX_ENTRY_ADDED);
            dropboxIntent.putExtra(DropBoxManager.EXTRA_TAG, tag);
            dropboxIntent.putExtra(DropBoxManager.EXTRA_TIME, time);
            if (!mBooted) {
                dropboxIntent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY);
            }

			// 发送DropBox广播
            mHandler.sendMessage(mHandler.obtainMessage(MSG_SEND_BROADCAST, dropboxIntent));
        } catch (IOException e) {
            Slog.e(TAG, "Can't write: " + tag, e);
        } finally {
            IoUtils.closeQuietly(output);
            IoUtils.closeQuietly(input);
            entry.close();
            if (temp != null) temp.delete();
        }
    	}
	}

可以看到，在DropBoxManagerService的add方法中，将信息保存在一个文件中，最终发送了一个DropBox广播通知，写入DropBox的时间。

6.AppErrors.crashApplication方法

在ActivityManagerService的handleApplicationCrash方法的最后，调用了AppErrors.crashApplication方法来显示应用Crash的Dialog。

	/**
     * Bring up the "unexpected error" dialog box for a crashing app.
     * Deal with edge cases (intercepts from instrumented applications,
     * ActivityController, error intent receivers, that sort of thing).
     * @param r the application crashing
     * @param crashInfo describing the failure
     */
    void crashApplication(ProcessRecord r, ApplicationErrorReport.CrashInfo crashInfo) {
		// 获取调用者的PID，即进程号
        final int callingPid = Binder.getCallingPid();
		// 获取调用者的UID
        final int callingUid = Binder.getCallingUid();

        final long origId = Binder.clearCallingIdentity();
        try {
            crashApplicationInner(r, crashInfo, callingPid, callingUid);
        } finally {
            Binder.restoreCallingIdentity(origId);
        }
    }

	void crashApplicationInner(ProcessRecord r, ApplicationErrorReport.CrashInfo crashInfo,
            int callingPid, int callingUid) {
		// 获取Crash的信息
        long timeMillis = System.currentTimeMillis();
        String shortMsg = crashInfo.exceptionClassName;
        String longMsg = crashInfo.exceptionMessage;
        String stackTrace = crashInfo.stackTrace;
        if (shortMsg != null && longMsg != null) {
            longMsg = shortMsg + ": " + longMsg;
        } else if (shortMsg != null) {
            longMsg = shortMsg;
        }

        AppErrorResult result = new AppErrorResult();
        TaskRecord task;
        synchronized (mService) {
          ......
			//创建Crash Dialog
            AppErrorDialog.Data data = new AppErrorDialog.Data();
            data.result = result;
            data.proc = r;

            // If we can't identify the process or it's already exceeded its crash quota,
            // quit right away without showing a crash dialog.
			// 调用makeAppCrashingLocked继续处理Crash
            if (r == null || !makeAppCrashingLocked(r, shortMsg, longMsg, stackTrace, data)) {
                return;
            }

            final Message msg = Message.obtain();
            msg.what = ActivityManagerService.SHOW_ERROR_UI_MSG;

            task = data.task;
            msg.obj = data;
			// 发送到主线程去显示Crash Dialog
            mService.mUiHandler.sendMessage(msg);
        }
		
		//进入阻塞等待，直到用户选择crash对话框"退出"或者"退出并报告"
        int res = result.get();

        Intent appErrorIntent = null;
        MetricsLogger.action(mContext, MetricsProto.MetricsEvent.ACTION_APP_CRASH, res);
        if (res == AppErrorDialog.TIMEOUT || res == AppErrorDialog.CANCEL) {
            res = AppErrorDialog.FORCE_QUIT;
        }
		//根据用户的选择，执行不同的方法
        synchronized (mService) {
            if (res == AppErrorDialog.MUTE) {
                stopReportingCrashesLocked(r);
            }
            if (res == AppErrorDialog.RESTART) {
                mService.removeProcessLocked(r, false, true, "crash");
                if (task != null) {
                    try {
                        mService.startActivityFromRecents(task.taskId,
                                ActivityOptions.makeBasic().toBundle());
                    } catch (IllegalArgumentException e) {
                        // Hmm, that didn't work, app might have crashed before creating a
                        // recents entry. Let's see if we have a safe-to-restart intent.
                        final Set<String> cats = task.intent.getCategories();
                        if (cats != null && cats.contains(Intent.CATEGORY_LAUNCHER)) {
                            mService.startActivityInPackage(task.mCallingUid,
                                    task.mCallingPackage, task.intent,
                                    null, null, null, 0, 0,
                                    ActivityOptions.makeBasic().toBundle(),
                                    task.userId, null, null);
                        }
                    }
                }
            }
            if (res == AppErrorDialog.FORCE_QUIT) {
                long orig = Binder.clearCallingIdentity();
                try {
                    // Kill it with fire!
                    mService.mStackSupervisor.handleAppCrashLocked(r);
                    if (!r.persistent) {
                        mService.removeProcessLocked(r, false, false, "crash");
                        mService.mStackSupervisor.resumeFocusedStackTopActivityLocked();
                    }
                } finally {
                    Binder.restoreCallingIdentity(orig);
                }
            }
            if (res == AppErrorDialog.FORCE_QUIT_AND_REPORT) {
				//创建action="android.intent.action.APP_ERROR"，组件为r.errorReportReceiver的Intent
                appErrorIntent = createAppErrorIntentLocked(r, timeMillis, crashInfo);
            }
            if (r != null && !r.isolated && res != AppErrorDialog.RESTART) {
               	// 将崩溃的进程信息保存到mProcessCrashTimes
                mProcessCrashTimes.put(r.info.processName, r.uid,
                        SystemClock.uptimeMillis());
            }
        }

        if (appErrorIntent != null) {
            try {
				//启动Intent为appErrorIntent的Activity
                mContext.startActivityAsUser(appErrorIntent, new UserHandle(r.userId));
            } catch (ActivityNotFoundException e) {
                Slog.w(TAG, "bug report receiver dissappeared", e);
            }
        }
    }

在该方法中，主要做了两件事情：
- 调用makeAppCrashingLocked，继续处理crash流程；
- 发送消息SHOW_ERROR_MSG，弹出提示crash的对话框，等待用户选择；

7.makeAppCrashingLocked方法

	 private boolean makeAppCrashingLocked(ProcessRecord app,
            String shortMsg, String longMsg, String stackTrace, AppErrorDialog.Data data) {
        app.crashing = true;
		// 创建一个进程错误记录，适合保存到ProcessRecord中
        app.crashingReport = generateProcessError(app,
                ActivityManager.ProcessErrorStateInfo.CRASHED, null, shortMsg, longMsg, stackTrace);
        startAppProblemLocked(app);
		// 停止屏幕冻结
        app.stopFreezingAllLocked();
        return handleAppCrashLocked(app, "force-crash" /*reason*/, shortMsg, longMsg, stackTrace,
                data);
    }
	

	void startAppProblemLocked(ProcessRecord app) {
        // If this app is not running under the current user, then we
        // can't give it a report button because that would require
        // launching the report UI under a different user.
        app.errorReportReceiver = null;

		// 获取当前用户下的crash应用的error receiver
        for (int userId : mService.mUserController.getCurrentProfileIdsLocked()) {
            if (app.userId == userId) {
                app.errorReportReceiver = ApplicationErrorReport.getErrorReportReceiver(
                        mContext, app.info.packageName, app.info.flags);
            }
        }
		// 忽略当前app的广播接收
        mService.skipCurrentReceiverLocked(app);
    }

可以看到，makeAppCrashingLocked方法主要功能如下：
- 创建一个进程错误记录；
- 获取当前用户下的crash应用的Error接收者；
- 停止屏幕冻结；

8.ProcessRecord.stopFreezingAllLocked方法

	public void stopFreezingAllLocked() {
        int i = activities.size();
        while (i > 0) {
            i--;
            activities.get(i).stopFreezingScreenLocked(true);
        }
    }

	public void stopFreezingScreenLocked(boolean force) {
        if (force || frozenBeforeDestroy) {
            frozenBeforeDestroy = false;
            service.mWindowManager.stopAppFreezingScreen(appToken, force);
        }
    }

	public void stopAppFreezingScreen(IBinder token, boolean force) {
        
		.......
        synchronized(mWindowMap) {
            AppWindowToken wtoken = findAppWindowToken(token);
            ....
            unsetAppFreezingScreenLocked(wtoken, true, force);

        }
    }

stopFreezingAllLocked方法的主要功能是停止屏幕冻结。

9.handleAppCrashLocked

	private boolean handleAppCrashLocked(ProcessRecord app, String reason,
        String shortMsg, String longMsg, String stackTrace) {
    long now = SystemClock.uptimeMillis();

    Long crashTime;
    if (!app.isolated) {
        crashTime = mProcessCrashTimes.get(app.info.processName, app.uid);
    } else {
        crashTime = null;
    }
    //当同一个进程，连续两次crash的时间间隔小于1分钟时，则认为crash太过于频繁
    if (crashTime != null && now < crashTime+ProcessList.MIN_CRASH_INTERVAL) {
        EventLog.writeEvent(EventLogTags.AM_PROCESS_CRASHED_TOO_MUCH,
                app.userId, app.info.processName, app.uid);
        
        mStackSupervisor.handleAppCrashLocked(app);
        if (!app.persistent) {
            //不再重启非persistent进程，除非用户显式地调用
            EventLog.writeEvent(EventLogTags.AM_PROC_BAD, app.userId, app.uid,
                    app.info.processName);
            if (!app.isolated) {
                //将当前app加入到mBadProcesses
                mBadProcesses.put(app.info.processName, app.uid,
                        new BadProcessInfo(now, shortMsg, longMsg, stackTrace));
                mProcessCrashTimes.remove(app.info.processName, app.uid);
            }
            app.bad = true;
            app.removed = true;
            //移除进程的所有服务，保证不再重启
            removeProcessLocked(app, false, false, "crash");
            //恢复最顶部的Activity
            mStackSupervisor.resumeTopActivitiesLocked();
            return false;
        }
        mStackSupervisor.resumeTopActivitiesLocked();
    } else {
        //此处reason="force-crash"
        mStackSupervisor.finishTopRunningActivityLocked(app, reason);
    }

    //运行在当前进程中的所有服务的crash次数执行加1操作
    for (int i=app.services.size()-1; i>=0; i--) {
        ServiceRecord sr = app.services.valueAt(i);
        sr.crashCount++;
    }

    //当桌面应用crash，并且被三方app所取代，那么需要清空桌面应用的偏爱选项。
    final ArrayList<ActivityRecord> activities = app.activities;
    if (app == mHomeProcess && activities.size() > 0
                && (mHomeProcess.info.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
        for (int activityNdx = activities.size() - 1; activityNdx >= 0; --activityNdx) {
            final ActivityRecord r = activities.get(activityNdx);
            if (r.isHomeActivity()) {
                //清空偏爱应用
                ActivityThread.getPackageManager()
                        .clearPackagePreferredActivities(r.packageName);
            }
        }
    }

    if (!app.isolated) {
        //无法记录孤立进程的crash时间点，由于他们并没有一个固定身份
        mProcessCrashTimes.put(app.info.processName, app.uid, now);
    }
    //当app存在crash的handler，那么交给其处理
    if (app.crashHandler != null) mHandler.post(app.crashHandler);
    return true;
	}

1.当同一进程在时间间隔小于1分钟时连续两次crash，则执行的情况下：

- 对于非persistent进程：
	- mStackSupervisor.handleAppCrashLocked(app);
	- removeProcessLocked(app, false, false, “crash”);
	- mStackSupervisor.resumeTopActivitiesLocked();
- 对于persistent进程，则只执行
	- mStackSupervisor.resumeTopActivitiesLocked();

2.否则执行
mStackSupervisor.finishTopRunningActivityLocked(app, reason);

可以看到，当应用app有Crash的Handlers是，则可以将Crash交给对应的Handler来处理。

10.KillProcess方法
在前面的KillApplicationHandler的finally方法中，最终会调用Process.killProcess方法，杀死Crash进程。

	Process.killProcess(Process.myPid());
	System.exit(10);
当Crash进程被杀后，并没有完全结束，还有Binder死亡通知的流程还没有处理完成。


### 3.总结
当进程抛出未捕获异常时，则系统会处理该异常并进入crash处理流程。

![异常处理](http://gityuan.com/images/stability/app_crash.jpg)

Crash的处理流程大致如下：

1. 首先发生crash所在进程，在创建之初便准备好了defaultUncaughtHandler，用来来处理Uncaught Exception，并输出当前crash基本信息；
2. 调用当前进程中的AMP.handleApplicationCrash；经过binder ipc机制，传递到system_server进程；
3. 接下来，进入system_server进程，调用binder服务端执行AMS.handleApplicationCrash；
4. 从mProcessNames查找到目标进程的ProcessRecord对象；并将进程crash信息输出到目录/data/system/dropbox；
5. 执行makeAppCrashingLocked
创建当前用户下的crash应用的error receiver，并忽略当前应用的广播；
停止当前进程中所有activity中的WMS的冻结屏幕消息，并执行相关一些屏幕相关操作；

6. 再执行handleAppCrashLocked方法，
	- 当1分钟内同一进程连续crash两次时，且非persistent进程，则直接结束该应用所有activity，并杀死该进程以及同一个进程组下的所有进程。然后再恢复栈顶第一个非finishing状态的activity;
	- 当1分钟内同一进程连续crash两次时，且persistent进程，，则只执行恢复栈顶第一个非finishing状态的activity;
	- 当1分钟内同一进程未发生连续crash两次时，则执行结束栈顶正在运行activity的流程。

7. 通过mUiHandler发送消息SHOW_ERROR_MSG，弹出crash对话框；
8. 到此，system_server进程执行完成。回到crash进程开始执行杀掉当前进程的操作；
9. 当crash进程被杀，通过binder死亡通知，告知system_server进程来执行appDiedLocked()；
10. 最后，执行清理应用相关的activity/service/ContentProvider/receiver组件信息。

这基本就是整个应用Crash后系统的执行过程。 最后，再说说对于同一个app连续crash的情况：

- 当60s内连续crash两次的非persistent进程时，被认定为bad进程：那么如果第3次从后台启动该进程(Intent.getFlags来判断)，则会拒绝创建进程；
- 当crash次数达到两次的非persistent进程时，则再次杀该进程，即便允许自启的service也会在被杀后拒绝再次启动。

参考文章：
[理解Android Crash处理流程](http://gityuan.com/2016/06/24/app-crash/)




## Native Crash
[TOC]

### 1.概述

Native层的Crash，即C/C++层面的Crash，是由debuggerd守护进程来完成。

### 2.debuggerd服务端
连接到bionic上的native程序（C/C++）出现异常时，kernel会发送相应的signal；当进程捕获致命的signal，通知debuggerd调用ptrace来捕获有价值的信息（发生Crash之前）。


debuggerd守护进程启动后，一直等待client socket的连接。当Native Crash发送后便会向debuggerd发送action = DEBUGGER_ACTION_CRASH的消息。

Android系统有监控程序异常退出的机制——debuggerd守护进程。当发生native crash或者主动调用debuggerd时，会输出进程相关的状态信息到文件或者控制台。输出的debuggerd数据 保存在文件/data/tombstones/tombstone_XX，该类型文件个数上限位10个，当超过时则每次覆盖时间最老的文件。

针对进程出现的不同的状态，Linux kernel会发送相应的signal给异常进程，捕获signal并对其做相应的处理（通常动作是退出异常进程）。而Android在这机制的前提下，通过拦截这些信号来dump进程信息，方便开发人员调试分析。

debuggerd守护进程会打开socket服务端，当需要调用debuggerd服务时，先通过客户端进程向debuggerd服务端建立socket连接，然后发送不同的请求给debuggerd服务端，当服务端收到不同的请求，则会采取相应的dump操作。

具体详见[理解Native Crash处理流程](http://gityuan.com/2016/06/25/android-native-crash/)


### 3.NativeCrashListener
在启动SystemServer系统服务时，会去注册Native Crash监听。具体是在SystemServer的startOtherService方法中，当开机过程中启动服务启动到阶段PHASE_ACTIVITY_MANAGER_READY(550)，即服务可以广播自己的Intents，然后启动native crash的监听进程。

1. SystemServer.startOtherServices()

		private void startOtherServices() {
		mActivityManagerService.systemReady(new Runnable() {
            @Override
            public void run() {
                Slog.i(TAG, "Making services ready");
                mSystemServiceManager.startBootPhase(SystemService.PHASE_ACTIVITY_MANAGER_READY);

                try {
                 	//开始监听Native Crash
				   mActivityManagerService.startObservingNativeCrashes();
                } catch (Throwable e) {
                    reportWtf("observing native crashes", e);
                }
       
	}

在ActivityManagerService服务启动后，可以运行第三方应用的代码后，开始监听Native Crash。

2. ActivityManagerService.startObservingNativeCrashes()


		public void startObservingNativeCrashes() {
			// 创建一个NativeCrashListener，
        	final NativeCrashListener ncl = new 	NativeCrashListener(this);
        	ncl.start();
    	}

3. NativeCrashListener


NativeCrashListener是一个线程，用来接收来自debuggerd传送过来的Native Crash信息，具体是通过一个UNIX域socket套接字，将native 信息传递过来。

	final class NativeCrashListener extends Thread {
		// Must match the path defined in debuggerd.c.
    	static final String DEBUGGERD_SOCKET_PATH = "/data/system/ndebugsocket";
		// Use a short timeout on socket operations and abandon the connection
    	// on hard errors, just in case debuggerd goes out to lunch.
    	static final long SOCKET_TIMEOUT_MILLIS = 10000;  // 10 seconds
		
		final ActivityManagerService mAm;


	/**
	* 守护线程，用来接收来自debuggerd的套接字连接，并且负责dump Crash信息
	*/
    NativeCrashListener(ActivityManagerService am) {
        mAm = am;
    }

	@Override
    public void run() {
        final byte[] ackSignal = new byte[1];


        // The file system entity for this socket is created with 0777 perms, owned
        // by system:system. selinux restricts things so that only crash_dump can
        // access it.
        {   //此处DEBUGGERD_SOCKET_PATH= "/data/system/ndebugsocket"
            File socketFile = new File(DEBUGGERD_SOCKET_PATH);
            if (socketFile.exists()) {
                socketFile.delete();
            }
        }

        try {
            FileDescriptor serverFd = Os.socket(AF_UNIX, SOCK_STREAM, 0);
			// 创建socket服务端
            final UnixSocketAddress sockAddr = UnixSocketAddress.createFileSystem(
                    DEBUGGERD_SOCKET_PATH);
			// 绑定套接字
            Os.bind(serverFd, sockAddr);
			// 监听
            Os.listen(serverFd, 1);
			// 修改权限为777
            Os.chmod(DEBUGGERD_SOCKET_PATH, 0777);

			// 循环等待连接
            while (true) {
                FileDescriptor peerFd = null;
                try {
                    // 等待debuggerd建立连接
                    peerFd = Os.accept(serverFd, null /* peerAddress */);
                    
                    if (peerFd != null) {
					    // 处理native Crash信息
                        consumeNativeCrashData(peerFd);
                    }
                } catch (Exception e) {
                    Slog.w(TAG, "Error handling connection", e);
                } finally {
                    // Always ack crash_dump's connection to us.  The actual
                    // byte written is irrelevant.
                    if (peerFd != null) {
                        try {
							// 应答debuggerd已建立连接，写入应答信息
                            Os.write(peerFd, ackSignal, 0, 1);
                        } catch (Exception e) {
                            .....
                        }
                        try {
							// 关闭套接字
                            Os.close(peerFd);
                        } catch (ErrnoException e) {
                           .....
                        }
                    }
                }
            }
        } catch (Exception e) {
            ....
        }
    }
	}

可以看到，在NativeCrashListener线程中，首先会创建一个Socket套接字，然后循环等待debuggerd建立socket连接，接着处理debuggerd传递过来的native Crash信息，最后应答debuggerd已建立连接，并将应答信息告知debuggerd进程，关闭Socket套接字。

处理debuggerd传递过来的native crash信息的方法是consumeNativeCrashData(peerFd);

	// Read a crash report from the connection
    void consumeNativeCrashData(FileDescriptor fd) {
        ......
        final byte[] buf = new byte[4096];
        final ByteArrayOutputStream os = new ByteArrayOutputStream(4096);

        try {
			//此处SOCKET_TIMEOUT_MILLIS=10s
            StructTimeval timeout = StructTimeval.fromMillis(SOCKET_TIMEOUT_MILLIS);
            Os.setsockoptTimeval(fd, SOL_SOCKET, SO_RCVTIMEO, timeout);
            Os.setsockoptTimeval(fd, SOL_SOCKET, SO_SNDTIMEO, timeout);

            // The socket is guarded by an selinux neverallow rule that only
            // permits crash_dump to connect to it. This allows us to trust the
            // received values.

            // first, the pid and signal number
			// 首先，读取pid和signal值
            int headerBytes = readExactly(fd, buf, 0, 8);
            if (headerBytes != 8) {
				// 读取失败，返回
                return;
            }

            int pid = unpackInt(buf, 0);
            int signal = unpackInt(buf, 4);
            ......

            // now the text of the dump
			// 读取dump的内容
            if (pid > 0) {
                final ProcessRecord pr;
                synchronized (mAm.mPidsSelfLocked) {
                    pr = mAm.mPidsSelfLocked.get(pid);
                }
                if (pr != null) {
                    // Don't attempt crash reporting for persistent apps
                    if (pr.persistent) {
                        .....
                        return;
                    }

                    int bytes;
                    do {
                        // get some data
						// 读取数据
                        bytes = Os.read(fd, buf, 0, buf.length);
                        if (bytes > 0) {
                            .....
                            // did we just get the EOD null byte?
							// 已读取到末尾
                            if (buf[bytes-1] == 0) {
                                os.write(buf, 0, bytes-1);  // exclude the EOD token
                                break;
                            }
                            // no EOD, so collect it and read more
                            os.write(buf, 0, bytes);
                        }
                    } while (bytes > 0);

                    synchronized (mAm) {
                        pr.crashing = true;
                        pr.forceCrashReport = true;
                    }

                    // Crash reporting is synchronous but we want to let debuggerd
                    // go about it business right away, so we spin off the actual
                    // reporting logic on a thread and let it take it's time.
                    //Crash报告是同步的过程，但是为了让debuggerd能快速返回处理其他事情，在这里开启一个线程来记录Crash信息。
                    final String reportString = new String(os.toByteArray(), "UTF-8");
                    (new NativeCrashReporter(pr, signal, reportString)).start();
                } else {
                    ......
                }
            } else {
                .....
            }
        } catch (Exception e) {
           ......
        }
    }

在consumeNativeCrashData方法中，读取debuggerd发送过来的native crash信息，最终交给NativeCrashReporter线程来真正记录crash信息。

4. NativeCrashReporter

	
		/*
     	* Spin the actual work of handling a debuggerd crash report into a
     	* separate thread so that the listener can go immediately back to
     	* accepting incoming connections.
     	*/
		
    	class NativeCrashReporter extends Thread {
        ProcessRecord mApp;
        int mSignal;
        String mCrashReport;

        NativeCrashReporter(ProcessRecord app, int signal, String report) {
            super("NativeCrashReport");
            mApp = app;
            mSignal = signal;
            mCrashReport = report;
        }

        @Override
        public void run() {
            try {
				// 构建Crash信息
                CrashInfo ci = new CrashInfo();
                ci.exceptionClassName = "Native crash";
                ci.exceptionMessage = Os.strsignal(mSignal);
                ci.throwFileName = "unknown";
                ci.throwClassName = "unknown";
                ci.throwMethodName = "unknown";
                ci.stackTrace = mCrashReport;

                //调用ActivityManagerService的handleApplicationCrashInner方法来处理Native Crash信息。
                mAm.handleApplicationCrashInner("native_crash", mApp, mApp.processName, ci);
                ....
            } catch (Exception e) {
                .....
            }
        }
    }

可以看到，最终是调用ActivityManagerService的handleApplicationCrashInner方法来处理Native Crash信息。Java Crash最终也是调用handleApplicationCrashInner方法来处理Crash信息。

**小结**：

SystemServer进程在启动过程中，调用startOtherServices来启动其他系统Service时，创建一个用于监听native crash事件的NativeCrashListener对象(继承于线程)，通过socket机制来监听，等待debuggerd与该socket创建连接，并处理相应事件。紧接着调用handleApplicationCrashInner来处理crash。

**NativeCrashListener的主要工作**：

1. 创建socket服务端”/data/system/ndebugsocket”
2. 等待socket客户端(即debuggerd)来建立连接；
3. 调用consumeNativeCrashData来处理native crash信息；
4. 应答debuggerd已经建立连接，并写入应答消息告知debuggerd进程。

### 4.总结
![Native Crash处理流程](http://gityuan.com/images/stability/native_crash.jpg)

Native程序通过link连接后，当发生Native Crash时，则kernel会发送相应的signal，当进程捕获致命的signal，通知debuggerd调用ptrace来获取有价值的信息(这是发生在crash前)。

1. kernel发送signal信号给target进程；
2. target进程通过**debuggerd_signal_handler**,捕获signal；
	- 建立与debuggerd进程的socket通道；
	- 将action = DEBUGGER_ACTION_CRASH的消息发送给的debuggerd服务端。
	- 阻塞等待debuggerd服务端的回应数据。

3. debuggerd作为守护进程，一直等待client socket的连接，此时收到action = DEBUGGER_ACTION_CRASH的消息；
4. 执行到handle_request时，通过fork创建子进程来执行各种dump相关操作；
5. 在新创建的进程中，通过socket与system_server进程中的NativeCrashListener线程建立socket通信，并向其发送native crash信息。
6. NativeCrashListener线程通过创建新的线程——NativeCrashReport来处理native crash信息，并调用AMS的handleApplicationCrashInner方法。

这个流程图只是从整体来概要介绍native crash流程，其中有两个部分是核心方法：

- 一个是perform_dump方法，该方法是debuggerd守护进程的核心工作，该方法内部调用engrave_tombstone。具体详见[debuggerd守护进程](http://gityuan.com/2016/06/15/android-debuggerd/#tombstone)以及[Android Tombstone 分析](http://www.cnblogs.com/CoderTian/p/5980426.html)


- 另外一个方法是AMS的handleApplicationCrashInner。具体详见[理解Android Crash处理流程](http://gityuan.com/2016/06/24/app-crash/#handleApplicationCrashInner)

参考文章： [理解Native Crash处理流程](http://gityuan.com/2016/06/25/android-native-crash/)


### 5.如何监控Native Crash？
> 当应用程序发生异常时，Linux内核会生成错误信号，并通知当前进程。应用进程接收到错误信号后，可捕获该信号并执行对应的信号处理函数。

信号机制是 Linux 进程间通信的一种重要方式，Linux 信号一方面用于正常的**进程间通信和同步**，如任务控制(SIGINT, SIGTSTP,SIGKILL, SIGCONT，……)；另一方面，它还负责**监控系统异常及中断**。 当应用程序运行异常时， **Linux 内核将产生错误信号并通知当前进程**。 当前进程在接收到该错误信号后，可以有三种不同的处理方式。

（1）忽略该信号。

（2）捕捉该信号并执行对应的信号处理函数(signal handler)。

（3）执行该信号的缺省操作(如 SIGSEGV， 其缺省操作是终止进程)。

当 Linux 应用程序在执行时发生严重错误，一般会导致程序 crash。其中，Linux 专门提供了一类 crash 信号，在程序接收到此类信号时，缺省操作是将 crash 的现场信息记录到 core 文件，然后终止进程。


应用在运行过程中，发生严重错误时会发生Crash，Linux有一类专门用于描述Crash的信号：

- SIGABRT：abort退出异常
- SIGBUS：硬件访问异常
- SIGFPE：浮点运算异常
- SIGILL：非法指令异常
- SIGSEGV：内存访问异常
- SIGSTKFLT：协处理器栈异常
- SIGTRAP：陷阱异常

只要在应用程序中注册了这些信号处理函数，当JNI Crash时，我们的处理函数就会被调用，然后获取dump文件再上传，后续的工作原理就和Java层异常处理逻辑一致了。

Android Native层注册信号量函数的代码如下：

	#include<signal.h>
	
	int sigaction(int sig, struct sigaction *act,struct sigaction *oact);
	
	struct sigaction{
		void (*sa_handler)(int);
		void (*sa_sigaction)(int,siginfo_t*,void*);
		sigset_t sa_mask;
		void (*sa_restorer)(void);
	}

signal.h是信号量的头文件，*act是指向sigaction结构的指针。在signation结构的实例中，指定了要处理的信号，信号附带的信息、信号处理函数执行过程中应屏蔽的函数等

在Android应用程序中，native层代码通过执行System.loadLibrary（）,把so库加载进来，然后执行so中的JNI_OnLoad(JavaVM *vm,void *reserverd)函数。

开发者可以在JNI_OnLoad()中进行一些数据初始化操作，同时也可以安装信号处理函数。这样当Native层代码发生了Crash，就会由Linux内核发送信号给应用进程，应用进程接收到信号后，会调用对应的信号处理函数，在信号处理函数中，可以获取并解析native crash信息，再把相应的信息压缩上传到服务器中，这样就完成了Native Crash信息的监控。
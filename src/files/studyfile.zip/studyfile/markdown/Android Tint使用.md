## Android Tint(着色)

Tint的意思为**着色**。它一般搭配Background使用，主要是为背景的着色，比如用一个颜色为我们的背景图片设置tint（着色）。


在Android 5.0以后，可以被Bitmap或者9-patch图片使用setTint()方法。在xml文件中，可以使用android:tint和android:tintMode这两个属性。

注意，使用android：tint指定颜色时一定要带透明度。

### 属性说明

android:tint     设置的是颜色。

android:tintMode  设置的是类型(src_in,src_over,src_atop,add,screen,multiply)

类型说明：

- src_in 只显示设置的遮罩颜色。 相当于遮罩在里面。 
- src_over遮罩颜色和图片都显示。相当于遮罩在图片上方。(特别是色值带透明度的) 
- src_atop遮罩在图片上方 
- multiply 混合色遮罩 
- screen 
- add 混合遮罩，drawable颜色和透明度

代码设置：

1.ImageView

	mImage.setColorFilter(mHintColor, mMode); 

2.Button、TextView

	tv.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(“#ff00ff”))); 
	tv.setBackgroundTintMode(Mode.SRC_OVER);







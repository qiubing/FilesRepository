## Android对话框

### 简介
Android的对话框有两种:PopUpWindow和AlertDialog。

它们的不同点在于：

1. AlertDialog的位置固定，而PopupWindow的位置可以随意；
2. AlertDialog是非阻塞线程的，AlertDialog弹出的时候，后台还可以做其他事情；
3. PopupWindow是阻塞线程的，在退出这个弹框之前，程序会一直等待；
4. PopupWindow的位置按照有无偏移可以分为：偏移和无偏移两种。按照有无参照物的不同，可以分为相对于某个控件(Anchor锚)和相对于父控件。

### PopupWindow

#### PopupWindow简介
PopupWindow类代表一个弹出的窗口，可以用来显示任意的View。popup窗口是一个悬浮在当前Activity上的一个容器。


#### 使用示例
悬浮窗口的xml定义pop_window.xml

	<?xml version="1.0" encoding="utf-8"?>
	<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#ffc0cb"
    android:orientation="vertical">

    <TextView
        android:id="@+id/pop_text"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:padding="10dp"
        android:textSize="16sp"
        android:textColor="#000000"
        android:text="PopupWindow text"/>
    <Button
        android:id="@+id/pop_btn"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:textSize="16sp"
        android:padding="10dp"
        android:textColor="#000000"
        android:text="popup Button"/>
	</LinearLayout>

弹出popWindow

	private void showPopupWindow(View view){
        // 加载自定义布局
        View contentView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.popup_window,null);
        Button popBtn = (Button) contentView.findViewById(R.id.pop_btn);
        popBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Popup Button Clicked!!!",Toast.LENGTH_LONG).show();
            }
        });

        final PopupWindow popupWindow = new PopupWindow(contentView, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,true);

        popupWindow.setTouchable(true);

        popupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Log.e("qiubing", "onTouch()...view = " + view + "motionEvent = " + motionEvent);

                // 这里如果返回true的话，touch事件将被拦截
                // 拦截后 PopupWindow的onTouchEvent不被调用，这样点击外部区域无法dismiss
                return false;
            }
        });

        // 如果不设置PopupWindow的背景，无论是点击外部区域还是Back键都无法dismiss弹框
        //popupWindow.setBackgroundDrawable(getResources().getDrawable(R.drawable.popup_window_bg2));

        // 设置好参数之后再show
        popupWindow.showAsDropDown(view);
    }

完整的例子：

#### PopupWindow源码分析
1.PopupWindow的构造函数

	public PopupWindow(Context context) {
        this(context, null);
    }
	
	public PopupWindow(Context context, AttributeSet attrs) {
        this(context, attrs, com.android.internal.R.attr.popupWindowStyle);
    }

	public PopupWindow(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

	public PopupWindow(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        mContext = context;
		// 获取WindowManger对象
        mWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		// 获取popupWindow的属性数组
        final TypedArray a = context.obtainStyledAttributes(
                attrs, R.styleable.PopupWindow, defStyleAttr, defStyleRes);
        final Drawable bg = a.getDrawable(R.styleable.PopupWindow_popupBackground);
        mElevation = a.getDimension(R.styleable.PopupWindow_popupElevation, 0);
        mOverlapAnchor = a.getBoolean(R.styleable.PopupWindow_overlapAnchor, false);

        // Preserve default behavior from Gingerbread. If the animation is
        // undefined or explicitly specifies the Gingerbread animation style,
        // use a sentinel value.
        if (a.hasValueOrEmpty(R.styleable.PopupWindow_popupAnimationStyle)) {
            final int animStyle = a.getResourceId(R.styleable.PopupWindow_popupAnimationStyle, 0);
            if (animStyle == R.style.Animation_PopupWindow) {
                mAnimationStyle = ANIMATION_STYLE_DEFAULT;
            } else {
                mAnimationStyle = animStyle;
            }
        } else {
            mAnimationStyle = ANIMATION_STYLE_DEFAULT;
        }

        final Transition enterTransition = getTransition(a.getResourceId(
                R.styleable.PopupWindow_popupEnterTransition, 0));
        final Transition exitTransition;
        if (a.hasValueOrEmpty(R.styleable.PopupWindow_popupExitTransition)) {
            exitTransition = getTransition(a.getResourceId(
                    R.styleable.PopupWindow_popupExitTransition, 0));
        } else {
            exitTransition = enterTransition == null ? null : enterTransition.clone();
        }

        a.recycle();
		
		// 设置进入和退出动画
        setEnterTransition(enterTransition);
        setExitTransition(exitTransition);
		//设置背景
        setBackgroundDrawable(bg);
    }

2.PopupWindow.setTouchable()

	public void setFocusable(boolean focusable) {
        mFocusable = focusable;
    }
该方法的主要作用是改变Popup Window获取的焦点。如果PopupWindow包含可以获取焦点的View，那么将从当前焦点控件获取焦点。默认地PopupWindow是不获取焦点的。

3.PopupWindow.setTouchable()
	public void setTouchable(boolean touchable) {
        mTouchable = touchable;
    }
该方法的主要作用是改变Popup Window的触控性。如果PopupWindow是可触控的，则PopupWindow是可以接受触摸事件，否则触摸事件将传递到在PopupWindow下面的窗口。默认的PopupWindow是可触摸的。

4.PopupWindow.setTouchInterceptor()

	public void setTouchInterceptor(OnTouchListener l) {
        mTouchInterceptor = l;
    }
该方法是设置回调，当popupWindow接受到touch事件时将回调该接口。

可以看到在PopupWindow里面定义了处理touch事件的方法：

	public boolean dispatchTouchEvent(MotionEvent ev) {
            if (mTouchInterceptor != null && mTouchInterceptor.onTouch(this, ev)) {
                return true;
            }
            return super.dispatchTouchEvent(ev);
        }
当mTouchInterceptor不为空，并且onTouch方法没有返回true时，则会将touch event事件分发给子View处理。

再来看下onTouchEvent事件处理：

	public boolean onTouchEvent(MotionEvent event) {
			// 获取事件的坐标
            final int x = (int) event.getX();
            final int y = (int) event.getY();
			
			// 如果是按下事件并且坐标位置在popupWindow范围外面，则让PopupWindow消失。
            if ((event.getAction() == MotionEvent.ACTION_DOWN)
                    && ((x < 0) || (x >= getWidth()) || (y < 0) || (y >= getHeight()))) {
                dismiss();
                return true;
            } else if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
				// 在窗口外面点击了会收到该事件
                dismiss();
                return true;
            } else {
				// 否则让子View取处理
                return super.onTouchEvent(event);
            }
        }

5.PopupWindow.showAsDropDown()
	
	public void showAsDropDown(View anchor) {
        showAsDropDown(anchor, 0, 0);
    }

	public void showAsDropDown(View anchor, int xoff, int yoff) {
        showAsDropDown(anchor, xoff, yoff, DEFAULT_ANCHORED_GRAVITY);
    }

	public void showAsDropDown(View anchor, int xoff, int yoff, int gravity) {
		// 如果已经显示了，则直接返回
        if (isShowing() || mContentView == null) {
            return;
        }
		
        TransitionManager.endTransitions(mDecorView);
		
		//将achor view依附到窗口中
        attachToAnchor(anchor, xoff, yoff, gravity);

        mIsShowing = true;
        mIsDropdown = true;

		// 获取Popup窗口的参数
        final WindowManager.LayoutParams p = createPopupLayoutParams(anchor.getWindowToken());
        // 准备PopWindow
		preparePopup(p);

        final boolean aboveAnchor = findDropDownPosition(anchor, p, xoff, yoff,
                p.width, p.height, gravity, mAllowScrollingAnchorParent);
        updateAboveAnchor(aboveAnchor);
        p.accessibilityIdOfAnchor = (anchor != null) ? anchor.getAccessibilityViewId() : -1;
		// 触发PopUpWindow显示
        invokePopup(p);
    }
该方法的主要作用是在指定的View下面弹出一个PopupWindow，该窗口被放置在由x和y以及gravity指定的位置上。

	private WindowManager.LayoutParams createPopupLayoutParams(IBinder token) {
        final WindowManager.LayoutParams p = new WindowManager.LayoutParams();

        // corner.
		// 计算gravity
        p.gravity = computeGravity();
		// 计算flags
        p.flags = computeFlags(p.flags);
		// 窗口的类型为WindowManager.LayoutParams.TYPE_APPLICATION_PANEL
        p.type = mWindowLayoutType;
        p.token = token;
        p.softInputMode = mSoftInputMode;
        p.windowAnimations = computeAnimationResource();
		
        if (mBackground != null) {
            p.format = mBackground.getOpacity();
        } else {
            p.format = PixelFormat.TRANSLUCENT;
        }

        if (mHeightMode < 0) {
            p.height = mLastHeight = mHeightMode;
        } else {
            p.height = mLastHeight = mHeight;
        }

        if (mWidthMode < 0) {
            p.width = mLastWidth = mWidthMode;
        } else {
            p.width = mLastWidth = mWidth;
        }

        p.privateFlags = PRIVATE_FLAG_WILL_NOT_REPLACE_ON_RELAUNCH
                | PRIVATE_FLAG_LAYOUT_CHILD_WINDOW_IN_PARENT_FRAME;

        // Used for debugging.
        p.setTitle("PopupWindow:" + Integer.toHexString(hashCode()));

        return p;
    }

6.PopupWindow.preparePopup()

	private void preparePopup(WindowManager.LayoutParams p) {
		// 检查参数
        if (mContentView == null || mContext == null || mWindowManager == null) {
            throw new IllegalStateException("You must specify a valid content view by "
                    + "calling setContentView() before attempting to show the popup.");
        }

        // The old decor view may be transitioning out. Make sure it finishes
        // and cleans up before we try to create another one.
        if (mDecorView != null) {
            mDecorView.cancelTransitions();
        }

        
		// 如果背景是可用的，则将content view嵌入到另外一个拥有background的View中
        if (mBackground != null) {
            mBackgroundView = createBackgroundView(mContentView);
            mBackgroundView.setBackground(mBackground);
        } else {
            mBackgroundView = mContentView;
        }
		// 创建新的DecorView
        mDecorView = createDecorView(mBackgroundView);

        mBackgroundView.setElevation(mElevation);

        p.setSurfaceInsets(mBackgroundView, true /*manual*/, true /*preservePrevious*/);

        mPopupViewInitialLayoutDirectionInherited =
                (mContentView.getRawLayoutDirection() == View.LAYOUT_DIRECTION_INHERIT);
    }
该方法的主要作用是将popupWindow嵌入到一个新的ViewGroup中，如果Background不为空的话。

	private PopupBackgroundView createBackgroundView(View contentView) {
        final ViewGroup.LayoutParams layoutParams = mContentView.getLayoutParams();
        final int height;
        if (layoutParams != null && layoutParams.height == WRAP_CONTENT) {
            height = WRAP_CONTENT;
        } else {
            height = MATCH_PARENT;
        }

        final PopupBackgroundView backgroundView = new PopupBackgroundView(mContext);
        final PopupBackgroundView.LayoutParams listParams = new PopupBackgroundView.LayoutParams(
                MATCH_PARENT, height);
        backgroundView.addView(contentView, listParams);

        return backgroundView;
    }

7.PopupWindow.invokePopup()

	private void invokePopup(WindowManager.LayoutParams p) {
        if (mContext != null) {
            p.packageName = mContext.getPackageName();
        }

        final PopupDecorView decorView = mDecorView;
        decorView.setFitsSystemWindows(mLayoutInsetDecor);

        setLayoutDirectionFromAnchor();
		// 通过WindowManager添加DecorView
        mWindowManager.addView(decorView, p);
		//执行进入动画
        if (mEnterTransition != null) {
            decorView.requestEnterTransition(mEnterTransition);
        }
    }

#### PopWindow常见问题

[Android PopupWindow的使用和分析](http://www.cnblogs.com/mengdd/p/3569127.html)

[PopUpWindow使用详解(一)——基本使用](http://blog.csdn.net/harvic880925/article/details/49272285)

[PopUpWindow使用详解(二)——进阶及答疑](http://blog.csdn.net/harvic880925/article/details/49278705)


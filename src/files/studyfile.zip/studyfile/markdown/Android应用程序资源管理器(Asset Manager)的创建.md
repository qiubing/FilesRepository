## Android应用程序资源管理器(Asset Manager)的创建

### 1.概述
Android应用程序在运行的过程中，是通过一个称为**AssetManager的资源管理器**来读取打包在APK文件里面的资源文件的。

我们知道，应用程序的每一个Activity组件都关联着一个ContextImpl对象，这个ContextImpl对象就是用来描述Activity组件的运行上下文环境的。

ContextImpl类的成员函数**getResources**返回的是一个Resource对象，有了这个Resources对象之后，我们就可以通过**资源ID**来访问那些被编译过的应用程序资源了。

ContextImpl类的成员函数**getAssets**返回的是一个AssetManager对象，有了这个AssetManager对象之后，我们就可以通过**文件名**来访问那些被编译过或者没有被编译过的应用程序资源文件了。事实上，Resource类也是通过AssetManager类来访问那些被编译过的应用程序资源文件的，不过在访问之前，它会先**根据资源ID查找得到对应的资源文件名**。


在Android系统中，一个进程是可以同时加载多个应用程序的，也可以同时加载多个APK文件。**每一个APK文件在进程中都对应有一个全局的Resources对象以及一个全局的AssetManager对象**。其中，这个全局的Resourses对象保存在一个对应的ContextImpl对象的成员变量mResources中，而这个全局的AssetManager对象保存在这个全局的Resourses对象的成员变量mAssets中。上述ContextImpl、Resourses和AssetManager的关系如图所示:

![ContextImpl、Resources和AssetManager的关系图](http://img.my.csdn.net/uploads/201304/12/1365697642_3078.jpg)

Resources类有一个成员函数getAssets，通过它就可以获得保存在Resources类的成员变量mAssets中的AssetManager，例如，ContextImpl类的成员函数getAssets就是通过调用其成员变量mResources所指向的一个Resources对象的成员函数getAssets来获得一个可以用来**访问应用程序的非编译资源文件的AssetManager**。

Android应用程序除了要访问自己的资源之外，还需要访问系统的资源。系统的资源打包在/system/framework/framework-res.apk文件中，它在应用程序进程中是通过一个单独的Resources对象和一个单独的AssetManager对象来管理的。这个单独的Resources对象就保存在Resources类的静态成员变量mSystem中，我们可以通过Resources类的静态成员函数getSystem就可以获得这个Resources对象；而这个单独的AssetManager对象就保存在AssetManager类的静态成员变量sSystem中，我们可以通过AssetManager类的静态成员函数getSystem同样可以获得这个AssetManager对象。

AssetManager类除了在Java层有一个实现之外，在 C++层也有一个对应的实现，而Java层的AssetManager类的功能就是通过C++层的AssetManager类来实现的。Java层的每一个AssetManager对象都有一个类型为int的成员变量mObject，它保存的便是在C++层对应的AssetManager对象的地址，因此，通过这个成员变量就可以将Java层的AssetManager对象与C++层的AssetManager对象关联起来。

C++层的AssetManager类有三个重要的成员变量**mAssetPaths、mResources和mConfig**。其中，**mAssetPaths保存的是资源存放目录，mResources指向的是一个资源索引表，而mConfig保存的是设备的本地配置信息**，例如屏幕密度和大小、国家地区和语言等等配置信息。有了这三个成员变量之后，C++层的AssetManager类就可以访问应用程序的资源了。

### 2.初始化过程源码分析

在每一个Activity组件的加载过程中，都会创建一个对应的ContextImpl，并调用这个ContextImpl对象的构造方法来初始化运行上下文环境。接下来就从ContextImpl的构造方法来分析Resource对象和AssetManager对象的初始化工作。

2.1 ContextImpl()

	private ContextImpl(ContextImpl container, ActivityThread mainThread,
            LoadedApk packageInfo, IBinder activityToken, UserHandle user, int flags,
            Display display, Configuration overrideConfiguration, int createDisplayWithId) {
		mOuterContext = this;
		.....
		mPackageInfo = packageInfo;
		Resources resources = packageInfo.getResources(mainThread);// 调用LoadedApk对象的getResource方法，见2.2
		.....
        mResources = resources;
		......
	}

参数packageInfo指向的是一个LoadedApk对象，这个LoadedApk对象描述的是当前正在启动的Activity组所属的Apk。

2.2 LoadedApk.getResources()

	public Resources getResources(ActivityThread mainThread) {
        if (mResources == null) {
            mResources = mainThread.getTopLevelResources(mResDir, mSplitResDirs, mOverlayDirs,
                    mApplicationInfo.sharedLibraryFiles, Display.DEFAULT_DISPLAY, this);// 调用ActivityThread的getTopLevelResources方法，见2.3
        }
        return mResources;
    }

参数mainThread指向了一个ActivityThread对象，这个ActivityThread对象描述的是当前正在运行的应用程序进程。

参数mResDir指定要获取Resource对象所对应的Apk文件路径。

LoadedApk类的成员函数getResources首先检查其成员变量mResources的值是否等于null。如果不等于的话，那么就会将它所指向的是一个Resources对象返回给调用者，否则的话，就会调用参数mainThread所指向的一个ActivityThread对象的成员函数getTopLevelResources来获得这个Resources对象，然后再返回给调用者。


2.3 ActivityThread.getTopLevelResources()

	Resources getTopLevelResources(String resDir, String[] splitResDirs, String[] overlayDirs,
            String[] libDirs, int displayId, LoadedApk pkgInfo) {
        return mResourcesManager.getResources(null, resDir, splitResDirs, overlayDirs, libDirs,
                displayId, null, pkgInfo.getCompatibilityInfo(), pkgInfo.getClassLoader());// 调用ResourceManager的getResources方法，见2.4
    }

在该方法中，主要是调用ResourceManager的getResources方法来获取一个Resources对象。

2.4 ResourceManager.getResources()

	public @Nullable Resources getResources(@Nullable IBinder activityToken,
            @Nullable String resDir,
            @Nullable String[] splitResDirs,
            @Nullable String[] overlayDirs,
            @Nullable String[] libDirs,
            int displayId,
            @Nullable Configuration overrideConfig,
            @NonNull CompatibilityInfo compatInfo,
            @Nullable ClassLoader classLoader) {
        try {
            Trace.traceBegin(Trace.TRACE_TAG_RESOURCES, "ResourcesManager#getResources");
            final ResourcesKey key = new ResourcesKey(
                    resDir,
                    splitResDirs,
                    overlayDirs,
                    libDirs,
                    displayId,
                    overrideConfig != null ? new Configuration(overrideConfig) : null, // Copy
                    compatInfo);//创建一个ResourcesKey对象
            classLoader = classLoader != null ? classLoader : ClassLoader.getSystemClassLoader();//获取ClassLoader对象
            return getOrCreateResources(activityToken, key, classLoader);//调用getOrCreateResources方法，见2.5
        } finally {
            Trace.traceEnd(Trace.TRACE_TAG_RESOURCES);
        }
    }

该方法获取或创建一个新的与activityToken相关联的Resources对象。Resources对象可以与Activity存活一样长的时间，那就意味着，Resource对象可以被缓存和重复使用，即使配置信息发生了变化。

如果ClassLoader参数发生了变化，则将返回一个新创建的Resource对象。

如果activityToken为null，则缓存的Resource对象将被返回，如果输入参数满足条件。否则的话，将根据输入参数创建一个新的Resource对象。

2.5 ResourceManager.getOrCreateResources()

	private @Nullable Resources getOrCreateResources(@Nullable IBinder activityToken,
            @NonNull ResourcesKey key, @NonNull ClassLoader classLoader) {
		synchronized (this) {

            if (activityToken != null) {// 1.获取Activity组件对应的资源文件
                final ActivityResources activityResources =
                        getOrCreateActivityResourcesStructLocked(activityToken);

                // Clean up any dead references so they don't pile up.
                ArrayUtils.unstableRemoveIf(activityResources.activityResources,
                        sEmptyReferencePredicate);

                // Rebase the key's override config on top of the Activity's base override.
                if (key.hasOverrideConfiguration()
                        && !activityResources.overrideConfig.equals(Configuration.EMPTY)) {
                    final Configuration temp = new Configuration(activityResources.overrideConfig);
                    temp.updateFrom(key.mOverrideConfiguration);
                    key.mOverrideConfiguration.setTo(temp);
                }

                ResourcesImpl resourcesImpl = findResourcesImplForKeyLocked(key);
                if (resourcesImpl != null) {
                    return getOrCreateResourcesForActivityLocked(activityToken, classLoader,
                            resourcesImpl);
                }

                // We will create the ResourcesImpl object outside of holding this lock.

            } else {
                // Clean up any dead references so they don't pile up.
                ArrayUtils.unstableRemoveIf(mResourceReferences, sEmptyReferencePredicate);

                // Not tied to an Activity, find a shared Resources that has the right ResourcesImpl
                ResourcesImpl resourcesImpl = findResourcesImplForKeyLocked(key);//获取指定key对应的缓存ResourceImpl对象
                if (resourcesImpl != null) {
                    return getOrCreateResourcesLocked(classLoader, resourcesImpl);
                }

                // We will create the ResourcesImpl object outside of holding this lock.
            }
        }

        // If we're here, we didn't find a suitable ResourcesImpl to use, so create one now.
		// 如果执行到这里，说明没有找到一个合适的ResourcesImpl对象，我们需要自己创建一个
        ResourcesImpl resourcesImpl = createResourcesImpl(key);//根据key创建一个ResourcesImpl对象，见2.6
        if (resourcesImpl == null) {
            return null;
        }

        synchronized (this) {
            ResourcesImpl existingResourcesImpl = findResourcesImplForKeyLocked(key);
            if (existingResourcesImpl != null) {
                resourcesImpl.getAssets().close();
                resourcesImpl = existingResourcesImpl;
            } else {
                // Add this ResourcesImpl to the cache.
                mResourceImpls.put(key, new WeakReference<>(resourcesImpl));// 添加到缓存中
            }

            final Resources resources;
            if (activityToken != null) {
                resources = getOrCreateResourcesForActivityLocked(activityToken, classLoader,
                        resourcesImpl);
            } else {
                resources = getOrCreateResourcesLocked(classLoader, resourcesImpl);//调用getOrCreateResourcesLocked方法，见2.13
            }
            return resources;
        }
	}

在该方法中，主要是先判断是获取是Activity组件相关联的Resources对象，还是获取全局应用的Resources对象。接着，根据key去缓存中查询，是否已经存在了ResourceImpl对象，如果存在，则直接返回ResourceImpl对象，并准备继续创建Resource对象。如果缓存中没有ResourcesImpl对象，则先创建一个ResourcesImpl对象，并把存入到缓存中，然后继续创建Resources对象。

创建ResourcesImpl对象的流程如下：

2.6 ResourcesManager.createResourcesImpl()

	private @Nullable ResourcesImpl createResourcesImpl(@NonNull ResourcesKey key) {
        final DisplayAdjustments daj = new DisplayAdjustments(key.mOverrideConfiguration);
        daj.setCompatibilityInfo(key.mCompatInfo);

        final AssetManager assets = createAssetManager(key);// 创建AssetManager对象，见2.7
        if (assets == null) {
            return null;
        }

        final DisplayMetrics dm = getDisplayMetrics(key.mDisplayId, daj);//获取屏幕显示的配置
        final Configuration config = generateConfig(key, dm);//创建配置信息
        final ResourcesImpl impl = new ResourcesImpl(assets, dm, config, daj);// 创建ResourceImpl对象
        return impl;
    } 

	public ResourcesImpl(@NonNull AssetManager assets, @Nullable DisplayMetrics metrics,
            @Nullable Configuration config, @NonNull DisplayAdjustments displayAdjustments) {
        mAssets = assets;
        mMetrics.setToDefaults();
        mDisplayAdjustments = displayAdjustments;
        updateConfiguration(config, metrics, displayAdjustments.getCompatibilityInfo());//更新配置信息，见2.14
        mAssets.ensureStringBlocks();
    }

在创建ResourcesImpl对象的过程中，首先会创建AssetManager对象、DisplayMetrics对象、Configuration对象，然后通过这些参数来创建ResourceImpl对象。

AssetManager对象的创建过程如下：

2.7 ResourcesManager.createAssetManager()

	protected @Nullable AssetManager createAssetManager(@NonNull final ResourcesKey key) {
        AssetManager assets = new AssetManager();// 创建一个AssetManager对象，见2.8

        if (key.mResDir != null) {//资源文件目录不为空
            if (assets.addAssetPath(key.mResDir) == 0) {//将APK资源文件目录添加到assetManager中
                Log.e(TAG, "failed to add asset path " + key.mResDir);
                return null;
            }
        }

        if (key.mSplitResDirs != null) {
            for (final String splitResDir : key.mSplitResDirs) {
                if (assets.addAssetPath(splitResDir) == 0) {
                    Log.e(TAG, "failed to add split asset path " + splitResDir);
                    return null;
                }
            }
        }

        if (key.mOverlayDirs != null) {
            for (final String idmapPath : key.mOverlayDirs) {
                assets.addOverlayPath(idmapPath);
            }
        }

        if (key.mLibDirs != null) {
            for (final String libDir : key.mLibDirs) {
                if (libDir.endsWith(".apk")) {
                    if (assets.addAssetPathAsSharedLibrary(libDir) == 0) {
                        Log.w(TAG, "Asset path '" + libDir +
                                "' does not exist or contains no resources.");
                    }
                }
            }
        }
        return assets;
    }

该方法的主要作用是创建一个AssetManager对象，并把Apk的资源文件路径添加的AssetManager中。

2.8 AssetManager()

	public AssetManager() {
        synchronized (this) {
           	......
            init(false);// 完成初始化工作，见2.10
            ensureSystemAssets();//创建一个访问系统资源的AssetManager对象，见2.9
        }
    }

AssetManager类的构造函数是通过调用另外一个成员函数init来执行初始化工作的。在初始化完成当前正在创建的AssetManager对象之后，AssetManager类的构造函数还会调用另外一个成员函数ensureSystemAssets来检查当前进程是否已经创建了一个用来访问系统资源的AssetManager对象。

2.9 AssetManager.ensureSystemAssets()

	private static void ensureSystemAssets() {
        synchronized (sSync) {
            if (sSystem == null) {
                AssetManager system = new AssetManager(true);//访问系统的AssetManager对象
                system.makeStringBlocks(null);
                sSystem = system;
            }
        }
    }

	private AssetManager(boolean isSystem) {
        init(true)；// 调用init方法进行初始化操作
    }

如果用来访问系统资源的AssetManager对象还没有创建的话，那么AssetManager类的成员函数ensureSystemAssets就会创建并且初始化它，并且将它保存在AssetManager类的静态成员变量sSystem中。注意，创建用来访问系统资源和应用程序资源的AssetManager对象的过程是一样的，区别只在于它们所要访问的Apk文件不一样，系统的资源打包在/system/framework/framework-res.apk文件中。

2.10 AssetManager.init()

	private native final void init(boolean isSystem);

AssetManager类的成员函数init是一个JNI函数，它是由C++层的函数android_content_AssetManager_init来实现的，该方法定义在android_util_AssetManager.cpp文件中。

	static void android_content_AssetManager_init(JNIEnv* env, jobject clazz, jboolean isSystem)
	{
    	if (isSystem) {
        	verifySystemIdmaps();
    	}
    	AssetManager* am = new AssetManager();//创建一个AssetManager对象
    	if (am == NULL) {
        	jniThrowException(env, "java/lang/OutOfMemoryError", "");
        	return;
    	}

    	am->addDefaultAssets();// 添加默认资源路径，见2.11

    	ALOGV("Created AssetManager %p for Java object %p\n", am, clazz);
    	env->SetLongField(clazz, gAssetManagerOffsets.mObject, reinterpret_cast<jlong>(am));//设置Java层AssetManager对象中成员变量mObject
	}

函数android_content_AssetManager_init首先创建一个C++层的AssetManager对象，接着调用这个C++层的AssetManager对象的成员函数addDefaultAssets来添加默认的资源路径，最后将这个这个C++层的AssetManager对象的地址保存在参数clazz所描述的一个Java层的AssetManager对象的成员变量mObject中。

2.11 AssetManager.addDefaultAssets()

	bool AssetManager::addDefaultAssets()
	{
    	const char* root = getenv("ANDROID_ROOT");// 获取系统路径
    	
    	String8 path(root);
    	path.appendPath(kSystemAssets);//系统资源的绝对路径

    	return addAssetPath(path, NULL, false /* appAsLib */, true /* isSystemAsset */);// 添加资源路径，见2.12
	}

	static const char* kSystemAssets = "framework/framework-res.apk";

AssetManager类的成员函数addDefaultAssets首先通过环境变量ANDROID_ROOT来获得Android的系统路径，接着再将全局变量kSystemAssets所指向的字符串“framework/framework-res.apk”附加到这个系统路径的后面去，这样就可以得到系统资源文件framework-res.apk的绝对路径了。一般来说，环境变量ANDROID_ROOT所设置的Android系统路径就是“/system”，因此，最终得到的系统资源文件的绝对路径就为“/system/framework/framework-res.apk”。

得到了系统资源文件framework-res.apk的绝对路径之后，就调用AssetManager类的成员函数addAssetPath来将它添加到当前正在初始化的AssetManager对象中去。

2.12 AssetManager.addAssetPath()

	bool AssetManager::addAssetPath(
        const String8& path, int32_t* cookie, bool appAsLib, bool isSystemAsset)
	{
		AutoMutex _l(mLock);
    	asset_path ap;
    	String8 realPath(path);
		if (kAppZipName) {
        	realPath.appendPath(kAppZipName);
    	}
		
		ap.type = ::getFileType(realPath.string());//获取资源路径的类型，是一个文件还是一个目录
    	if (ap.type == kFileTypeRegular) {
        	ap.path = realPath;
    	} else {
        	ap.path = path;
        	ap.type = ::getFileType(path.string());
        	if (ap.type != kFileTypeDirectory && ap.type != kFileTypeRegular) {
            	ALOGW("Asset path %s is neither a directory nor file (type=%d).",
                 	path.string(), (int)ap.type);
            	return false;//文件或目录不存在，直接返回
        	}
    	}

		for (size_t i=0; i<mAssetPaths.size(); i++) {
        	if (mAssetPaths[i].path == ap.path) {
            	if (cookie) {
                	*cookie = static_cast<int32_t>(i+1);
            	}
            	return true;
        	}
    	}

		ap.isSystemAsset = isSystemAsset;
    	mAssetPaths.add(ap);

		if (cookie) {
        	*cookie = static_cast<int32_t>(mAssetPaths.size());
    	}

		if (mResources != NULL) {
        	appendPathToResTable(ap, appAsLib);
    	}

    	return true;
	}

如果全局变量kAppZipName的值不等于NULL的话，那么它的值一般就是被设置为“classes.jar”，这时候就表示应用程序的资源文件是保存在参数path所描述的一个目录下的一个classes.jar文件中。全局变量kAppZipName的值一般被设置为NULL，并且参数path指向的是一个Apk文件，因此，接下来我们只考虑应用程序资源不是保存在一个classes.jar文件的情况。

AssetManager类的成员函数addAssetPath首先是要检查参数path指向的是一个文件或者目录，并且判断该文件或者目录存在，否则的话，它就会直接返回一个false值，而不会再继续往下处理了。

接着再检查其成员变量mAssetPaths所描述的一个类型为asset_path的Vector中是否已经添加过参数path所描述的一个Apk文件路径了。如果已经添加过了，那么AssetManager类的成员函数addAssetPath就不会再继续往下处理了，而是将与参数path所描述的一个Apk文件路径所对应的一个Cookie返回给调用者，即保存在输出参数cookie中，前提是参数cookie的值不等于NULL。一个Apk文件路径所对应的Cookie实际上只是一个整数，这个整数表示该Apk文件路径所对应的一个asset_path对象在成员变量mAssetPaths所描述的一个Vector中的索引再加上1。

经过上面的检查之后，AssetManager类的成员函数addAssetPath确保参数path所描述的一个Apk文件路径之前没有被添加过，于是接下来就会将与该Apk文件路径所对应的一个asset_path对象保存在成员变量mAssetPaths所描述的一个Vector的最末尾位置上，并且将这时候得到的Vector的大小作为一个Cookie值保存在输出参数cookie中返回给调用者。

返回到2.5步骤中，当创建完ResourceImpl对象之后，接着调用ResourceManager类的getOrCreateResourcesLocked()方法创建一个Resources对象。

2.13 ResourceManager.getOrCreateResourcesLocked()

	private @NonNull Resources getOrCreateResourcesLocked(@NonNull ClassLoader classLoader,
            @NonNull ResourcesImpl impl) {
        // Find an existing Resources that has this ResourcesImpl set.
        final int refCount = mResourceReferences.size();
        for (int i = 0; i < refCount; i++) {
            WeakReference<Resources> weakResourceRef = mResourceReferences.get(i);
            Resources resources = weakResourceRef.get();
			// 如果ClassLoader和ResourceImpl对应的Resources对象存在，则直接返回
            if (resources != null &&
                    Objects.equals(resources.getClassLoader(), classLoader) &&
                    resources.getImpl() == impl) {
                return resources;
            }
        }

        // Create a new Resources reference and use the existing ResourcesImpl object.
        Resources resources = new Resources(classLoader);//创建一个新的Resources对象
        resources.setImpl(impl);//将ResourcesImpl对象与Resources对象关联
        mResourceReferences.add(new WeakReference<>(resources));//添加到引用数组中
        return resources;
    }

该方法的主要作用是先查询ResourcesImpl对象和ClassLoader对象对应的Resources对象是否存在，如果存在，则直接返回。否则的话，先创建一个Resources对象，然后将ResourcesImpl对象与Resources对象进行关联，最后返回resources对象。


这样Resources对象以及AssetManager对象都初始化完成了。

2.14 ResourcesImpl.updateConfiguration()

	public void updateConfiguration(Configuration config, DisplayMetrics metrics,
                                    CompatibilityInfo compat) {
		synchronized (mAccessLock) {
			if (compat != null) {
                mDisplayAdjustments.setCompatibilityInfo(compat);
            }
            if (metrics != null) {
                mMetrics.setTo(metrics);
            }

			mDisplayAdjustments.getCompatibilityInfo().applyToDisplayMetrics(mMetrics);

            final @Config int configChanges = calcConfigChanges(config);

			LocaleList locales = mConfiguration.getLocales();
            if (locales.isEmpty()) {
                locales = LocaleList.getDefault();
                mConfiguration.setLocales(locales);
            }

			if ((configChanges & ActivityInfo.CONFIG_LOCALE) != 0) {
                    if (locales.size() > 1) {
                        // The LocaleList has changed. We must query the AssetManager's available
                        // Locales and figure out the best matching Locale in the new LocaleList.
                        String[] availableLocales = mAssets.getNonSystemLocales();
                        if (LocaleList.isPseudoLocalesOnly(availableLocales)) {
                            // No app defined locales, so grab the system locales.
                            availableLocales = mAssets.getLocales();
                            if (LocaleList.isPseudoLocalesOnly(availableLocales)) {
                                availableLocales = null;
                            }
                        }

                        if (availableLocales != null) {
                            final Locale bestLocale = locales.getFirstMatchWithEnglishSupported(
                                    availableLocales);
                            if (bestLocale != null && bestLocale != locales.get(0)) {
                                mConfiguration.setLocales(new LocaleList(bestLocale, locales));
                            }
                        }
                    }
                }

			if (mConfiguration.densityDpi != Configuration.DENSITY_DPI_UNDEFINED) {
                    mMetrics.densityDpi = mConfiguration.densityDpi;
                    mMetrics.density =
                            mConfiguration.densityDpi * DisplayMetrics.DENSITY_DEFAULT_SCALE;
                }
                mMetrics.scaledDensity = mMetrics.density * mConfiguration.fontScale;

                final int width, height;
                if (mMetrics.widthPixels >= mMetrics.heightPixels) {
                    width = mMetrics.widthPixels;
                    height = mMetrics.heightPixels;
                } else {
                    //noinspection SuspiciousNameCombination
                    width = mMetrics.heightPixels;
                    //noinspection SuspiciousNameCombination
                    height = mMetrics.widthPixels;
                }

			 final int keyboardHidden;
                if (mConfiguration.keyboardHidden == Configuration.KEYBOARDHIDDEN_NO
                        && mConfiguration.hardKeyboardHidden
                        == Configuration.HARDKEYBOARDHIDDEN_YES) {
                    keyboardHidden = Configuration.KEYBOARDHIDDEN_SOFT;
                } else {
                    keyboardHidden = mConfiguration.keyboardHidden;
                }

                mAssets.setConfiguration(mConfiguration.mcc, mConfiguration.mnc,
                        adjustLanguageTag(mConfiguration.getLocales().get(0).toLanguageTag()),
                        mConfiguration.orientation,
                        mConfiguration.touchscreen,
                        mConfiguration.densityDpi, mConfiguration.keyboard,
                        keyboardHidden, mConfiguration.navigation, width, height,
                        mConfiguration.smallestScreenWidthDp,
                        mConfiguration.screenWidthDp, mConfiguration.screenHeightDp,
                        mConfiguration.screenLayout, mConfiguration.uiMode,
                        Build.VERSION.RESOURCES_SDK_INT);//调用AssetManager的setConfiguration()方法
				mDrawableCache.onConfigurationChange(configChanges);
                mColorDrawableCache.onConfigurationChange(configChanges);
                mComplexColorCache.onConfigurationChange(configChanges);
                mAnimatorCache.onConfigurationChange(configChanges);
                mStateListAnimatorCache.onConfigurationChange(configChanges);

                flushLayoutCache();
		}
		synchronized (sSync) {
                if (mPluralRule != null) {
                    mPluralRule = PluralRules.forLocale(mConfiguration.getLocales().get(0));
                }
            }
		}
	}

ResourcesImpl类的成员变量mConfiguration指向的是一个Configuration对象，用来描述**设备当前的配置信息**，这些配置信息对应的就是18个资源维度。

Resources类的成员函数updateConfiguration首先是根据参数config和metrics来更新设备的当前配置信息，例如，屏幕大小和密码、国家地区和语言、键盘配置情况等等，接着再调用成员变量mAssets所指向的一个Java层的AssetManager对象的成员函数setConfiguration来将这些配置信息设置到与之关联的C++层的AssetManager对象中去。

至此，我们就分析完成Android应用程序资源管理器的创建的初始化过程了，主要就是**创建和初始化用来访问应用程序资源的AssetManager对象和Resources对象**，其中，初始化操作包括**设置AssetManager对象的资源文件路径以及设备配置信息**等。





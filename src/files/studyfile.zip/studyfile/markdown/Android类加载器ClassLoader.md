## Android类加载器

[TOC]

### 1.概述

Android从5.0开始就采用art虚拟机, 该虚拟机有些类似Java虚拟机, 程序运行过程也需要**通过ClassLoader 将目标类加载到内存**。

传统Jvm主要是通过读取**class字节码**来加载, 而art则是从**dex字节码**来读取. 这是一种更为优化的方案, 可以将**多个.class文件合并成一个classes.dex文件**. 下面直接来看看ClassLoader的关系。

#### 1.1Android类加载器的架构图

![Android类加载器框架图](http://orbohk5us.bkt.clouddn.com/17-7-6/32671714.jpg)


### 2.ClassLoader源码解析

#### 2.1 PathClassLoader源码解析
PathClassLoader提供了一个简单的ClassLoader实现，用来操作在**本地文件系统**中的文件和目录，不要尝试从网络中加载类。

Android使用**PathClassLoader来作为系统类加载器和应用类加载器**。

##### PathClassLoader构建
首先看下PathClassLoader的构造函数：

	//继承自BaseDexClassLoader
	public class PathClassLoader extends BaseDexClassLoader {
    /**
     * Creates a {@code PathClassLoader} that operates on a given list of files
     * and directories. This method is equivalent to calling
     * {@link #PathClassLoader(String, String, ClassLoader)} with a
     * {@code null} value for the second argument (see description there).
     *
     * @param dexPath the list of jar/apk files containing classes and
     * resources, delimited by {@code File.pathSeparator}, which
     * defaults to {@code ":"} on Android
     * @param parent the parent class loader
     */
	// PathClassLoader用来操作指定的文件和目录
    public PathClassLoader(String dexPath, ClassLoader parent) {
        super(dexPath, null, null, parent);
    }

    /**
     * Creates a {@code PathClassLoader} that operates on two given
     * lists of files and directories. The entries of the first list
     * should be one of the following:
     *
     * <ul>
     * <li>JAR/ZIP/APK files, possibly containing a "classes.dex" file as
     * well as arbitrary resources.
     * <li>Raw ".dex" files (not inside a zip file).
     * </ul>
     *
     * The entries of the second list should be directories containing
     * native library files.
     *
     * @param dexPath the list of jar/apk files containing classes and
     * resources, delimited by {@code File.pathSeparator}, which
     * defaults to {@code ":"} on Android
     * @param libraryPath the list of directories containing native
     * libraries, delimited by {@code File.pathSeparator}; may be
     * {@code null}
     * @param parent the parent class loader
     */
    public PathClassLoader(String dexPath, String libraryPath,
            ClassLoader parent) {
        super(dexPath, null, libraryPath, parent);
    }
    }

可以看到PathClassLoader的构造方法有四个参数：

- dexPath： 需要加载的JAR/APK/ZIP压缩文件，里面包含了“.dex”文件，以及任意的资源文件
- libraryPath： 包含本地库文件的目录
- parent： 父类加载器

PathClassLoader继承自BaseDexClassLoader，接下来看BaseDexClassLoader的实现：

	// 继承自ClassLoader
	public class BaseDexClassLoader extends ClassLoader {
    private final DexPathList pathList;

    /**
     * Constructs an instance.
     *
     * @param dexPath the list of jar/apk files containing classes and
     * resources, delimited by {@code File.pathSeparator}, which
     * defaults to {@code ":"} on Android
     * @param optimizedDirectory directory where optimized dex files
     * should be written; may be {@code null}
     * @param libraryPath the list of directories containing native
     * libraries, delimited by {@code File.pathSeparator}; may be
     * {@code null}
     * @param parent the parent class loader
     */
    public BaseDexClassLoader(String dexPath, File optimizedDirectory,
            String libraryPath, ClassLoader parent) {
		//调用ClassLoader的构造器
        super(parent);
		//构建DexPathList
        this.pathList = new DexPathList(this, dexPath, libraryPath, optimizedDirectory);
    }
	}

可以看到BaseDexClassLoader继承自ClassLoader，在构造器中调用了ClassLoader的构造方法，并且在构建的时候，创建了一个PathList。这个PathList用来保存需要加载文件的路径。

DexPathList里面包含了两个关于ClassLoader的List集合。一个List用来保存dex/resource路径；另外一个List用来保存本地代码库路径。

DexPathList包含了查找Class文件以及Resource文件的方法。

	final class DexPathList {
    private static final String DEX_SUFFIX = ".dex";
    private static final String zipSeparator = "!/";

    /** class definition context */
    private final ClassLoader definingContext;

    /**
     * List of dex/resource (class path) elements.
     * Should be called pathElements, but the Facebook app uses reflection
     * to modify 'dexElements' (http://b/7726934).
     */
    private final Element[] dexElements;//保存dex/resource元素

    /** List of native library path elements. */
    private final Element[] nativeLibraryPathElements;//native库路径元素

    /** List of application native library directories. */
    private final List<File> nativeLibraryDirectories;//应用native库目录

    /** List of system native library directories. */
    private final List<File> systemNativeLibraryDirectories;//系统native库目录
	
	 /**
     * Constructs an instance.
     *
     * @param definingContext the context in which any as-yet unresolved
     * classes should be defined
     * @param dexPath list of dex/resource path elements, separated by
     * {@code File.pathSeparator}
     * @param libraryPath list of native library directory path elements,
     * separated by {@code File.pathSeparator}
     * @param optimizedDirectory directory where optimized {@code .dex} files
     * should be found and written to, or {@code null} to use the default
     * system directory for same
     */
    public DexPathList(ClassLoader definingContext, String dexPath,
            String libraryPath, File optimizedDirectory) {
		//参数检查
        if (definingContext == null) {
            throw new NullPointerException("definingContext == null");
        }

        if (dexPath == null) {
            throw new NullPointerException("dexPath == null");
        }

        if (optimizedDirectory != null) {
            if (!optimizedDirectory.exists())  {
                throw new IllegalArgumentException(
                        "optimizedDirectory doesn't exist: "
                        + optimizedDirectory);
            }

            if (!(optimizedDirectory.canRead()
                            && optimizedDirectory.canWrite())) {
                throw new IllegalArgumentException(
                        "optimizedDirectory not readable/writable: "
                        + optimizedDirectory);
            }
        }
		//将ClassLoader赋值
        this.definingContext = definingContext;

        ArrayList<IOException> suppressedExceptions = new ArrayList<IOException>();
        // save dexPath for BaseDexClassLoader
		//保存所有的dex文件
        this.dexElements = makePathElements(splitDexPath(dexPath), optimizedDirectory,
                                            suppressedExceptions);

        // Native libraries may exist in both the system and
        // application library paths, and we use this search order:
        //
        //   1. This class loader's library path for application libraries (libraryPath):
        //   1.1. Native library directories
        //   1.2. Path to libraries in apk-files
        //   2. The VM's library path from the system property for system libraries
        //      also known as java.library.path
        //
        // This order was reversed prior to Gingerbread; see http://b/2933456.
		//记录app的native动态库
        this.nativeLibraryDirectories = splitPaths(libraryPath, false);
		//记录系统的native动态库
        this.systemNativeLibraryDirectories =
                splitPaths(System.getProperty("java.library.path"), true);
        List<File> allNativeLibraryDirectories = new ArrayList<>(nativeLibraryDirectories);
        allNativeLibraryDirectories.addAll(systemNativeLibraryDirectories);
		
		//记录所有的native动态库
        this.nativeLibraryPathElements = makePathElements(allNativeLibraryDirectories, null,
                                                          suppressedExceptions);
        if (suppressedExceptions.size() > 0) {
            this.dexElementsSuppressedExceptions =
                suppressedExceptions.toArray(new IOException[suppressedExceptions.size()]);
        } else {
            dexElementsSuppressedExceptions = null;
        }
    }
	}

在构建DexPathList类的时候，会用两个List去记录dex文件以及native动态库文件。他们都是封装成一个Element元素，添加到一个List集合中。添加到集合的方法是makePathElements方法，在DexPathList中实现：

	/**
     * Makes an array of dex/resource path elements, one per element of
     * the given array.
     */
    private static Element[] makePathElements(List<File> files, File optimizedDirectory,
                                              List<IOException> suppressedExceptions) {
		// 创建一个Element数组
        List<Element> elements = new ArrayList<>();
        /*
         * Open all files and load the (direct or contained) dex files
         * up front.
         */
		//加载目录中的所有文件
        for (File file : files) {
            File zip = null;
            File dir = new File("");
            DexFile dex = null;
            String path = file.getPath();//获取文件的路径
            String name = file.getName();//获取文件的名字

            if (path.contains(zipSeparator)) {
                String split[] = path.split(zipSeparator, 2);
                zip = new File(split[0]);
                dir = new File(split[1]);
			// 处理目录元素
            } else if (file.isDirectory()) {
                // We support directories for looking up resources and native libraries.
                // Looking up resources in directories is useful for running libcore tests.
                elements.add(new Element(file, true, null, null));
			// 处理文件元素
            } else if (file.isFile()) {
				//如果文件是以.dex文件结尾的，则直接加载原始的.dex文件
                if (name.endsWith(DEX_SUFFIX)) {
                    // Raw dex file (not inside a zip/jar).
                    try {
                        dex = loadDexFile(file, optimizedDirectory);
                    } catch (IOException ex) {
                        System.logE("Unable to load dex file: " + file, ex);
                    }
                } else {//处理压缩文件元素
                    zip = file;

                    try {
                        dex = loadDexFile(file, optimizedDirectory);
                    } catch (IOException suppressed) {
                        /*
                         * IOException might get thrown "legitimately" by the DexFile constructor if
                         * the zip file turns out to be resource-only (that is, no classes.dex file
                         * in it).
                         * Let dex == null and hang on to the exception to add to the tea-leaves for
                         * when findClass returns null.
                         */
                        suppressedExceptions.add(suppressed);
                    }
                }
            } else {
                System.logW("ClassLoader referenced unknown path: " + file);
            }
			//将dex文件和压缩文件添加到Element集合中
            if ((zip != null) || (dex != null)) {
                elements.add(new Element(dir, false, zip, dex));
            }
        }
		//返回Element集合数组
        return elements.toArray(new Element[elements.size()]);
    }
	
在dex文件以及native动态库文件添加List集合中，借助了一个Element类，来表示元素的相关信息。Element是DexPathList中的一个内部类，定义如下：

	 /**
     * Element of the dex/resource file path
     */
     /*package*/ static class Element {
        private final File dir;//目录文件
        private final boolean isDirectory;//是否为目录
        private final File zip;//压缩文件
        private final DexFile dexFile;//dex文件

        private ZipFile zipFile;
        private boolean initialized;

        public Element(File dir, boolean isDirectory, File zip, DexFile dexFile) {
            this.dir = dir;
            this.isDirectory = isDirectory;
            this.zip = zip;
            this.dexFile = dexFile;
        }

在DexPathList类中的makePathElements方法中，会调用loadDexFile方法来创建DexFile对象。

	 /**
     * Constructs a {@code DexFile} instance, as appropriate depending
     * on whether {@code optimizedDirectory} is {@code null}.
     */
    private static DexFile loadDexFile(File file, File optimizedDirectory)
            throws IOException {
        if (optimizedDirectory == null) {
            return new DexFile(file);
        } else {
            String optimizedPath = optimizedPathFor(file, optimizedDirectory);
            return DexFile.loadDex(file.getPath(), optimizedPath, 0);
        }
    }

DexFile用来管理dex文件，定义如下：

	public final class DexFile {
    	private Object mCookie;
    	private final String mFileName;//文件路径
    	private final CloseGuard guard = CloseGuard.get();

    /**
     * Opens a DEX file from a given File object. This will usually be a ZIP/JAR
     * file with a "classes.dex" inside.
     *
     * The VM will generate the name of the corresponding file in
     * /data/dalvik-cache and open it, possibly creating or updating
     * it first if system permissions allow.  Don't pass in the name of
     * a file in /data/dalvik-cache, as the named file is expected to be
     * in its original (pre-dexopt) state.
     *
     * @param file
     *            the File object referencing the actual DEX file
     *
     * @throws IOException
     *             if an I/O error occurs, such as the file not being found or
     *             access rights missing for opening it
     */
    public DexFile(File file) throws IOException {
        this(file.getPath());
    }

    /**
     * Opens a DEX file from a given filename. This will usually be a ZIP/JAR
     * file with a "classes.dex" inside.
     *
     * The VM will generate the name of the corresponding file in
     * /data/dalvik-cache and open it, possibly creating or updating
     * it first if system permissions allow.  Don't pass in the name of
     * a file in /data/dalvik-cache, as the named file is expected to be
     * in its original (pre-dexopt) state.
     *
     * @param fileName
     *            the filename of the DEX file
     *
     * @throws IOException
     *             if an I/O error occurs, such as the file not being found or
     *             access rights missing for opening it
     */
    public DexFile(String fileName) throws IOException {
        mCookie = openDexFile(fileName, null, 0);//打开dex文件
        mFileName = fileName;
        guard.open("close");
        //System.out.println("DEX FILE cookie is " + mCookie + " fileName=" + fileName);
    }

	/*
     * Open a DEX file.  The value returned is a magic VM cookie.  On
     * failure, an IOException is thrown.
     */
    private static Object openDexFile(String sourceName, String outputName, int flags) throws IOException {
        // Use absolute paths to enable the use of relative paths when testing on host.
		// 调用本地方法打开Dex文件
        return openDexFileNative(new File(sourceName).getAbsolutePath(),
                                 (outputName == null) ? null : new File(outputName).getAbsolutePath(),
                                 flags);
    }

至此，创建完了PathClassLoader类，在创建PathClassLoader对象的同时，会去创建DexPathList，里面包含了两个List集合，分别包含了dex文件信息以及native动态库文件信息。

##### 查找class

在创建完PathClassLoader后，可以通过findClass方法来加载指定名字对应的class文件。该方法定义在PathClassLoader类的父类BaseDexClassLoader类中，具体是通过findClass方法来实现。

	@Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        List<Throwable> suppressedExceptions = new ArrayList<Throwable>();
		//调用DexpathList中的findClass方法，DexPathList在创建PathClassLoader时被初始化
        Class c = pathList.findClass(name, suppressedExceptions);
		//如果没有找到该类，抛出异常
        if (c == null) {
            ClassNotFoundException cnfe = new ClassNotFoundException("Didn't find class \"" + name + "\" on path: " + pathList);
            for (Throwable t : suppressedExceptions) {
                cnfe.addSuppressed(t);
            }
            throw cnfe;
        }
        return c;
    }

在DexPathList中实现了findClass方法，具体如下：

	 /**
     * Finds the named class in one of the dex files pointed at by
     * this instance. This will find the one in the earliest listed
     * path element. If the class is found but has not yet been
     * defined, then this method will define it in the defining
     * context that this instance was constructed with.
     *
     * @param name of class to find
     * @param suppressed exceptions encountered whilst finding the class
     * @return the named class or {@code null} if the class is not
     * found in any of the dex files
     */
	//按顺序来查找dex文件，看是否存在class类
    public Class findClass(String name, List<Throwable> suppressed) {
		// 遍历dexElements集合，里面保存了dex元素
        for (Element element : dexElements) {
            DexFile dex = element.dexFile;//获取dex文件

            if (dex != null) {
				//通过DexFile的loadClassBinaryName方法来查找class
                Class clazz = dex.loadClassBinaryName(name, definingContext, suppressed);
                if (clazz != null) {
                    return clazz;
                }
            }
        }
        if (dexElementsSuppressedExceptions != null) {
            suppressed.addAll(Arrays.asList(dexElementsSuppressedExceptions));
        }
        return null;
    }

在DexFile中实现了loadClassBinaryName方法，具体如下：

	/**
     * See {@link #loadClass(String, ClassLoader)}.
     *
     * This takes a "binary" class name to better match ClassLoader semantics.
     *
     * @hide
     */
    public Class loadClassBinaryName(String name, ClassLoader loader, List<Throwable> suppressed) {
        return defineClass(name, loader, mCookie, suppressed);
    }

	private static Class defineClass(String name, ClassLoader loader, Object cookie,
                                     List<Throwable> suppressed) {
        Class result = null;
        try {
			//调用本地方法来查找class，loader为definingContext，在创建PathClassLoader时，被赋值为BaseDexClassLoader
            result = defineClassNative(name, loader, cookie);
        } catch (NoClassDefFoundError e) {
            if (suppressed != null) {
                suppressed.add(e);
            }
        } catch (ClassNotFoundException e) {
            if (suppressed != null) {
                suppressed.add(e);
            }
        }
        return result;
    }
	
	// 本地方法，加载类
	private static native Class defineClassNative(String name, ClassLoader loader, Object cookie)
            throws ClassNotFoundException, NoClassDefFoundError;

可以看到查找class的过程是从dex文件集合中，顺序查找dex文件中是否有定义class文件，如果有则直接返回。也就是说，如果一个class在多个dex文件中有定义的话，返回的是前面dex文件包含的class文件。

	static jclass DexFile_defineClassNative(JNIEnv* env, jclass, jstring javaName, jobject javaLoader,
                                        jobject cookie) {
  		std::unique_ptr<std::vector<const DexFile*>> dex_files = ConvertJavaArrayToNative(env, cookie);
  		if (dex_files.get() == nullptr) {
    	return nullptr; //dex文件为空, 则直接返回
  		}

  		ScopedUtfChars class_name(env, javaName);
  		if (class_name.c_str() == nullptr) {
    	return nullptr; //类名为空, 则直接返回
  		}

  		const std::string descriptor(DotToDescriptor(class_name.c_str()));
  		const size_t hash(ComputeModifiedUtf8Hash(descriptor.c_str())); //将类名转换为hash码
  		for (auto& dex_file : *dex_files) {
    	const DexFile::ClassDef* dex_class_def = dex_file->FindClassDef(descriptor.c_str(), hash);
    	if (dex_class_def != nullptr) {
      	ScopedObjectAccess soa(env);
      	ClassLinker* class_linker = Runtime::Current()->GetClassLinker();
      	class_linker->RegisterDexFile(*dex_file);
      	StackHandleScope<1> hs(soa.Self());
      	Handle<mirror::ClassLoader> class_loader(
          hs.NewHandle(soa.Decode<mirror::ClassLoader*>(javaLoader)));
      	//获取目标类
      	mirror::Class* result = class_linker->DefineClass(soa.Self(), descriptor.c_str(), hash,
                                                        class_loader, *dex_file, *dex_class_def);
      	if (result != nullptr) {
        	// 找到目标对象
        	return soa.AddLocalReference<jclass>(result);
      	}
    	}
  		}
  		return nullptr; //没有找到目标类
	}


#### 2.2 DexClassLoader类解析

DexClassLoader从.jar和.apk文件中包含的classes.dex加载class。这个可以用来执行那些不在应用程序中的代码。

DexClassLoader需要一个应用私有，可写入的目录来缓存优化后的class。通过使用Context.getCodeCacheDir()来创建一个目录。例如， File dexOutputDir = context.getCodeCacheDir();

注意，不要缓存优化后的class到外部存储中。外部存储不提供访问控制来保护应用遭受代码注入攻击。

DexClassLoader的构造函数如下：

	public class DexClassLoader extends BaseDexClassLoader {
    /**
     * Creates a {@code DexClassLoader} that finds interpreted and native
     * code.  Interpreted classes are found in a set of DEX files contained
     * in Jar or APK files.
     *
     * <p>The path lists are separated using the character specified by the
     * {@code path.separator} system property, which defaults to {@code :}.
     *
     * @param dexPath the list of jar/apk files containing classes and
     *     resources, delimited by {@code File.pathSeparator}, which
     *     defaults to {@code ":"} on Android
     * @param optimizedDirectory directory where optimized dex files
     *     should be written; must not be {@code null}
     * @param libraryPath the list of directories containing native
     *     libraries, delimited by {@code File.pathSeparator}; may be
     *     {@code null}
     * @param parent the parent class loader
     */
    public DexClassLoader(String dexPath, String optimizedDirectory,
            String libraryPath, ClassLoader parent) {
        super(dexPath, new File(optimizedDirectory), libraryPath, parent);
    }
	}

同样的，DexClassLoader也是继承BaseClassLoader，创建的过程和PathClassLoader过程一样。



### 3. 总结

- PathClassLoader: **主要用于系统和app的类加载器,其中optimizedDirectory为null, 采用默认目录/data/dalvik-cache/**


- DexClassLoader: **可以从包含classes.dex的jar或者apk中，加载类的类加载器, 可用于执行动态加载,但必须是app私有可写目录来缓存odex文件。 能够加载系统没有安装的apk或者jar文件， 因此很多插件化方案都是采用DexClassLoader;**


- BaseDexClassLoader: 比较基础的类加载器, PathClassLoader和DexClassLoader都只是在构造函数上对其简单封装而已。


参考：[Android类加载器ClassLoader](http://gityuan.com/2017/03/19/android-classloader/)





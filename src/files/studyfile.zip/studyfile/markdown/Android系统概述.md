## Android系统概述

[TOC]

> Android系统非常庞大、错综复杂，其底层是采用**Linux作为基底**，上层采用包括**虚拟机的Java层**及**Native层**，通过**系统调用(Syscall)**连通系统的**内核空间**和**用户空间**。用户空间主要采用C++和Java代码，通过**JNI技术**打通用户空间的**Java层**和**Native层(C/C++)**,从而融为一体。

Google官方提供了一张经典的四层架构图，从下往上一次分别为**Linux内核**、**系统库和Android运行时环境**、**框架层**以及**应用层**这4层架构，其中每一层都包含了大量的子模块或子系统。

![Android系统架构图](http://orbohk5us.bkt.clouddn.com/17-7-13/4376031.jpg)


### Android架构

以进程的视角来看Android系统启动过程

![Android系统启动过程](http://orbohk5us.bkt.clouddn.com/17-7-13/48675807.jpg)

Android系统的启动过程如下：

Loader——>kernel——>Native——>Framework——>App

#### 1.Loader层
- **Boot ROM**:当手机处于关机状态下时，长按Power键开机，引导芯片开始从固化在ROM里的预设代码开始执行，然后加载引导程序到RAM。
- **Boot Loader**： 这是启动Android系统之前的引导程序，主要是检查RAM，初始化硬件参数等功能。

#### 2.Kernel层

Kernel层是指Android内核层，到这里才刚刚开始进入Android系统。

- 启动Kernel的**swapper进程(pid=0)**：该进程又称为idle进程, 系统初始化过程Kernel由无到有开创的第一个进程, 用于初始化进程管理、内存管理，加载Display,Camera Driver，Binder Driver等相关工作；
- 启动**kthreadd进程（pid=2）**：是**Linux系统的内核进程**，会创建内核工作线程kworkder，软中断线程ksoftirqd，thermal等内核守护进程。**kthreadd进程是所有内核进程的鼻祖**。

#### 3.Native层

这里的Native层主要包括init孵化来的用户空间的**守护进程**、HAL层以及开机动画等。启动**init进程(pid=1),是Linux系统的用户进程，init进程是所有用户进程的鼻祖**。

- init进程会孵化出ueventd、logd、healthd、installd、adbd、lmkd等用户守护进程；
- init进程还启动servicemanager(binder服务管家)、bootanim(开机动画)等重要服务
- init进程孵化出Zygote进程，**Zygote进程是Android系统的第一个Java进程(即虚拟机进程)**，**Zygote是所有Java进程的父进程**，Zygote进程本身是由init进程孵化而来的。

#### 4.Framework层

- Zygote进程，是由init进程通过解析init.rc文件后fork生成的，Zygote进程主要包含：
	- 加载ZygoteInit类，注册Zygote Socket服务端套接字；
	- 加载虚拟机；
	- preloadClasses；
	- preloadResouces；

- System Server进程，是由Zygote进程fork而来，**System Server是Zygote孵化的第一个进程**，System Server负责启动和管理整个Java framework，包含ActivityManager，PowerManager等服务。
- Media Server进程，是由init进程fork而来，负责启动和管理整个C++ framework，包含AudioFlinger，Camera Service，等服务。

#### 5.App层

- Zygote进程孵化出的第一个App进程是Launcher，这是用户看到的桌面App；
- Zygote进程还会创建Browser，Phone，Email等App进程，每个App至少运行在一个进程上。
- 所有的App进程都是由Zygote进程fork生成的。

#### 6.Syscall && JNI

- Native与Kernel之间有一层系统调用(SysCall)层;
- Java层与Native(C/C++)层之间的纽带JNI。

### 总结
进程关系：

- **swapper进程(pid=0)**：启动Kernel的进程，第一个进程。
- **kthreadd进程（pid=2)**：Linux系统的内核进程，kthreadd进程是所有内核进程的鼻祖。
- **init进程(pid=1)**：Linux系统的用户进程，init进程是所有用户进程的鼻祖。
- **Zygote进程**：Zygote进程是Android系统的第一个Java进程(即虚拟机进程)，Zygote是所有Java进程的父进程，Zygote进程本身是由init进程孵化而来的。
- **System Server进程**：是由Zygote进程fork而来，System Server是Zygote孵化的第一个进程，System Server负责启动和管理整个Java framework。
- **Media Server进程**：是由init进程fork而来，负责启动和管理整个C++ framework。
- **Launcher进程**：Zygote进程孵化出的第一个App进程
- 所有的App进程都是由Zygote进程fork生成的。

## Android系统理解

-----

本质上说，Android是一个Linux系统，因此它是基于Linux内核开发的。但是Android与一般的Linux系统不同的是，它有着自己的一套独特的用户空间运行时，也就是我们通常说的**应用程序框架**。举个例子来说，以前很多基于Linux的嵌入式开发，就是移植一个Linux内核，然后再用Qt作为应用程序框架，这样一个系统就跑起来了。因此，将Qt应用程序框架替换为Android自己的应用程序框架，就得到了一个现代化的移动操作系统。

在Android应用程序框架中，包含了很多开源工程，例如浏览器用的内核WebKit、管理Wi-Fi网络的wap_supplicant、播放音乐视频的StageFright等，它们都是使用C/C\++来写的。而且Android系统专用的用来渲染UI的SurfaceFlinger、用来播放声音的AudioFlinger等，也是用C/C\++来写的。更不用提每一个应用程序都要使用到C库bionic、Dalvik虚拟机等了，它们都是用C/C++来写的。这些使用C/C\++写的服务，实现了最基本的功能。这些最基本的功能被在**Java层的提供的关键服务**所使用，例如组件管理服务ActivityManagerService、应用程序安装服务PackageManagerService、网络连接服务ConnectivityService等。最后，Android再封装了一套基于**Java语言的SDK**给开发者去使用那些实现在Java层的系统服务。

> 也就是说：**Android系统=Linux内核+Android用户空间运行时+ Android SDK**，而**Android用户空间运行时=C/C++ Runtime Framework + Java Runtime Framework**。很多情况下，我们调用Android SDK提供的一个API时，这个API调用会交给Java Runtime Framework处理，而Java Runtime Framework又继续将这个API调用交给C/C++ Runtime Framework处理，最后C/C++ Runtime Framework又有可能接着将这个API调用交给Linux内核来处理。

从上面的调用过程就可以看出，Java只是位于Android最上面的一层编程接口，而没有这一层编程接口Android也是可以正常运行的。我们知道，Android除了提供SDK外，还提供有NDK。也就是说，我们完全可以不使用SDK，而是通过NDK提供的接口绕过Java Runtime Framework，直接将请求交给C/C++Runtime Framework处理。

至于Android系统使用的Linux内核，其实与传统的Linux内核并无多大区别，甚至可以看成是一样的。要说真的区别，就是有两点。一是Android在传统的Linux内核中以**模块的形式**加入了一些专用的驱动，例如日志驱动Logger、匿名共享内存驱动Ashmem、进程间通信驱动Binder。二是Android系统将在传统的Linux内核实现的硬件驱动程序划分成了两部分，**一部分在内核实现，另一部分在用户空间实现**，也就是我们常说的**硬件抽象层HAL**。Android系统之所以要这样划分，是出于**商业考虑**，而不是技术考虑。因为**Linux内核使用的GPL许可协议**，**驱动全部放在内核实现就意味着需要全部开源代码**，而**用户空间使用的是Apache License，可以不开源代码**。通过这种方式，就可以保护厂家的商业利益，因为这些代码通常都会包含有硬件的相关参数。

-----

Android = Linux Kernel + C/C++ Runtime Framework + Davik Virtual Machine + Java Runtime Framework + Java SDK

下面我们再以APK的开发、编译、安装和运行来说明这些层次之间的关系。

首先，我们是在PC上使用Android SDK提供的接口来开发APK，用的Java语言。开发完成之后，使用Java编译器将源代码编译成**Java字节码**，也就是**带.class后缀的文件**。接下来这些.class再被Android SDK提供的**dx工具**转化成Dex字节码，最后打包在APK里面的**classes.dex**文件中。

接着，APK文件在手机上安装时，Java Runtime Framework里面的PacakgeManagerService就会对该APK文件进行解析，并且通过Socket IPC通知C/C++ Runtime Framework里面的installd守护进程对APK里面的classes.dex文件进行优化，得到另外一个**classes.odex**文件。

APK安装完成之后，就可以运行了。我们以APK从桌面Launcher启动的过程为例说明它的运行过程。当我们从Launcher点击应用图标的时候，Launcher向Java Runtime Framework里面的ActivityManagerService发送一个启动应用的请求。ActivityManagerService又通过Socket IPC向C/C++ Runtime Framework里面的zygote守护进程请求创建一个应用程序进程。这个应用程序进程包含有一个**Dalvik虚拟机**。应用程序进程创建并且启动起来之后，就会通过它里面的Dalvik虚拟机加载前面提到的classes.odex文件。这样我们的应用程序就运行起来了。

APK的运行过程是依赖于Dalvik虚拟机的。我们可以将它看成是将classes.odex里面的字节码解释成本地机器指令执行。例如，我们在APK里面通过FileInputStream或者FileOutputStream打开一个文件的时候，Dalvik虚拟机就会找到C/C++ Runtime Framework里面的C库bionic提供的系统接口open，并且通过它来打开指定的文件。

我们再以应用程序界面的绘制和渲染过程来详细说明各个层次的关系。首先是应用程序通过SDK提供的UI类向Java Runtime Framework里面的WindowManagerService申请分配一块**图形缓冲区**。WindowManagerService又是通过Binder IPC向C/C++ Runtime Framework里面的SurfaceFlinger申请分配图形缓冲区的。图形缓冲区实际上不是由SurfaceFlinger分配的，而是由显示系统分配的，可能在显存里面，也有可能在GPU里面。这时候SurfaceFlinger就要通过HAL层次Gralloc模块向Kernel里面的显卡或者GPU驱动申请分配真正的图形缓冲区。HAL层可以看作是运行在C/C++ Runtime Framework中。

应用程序得通过上述方式得到绘制UI所需要的图形缓冲区之后，就开始绘制自己的UI了。假设应用程序使用的是硬件绘制方式，也就是通过C/C++ Runtime Framework里面的OpenGL来**绘制**。这时候SDK的UI类的与绘制相关的函数调用通过Dalvik虚拟机都转化成了C/C++ Runtime Framework里面的OpenGL操作。

应用程序UI绘制完成之后，结果就保存上述的图形缓冲区中。这时候如果要将该图形缓冲区**渲染**到手机屏幕上，那么还需要通过Binder IPC将该图形缓冲区发送给C/C++ Runtime Framework里面的SurfaceFlinger。SurfaceFlinger通过使用**OpenGL或者HWComposer**将所有请求要渲染到手机屏幕上的图形缓冲区合成之后，得到一个**主图形缓冲区**。最后这个图形缓冲区又会被SurfaceFlinger提交给Kernel的显卡驱动，并且在手机屏幕上进行显示。

上面描述的就是Android系统各个层次的调用关系。总的来说，应用程序运行在Dalvik虚拟机上，并且通过SDK使用Java Runtime Framework里面的服务，而Java Runtime Framework里面的服务又通过C/C++ Runtime Framework里面的服务来实现自己的功能，最后C/C++ Runtime Framework里面的服务又会在需要的时候请求Kernel里面的模块或者驱动来为自己服务。







## Android进程启动流程
[TOC]

### 1.简介

在进程的创建的过程中，将涉及到system_server进程和Zygote进程，这两个进程的作用如下：

- system_server进程：system_server进程是用于管理整个Java Framework层，包含ActivityManager、WindowManager等各种系统服务；
- Zygote进程：Zygote进程是Android系统首个Java进程，Zygote进程是所有Java进程的父进程，包括system_server进程以及所有的App进程都是Zygote的子进程；

进程创建的大致流程：

发起进程(startActivity/startService) ——> system_server进程(Process.start) ——> Zygote进程(ZygoteInit.runSelectLoop) ——>新建进程(ActivityThread.main)

1. App发起进程：当从桌面启动应用，则发起进程就是Launcher所在进程，当从某App内启动远程进程，则发送进程便是该App所在进程。发起进程先通过**Binder**发送消息给system_server进程；
2. system_server进程：调用Process.start()方法，通过**socket**向zygote进程发送创建新进程的请求；
3. Zygote进程：在执行ZygoteInit.main()后便进入runSelectLoop()循环体内，当有客户端连接时，便会执行ZygoteConnection.runOnce()方法，再经过层层调用fork出新的应用进程；
4. 新进程：执行handleChildProc方法，最后调用ActivityThread.main()方法；

一个进程里面可以跑多个APP(通过share uid的方式)，一个APP也可以跑在多个进程里(通过配置android:process属性)。

### 2.四大组件与进程

Activity、Service、ContentProvider、BroadcastReceiver这四大组件，在启动的过程中，当其所承载的进程不存在时，需要调用startProcessLocked方法先创建进程。

![](http://gityuan.com/images/process/component_process.jpg)

#### 2.1 Activity

启动Activity过程: 调用startActivity,该方法经过层层调用,最终会调用ActivityStackSupervisor.java中的startSpecificActivityLocked,当activity所属进程还没启动的情况下,则需要创建相应的进程。

	void startSpecificActivityLocked(...) {
    ProcessRecord app = mService.getProcessRecordLocked(r.processName,
            r.info.applicationInfo.uid, true);
    if (app != null && app.thread != null) {
        ...  //进程已创建的case
        return
    }
    mService.startProcessLocked(r.processName, r.info.applicationInfo, true, 0,
                "activity", r.intent.getComponent(), false, false, true);
	}
#### 2.2 Service

启动服务过程: 调用startService,该方法经过层层调用,最终会调用ActiveServices.java中的bringUpServiceLocked,当Service进程没有启动的情况(app==null), 则需要创建相应的进程。

	private final String bringUpServiceLocked(...){
    ...
    ProcessRecord app = mAm.getProcessRecordLocked(procName, r.appInfo.uid, false);
    if (app == null) {
        if ((app=mAm.startProcessLocked(procName, r.appInfo, true, intentFlags,
                "service", r.name, false, isolated, false)) == null) {
            ...
        }
    }
    ...
	}

#### 2.3 BroadcastReceiver

广播处理过程: 调用sendBroadcast,该方法经过层层调用, 最终会调用到BroadcastQueue.java中的processNextBroadcast,当BroadcastReceiver所对应的进程尚未启动，则创建相应进程。

	final void processNextBroadcast(boolean fromMsg) {
    ...
    ProcessRecord app = mService.getProcessRecordLocked(targetProcess,
        info.activityInfo.applicationInfo.uid, false);
    if (app != null && app.thread != null) {
        ...  //进程已创建的case
        return
    }

    if ((r.curApp=mService.startProcessLocked(targetProcess,
            info.activityInfo.applicationInfo, true,
            r.intent.getFlags() | Intent.FLAG_FROM_BACKGROUND,
            "broadcast", r.curComponent,
            (r.intent.getFlags()&Intent.FLAG_RECEIVER_BOOT_UPGRADE) != 0, false, false))
                    == null) {
        ...
    }
    ...
	}

#### 2.4 ContentProvider

ContentProvider处理过程: 调用ContentResolver.query该方法经过层层调用, 最终会调用到AMS.java中的getContentProviderImpl,当ContentProvider所对应进程不存在,则需要创建新进程。

	private final ContentProviderHolder getContentProviderImpl(...) {
    ...
    ProcessRecord proc = getProcessRecordLocked(cpi.processName, cpr.appInfo.uid, false);
    if (proc != null && proc.thread != null) {
        ...  //进程已创建的case
    } else {
        proc = startProcessLocked(cpi.processName,
                    cpr.appInfo, false, 0, "content provider",
                    new ComponentName(cpi.applicationInfo.packageName,cpi.name),
                    false, false, false);
    }
    ...
	}

四大组件的进程创建方法：

组件      |  创建方法
--------- | ----------
Activity | ActivityStackSupervisor.startSpecificActivityLocked()
Service  | ActiveServices.bringUpServiceLocked()
ContentProvider | AMS.getContentProviderImpl()
BroadcastReceiver | BroadcastQueue.processNextBroadcast()

进程的创建过程交由系统进程system_server来完成的。


### 3.进程的创建

![](http://gityuan.com/images/process/app_process_ipc.jpg)

简称:

- ATP: ApplicationThreadProxy
- AT: ApplicationThread (继承于ApplicationThreadNative)
- AMP: ActivityManagerProxy
- AMS: ActivityManagerService (继承于ActivityManagerNative)

图解：

1. system_server进程中调用startProcessLocked方法,该方法最终通过socket方式,将需要创建新进程的消息告知Zygote进程,并阻塞等待Socket返回新创建进程的pid;
2. Zygote进程接收到system_server发送过来的消息, 则通过fork()方法，将zygote自身进程复制生成新的进程，并将ActivityThread相关的资源加载到新进程app process,这个进程可能是用于承载activity等组件;
3. 创建完新进程后fork返回两次, 在新进程app process中向ServiceManager查询system_server进程中binder服务端AMS,获取相对应的Client端,也就是AMP. 有了这一对Binder c/s对, 那么app process便可以通过Binder向跨进程system_server发送请求,即attachApplication();
4. system_server进程接收到相应Binder操作后,经过多次调用,利用ATP向app process发送binder请求, 即bindApplication；
5. system_server拥有ATP/AMS, 每一个新创建的进程都会有一个相应的AT/AMP,从而可以跨进程进行相互通信；


参考：
[理解Android进程创建流程](http://gityuan.com/2016/03/26/app-process-create/)

[Android四大组件与进程启动的关系](http://gityuan.com/2016/10/09/app-process-create-2/)
## 动画的显示过程

Android底层会每隔16ms发送一个VSYNC信号，来触发UI更新。上层Choreographer收到相应的VSYNC信号后，会执行dispatchVsync方法，最终触发Input、Animation、Traversal的回调方法。但当系统有需要时，可以主动触发Choreographer执行动画显示，而不用等到VSYNC信号的到来。

动画的显示是有WMS调用scheduleAnimationLocked()方法来设置mFrameScheduled=true来触发动画的。

1.WMS.scheduleAnimationLocked

	void scheduleAnimationLocked() {
        if (!mAnimationScheduled) {
            mAnimationScheduled = true;
            mChoreographer.postFrameCallback(mAnimator.mAnimationFrameCallback);
        }
    }
该方法主要是调用Choreographer的postFrameCallback方法，将动画执行的过程添加到Choreographer中。动画执行的CallBack在WindowAnimator类中定义：
	
	WindowAnimator(final WindowManagerService service) {
        mService = service;
        mContext = service.mContext;
        mPolicy = service.mPolicy;
        mWindowPlacerLocked = service.mWindowPlacerLocked;
		// 动画显示的callback
        mAnimationFrameCallback = new Choreographer.FrameCallback() {
            public void doFrame(long frameTimeNs) {
                synchronized (mService.mWindowMap) {
                    mService.mAnimationScheduled = false;
					// 真正动画的处理过程
                    animateLocked(frameTimeNs);
                }
            }
        };
    }

2.Choreographer.postFrameCallback

	public void postFrameCallback(FrameCallback callback) {
        postFrameCallbackDelayed(callback, 0);
    }
该方法的主要作用将一个帧回调方法在下一帧时间内执行。

	public void postFrameCallbackDelayed(FrameCallback callback, long delayMillis) {
        if (callback == null) {
            throw new IllegalArgumentException("callback must not be null");
        }
		//回调类型为动画类型，Token为FRAME_CALLBACK_TOKEN，延迟时间为0
        postCallbackDelayedInternal(CALLBACK_ANIMATION,
                callback, FRAME_CALLBACK_TOKEN, delayMillis);
    }

在该方法中，设置回调类型为动画类型，即为CALLBACK_ANIMATION，Token为FRAME_CALLBACK_TOKEN，延迟时间为0。

	private void postCallbackDelayedInternal(int callbackType,
            Object action, Object token, long delayMillis) {
        
        synchronized (mLock) {
			// 记录当前时间
            final long now = SystemClock.uptimeMillis();
			// 计算执行时间
            final long dueTime = now + delayMillis;
			// 将回调任务添加到动画类型的回调队列中
            mCallbackQueues[callbackType].addCallbackLocked(dueTime, action, token);
			// 因为delayMillis时间为0，所以立即执行，调用scheduleFrameLocked方法。
            if (dueTime <= now) {
                scheduleFrameLocked(now);
            } else {
                Message msg = mHandler.obtainMessage(MSG_DO_SCHEDULE_CALLBACK, action);
                msg.arg1 = callbackType;
                msg.setAsynchronous(true);
                mHandler.sendMessageAtTime(msg, dueTime);
            }
        }
    }

在方法中，主要是调用回调任务加入到队列中，然后调用scheduleFrameLocked方法。

3.Choreographer.scheduleFrameLocked

	private void scheduleFrameLocked(long now) {
        if (!mFrameScheduled) {
            mFrameScheduled = true;
            if (USE_VSYNC) {
                ....
				//当运行在Looper线程，则立刻调度vsync
                if (isRunningOnLooperThreadLocked()) {
                    scheduleVsyncLocked();
                } else {
					//否则，发送消息到UI线程
                    Message msg = mHandler.obtainMessage(MSG_DO_SCHEDULE_VSYNC);
                    msg.setAsynchronous(true);
                    mHandler.sendMessageAtFrontOfQueue(msg);
                }
            } else {
                final long nextFrameTime = Math.max(
                        mLastFrameTimeNanos / TimeUtils.NANOS_PER_MS + sFrameDelay, now);
                Message msg = mHandler.obtainMessage(MSG_DO_FRAME);
                msg.setAsynchronous(true);
                mHandler.sendMessageAtTime(msg, nextFrameTime);
            }
        }
    }

该方法的功能：

- 当运行在Looper线程，则立刻调度scheduleVsyncLocked();
- 当运行在其他线程，则通过发送一个消息到Looper线程，然后再执行scheduleVsyncLocked();

4.Choreographer.scheduleVsyncLocked
	
	private void scheduleVsyncLocked() {
        mDisplayEventReceiver.scheduleVsync();
    }
mDisplayEventReceiver对象是在构建Choreographer对象时初始化的。

	public void scheduleVsync() {
        if (mReceiverPtr == 0) {
            Log.w(TAG, "Attempted to schedule a vertical sync pulse but the display event "
                    + "receiver has already been disposed.");
        } else {
			// 调用native方法，触发下一个VSYNC信号的产生
            nativeScheduleVsync(mReceiverPtr);
        }
    }
scheduleVsync方法的主要作用是让系统产生一个VSYNC信号，然后开始下一个帧的处理流程。

5.Choreographer.doFrame

在收到了底层发送的VSYNC信号之后，Choreographer会调用doFrame方法进行一系列处理。

	void doFrame(long frameTimeNanos, int frame) {
		.....
		try {
			mFrameInfo.markAnimationsStart();
            doCallbacks(Choreographer.CALLBACK_ANIMATION, frameTimeNanos);
			....
		}
	}
动画的显示会执行类型的CALLBACK_ANIMATION回调，具体在doCallbacks中。

6.Choreographer.doCallbacks

	void doCallbacks(int callbackType, long frameTimeNanos) {
		CallbackRecord callbacks;
		synchronized (mLock) {
			....
			try {
            Trace.traceBegin(Trace.TRACE_TAG_VIEW, CALLBACK_TRACE_TITLES[callbackType]);
            for (CallbackRecord c = callbacks; c != null; c = c.next) {
                .....
				
                c.run(frameTimeNanos);
            }
		}
	}
在doCallbacks方法中，主要是调用CallbackRecord里的run方法，来执行任务。

	public void run(long frameTimeNanos) {
            if (token == FRAME_CALLBACK_TOKEN) {
                ((FrameCallback)action).doFrame(frameTimeNanos);
            } else {
                ((Runnable)action).run();
            }
     }
先前在Choreographer的postFrameCallbackDelayed方法中，将动画显示的Token设置为FRAME_CALLBACK_TOKEN类型，所以在这里回调doFrame方法，该方法就是在WindowAnimator中定义的mAnimationFrameCallback。

	mAnimationFrameCallback = new Choreographer.FrameCallback() {
            public void doFrame(long frameTimeNs) {
                synchronized (mService.mWindowMap) {
                    mService.mAnimationScheduled = false;
                    animateLocked(frameTimeNs);
                }
            }
        };

7.WindowAnimator.animateLocked

	private void animateLocked(long frameTimeNs) {
		// 是否已经成功了
        if (!mInitialized) {
            return;
        }
		// 当前时间
        mCurrentTime = frameTimeNs / TimeUtils.NANOS_PER_MS;
        mBulkUpdateParams = SET_ORIENTATION_CHANGE_COMPLETE;
		// 记录上一次的动画状态
        boolean wasAnimating = mAnimating;
        setAnimating(false);
        mAppWindowAnimating = false;
        
       	// 业务开始，先本地记录下所有对Surface的更改，最后再统一提交给SurfaceFlinger。
        SurfaceControl.openTransaction();
        SurfaceControl.setAnimationTransaction();
        try {
            final int numDisplays = mDisplayContentsAnimators.size();
            for (int i = 0; i < numDisplays; i++) {
                final int displayId = mDisplayContentsAnimators.keyAt(i);
				// 1.执行App Window动画
                updateAppWindowsLocked(displayId);
                DisplayContentsAnimator displayAnimator = mDisplayContentsAnimators.valueAt(i);
				// 2.执行屏幕旋转动画
                final ScreenRotationAnimation screenRotationAnimation =
                        displayAnimator.mScreenRotationAnimation;
                if (screenRotationAnimation != null && screenRotationAnimation.isAnimating()) {
                    if (screenRotationAnimation.stepAnimationLocked(mCurrentTime)) {
                        setAnimating(true);
                    } else {
                        mBulkUpdateParams |= SET_UPDATE_ROTATION;
                        screenRotationAnimation.kill();
                        displayAnimator.mScreenRotationAnimation = null;

                        //TODO (multidisplay): Accessibility supported only for the default display.
                        if (mService.mAccessibilityController != null
                                && displayId == Display.DEFAULT_DISPLAY) {
                            mService.mAccessibilityController.onRotationChangedLocked(
                                    mService.getDefaultDisplayContentLocked(), mService.mRotation);
                        }
                    }
                }

				//3.更新WindowStateAnimator的动画，包括正在退出的应用
                updateWindowsLocked(displayId);
                updateWallpaperLocked(displayId);

                final WindowList windows = mService.getWindowListLocked(displayId);
                final int N = windows.size();
                for (int j = 0; j < N; j++) {
					// 4.更新Surface
                    windows.get(j).mWinAnimator.prepareSurfaceLocked(true);
                }
            }

            for (int i = 0; i < numDisplays; i++) {
                final int displayId = mDisplayContentsAnimators.keyAt(i);

                testTokenMayBeDrawnLocked(displayId);

                final ScreenRotationAnimation screenRotationAnimation =
                        mDisplayContentsAnimators.valueAt(i).mScreenRotationAnimation;
                if (screenRotationAnimation != null) {
                    screenRotationAnimation.updateSurfacesInTransaction();
                }

                orAnimating(mService.getDisplayContentLocked(displayId).animateDimLayers());
                orAnimating(mService.getDisplayContentLocked(displayId).getDockedDividerController()
                        .animate(mCurrentTime));
                //TODO (multidisplay): Magnification is supported only for the default display.
                if (mService.mAccessibilityController != null
                        && displayId == Display.DEFAULT_DISPLAY) {
                    mService.mAccessibilityController.drawMagnifiedRegionBorderIfNeededLocked();
                }
            }

            if (mService.mDragState != null) {
                mAnimating |= mService.mDragState.stepAnimationLocked(mCurrentTime);
            }
			// 接下来是否还需要再执行动画？
            if (mAnimating) {
				// 在执行一次schedule
                mService.scheduleAnimationLocked();
            }

            if (mService.mWatermark != null) {
                mService.mWatermark.drawIfNeeded();
            }
        } catch (RuntimeException e) {
            Slog.wtf(TAG, "Unhandled exception in Window Manager", e);
        } finally {
			// 5.统一提交给SurfaceFlinger进行处理
            SurfaceControl.closeTransaction();
        }

        boolean hasPendingLayoutChanges = false;
        final int numDisplays = mService.mDisplayContents.size();
        for (int displayNdx = 0; displayNdx < numDisplays; ++displayNdx) {
            final DisplayContent displayContent = mService.mDisplayContents.valueAt(displayNdx);
            final int pendingChanges = getPendingLayoutChanges(displayContent.getDisplayId());
            if ((pendingChanges & WindowManagerPolicy.FINISH_LAYOUT_REDO_WALLPAPER) != 0) {
                mBulkUpdateParams |= SET_WALLPAPER_ACTION_PENDING;
            }
            if (pendingChanges != 0) {
                hasPendingLayoutChanges = true;
            }
        }

        boolean doRequest = false;
        if (mBulkUpdateParams != 0) {
            doRequest = mWindowPlacerLocked.copyAnimToLayoutParamsLocked();
        }

        if (hasPendingLayoutChanges || doRequest) {
            mWindowPlacerLocked.requestTraversal();
        }

        if (mAnimating && !wasAnimating && Trace.isTagEnabled(Trace.TRACE_TAG_WINDOW_MANAGER)) {
            Trace.asyncTraceBegin(Trace.TRACE_TAG_WINDOW_MANAGER, "animating", 0);
        }

        if (!mAnimating && wasAnimating) {
            mWindowPlacerLocked.requestTraversal();
            if (Trace.isTagEnabled(Trace.TRACE_TAG_WINDOW_MANAGER)) {
                Trace.asyncTraceEnd(Trace.TRACE_TAG_WINDOW_MANAGER, "animating", 0);
            }
        }

        if (mRemoveReplacedWindows) {
            removeReplacedWindowsLocked();
        }

        mService.stopUsingSavedSurfaceLocked();
        mService.destroyPreservedSurfaceLocked();
        mService.mWindowPlacerLocked.destroyPendingSurfaces();

    }

animateLocked是动画处理的主要函数。

总体流程如下：

	WindowManagerService.scheduleAnimationLocked
		Choreographer.postFrameCallback
			Choreographer.scheduleFrameLocked
				Choreographer.scheduleVsyncLocked
					Choreographer.doFrame
						Choreographer.doCallbacks
							WindowAnimator.animateLocked

Choreographer类里面的方法使用可以参考Choreographer的简介文章。

	
	



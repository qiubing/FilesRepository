## AsyncTask
[TOC]

### 1.简介
  
**AsyncTask允许你执行后台耗时操作，并将结果发布到UI线程**。整个实现过程不需要多个Thread或者Handler。
    
AsyncTask是被设计来替代Handler与Thread组合的一种方式，它不需要构建通用的线程框架。
    
AsyncTask理想的情况下是用来执行**短时间的操作**，例如几秒种操作。如果需要执行一些长时间的耗时操作，推荐使用**并发执行框架**，例如Executor框架和ThreadPoolExecutor以及FutureTask。

一个异步任务主要是**在后台执行计算操作，并把计算结果发布到UI线程**。一个异步任务主要通过三种类型参数：Params、Progress、Result和4步操作：**onPreExecute()、doInBackground()、onProgressUpdate()、onPostExecute()**来定义的。

AsyncTask必须被子类化才能使用，并且必须覆写**doInBackground()**方法。通常的情况下，还可以覆写onPreExecute()方法。
   
这里有个一AsyncTask的使用示例：

	private class DownloadFileTask extends AsyncTask<URL,Integer,Long>{

		@Override
		protected Long doInBackground(URL... urls) {
			int count = urls.length;
        	long totalSize = 0;
        	for (int i = 0; i < count; i++){
            	totalSize += DownLoader.downloadFile(urls[i]);
				publishProgress((int) ((i/(float) count) * 100));
            	if (isCancelled()){
					break;
				}
        	}
			return totalSize;
		}

		@Override
		protected void onProgressUpdate(Integer... progress) {
        	setProgress(progress[0]);
		}

		@Override
		protected void onPostExecute(Long result) {
        	showDialog("DownLoaded" + result + " tytes");
		}
	}

一旦一个AsyncTask被创建完之后，任务执行很简单，只需调用new DownloadFileTask().execute(url1,url2,url3)方法就可以开始执行任务。

AsyncTask包含三种类型的参数：

- Param参数：发送给任务执行的参数类型；
- Progress参数：在后台计算时，显示任务处理的进度单元；
- Result参数：后台计算出结果的参数类型；

上面的三个参数并不是每个参数都被使用，当不需要使用时，可以简单声明为一个Void类型。例如AsyncTask<Void，Void，Void>。

当异步任务AsyncTask执行时，将会经历以下4步：

1. **onPreExecute()**;该方法在**UI线程**被触发执行，该方法经常被用来做一些初始化操作，初始化任务执行，例如初始化一个进度条。

2. **doInBackground()**;该方法在**子线程**中执行，在执行完onPreExecute方法之后，就开始执行该方法。该方法用来执行后台耗时的操作，参数是通过AsyncTask传递进来，并且该方法将计算结果返回给onPostExecute方法，做后续的进一步处理。在该方法中，还可以调用publishProcess方法将该任务执行的进度发布的UI线程中。publishProcess方法将任务执行结果发送到onProgressUpdate方法中，用来更新UI任务执行的进度。

3. **onProgressUpdate()**;该方法在**UI线程**中执行，在调用publishProcess方法后，将触发该方法在UI线程中执行。该方法主要用来显示任务执行的进度。

4. **onPostExecute()**;该方法在UI线程中执行，当后台任务执行完成后，将调用该方法。doInBackground方法返回的结果将作为该函数的参数传递给该函数处理。

#### 1.1任务的取消
一个任务可以在任何时候被取消，通过调用cancel(boolean)方法。触发了cancel方法之后，将会导致后续查询isCancelled方法时返回true。

**在调用了Cancel方法之后，在doInBackground方法返回时，将调用onCancel方法而不是onPostExecute方法。为了尽快的让一个任务可以被取消，应该在doInBackground方法中定期地检查isCancelled方法返回的值，及时的取消任务的执行。**

### 1.2线程规则

在使用AsyncTask时，有一些线程规则需要被遵循：

1. AsyncTask必须在UI线程上加载执行。AsyncTask必须在UI线程上创建，execute()方法必须在UI线程中执行。

2. 不要手动去调用onPreExecute()、doInBackground()、onProgressUpdate()、onPostExecute()方法。

3. AsyncTask任务只能被执行一次，如果执行多次，将会抛出异常。

#### 1.3内存一致性
AsyncTask保证所有的回调函数调用将同步：
    
- 在构造器中或是在onPreExecute方法中设置的变量可以在doInBackground中安全的使用；
- 在doInBackground中设置的变量可以在onProgressUpdate()或者onPostExecute()方法中安全的使用。

### 1.4执行的顺序

当AsyncTask刚被引入时，AsyncTask任务是在一个后台线程中**顺序执行的**。从Android 1.6版本以后，改变为一个线程池了，允许多个任务并发的执行。从**Android3.0开始**，任务被执行在**单个线程中**，避免由并发执行引发的应用程序错误。**如果想并发执行的话，可以通过调用AsyncTask的executeOnExecutor()方法来指定THREAD\_POOL\_EXECUTOR**。

### 2.源码分析
#### 2.1任务的执行

任务的执行可以通过两种方式实现，一种是任务顺序执行；另外一种是任务并发的执行；

- 调用AsyncTask的execute方法，任务将**顺序的执行**；
- 调用AsyncTask的executeOnExecutor()方法，并指定执行器Executor，**任务将并发的执行**。

    	@MainThread
    	public final AsyncTask<Params, Progress, Result> execute(Params... params) {
			//使用sDefaultExecutor执行任务
        	return executeOnExecutor(sDefaultExecutor, params);
    	}
	    

如果想任务并发执行，则需要调用AsyncTask的executeOnExecutor方法，指定执行器Executor。

    @MainThread
    public final AsyncTask<Params, Progress, Result> executeOnExecutor(Executor exec,
            Params... params) {
		//如果AsyncTask状态不是PENDING状态，则说明任务已经执行，不能重复执行，直接抛异常
        if (mStatus != Status.PENDING) {
            switch (mStatus) {
                case RUNNING:
                    throw new IllegalStateException("Cannot execute task:"
                            + " the task is already running.");
                case FINISHED:
                    throw new IllegalStateException("Cannot execute task:"
                            + " the task has already been executed "
                            + "(a task can be executed only once)");
            }
        }

		//将任务的状态设置为RUNNING状态
        mStatus = Status.RUNNING;
		//调用onPreExecute方法，该方法在UI线程中执行
        onPreExecute();
		
		//将参数传递给执行的任务
        mWorker.mParams = params;
		//调用任务执行器执行任务
        exec.execute(mFuture);

        return this;
    }

	private volatile Status mStatus = Status.PENDING;
	private final FutureTask<Result> mFuture;

可以看到，任务的执行最终都是由Executor执行器来执行，任务的执行顺序也是由Executor来决定的。在执行任务前，会先回调onPreExecute方法，该方法主要是做一些初始化工作，在UI线程中执行。

#### 2.2任务执行器Executor
我们知道AsyncTask的任务可以顺序执行，也可以并发执行，具体取决于任务执行器Executor。任务执行器分为两类：顺序任务执行器和并发任务执行器。
##### 2.2.1顺序执行器SERIAL_EXECUTOR

	private static volatile Executor sDefaultExecutor = SERIAL_EXECUTOR;//顺序执行器
    public static final Executor SERIAL_EXECUTOR = new SerialExecutor();

	private static class SerialExecutor implements Executor {
		//双端任务队列
        final ArrayDeque<Runnable> mTasks = new ArrayDeque<Runnable>();
       	Runnable mActive;
			
        public synchronized void execute(final Runnable r) {
			//将任务添加到任务队列的尾部
            mTasks.offer(new Runnable() {
                public void run() {
                    try {
                      	r.run();//执行具体的任务
                    } finally {
                    	scheduleNext();//任务执行完成后，触发执行下一个任务，这样就保证了任务是一个接一个执行
                    }
                }
            });
			//第一次执行时，mActive为空，触发调用下一个任务执行。后续的任务执行，是通过scheduleNext()来触发执行的
            if (mActive == null) {
                scheduleNext();
            }
        }

		/*
		* 该方法从任务队列中取出任务，然后通过THREAD_POOL_EXECUTOR执行任务，执行完任务之后，就开始下一个任务执行。
		* 这样就保证了任务一个接一个在后台执行。SerialExecutor可以添加多个任务，但任务的执行还是
		* 顺序的执行，一个接一个执行。
		*/
        protected synchronized void scheduleNext() {
			//从任务队里中取出任务，并将它赋值给mActive对象
            if ((mActive = mTasks.poll()) != null) {
				//通过任务执行器，执行任务
                THREAD_POOL_EXECUTOR.execute(mActive);
            }
        }
    }

可以看到，顺序执行器其实是通过在Runnable对象中封装要执行的任务，并把任务添加到任务队列中，然后由任务队列中的任务触发执行下一个任务，这样就保证了任务顺序执行。

##### 2.2.2并发执行器THREAD\_POOL\_EXECUTOR

	 /**
     * An {@link Executor} that can be used to execute tasks in parallel.
     */
    public static final Executor THREAD_POOL_EXECUTOR;
	
	static {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                CORE_POOL_SIZE, MAXIMUM_POOL_SIZE, KEEP_ALIVE_SECONDS, TimeUnit.SECONDS,
                sPoolWorkQueue, sThreadFactory);
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        THREAD_POOL_EXECUTOR = threadPoolExecutor;
    }
	
	//CPU的数量
	private static final int CPU_COUNT = Runtime.getRuntime().availableProcessors();
	//cool pool至少需要2个线程，至多4个线程
	private static final int CORE_POOL_SIZE = Math.max(2, Math.min(CPU_COUNT - 1, 4));
	private static final int MAXIMUM_POOL_SIZE = CPU_COUNT * 2 + 1;
	private static final int KEEP_ALIVE_SECONDS = 30;
	//128个大小的工作队列
	private static final BlockingQueue<Runnable> sPoolWorkQueue =
		new LinkedBlockingQueue<Runnable>(128);

	//线程工厂
	private static final ThreadFactory sThreadFactory = new ThreadFactory() {
	private final AtomicInteger mCount = new AtomicInteger(1);

    public Thread newThread(Runnable r) {
		return new Thread(r, "AsyncTask #" + mCount.getAndIncrement());
	}
	};

可以看到并发执行器是一个THreadPoolExecutor，它指定了一些执行参数，例如线程数目，存活时间等。

#### 2.3任务的执行状态

任务的执行状态有三种，分别是**等待执行**，**正在执行**，**执行完成**

	private volatile Status mStatus = Status.PENDING;
	//指示当前任务执行的状态，每个状态只在整个任务生命周期内执行一次。
	public enum Status {
		//指示任务等待被执行的状态
		PENDING,
		//指示任务正在执行的状态
		RUNNING,
		//指示任务已经执行完成了
		FINISHED,
	}

	//返回的任务执行状态
	public final Status getStatus() {
		return mStatus;
	}


#### 2.4 任务执行的回调方法

	/* 需要被覆写的方法，在后台线程执行任务的方法；
	* 执行任务的参数params是在调用execute方法时传入的；
	* 在该方法中，可以调用publishProgress()方法，来更新UI线程中任务执行的进度。
	*/
	@WorkerThread
	protected abstract Result doInBackground(Params... params);

	/*在主线程中执行
	* 在调用doInBackground方法之前调用。
	* /
	@MainThread
	protected void onPreExecute() {
	}

	/*在主线程中执行
	 * 在调用doInBackground方法之后调用
	 * result参数的值是doInBackground方法返回的值
	 * 如果任务被取消了，则该方法不会被调用
	@MainThread
	protected void onPostExecute(Result result) {
	}

	/*在主线程中执行
	* 在执行完publishProgress方法之后，调用该方法
	* 参数values的值是传递给publishProgress()方法参数的值
	* /
	@MainThread
	protected void onProgressUpdate(Progress... values) {
	}

#### 2.5任务的封装
	
在构建执行AsyncTask构造器的时，创建了两个变量mWorker和mFuture。mWorker是对执行任务的包装，而mFuture是对mWorker的封装，表示在执行框架中执行的任务。

	 /**
     * Creates a new asynchronous task. This constructor must be invoked on the UI thread.
     */
    public AsyncTask() {
        mWorker = new WorkerRunnable<Params, Result>() {
            public Result call() throws Exception {
                mTaskInvoked.set(true);
                Result result = null;
                try {
					//设置线程的优先级为后台优先级
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                    //noinspection unchecked
					//在后台线程中执行
                    result = doInBackground(mParams);
                    Binder.flushPendingCommands();
                } catch (Throwable tr) {
                    mCancelled.set(true);
                    throw tr;
                } finally {
					//执行完doInBackground方法后，执行postResult方法
                    postResult(result);
                }
				//返回执行结果
                return result;
            }
        };
		//封装执行任务
        mFuture = new FutureTask<Result>(mWorker) {
            @Override
            protected void done() {
                try {
					//任务执行完成后，将任务执行结果投递到UI线程中
                    postResultIfNotInvoked(get());
                } catch (InterruptedException e) {
                    android.util.Log.w(LOG_TAG, e);
                } catch (ExecutionException e) {
                    throw new RuntimeException("An error occurred while executing doInBackground()",
                            e.getCause());
                } catch (CancellationException e) {
                    postResultIfNotInvoked(null);
                }
            }
        };
    }

	private static abstract class WorkerRunnable<Params, Result> implements Callable<Result> {
        Params[] mParams;//任务执行的参数，在AsyncTask的executeOnExecutor()方法中被赋值

    }

当调用任务执行框架的execute()方法时，开始任务的执行。在WorkerRunnable的call方法中，执行doInBackground方法。由于任务的执行是在子线程中执行，所以doInBackground方法也是在子线程中执行。doInBackground()方法中的参数是在调用AsyncTask的execute（)方法时传递进来的。doInBackground()方法执行的结果，将通过postResult()方法投递到UI线程中。

	//将任务的执行结果返回到UI线程中
	private Result postResult(Result result) {
	@SuppressWarnings("unchecked")
    	Message message = getHandler().obtainMessage(MESSAGE_POST_RESULT,
            new AsyncTaskResult<Result>(this, result));
		message.sendToTarget();
    	return result;
	}

	private static Handler getHandler() {
        synchronized (AsyncTask.class) {
            if (sHandler == null) {
                sHandler = new InternalHandler();
            }
            return sHandler;
        }
    }

	private static class InternalHandler extends Handler {
        public InternalHandler() {
            super(Looper.getMainLooper());//用主线程的Looper对象创建Handler
        }

        @SuppressWarnings({"unchecked", "RawUseOfParameterizedType"})
        @Override
        public void handleMessage(Message msg) {
            AsyncTaskResult<?> result = (AsyncTaskResult<?>) msg.obj;
            switch (msg.what) {
                case MESSAGE_POST_RESULT:
                    // There is only one result
					//消息类型是返回结果，则调用AsyncTask的finish方法
                    result.mTask.finish(result.mData[0]);
                    break;
                case MESSAGE_POST_PROGRESS:
					//消息类型是显示进度条，则调用AsyncTask的onProgressUpdate方法
                    result.mTask.onProgressUpdate(result.mData);
                    break;
            }
        }
    }

	private void finish(Result result) {
		//如果任务被取消了，则直接调用onCancelled方法
        if (isCancelled()) {
            onCancelled(result);
        } else {
		//如果任务没有被取消，则执行onPostExecute方法，并把结果返回
            onPostExecute(result);
        }
		//状态为结束状态
        mStatus = Status.FINISHED;
    }

可以看到，当任务执行完成后，会调用postResult方法，发送MESSAGE\_POST\_RESULT消息到UI线程，执行相应的操作。如果任务没有被取消的话，则调用onPostExecute方法；如果任务被取消的话，则调用onCancelled()方法。


如果需要更新任务执行进度，则需要在doInBackground方法中，调用publishProgress方法来更新进度。

    @WorkerThread
    protected final void publishProgress(Progress... values) {
		//任务没有被取消，则发送MESSAGE_POST_PROGRESS消息到主线程中取执行。
        if (!isCancelled()) {
            getHandler().obtainMessage(MESSAGE_POST_PROGRESS,
                    new AsyncTaskResult<Progress>(this, values)).sendToTarget();
        }
    }

在InternalHandler中，处理MESSAGE\_POST\_PROGRESS消息的方法是调用AsyncTask的onProgressUpdate方法，该方法在UI线程中执行，用来更新任务执行进度。

    @SuppressWarnings({"UnusedDeclaration"})
    @MainThread
    protected void onProgressUpdate(Progress... values) {
    }

#### 2.6任务的取消
任务的取消是通过调用cancle方法来实现的，具体的代码如下：

	// 尝试取消一个任务
	// 如果任务已经完成了，或者是已经被取消了，或者是由于其他原因不能被取消，则取消操作将返回失败。
	// 如果任务还未开始，当执行完cancel操作后，该任务不会再执行
	// 如果任务已经开始了，那么mayInterruptIfRunning参数将决定是否执行该任务的线程应该被中断
    public final boolean cancel(boolean mayInterruptIfRunning) {
		//设置取消标志
        mCancelled.set(true);
		//调用FutureTask的取消方法，取消任务
        return mFuture.cancel(mayInterruptIfRunning);
    }

	private final AtomicBoolean mCancelled = new AtomicBoolean();//mCancell是一个原子变量

在执行完doInBackground方法后，会判断任务已经取消了，如果任务已经被取消了，则执行onCancelled方法。
	
    @MainThread
    protected void onCancelled() {
    }

可以看到，该方法是一个空实现，需要子类覆写该方法。那么怎么判断任务已经被取消了呢？

    public final boolean isCancelled() {
        return mCancelled.get();
    }

如果任务在执行前被取消了，则返回true。如果调用了Cancel方法来取消任务时，应该在doInBackground方法中调用该方法定期地检查任务是否被取消了，以尽快的结束任务。

#### 2.7后台执行任务更新

当需要更新后台任务执行进度时，可以在doInBackground方法中调用publishProgress()方法，将后台任务执行进度更新到UI线程中。publishProgress方法将发送MESSAGE\_POST\_PROGRESS消息到UI线程，在UI线程中调用onProgressUpdate方法。

    @WorkerThread
    protected final void publishProgress(Progress... values) {
        if (!isCancelled()) {
            getHandler().obtainMessage(MESSAGE_POST_PROGRESS,
                    new AsyncTaskResult<Progress>(this, values)).sendToTarget();
        }
    }

	case MESSAGE_POST_PROGRESS:
		// 在后台执行的过程中，通过调用publishProcess()方法，发送MESSAGE_POST_PROGRESS消息到UI线程，
		// 在UI线程中执行onProgressUpdate方法，完成后台任务执行进度更新。
		result.mTask.onProgressUpdate(result.mData);
    break;

### 3.总结
AsyncTask允许你执行后台耗时操作，并将结果发布到UI线程。

当调用AsyncTask.execute()方法时，采用的是默认的顺序执行器，任务是在后台线程中顺序执行的。如果想任务在后台并发地执行，则需要调用AsyncTask.executeOnExecutor()方法，并指定Executor执行器。

AsyncTask任务执行的一般流程如下：

![AsyncTask任务执行的流程](https://ooo.0o0.ooo/2017/07/01/59577ce38ee2e.png)

图中深色的部分表示在后台线程执行的操作，其余的都是在主线程中执行的操作。

### 4.AsyncTask使用示例

	import android.app.Activity;
	import android.app.ProgressDialog;
	import android.content.Context;
	import android.os.AsyncTask;
	import android.os.Bundle;
	import android.util.Log;
	import android.view.View;
	import android.widget.Button;
	import android.widget.Toast;


	public class MainActivity extends Activity {
		private static final String TAG = "MainActivity";
    	private ProgressDialog mDialog;
    	private MyAsyncTask mTask;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			mDialog = new ProgressDialog(this);
			mDialog.setMax(100);
			mDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);


			mTask = new MyAsyncTask(this);

			//开始执行任务
			Button start = (Button) findViewById(R.id.start);
			start.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
               		Log.i(TAG,"start task");
					mTask.execute();
				}
        	});

			//取消任务执行
			Button cancel = (Button) findViewById(R.id.cancel);
			cancel.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
                	Log.i(TAG,"cancel task");
					mTask.cancel(false);
				}
        	});
		}

		private class MyAsyncTask extends AsyncTask<Void,Integer,Void>{
			private Context mContext;
        	public MyAsyncTask(Context context){
				mContext = context;
			}
	
			@Override
			protected void onPreExecute() {
            	Log.i(TAG, "onPreExecute()...on: " + Thread.currentThread().getName());
				mDialog.show();
			}

			@Override
			protected Void doInBackground(Void... params) {
            	Log.i(TAG,"doInBackground()...on: " + Thread.currentThread().getName());
				//模拟后台执行
				for (int i = 0;i < 100; i++){
					//如果任务被取消了，则直接返回
					if (isCancelled()){
						break;
					}

					try {
                    	Thread.sleep(100);
					} catch (InterruptedException e) {
                   	 	e.printStackTrace();
					}
                	publishProgress(i);
				}
				return null;
			}

			@Override
			protected void onProgressUpdate(Integer... values) {
            	Log.i(TAG, "onProgressUpdate()...on: " + Thread.currentThread().getName());
				mDialog.setProgress(values[0]);
			}

			@Override
			protected void onPostExecute(Void result) {
            	Log.i(TAG,"onPostExecute()...on: " + Thread.currentThread().getName());
				mDialog.dismiss();
				Toast.makeText(mContext,"任务执行完成",Toast.LENGTH_LONG).show();
			}

			@Override
			protected void onCancelled(Void result) {
            	Log.i(TAG,"onCancelled()...on: " + Thread.currentThread().getName());
				mDialog.dismiss();
				Toast.makeText(mContext,"任务被取消了",Toast.LENGTH_LONG).show();
			}
    	}
	}
	

布局文件activity_main.xml

	<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
		android:layout_width="match_parent"
		android:layout_height="match_parent">
    	<Button
			android:id="@+id/start"
			android:layout_width="match_parent"
			android:layout_height="wrap_content"
			android:text="开始任务"/>

    	<Button
			android:id="@+id/cancel"
			android:layout_width="match_parent"
			android:layout_height="wrap_content"
			android:layout_below="@+id/start"
			android:text="取消任务"/>

	</RelativeLayout>

Demo地址：[AsyncTask示例](https://github.com/qiubing/AsyncTaskDemo.git)
	

	
	







	
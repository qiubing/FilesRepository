## AIDL的使用

AIDL帮助我们生成了**一个接口**，**一个Stub类用于服务端**，**一个Proxy类用于客户端**调用。

![AIDL类图](http://orbohk5us.bkt.clouddn.com/17-11-13/47911096.jpg)

### 1.Stub类

Stub类继承自Binder类，实现了onTransact()方法，在onTransact()方法中，由其参数决定执行服务端的代码。可以看到onTransact()方法有四个参数：

- code：一个整形的唯一标识，用于区分执行哪个方法，客户端会传递此参数，告诉服务端执行哪个方法；
- data：客户端传递过来的参数；
- replay：服务器返回回去的值；
- flags:表明是否有返回值，0为有(双向)，1为没有(单向)。

代码实例：

	@Override 
	public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
	{
		switch (code)
		{
			case INTERFACE_TRANSACTION:
			{
				reply.writeString(DESCRIPTOR);
				return true;
			}
		case TRANSACTION_getId:
		{
			data.enforceInterface(DESCRIPTOR);
			int _result = this.getId();
			reply.writeNoException();
			reply.writeInt(_result);
			return true;
		}
		return super.onTransact(code, data, reply, flags);
	}

服务端只需实现在接口中定义的函数，例如getId()函数，其余的操作都已经被Stub类封装好了。

1.1 Stub()的构造函数

	public Stub()
	{
		this.attachInterface(this, DESCRIPTOR);
	}
该方法的主要作用是构建一个Stub类，并绑定到DESCRIPTOR描述符对应的接口。该方法最终调用Binder类的attachInterface()方法:
	
	public void attachInterface(IInterface owner, String descriptor) {
        mOwner = owner;
        mDescriptor = descriptor;
    }
attachInterface()方法的主要作用是将一个Interface与一个Binder对象进行关联。该方法的主要作用是为后续调用queryLocalInterface()方法时，返回对应Interface所管理的Binder对象。

	public IInterface queryLocalInterface(String descriptor) {
        if (mDescriptor.equals(descriptor)) {//描述相等，则返回在attachInterface中保存的mOwner
            return mOwner;
        }
        return null;
    }

1.2 asInterface()方法

	public static cn.nubia.aidldemo.IRemoteService asInterface(android.os.IBinder obj)
	{
		if ((obj==null)) {
			return null;
		}
		android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);//返回DESCRIPTOR对应的IInterface对象
		if (((iin!=null)&&(iin instanceof cn.nubia.aidldemo.IRemoteService))) {
			return ((cn.nubia.aidldemo.IRemoteService)iin);//1.直接返回接口实现对象
		}
		return new cn.nubia.aidldemo.IRemoteService.Stub.Proxy(obj);//2.返回一个新建Proxy()类
	}
该方法的主要作用是将一个IXXXInterface接口转换为一个IBinder接口实现对象。上面代码中，IRemoteService代表IXXXInterface接口。

如果参数obj中没有保存DESCRIPTOR对应的IInterface对象，则新创建一个Proxy对象。例如在前面的构建Stub对象时，会调用attachInterface()方法，保存DESCRIPTOR对应的IInterface对象，该对象为Stub本身，因此asInterface()方法返回的对象就是Stub类，因为Stub类也实现了IXXXInterface接口。

	Proxy(android.os.IBinder remote)
	{
		mRemote = remote;//mRemote对象保存的是服务端的Binder对象引用
	}

1.3 asBinder()方法

	@Override 
	public android.os.IBinder asBinder()
	{
		return this;
	}
Stub类的asBinder()方法，直接返回Stub类本身；


### 2.Proxy类

在Proxy类中主要是调用mRemote的transact()方法来调用服务端对应的方法。transact()方法的参数与onTransact()方法中的参数是一致的。

2.1 transact()方法

transact()方法是定义在IBinder接口中，在Binder类中实现了该接口。

	public final boolean transact(int code, Parcel data, Parcel reply,
            int flags) throws RemoteException {
        if (false) Log.v("Binder", "Transact: " + code + " to " + this);
        if (data != null) {
            data.setDataPosition(0);
        }
        boolean r = onTransact(code, data, reply, flags);//调用Binder子类的onTransact()方法
        if (reply != null) {
            reply.setDataPosition(0);
        }
        return r;
    }
可以看到，在Binder中的transact()方法是一个final方法，子类是不可以覆写该方法的。也就是说，Binder子类调用的transact()方法都是Binder类中的transact()方法。

在transact()方法中，最终会调用onTransact()方法，该方法定义在Binder类中。

	protected boolean onTransact(int code, Parcel data, Parcel reply,
            int flags) throws RemoteException {
        if (code == INTERFACE_TRANSACTION) {
            reply.writeString(getInterfaceDescriptor());
            return true;
        } else if (code == DUMP_TRANSACTION) {
            ParcelFileDescriptor fd = data.readFileDescriptor();
            String[] args = data.readStringArray();
            if (fd != null) {
                try {
                    dump(fd.getFileDescriptor(), args);
                } finally {
                    try {
                        fd.close();
                    } catch (IOException e) {
                        // swallowed, not propagated back to the caller
                    }
                }
            }
            // Write the StrictMode header.
            if (reply != null) {
                reply.writeNoException();
            } else {
                StrictMode.clearGatheredViolations();
            }
            return true;
        }
        return false;
    }
可以看到，在Binder中的onTransact()方法是一个受保护的方法，也就是说，Binder子类都可以覆写该方法。例如前面提到的Stub类就覆写了onTransact()方法，因此当从客户端调用transact()方法时，会调用到服务端Binder子类的onTransact()方法，在onTransact()中处理具体的请求。

2.2 asBinder()方法

	@Override 
	public android.os.IBinder asBinder()
	{
		return mRemote;
	}
Proxy类的asBinder()方法返回的mRemote对象，该对象是在构造Proxy类的时候传递进来的参数。

### AIDL调用图

![AIDL调用图](http://gityuan.com/images/binder/AIDL/MyServer_java_binder.jpg)

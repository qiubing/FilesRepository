## 关键类

### IInterface接口

Binder接口的基础类。

### IBinder接口

IBinder接口描述了与远端Object进行交互的抽象协议。

不要直接实现该接口，而应该继承自Binder。

IBinder的关键API是transact接口，对应于Binder中的onTransact方法。这些方法允许你发送一个调用到IBinder对象，接收来自IBinder对象的调用。

传输接口是同步方法，当调用transaction方法时，会等待从Binder的onTransact()方法返回之后再返回。

### Binder类

Binder类代表远端对象的基础类，是IBinder接口的标准实现。

大部分开发者不会直接实现该类，而是通过使用AIDL工具来完成相应的工作。


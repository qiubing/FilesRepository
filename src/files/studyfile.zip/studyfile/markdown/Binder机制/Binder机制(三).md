## Binder机制(三)

### 1.Binder核心机制

Binder通信核心机制简要概述：

1. binder通信是一种client-server的通信结构；
2. 从表面上来看，是client通过获得一个server的代理接口，对server进行直接调用；
3. 实际上，代理接口中定义的方法与server中定义的方法是一一对应的；
4. Client调用某个代理接口中的方法时，代理接口的方法会将Client传递的参数打包成Parcel对象；
5. 代理接口将该Parcel发送给内核中的binder driver；
6. Server会读取binder driver中的请求数据，如果是发送给自己的，解包Parcel对象，处理并将结果返回。
7. 整个的调用过程是一个同步过程，在Server处理的时候，Client会block住。


BBinder对象代表的是Binder实体对象，也就是binder服务的提供者。

BpBinder对象代表的是Binder实体对象在客户进程的代理，也就是Binder引用对象；BpBinder也就是BproxyBinder。

### 2.ServiceManager

任何service在被使用之前，均要向SM(Service Manager)注册，同时客户端需要访问某个service时，应该首先向SM查询是否存在该服务。如果SM存在这个service，那么会将该service的handle返回给client，handle是每个service的唯一标识符。

SM的入口函数在service_manager.c中，它的主要工作为：

1. 初始化binder，打开/dev/binder设备；在内存中为binder映射128K字节空间；
2. 指定SM对应的代理binder的handle为0，当client尝试与SM通信时，需要创建一个handle为0的代理binder，这里的代理binder其实就是前面说到的那个代理接口；
3. 通知binder driver(BD)使SM成为BD的context manager；
4. 维护一个死循环，在这个死循环中，不停地去读内核中binder driver，查看是否有可读的内容；即是否有对service的操作要求, 如果有，则调用svcmgr_handler回调来处理请求的操作；
5. SM维护了一个svclist列表来存储service的信息；

说明一下：当service在向SM注册时，该service就是一个client，而SM则作为了server。而某个进程需要与service通信时，此时这个进程为client，service才作为server。因此service不一定为server，有时它也是作为client存在的。所以应用和service之间的通信会涉及到2次binder通信：1.应用向SM查询service是否存在，如果存在获得该service的代理binder，此为一次binder通信；2.应用通过代理binder调用service的方法，此为第二次binder通信。

### 3.ProcessState

ProcessState是以单例模式设计的。每个进程在使用binder机制通信时，均需要维护一个ProcessState实例来描述当前进程在binder通信时的binder状态，ProcessState有2个主要功能：

1. 创建一个thread,**该线程负责与内核中的binder模块进行通信**，称该线程为Pool thread。在Binder IPC中，所有进程均会启动一个thread来负责与BD来直接通信，也就是不停的读写BD，这个线程的实现主体是一个**IPCThreadState对象**。Pool thread的启动方式为：ProcessState::self()->startThreadPool()；
2. 为指定的handle创建一个BpBinder对象，并管理该进程中所有的BpBinder对象。

BpBinder主要功能是**负责client向BD发送调用请求的数据**。它是client端binder通信的核心对象，通过调用transact函数向BD发送调用请求的数据。通过BpBinder的构造函数发现，BpBinder会将当前通信中server的handle记录下来，当有数据发送时，会通知BD数据的发送目标。ProcessState获取BpBinder对象的方式为：ProcessState::self()->getContextObject(handle)；在这个过程中，ProcessState会维护一个BpBinder的vector mHandleToObject，每当ProcessState创建一个BpBinder的实例时，会去查询mHandleToObject，如果对应的handle已经有binder指针，那么不再创建，否则创建binder并插入到mHandleToObject中。ProcessState创建的BpBinder实例，一般情况下会作为参数构建一个client端的代理接口，这个代理接口的形式为BpINTERFACE,例如在与SM通信时，client会创建一个代理接口BpServiceManager。

### 4.IPCThreadState

IPCThreadState也是以单例模式设计的。由于每个进程只维护了一个ProcessState实例，同时ProcessState只启动一个Pool thread，也就是说每一个进程只会启动一个Pool thread，因此每个进程则只需要一个IPCThreadState即可。

Pool thread的实际内容就是：IPCThreadState::self()->joinThreadPool()。

ProcessState中有2个Parcel成员，mIn和mOut，Pool thread会不停的查询BD中是否有数据可读，如果有将其读出并保存到mIn，同时不停的检查mOut是否有数据需要向BD发送，如果有，则将其内容写入到BD中，总而言之，从BD中读出的数据保存到mIn，待写入到BD中的数据保存在了mOut中。

ProcessState中生成的BpBinder实例通过调用IPCThreadState的transact函数来向mOut中写入数据，在这个过程中，涉及两个重要的函数：

1. talkWithDriver函数负责从BD读写数据；
2. executeCommand函数负责解析并执行mIn中的数据；

### 5.重要的基类

- IInterface：为server端提供接口，它的子类声明了service能够实现的所有的方法。
- IBinder：BBinder与BpBinder均为IBinder的子类，因此可以看出**IBinder定义了binder IPC的通信协议**，BBinder与BpBinder在这个协议框架内进行的收和发操作，构建了基本的binder IPC机制。
- BpRefBase：client端在查询SM获得所需的的BpBinder后，BpRefBase负责管理当前获得的BpBinder实例。


### 6.两个接口类

- **BpINTERFACE**

如果client想要使用binder IPC来通信，那么首先会从SM中查询并获得server端service的BpBinder，在client端，这个对象被认为是server端的远程代理。

为了能够使client像本地调用一样调用一个远程server，server端需要向client提供一个接口，client在在这个接口的基础上创建一个BpINTERFACE，使用这个对象，client的应用就能像本地调用一样直接调用server端的方法。BpINTERFACE的原型：

	class BpINTERFACE : public BpInterface<IINTERFACE>{
	
	}
顺着继承关系再往上看：
	
	template<typename INTERFACE> class BpInterface : public INTERFACE, public BpRefBase{
		
	}
所以BpINTERFACE分别继承自INTERFACE，和BpRefBase；

BpINTERFACE既实现了service中各方法的本地操作，将每个方法的参数以Parcel的形式发送给BD。例如BpServiceManager的virtual status\_t addService(const String16& name, const sp<IBinder>& service)方法。同时又将BpBinder作为了自己的成员来管理，将BpBinder存储在mRemote中，BpServiceManager通过调用BpRefBase的remote()来获得BpBinder指针。

**BnINTERFACE**

在定义android native端的service时，每个service均继承自BnINTERFACE(INTERFACE为service name)。

BnINTERFACE类型定义了一个onTransact函数，这个函数负责解析收到的Parcel并执行client端的请求的方法。

顺着BnINTERFACE的继承关系再往上看：

	class BnINTERFACE: public BnInterface<IINTERFACE>{
		
	}
IINTERFACE为client端的代理接口BpINTERFACE和server端的BnINTERFACE的共同接口类，这个共同接口类的目的就是保证service方法在C-S两端的一致性。

再往上看：

	class BnInterface : public INTERFACE, public BBinder{
		
	}

同时我们发现了BBinder类型，这个类型又是干什么用的呢？既然每个service均可视为一个binder，那么真正server端的binder的操作及状态的维护就是通过继承自BBinder来实现的。可见BBinder是service作为binder的本质所在。

那么BBinder与BpBinder的区别又是什么呢？

其实它们的区别很简单，BpBinder是client端创建的用于消息发送的代理，而BBinder是server端用于接收消息的通道。

虽然两个类型均有transact的方法，但是两者的作用不同，BpBinder的transact方法是向IPCThreadState实例发送消息，通知其有消息要发送给BD；而BBinder则是当IPCThreadState实例收到BD消息时，通过BBinder的transact的方法将其传递给它的子类BnSERVICE的onTransact函数执行server端的操作。

### 7.Parcel

Parcel是binder IPC中的最基本的通信单元，它存储C-S间函数调用的参数.但是Parcel只能存储基本的数据类型，如果是复杂的数据类型的话，在存储时，需要将其拆分为基本的数据类型来存储。

Parcel有两个重要的函数：writeStrongBinder和readStrongBinder。

- writeStrongBinder：当client需要将一个binder向server发送时，可以调用此函数；如addService函数中的调用。写入到Parcel的binder类型为BINDER\_TYPE\_BINDER，而我们在看SM的代码时会发现如果SM收到的service的binder类型不为BINDER\_TYPE\_HANDLE时，SM就不会将此service添加到svclist，但是很显然每个service的添加都是成功的，addService在开始传递的binder类型为BINDER_TYPE_BINDER，SM收到的binder类型为BINDER\_TYPE\_HANDLE，那么这个过程当中究竟发生了什么？原来在BD中做了如下操作，看binder\_transaction函数。发现这个过程做了相应的转换。

**SM只是保存了service binder的handle和service的name**，那么当client需要和某个service通信了，如何获得service的binder呢？这就需要看另外一个重要的函数readStrongBinder了。

- readStrongBinder：当server端收到client的调用请求之后，如果需要返回一个binder时，可以向BD发送这个binder，当IPCThreadState实例收到这个返回的Parcel时，client可以通过这个函数将这个被server返回的binder读出。

如果server返回的binder类型为BINDER\_TYPE\_BINDER的话，也就是返回一个binder引用的话，直接获取这个binder；如果server返回的binder类型为BINDER\_TYPE\_HANDLE时，也就是server返回的仅仅是binder的handle，那么需要重新创建一个BpBinder返回给client。


### 8.Binder的几个重要的核心原理

#### 8.1面向对象原理

Binder使用Client-Server通信方式：一个进程作为Server提供诸如视频/音频解码，视频捕获，地址本查询，网络连接等服务；其他一个或多个进程作为Client向Server发起服务请求，获得所需要的服务。所以要想实现Client-Server通信就必须实现以下两点：

- 一是server必须有确定的访问接入点或者说确切的地址来接受Client的请求，并且Client可以通过某种途径获知Server的地址；
- 二是制定Command-Reply协议来传输数据。

例如在网络通信中Server的访问接入点就是Server主机的IP地址+端口号，传输协议为TCP协议。而对Binder而言，Binder就可以看成Server提供的实现某个特定服务的访问接入点， Client通过这个访问接入点向Server发送请求来使用该服务；

与其它IPC不同，Binder使用了面向对象的思想来描述作为访问接入点的Binder及其在Client中的入口：Binder是一个实体位于Server中的对象，该对象提供了一套方法用以实现对服务的请求，就像类的成员函数。遍布于client中的入口可以看成指向这个binder对象的‘指针’，一旦获得了这个‘指针’就可以调用该对象的方法访问server。在Client看来，通过Binder‘指针’调用其提供的方法和通过指针调用其它任何本地对象的方法并无区别，尽管前者的实体位于远端Server中，而后者实体位于本地内存中。‘指针’是C++的术语，而更通常的说法是引用，即Client通过Binder的引用访问Server。而软件领域另一个术语‘句柄’也可以用来表述Binder在Client中的存在方式。从通信的角度看，Client中的Binder也可以看作是Server Binder的‘代理’，在本地代表远端Server为Client提供服务。本文中会使用‘引用’或‘句柄’这个两广泛使用的术语。

面向对象思想的引入将进程间通信转化为通过对某个Binder对象的引用调用该对象的方法，而其独特之处在于Binder对象是一个可以跨进程引用的对象，它的实体位于一个进程中，而它的引用却遍布于系统的各个进程之中。最诱人的是，这个引用和java里引用一样既可以是强类型，也可以是弱类型，而且可以从一个进程传给其它进程，让大家都能访问同一Server，就像将一个对象或引用赋值给另一个引用一样。Binder模糊了进程边界，淡化了进程间通信过程，整个系统仿佛运行于同一个面向对象的程序之中。形形色色的Binder对象以及星罗棋布的引用仿佛粘接各个应用程序的胶水，这也是Binder在英文里的原意。


#### 8.2 serviceManager实现server查找的原理

和DNS类似，serviceManager的作用是将字符形式的Binder名字转化成Client中对该Binder的引用，使得Client能够通过Binder名字获得对Server中Binder实体的引用。

注册了名字的Binder叫实名Binder，就好像每个网站除了有IP地址外还有自己的网址。Server创建了Binder实体，为它取一个字符形式，可读容易记的名字，然后将这个Binder连同名字以数据包的形式通过Binder驱动发送给serviceManager，并通知serviceManager注册一个名叫“张三“的Binder，它位于某个Server中。

Binder驱动为这个穿过进程边界的Binder创建位于内核中的实体节点以及serviceManager对实体的引用，然后将名字及新建的引用打包传递给serviceManager。

最后serviceManager收数据包后，从中取出名字和引用填入一张查找表中。

那么这里还有一个问题就是：serviceManager是一个进程，Server是另一个进程，Server向serviceManager注册Binder必然会涉及进程间通信。这就相当于实现的是进程间通信却又要用到进程间通信，这就好像蛋可以孵出鸡但前提是要找只鸡来孵蛋。对于这一点Binder的实现比较巧妙：它是预先创造一只鸡来孵蛋：serviceManager和其它进程同样采用Binder通信，这个时候serviceManager是Server端，有自己的Binder实体对象，其它进程都是Client，需要通过这个Binder的引用来实现Binder的注册、查询和获取。serviceManager提供的Binder比较特殊，它没有名字也不需要注册，当一个进程使用BINDER\_SET\_CONTEXT\_MGR命令将自己注册成serviceManager时Binder驱动会自动为它创建Binder实体（这就是那只预先造好的鸡）。其次这个Binder的引用在所有Client中都固定为0而无须通过其它手段获得。也就是说，一个Server若要向serviceManager注册自己Binder就必需通过0这个引用号和serviceManager的Binder进行通信。类比于网络通信，0号引用就像是域名服务器的地址，你必须预先手工或动态配置好，先和域名服务器建立通信连接。要注意这里说的Client是相对ServiceManager而言的，一个应用程序可能是提供服务的Server，但对serviceManager来说它仍然是个Client。

Server向ServiceManager注册了Binder实体及其名字后，Client就可以通过名字获得该Binder的引用了。Client也利用保留的0号引用向ServiceManager请求访问某个Binder：我申请获得名字叫”张三”的Binder的引用。ServiceManager收到这个连接请求，从请求数据包里获得Binder的名字，在查找表里找到该名字对应的条目，从条目中取出Binder的引用，将该引用作为回复发送给发起请求的Client。从面向对象的角度，这个Binder对象现在有了两个引用：一个位于ServiceManager中，一个位于发起请求的Client中。如果接下来有更多的Client请求该Binder，系统中就会有更多的引用指向该Binder，就象java里一个对象存在多个引用一样。而且类似的这些指向Binder的引用是强类型，从而确保只要有引用Binder实体就不会被释放掉。这就像火车票代售一样，ServiceManager就是一个火车票代售点，收集了所有火车的车票，可以通过它购买到乘坐各趟火车的票-得到某个Binder的引用。

**匿名Binder**

还有一个匿名binder的概念，需要了解清楚，需要了解匿名binder是怎么来的，因为并不是所有的Binder都需要注册给servicemanager的，有的时候server端可以通过已经建立的Binder连接将创建的binder实体传给client，当然这条已经建立的binder连接必须是通过实名Binder实现，由于这个binder 没有向servicemanager注册名字，所以是个匿名的binder，client将会收到这个匿名Binder的引用，通过这个引用向位于server中的实体发送请求。匿名Binder为通信双方建立一条私密通道，只要server没有把匿名Binder发给别的进程，别的进程就无法通过穷举或猜测等任何方式获得该binder的引用，向该binder发送请求；
这个匿名Binder就是支持匿名服务而设定的，一般我们自己开发应用的binder服务经常不会加入到servicemanager中进行系统管理，所以这个服务就属于匿名服务。针对匿名服务，使用者还是需要通过Binder才能得到它的引用对象。匿名服务常用的场景是服务进程回调客户进程中的函数。过程如下：客户端与服务端通过Binder连接上后，客户端把本进程中创建的匿名服务的实体对象作为函数参数传递给服务端，然后驱动会在中间把实体对象转换成引用对象，这样服务进程就得到了客户进程创建的binder服务的引用对象，然后就能回调客户进程中Binder服务的函数了。

#### 8.3 Binder接收线程管理

Binder通信的设计就是位于不同进程中的线程之间的通信。

这里假设进程S是Server端，提供Binder实体，线程T1从Client进程C1中通过Binder的引用向进程S发送请求。S为了处理这个请求需要启动线程T2，而此时线程T1处于接收返回数据的等待状态。T2处理完请求就会将处理结果返回给T1，然后T1被唤醒得到处理结果。在这过程中，T2就像是T1在进程S中的代理，代表T1执行远程任务，而给T1的感觉就是象穿越到S中执行一段代码又回到了C1。为了使这种穿越更加真实，驱动会将T1的一些属性赋给T2，特别是T1的优先级nice，这样T2会使用和T1类似的时间完成任务。很多资料会用‘线程迁移’来形容这种现象，容易让人产生误解。一来线程根本不可能在进程之间跳来跳去，二来T2除了和T1优先级一样，其它没有相同之处，包括身份，打开文件，栈大小，信号处理，私有数据等。

对于Server进程S，可能会有很多Client同时发起请求，为了提高效率往往开辟线程池并发处理收到的请求。那么怎样使用线程池实现并发处理呢？这个应该和具体的IPC机制有关。比如socket，Server端的socket设置为监听模式，有一个专门的线程使用该socket监听来自Client的连接请求，即阻塞在accept()上。这个socket就象一只会生蛋的鸡，一旦收到来自Client的请求就会生一个蛋 – 创建新socket并从accept()返回。侦听线程从线程池中启动一个工作线程并将刚下的蛋交给该线程。后续业务处理就由该线程完成并通过这个蛋与Client实现交互。但是binder机制中没有侦听模式也不会下蛋（也就是不能创建新的socket）,所以能做的就是直接先创建一堆线程，而每个线程都用BINDER_WRITE_READ命令读Binder，这些线程会阻塞在驱动为该Binder设置的等待队列上，一旦有来自Client的数据驱动会从队列中唤醒一个线程来处理。这样做简单直观，省去了线程池，但一开始就创建一堆线程有点浪费资源。于是Binder协议引入了专门的命令或消息帮助用户管理线程池，如：

- BINDER\_SET\_MAX\_THREADS；
- BC\_REGISTER\_LOOP；
- BC\_ENTER\_LOOP；
- BC\_EXIT\_LOOP；
- BR\_SPAWN\_LOOPER；

它的原理如下：

要管理线程池，首先必须要知道这个线程池的池子有多大,这个线程池是有binder驱动来控制的。而应用程序需要通过BINDER\_SET\_MAX\_THREADS告诉驱动我们的这次Binder通信最多可以创建几个线程。以后每个线程的创建，进入主循环，退出主循环时都要分别使用BC_REGISTER\_LOOP，BC\_ENTER\_LOOP，BC\_EXIT\_LOOP这几个消息来告知驱动，以便驱动收集和记录当前线程池的状态。每当驱动接收完数据包返回读Binder的线程时，都要检查一下是不是前面已经创建的线程没有闲置线程了。如果前面已经创建的线程没有空置线程了，并且线程总数不会超出线程池的最大线程数，就会在当前读出的数据包后面再追加一条BR\_SPAWN\_LOOPER消息，告诉用户线程即将不够用了，请再启动一些，否则下一个请求可能不能及时响应。然后新线程一启动又会通过BC\_xxx\_LOOP告知驱动更新状态。这样只要线程没有耗尽，总是有空闲线程在等待队列中随时待命，及时处理请求。

另外,还有一点,就是工作线程的启动问题, Binder驱动有一个优化。即当进程P1的线程T1向进程P2发送请求时，驱动会先查看一下线程T1是否也正在处理来自P2某个线程请求但尚未完成（没有发送回复）。这种情况通常发生在两个进程都有Binder实体并互相对发时请求时(也就是两个进程间通信的时候即可以作为server端,又可以作为client端)。假如驱动在进程P2中发现了这样的线程，比如说T2(也就是正在等待T1的处理结果的线程)，就会要求T2来处理T1的这次请求。因为T2既然向T1发送了请求尚未得到返回包，说明T2肯定（或将会）阻塞在读取返回包的状态。这时候可以让T2顺便做点事情，总比等在那里闲着好。而且如果T2不是线程池中的线程还可以为线程池分担部分工作，减少线程池使用率。

#### 8.4 数据包接收队列与线程等待队列管理

通常数据传输的接收端有两个队列,一个数据包接收队列,一个线程等待队列，用以缓解供需矛盾。如果数据包太多，数据就会堆积太多而不能及时处理；而如果等待队列太多，就会导致多个线程在等待数据处理而使得资源浪费。在binder驱动中，每个进程有一个全局的接收队列，也叫to-do队列，存放不是发往特定线程的数据包。而相应地也会有一个全局等待队列，所有等待从全局接收队列里接收数据的线程在该队列里排队；同样的，每个线程都有自己私有的to-do队列，存放发送给该线程的数据包。相应的每个线程都有各自私有等待队列，专门用于本线程等待接收自己to-do队列里的数据。虽然名字也叫队列，但其实线程的私有等待队列中最多只有一个线程，就是它自己。

由于发送时没有特别标记，驱动怎么判断哪些数据包该送入全局to-do队列，哪些数据包该送入特定线程的to-do队列呢？有两条规则：

1. Client发给Server的请求数据包都提交到Server进程的全局to-do队列。不过有个特例，就是上面说到的的Binder对工作线程启动的优化的部分，即Client端和Server端分别也作为Server端和Client端来进行的双向通信的情况。经过优化，来自T1的请求不是提交给P2的全局to-do队列，而是送入了T2的私有to-do队列。
2. 对同步请求的返回数据包（由BC_REPLY发送的包）都发送到发起请求的线程的私有to-do队列中。如上面的例子，如果进程P1的线程T1发给进程P2的线程T2的是同步请求，那么T2返回的数据包将送进T1的私有to-do队列而不会提交到P1的全局to-do队列。

数据包进入接收队列的规则也就决定了线程进入等待队列的潜规则，即一个线程只要不接收返回数据包则应该在全局等待队列中等待新任务，否则就应该在其私有等待队列中等待Server的返回数据。上面的例子中， T1在向T2发送同步请求后就必须等待在它私有等待队列中，而不是在P1的全局等待队列中排队，否则将得不到T2的返回的数据包。


这些规则是驱动对Binder通信双方施加的限制条件，体现在应用程序上就是同步请求交互过程中的线程一致性：1) Client端，等待返回包的线程必须是发送请求的线程，而不能由一个线程发送请求包，另一个线程等待接收包，否则将收不到返回包；2) Server端，发送对应返回数据包的线程必须是收到请求数据包的线程，否则返回的数据包将无法送交发送请求的线程。这是因为返回数据包的目的Binder不是用户指定的，而是驱动记录在收到请求数据包的线程里，如果发送返回包的线程不是收到请求包的线程驱动将不知道返回包将送往何处。


最后关于同步交互和异步交互的理解：同步交互和异步交互的区别是同步交互的请求端（client）在发出请求数据包后须要等待应答端（Server）的返回数据包，而异步交互的发送端发出请求数据包后交互即结束。对于这两种交互的请求数据包，驱动不是统统丢到接收端的to-do队列中一个一个处理，而是对异步交互做了限流，让他为同步交互让路，具体做法是：对于某个Binder实体，只要有一个异步交互没有处理完毕，例如正在被某个线程处理或还在任意一条to-do队列中排队，那么接下来发给该实体的异步交互包将不再投递到to-do队列中，而是阻塞在驱动为该实体开辟的异步交互接收队列（Binder节点的async_todo域）中，但这期间同步交互依旧不受限制直接进入to-do队列获得处理。一直到该异步交互处理完毕下一个异步交互方可以脱离异步交互队列进入to-do队列中。之所以要这么做是因为同步交互的请求端需要等待返回包，必须迅速处理完毕以免影响请求端的响应速度，而异步交互属于发送后不管，稍微延时一点不会阻塞其它线程。所以用专门队列将过多的异步交互暂存起来，以免突发大量异步交互挤占Server端的处理能力或耗尽线程池里的线程，进而阻塞同步交互。

所以总结来说Binder使用Client-Server通信方式，安全性好，简单高效，再加上其面向对象的设计思想，独特的接收缓存管理和线程池管理方式，成为Android进程间通信的中流砥柱。

### 9.Binder驱动
binder驱动的功能就是：

- 提供Binder通信的通道；
- 维护Binder对象的引用计数；
- 转换传输中的binder实体对象和引用对象；
- 管理数据缓存区。


Binder驱动的重要数据结构：

- binder_work：描述处理的工作项
- binder_node：描述一个Binder实体对象
- binder\_ref\_death：描述一个Service组件的死亡接收通知
- binder_ref：描述一个Binder引用对象
- binder_buffer：描述一个内核缓冲区，它是用来在进程间传输数据
- binder_proc：描述一个正在使用Binder进程间通信机制的进程
- binder_thread ：描述Binder线程池中的一个线程
- binder_transaction：描述进程间通信过程，这个过程又称为一个事务
- binder\_write\_read：描述进程间通信过程中所传输的数据
- binder\_transaction\_data：描述进程间通信过程中所传输的数据
- binder\_driver\_command\_protocol：请求协议
- binder\_driver\_return\_protocol：响应协议
- binder\_ptr\_cookie：描述一个Binder实体对象或者一个Service组件的死亡接收通知
- flat\_binder\_object：即可以描述一个Binder实体对象和一个Binder引用对象，还可以用来描述一个文件描述符


Binder通信中，由Binder驱动负责管理数据接收缓存，在binder驱动中实现了mmap()系统调用，用来创建数据接收的缓存空间。

接收缓存区映射好后就可以做为缓存池接收和存放数据了，接收数据包的结构为binder\_transaction\_data，但这只是消息头，真正的有效数据位于data.buffer所指向的内存中的，而这片内存不需要接收方提供，恰恰是来自mmap()映射的这片缓存池。

在数据从发送方向接收方拷贝时，驱动会根据发送数据包的大小，使用最佳匹配算法从缓存池中找到一块大小合适的空间，将数据从发送缓存区复制过来。

### 10.Binder通信过程中的ANR分析

trace log：在发生anr的时候才会生成trace log，trace log中所表达的信息是**发生anr时刻系统中进程和线程的当前运行状态，它表示的是一个时间点**，不是一个时间段。所以它并不能非常准确的反映anr问题的根源。

**进程的主线程的tid与进程号是一样的**。

一个进程最多只能创建16个binder线程。

确定一个trace log是否是因为Binder通信导致的anr，必须要满足两个条件：

1. trace log当前进程的主线程是否处于waitForResponse状态下。
2. 进程主线程通信对端的binder线程是否创建满且被全部占用。





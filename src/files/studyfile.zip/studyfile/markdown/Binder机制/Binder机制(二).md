## Binder机制(二)

Client进程向Server进程通信，利用**进程间可共享的内核内存空间**来完成底层通信工作。

Client端与Server端进程采用**ioctl等方法**与内核空间的驱动进行交互。


### 1.Binder IPC机制

在进程间传输数据(binder\_transaction\_data)，一次数据的传输，称为事务(binder\_transaction)。对于多个不同进程向同一个进程发送事务时，这个同一个进程或线程的事务需要**串行执行**，在Binder驱动中binder\_proc和binder\_thread都有todo队列。


### 2.Binder原理

对于进程间的通信，就是发送端把binder\_transation节点，插入到目标进程或其子线程的todo队列中，等目标进程或线程不断循环地从todo队列中取出数据并进行相应的操作。

![](http://orbohk5us.bkt.clouddn.com/17-11-7/85936683.jpg)

Binder通信采用C/S架构。

从组件视角来说，包含了Client、Server、ServiceManager以及binder驱动，其中ServiceManager用于管理系统中的各种服务。

当ServiceManager启动之后，Client端和Server端通信时都需要先获取ServiceManager接口，才能开始通信服务。

Binder是客户端和服务端进行通信的媒介，当bindService的时候，服务端会返回一个包含了服务端业务调用的Binder对象，通过这个Binder对象，客户端就可以获取服务端提供的服务或者数据，这里的服务包括**普通服务和基于AIDL的服务**。

#### 2.1 C/S模式

![Binder C/S模式](http://orbohk5us.bkt.clouddn.com/17-11-7/14286060.jpg)

- **client端**：BpBinder.transact()用来发送事务请求；

- **server端**：BBinder.onTransact()会接收相应的事务；

![Binder架构](http://orbohk5us.bkt.clouddn.com/17-11-7/19442869.jpg)

#### 2.2 Binder进程与线程

![Binder进程与线程](http://orbohk5us.bkt.clouddn.com/17-11-7/16355628.jpg)

对于底层Binder驱动，通过binder\_procs链表记录所有创建的binder\_proc结构体。binder驱动层的每一个binder\_proc结构体都与用户空间的一个用于binder通信的进程一一对应，且每个进程有且只有一个**ProcessState对象**，这是通过单例模式来保证的。

在每个进程中可以有很多线程，每个线程对应一个**IPCThreadState对象**。IPCThreadState对象也是单例模式，即一个线程对应一个IPCThreadState对象，在Binder驱动层也有与之相对应的结构，那就是binder\_thread结构体。在binder\_proc结构体中通过成员变量rb\_root\_threads来记录当前进程内所有的binder\_thread。


**Binder线程池**：每个Server进程在启动时会创建一个binder线程池，并向其中注册一个Binder线程；之后，Server进程也可以向binder线程池注册新的线程，或者Binder驱动在探测到没有空闲binder线程时，也会主动向Server进程注册新的binder线程。

对于一个Server进程有一个最大Binder线程数限制，默认为**16个binder线程**。例如Android的system\_server进程就存在16个线程。

**对于所有client端进程的binder请求都是交由server端进程的binder线程来处理的**。


![Binder传输过程](http://orbohk5us.bkt.clouddn.com/17-11-7/27112079.jpg)


在Binder驱动层，**每个接收端进程都有一个todo队列，用于保存发送端进程发送过来的binder请求**。这类请求可以由接收端进程的任意一个空闲的binder线程处理；

接收端进程存在一个或多个binder线程，在每个binder线程里都有一个todo队列，也是用于保存发送端进程发送过来的binder请求，这类请求只能由当前binder线程来处理。

binder线程在空闲时进入可中断的休眠状态，当自己的todo队列或所属进程的todo队列有新的请求到来时便会唤醒，如果是由所需进程唤醒的，那么进程会让其中一个线程处理响应的请求，其他线程再次进入休眠状态。

对于Binder驱动来说，应尽可能地把binder\_transaction节点插入到目标进程的某个binder线程的todo队列，效率更高。当Binder驱动可以找到合适的线程，就会把binder\_transaction节点插入到相应线程的todo队列中。如果找不到合适的线程，就把节点插入到进程binder_proc的todo队列。

#### 2.3 Binder驱动

Binder驱动是Android专用的，但底层的驱动架构与Linux驱动一样。

Binder驱动以**misc设备**进行注册，作为虚拟设备，没有直接操作硬件，只是对设备内存的处理。

Binder驱动的操作：

1. 通过init(),创建/dev/binder设备节点；
2. 通过open(),获取Binder Driver的文件描述符；
3. 通过mmap(),在内核分配一块内存，用于存放数据；
4. 通过ioctl()，将IPC数据作为参数传递给Binder Driver。

初始化：binder_init()

打开：binder_open()

映射：binder_mmap()

数据操作：binder_ioctl()

#### 2.4 Binder系统调用

![Binder系统调用](http://orbohk5us.bkt.clouddn.com/17-11-7/76038108.jpg)

用户态的程序调用kernel层驱动是需要陷入内核态，进行系统调用(syscall)，比如打开Binder驱动方法的调用链为：

	open->_open()->binder_open()

open()为用户空间方法，\_open()是系统调用(syscall)中相应的方法，通过查找，对应调用到内核binder驱动的binder\_open()方法，至于其他方法从用户态陷入到内核态的流程也基本一致。

**Binder从用户态进入内核态，都依赖于系统调用过程**。

Binder系统核心方法：

- **binder_init()**
	- 创建名为binder的工作队列；
	- 注册misc设备；

- **binder_open()**
	- 创建binder\_proc对象，并把当前进程等信息保存到binder\_proc对象；
	- 把binder\_proc对象保存到文件指针filp，以及把binder\_proc加入到全局链表binder_procs。
	- 通过HLIST\_HEAD(binder\_procs)创建了全局的哈希链表binder\_procs，用于保存所有的binder\_proc队列，每次新创建的binder\_proc对象都会加入binder\_procs链表中。
	
- **binder_mmap()**
	- binder\_mmap()通过加锁，保证一次只有一个进程分配内存，保证多进程间的并发访问。
	- user\_buffer\_offset是虚拟进程地址空间与虚拟内核地址的差值，也就是说同一物理地址，当内核地址为kernel\_addr，则进程地址为proc\_addr = kernel\_addr + user\_buffer\_offset。
	- binder\_update\_page\_range主要完成的工作：**分配物理空间，将物理空间映射到内核空间，将物理空间映射到进程空间**。

	![](http://orbohk5us.bkt.clouddn.com/17-11-7/2033024.jpg)
- **binder_ioctl()**
	- binder_ioctl()函数负责在两个进程间收发IPC数据和IPC reply数据。
	- ioctl(文件描述符，ioctl命令，数据类型)
		- 文件描述符是通过open()方法打开Binder Driver后返回的值；
		- ioctl命令和数据类型是一体的，不同的命令对应不同的数据类型；
![](http://orbohk5us.bkt.clouddn.com/17-11-7/73466146.jpg)


### 3.Binder分层通信

![](http://orbohk5us.bkt.clouddn.com/17-11-7/80597605.jpg)

Client进程通过RPC(Remote Procedure Call Protocol)与Server通信，可以简单地划分为三层：**驱动层、IPC层、业务层**。

demo()便是Client端和Server端共同协商好的统一方法。handle、RPC数据、PRC代码、Binder协议这4项组成了IPC层的数据，通过IPC层进行数据传输；而真正在Client和Server两端建立通信的基础设施便是Binder Driver。

例如，当名为BatteryStatsService的Client向ServiceManager注册服务的过程中，IPC层的数据组成为：Handle=0，RPC代码为ADD\_SERVICE\_TRANSACTION，RPC数据为BatteryStatsService，Binder协议为BC\_TRANSACTION。

#### 3.1 Binder通信协议

##### 3.1.1 Binder请求协议

![](http://orbohk5us.bkt.clouddn.com/17-11-7/94300443.jpg)

Binder协议包含在IPC数据中，分为两类：

- BINDER\_COMMAND\_PROTOCOL：Binder请求码，以“BC_”开头，简称BC码，用于从IPC层传递到Binder Driver层；
- BINDER\_RETURN\_PROTOCOL：Binder响应码，以“BR_”开头，简称BR码，用于从Binder Driver层传递到IPC层；

binder请求码，是用enum binder\_driver\_command\_protocol来定义的，是用于应用程序向binder驱动设备发送请求消息，应用程序包含Client端和Server端，以BC_开头，总17条。

![](http://orbohk5us.bkt.clouddn.com/17-11-7/99094637.jpg)

1. **BC\_FREE\_BUFFER**：通过mmap()映射内存，**其中ServiceManager映射的空间大小为128K，其他Binder应用进程映射的内存大小为1M-8K**。Binder驱动基于这块映射的内存采用**最佳匹配算法来动态分配和释放**，通过**binder\_buffer**结构体中的free字段来表示相应的buffer是空闲还是已分配状态。对于已分配的buffers加入到binder\_proc中的allocated\_buffers红黑树;对于空闲的buffers加入到binder\_proc中的free\_buffers红黑树。当应用程序需要内存时，根据所需内存大小从free\_buffers中找到最合适的内存，并放入allocated\_buffers树；当应用程序处理完后必须尽快使用BC\_FREE\_BUFFER命令来释放该buffer，从而添加回到free\_buffers树中。


2. Binder线程创建与退出：
	- BC\_ENTER\_LOOPER：binder主线程(由应用层发起)的创建会向驱动发送该消息；
	- BC\_REGISTER\_LOOPER：Binder用于驱动层决策而创建新的binder线程；
	- BC\_EXIT\_LOOPER：退出Binder线程，对于binder主线程是不能退出。

3. 请求处理过程是通过binder\_thread\_write()方法，该方法用于处理Binder协议中的请求码。当binder\_buffer存在数据，binder线程的写操作循环执行。

4. 对于请求码为BC\_TRANSACTION或BC\_REPLY时，执行binder\_transaction()方法进行Binder事务处理。


##### 3.1.2 Binder响应协议

![](http://orbohk5us.bkt.clouddn.com/17-11-7/94300443.jpg)

binder响应码，是用enum binder\_driver\_return\_protocol来定义的，是binder设备向应用程序回复的消息，应用程序包含Client端和Server端，以BR_开头，总18条。

![](http://orbohk5us.bkt.clouddn.com/17-11-7/86345993.jpg)

- **BR\_SPAWN\_LOOPER**：binder驱动已经检测到进程中没有线程等待即将到来的事务。那么当一个进程接收到这条命令时，该进程必须创建一条新的服务线程并注册该线程。
- **BR\_TRANSACTION\_COMPLETE**：当Client端向Binder驱动发送BC\_TRANSACTION命令后，Client会收到BR\_TRANSACTION\_COMPLETE命令，告知Client端请求命令发送成功；对于Server向Binder驱动发送BC\_REPLY命令后，Server端会收到BR_TRANSACTION\_COMPLETE命令，告知Server端请求回应命令发送成功。
- **BR\_DEAD\_REPLY**：当应用层向Binder驱动发送Binder调用时，若Binder应用层的另一个端已经死亡，则驱动回应BR\_DEAD\_BINDER命令。
- **BR\_FAILED\_REPLY**：当应用层向Binder驱动发送Binder调用时，若transaction出错，比如调用的函数号不存在，则驱动回应BR\_FAILED\_REPLY。

当transaction堆栈为空，且线程todo链表为空，且non\_block=false时，意味着没有任何事务需要处理的，会进入等待客户端请求的状态。

当有事务需要处理时便会进入循环处理过程，并生成相应的响应码。在Binder驱动层，只有在进入binder\_thread\_read()方法时，同时满足以下条件，才会生成BR_SPAWN_LOOPER命令，当用户态进程收到该命令则会创建新线程：

- binder\_proc的requested\_threads线程数为0；
- binder\_proc的ready\_threads线程数为0；
- binder\_proc的requested\_threads\_started个数小于15(即最大线程个数)；
- binder\_thread的looper状态为BINDER\_LOOPER\_STATE\_REGISTERED或BINDER\_LOOPER\_STATE\_ENTERED。

处理响应码的过程是在**用户态进行处理**，即用户空间IPCThreadState类中的IPCThreadState::waitForResponse()和IPCThreadState::executeCommand()两个方法共同处理Binder协议中的18个响应码。

#### 3.2 Binder通信模型

![Binder通信模型](http://orbohk5us.bkt.clouddn.com/17-11-7/55020165.jpg)

#### 3.3 Binder内存

![](http://orbohk5us.bkt.clouddn.com/17-11-7/37077115.jpg)

**虚拟进程地址空间(vm\_area\_struct)和虚拟内核地址空间(vm\_struct)都映射到同一块物理内存空间**。当Client端向Server端发送数据时，Client（作为数据发送端）先从自己的进程空间把IPC通信数据copy\_from\_user拷贝到内核空间，而Server端（作为数据接收端）与内核共享数据，不再需要拷贝数据，而是通过内存地址空间的偏移量，即可获悉内存地址，整个过程只发生一次内存拷贝。一般地做法，需要Client端进程空间拷贝到内核空间，再由内核空间拷贝到Server进程空间，会发生两次拷贝。

![](http://orbohk5us.bkt.clouddn.com/17-11-7/12863209.jpg)

Binder内存分配方法通过binder\_alloc\_buf()方法，**内存管理单元为binder\_buffer结构体**。

Binder内存释放方法通过binder\_free\_buf()方法。







## Binder线程池

Binder线程池的创建流程如下所示：

![Binder线程池的创建流程](http://gityuan.com/images/binder/binder-thread-pool/binder_thread_create.jpg)

在执行IPCThreadState.joinThreadPool()方法时，会根据参数isMain决定是否创建Binder主线程。

- 当isMain = true时，command为BC\_ENTER\_LOOPER，则代表的是Binder主线程，该线程不会退出。
- 当isMain = false时，command为BC\_REGISTER\_LOOPER，则代表的是由Binder驱动请求创建的线程。

在Binder设计架构中，只有第一个Binder主线程(也就是Binder_1)是由应用程序主动创建的，Binder线程池中的普通线程则都是由Binder驱动根据IPC通信需求创建的。

每次由Zygote fork出新进程的过程中，都伴随着创建binder线程池，通过调用spawnPooledThread来创建Binder主线程。当线程执行binder\_thread\_read的过程中，发现**当前没有空闲线程，没有请求创建线程，且没有达到上限**，则会创建新的binder线程。

可以看到，触发Binder驱动请求进程创建binder线程的条件有：

- 当前没有空闲线程；
- 当前没有请求创建线程；
- 没有达到线程数量的上限(15)；

Binder系统中可以分为3类binder线程：

- **Binder主线程**：在进程的创建过程中，会调用startThreadPool()方法，接着进入到spawnPooledThread(true)，来创建Binder主线程。编号是从1开始，也就是意味着binder主线程名称为Binder_1，并且主线程是不会退出的。
- **Binder普通线程**：由Binder Driver来根据是否有空闲的binder线程来决定是否创建binder线程，回调swapPooledThread(false)，isMain = false,该线程的名称格式为Binder_x。
- **Binder其他线程**：其他线程是指没有调用spawnPooledThread方法来创建线程，而是直接调用IPC.joinThreadPool()方法，将当前线程直接加入到Binder线程队列中。例如:mediaserver和servicemanager的主线程都是binder线程，但system_server的主线程并非binder线程。





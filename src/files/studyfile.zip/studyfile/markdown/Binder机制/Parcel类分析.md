## Parcel
[TOC]

> Parcel是进程间数据传递的载体。

在同一个进程间的对象传递是通过引用来做的，因而本质上就是传递了一个**内存地址**。这种方式在跨进程的情况下就无能为力了。由于采用了虚拟内存地址，两个进程都有自己独立的内存地址空间，所以跨进程传递的地址值是无效的。

Parcel是一种数据的载体，用于承载希望通过IBinder发送的相关信息（包括数据和对象引用）。

Parcel的英文直译是“打包”，具备这种打包和重组的能力。


### Parcel类

1.Parcel设置相关

- dataSize():获取当前已经存储的数据大小
- setDataCapability(int size):设置Parcel的空间大小
- setDataPosition(int post)：改变Parcel中的读写位置


2.Primitives

原始类型数据的读写操作：

- writeByte(byte)：写入一个byte
- readByte():读取一个byte

读写操作是配套的，用哪种方式写入的数据就要用相应的方式正确读取。另外，数据是按照主机顺序的字节序来读写的。

3.Primitive Arrays

原始数据类型的数组的读写操作通常是先写入4个字节表示的数据大小值，接着才写入数据本身。另外，用户既可以选择将数据读入现有的数据空间中，也可以让Parcel返回一个新的数组。

- writeByteArray(byte[]):写入字节数组
- readByteArray(byte[]):读取字节数组
- byte[] createByteArray():读取并返回一个数组

4.Parcelables

遵循Parcelable协议的对象可以通过Parcel进行存取。

- writeParcelable（Parcelable，int）:将这个Parcelable类的名字和内容写入到Parcel中
- readParcelable(ClassLoader)：读取并返回一个新的Parcelable对象

5.Bundle

Bundle继承自Parcelable，是一种特殊的type-safe的容器。Bundle的最大特点是采用键值对的方式存储数据。

- writeBundle(Bundle):将Bundle写入Parcel中
- readBundle():读取并返回一个新的Bundle对象

6.Active Objects

Parcel的另一个强大武器是可以读写Active Object。Active Object写入的是他们的特殊标志引用。当从Parcel中读取对象时，看到的并不是重新创建的对象实例，而是原来那个被写入的实例。

有两类Active Object类型：

- Binder。Binder是一个对象，利用Parcel将Binder对象写入，读取时就能得到原始的Binder对象，或者是它的特殊代理实现。

- FileDescriptor。FileDescriptor是Linux中的文件描述符，可以通过Parcel的如下方法进行传输：
- writeFileDescriptor(FileDescriptor)
- readFileDescriptor()

7.Untyped Containers

它是用于读写标准的任意类型的Java容器，包含：

- writeArray(Object[])
- readArray(ClassLoader)
- writeList(List)
- readList(List, ClassLoader)

创建Parcel实例的方法如下：

	public static Parcel obtain() {
        final Parcel[] pool = sOwnedPool;//Parcel池的大小为6
        synchronized (pool) {
            Parcel p;
            for (int i=0; i<POOL_SIZE; i++) {
                p = pool[i];
                if (p != null) {
                    pool[i] = null;// 引用置空，这样下次就知道这个Parcel已经被占用了
                    return p;
                }
            }
        }
        return new Parcel(0);// 如果Parcel池为空，就新建一个
    }
	
	private Parcel(long nativePtr) {
        init(nativePtr);
    }
	
	private void init(long nativePtr) {
        if (nativePtr != 0) {
            mNativePtr = nativePtr;
            mOwnsNativeParcelObject = false;
        } else {// nativePtr为0
            mNativePtr = nativeCreate();// 调用本地方法创建Parcel对象
            mOwnsNativeParcelObject = true;
        }
    }

	static jlong android_os_Parcel_create(JNIEnv* env, jclass clazz)
	{
    	Parcel* parcel = new Parcel();
    	return reinterpret_cast<jlong>(parcel);
	}

在Parcel传递数据的过程中，**写入方和读取方所使用的协议必须是完全一致的**。


### Parcelable接口

Parcelable接口是用来描述那些可以被写入Parcel和从Parcel恢复的类。

实现Parcelable接口的类必须有一个静态的域——CREATOR，CREATOR实现了Parcelable.Creator接口。

一个典型的Parcelable实现如下：

	public class MyParcelable implements Parcelable {
    	private int mData;
  
        public int describeContents() {
           return 0;
        }
  
        public void writeToParcel(Parcel out, int flags) {
           out.writeInt(mData);
        }
 
        public static final Parcelable.Creator<MyParcelable> CREATOR
              = new Parcelable.Creator<MyParcelable>() {
          public MyParcelable createFromParcel(Parcel in) {
              return new MyParcelable(in);
          }
 
          public MyParcelable[] newArray(int size) {
              return new MyParcelable[size];
          }
         };
      
         private MyParcelable(Parcel in) {
            mData = in.readInt();
         }
    }

Parcelable接口的定义如下：

	public interface Parcelable {
		public static final int PARCELABLE_WRITE_RETURN_VALUE = 0x0001;
		public static final int PARCELABLE_ELIDE_DUPLICATES = 0x0002;
		public static final int CONTENTS_FILE_DESCRIPTOR = 0x0001;
		// 描述在Parcel中包含特殊对象引用的种类
		public int describeContents();
        // 将对象写入Parcel中
		public void writeToParcel(Parcel dest, int flags);

		// 必须实现的接口，提供从Parcel中产生实例对象的方法
		public interface Creator<T> {
			// 从指定的Parcel对象创建实例对象
			public T createFromParcel(Parcel source);
            // 创建一个实例对象数组
			public T[] newArray(int size);
		}
		
		// 特定的Creator，允许你通过指定的ClassLoader来创建对象
		public interface ClassLoaderCreator<T> extends Creator<T> {
			public T createFromParcel(Parcel source, ClassLoader loader);
		}
	}


### Bundle类

	public final class Bundle extends BaseBundle implements Cloneable, Parcelable {
		
		@Override
    	public int describeContents() {
        	int mask = 0;
        	if (hasFileDescriptors()) {
            	mask |= Parcelable.CONTENTS_FILE_DESCRIPTOR;
        	}
       	 	return mask;
    	}

		@Override
    	public void writeToParcel(Parcel parcel, int flags) {
        	final boolean oldAllowFds = parcel.pushAllowFds((mFlags & FLAG_ALLOW_FDS) != 0);
        	try {
            	super.writeToParcelInner(parcel, flags);
        	} finally {
            	parcel.restoreAllowFds(oldAllowFds);
        	}
    	}

		public static final Parcelable.Creator<Bundle> CREATOR =
        	new Parcelable.Creator<Bundle>() {
        	@Override
        	public Bundle createFromParcel(Parcel in) {
            	return in.readBundle();
        	}

        	@Override
        	public Bundle[] newArray(int size) {
            	return new Bundle[size];
       		}
    	};
	}

### Parcelable与Serialable的对比

可以从以下几个方面对比Parcelable和Serializable：

#### 1.作用

Serializable的作用是为了保存对象的属性到本地文件、数据库、网络流、rmi以方便数据传输，当然这种传输可以是程序内的也可以是两个程序间的。

Android的Parcelable的设计初衷是因为Serializable效率过慢，为了在程序内不同组件间以及不同android程序间(AIDL)高效的传输数据而设计，这些数据仅在**内存**中存在，**Parcelable是通过IBinder通信的消息的载体**。

#### 2.效率

Parcelable的性能比Serializable好，在内存开销方面较小，所以在**内存间数据传输**时推荐使用Parcelable，如activity间传输数据。

Serializable可将数据持久化方便保存，所以在需要**保存或网络传输数据**时选择Serializable，**因为android不同版本Parcelable可能不同，所以不推荐使用Parcelable进行数据持久化**。

#### 3.编程实现

对于Serializable，类只需要实现Serializable接口，并提供一个序列化版本id(serialVersionUID)即可。

而Parcelable则需要实现writeToParcel、describeContents函数以及静态的CREATOR变量，实际上就是**将如何打包和解包的工作自己来定义**，而**序列化的这些操作完全由底层实现**。

**当类字段较多时务必保持写入和读取的类型及顺序一致。**

Serializable序列化**不保存静态变量**，可以使用**Transient**关键字对部分字段不进行序列化，也可以覆盖writeObject、readObject方法以实现序列化过程自定义。





## Binder机制

### 简介

在Android系统的Binder机制中，由一系统组件组成，分别是**Client**、**Server**、**Service Manager**和**Binder驱动程序**，其中Client、Server和Service Manager运行在用户空间，Binder驱动程序运行内核空间。

Binder就是一种把这四个组件粘合在一起的粘结剂了，其中，核心组件便是**Binder驱动程序**了，**Service Manager**提供了辅助管理的功能，**Client和Server正是在Binder驱动和Service Manager提供的基础设施上，进行Client-Server之间的通信**。Service Manager和Binder驱动已经在Android平台中实现好，开发者只要按照规范实现自己的Client和Server组件就可以了。

Android系统Binder机制中的四个组件Client、Server、Service Manager和Binder驱动程序的关系如下图所示：

![Binder组件关系](http://hi.csdn.net/attachment/201107/19/0_13110996490rZN.gif)

1. Client、Server和Service Manager实现在用户空间中，Binder驱动程序实现在内核空间中。
2. Binder驱动程序和Service Manager在Android平台中已经实现，开发者只需要在用户空间实现自己的Client和Server。
3. Binder驱动程序提供设备文件/dev/binder与用户空间交互，Client、Server和Service Manager通过open和ioctl文件操作函数与Binder驱动程序进行通信。
4. Client和Server之间的进程间通信通过Binder驱动程序间接实现。
5. Service Manager是一个守护进程，用来管理Server，并向Client提供查询Server接口的能力。


### ServiceManger

Service Manager，它是整个Binder机制的守护进程，用来管理开发者创建的各种Server，并且向Client提供查询Server远程接口的功能。

既然Service Manager组件是用来管理Server并且向Client提供查询Server远程接口的功能，那么，Service Manager就必然要和Server以及Client进行通信了。我们知道，Service Manger、Client和Server三者分别是运行在独立的进程当中，这样它们之间的通信也属于进程间通信了，而且也是采用Binder机制进行进程间通信，因此，Service Manager在充当Binder机制的守护进程的角色的同时，也在充当Server的角色。




### Binder分析
参考文章:

[Android深入浅出之Binder机制](http://www.cnblogs.com/innost/archive/2011/01/09/1931456.html)

1. [Android进程间通信（IPC）机制Binder简要介绍和学习计划](http://blog.csdn.net/luoshengyang/article/details/6618363)

2. [浅谈Android系统进程间通信（IPC）机制Binder中的Server和Client获得Service Manager接口之路](http://blog.csdn.net/Luoshengyang/article/details/6627260)

3. [Android系统进程间通信（IPC）机制Binder中的Server启动过程源代码分析](http://blog.csdn.net/Luoshengyang/article/details/6629298)

4. [Android系统进程间通信（IPC）机制Binder中的Client获得Server远程接口过程源代码分析](http://blog.csdn.net/Luoshengyang/article/details/6633311)

5. [Android系统进程间通信Binder机制在应用程序框架层的Java接口源代码分析](http://blog.csdn.net/Luoshengyang/article/details/6642463)
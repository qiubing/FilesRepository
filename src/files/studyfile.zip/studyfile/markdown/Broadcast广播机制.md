## Broadcast广播机制

### 思维导向图

![Broadcast广播机制](http://orbohk5us.bkt.clouddn.com/17-9-5/81083831.jpg)

### 参考文章
[Android Broadcast广播机制分析](http://gityuan.com/2016/06/04/broadcast-receiver/)

[Android应用程序注册广播接收器（registerReceiver）的过程分析](http://blog.csdn.net/luoshengyang/article/details/6737352)

[Android应用程序发送广播（sendBroadcast）的过程分析](http://blog.csdn.net/Luoshengyang/article/details/6744448)

[四大组件之BroadcastRecord](http://gityuan.com/2017/06/03/broadcast_record/)
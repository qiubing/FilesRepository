## Choreographer简介

Choreographer一方面需要接收VSYNC信号，另一方面要将这事件转发给感兴趣的人，所以需要监听VSYNC事件的对象都需要在Choreographer中注册。


Choreographer将所有注册者分为Input，Animation，Traversal(layout,draw)3个类别，存储在其内部的一个CallBackQueue数组中（CallBackQueue[] mCallbackQueues）中。

每个Looper线程有它自己的Choreographer。

### 初始化
1.Choreographer初始化

    // 私有构造函数
	private Choreographer(Looper looper) {
        mLooper = looper;
		// 初始化Handler
        mHandler = new FrameHandler(looper);
		// 如果使用VSYNC信号，则使用FrameDisplayEventReceiver作为VSYNC信号处理器
        mDisplayEventReceiver = USE_VSYNC ? new FrameDisplayEventReceiver(looper) : null;
        mLastFrameTimeNanos = Long.MIN_VALUE;
        // 每一帧的事件，为16ms
        mFrameIntervalNanos = (long)(1000000000 / getRefreshRate());
		// 创建CallBackQueue数组
        mCallbackQueues = new CallbackQueue[CALLBACK_LAST + 1];
        for (int i = 0; i <= CALLBACK_LAST; i++) {
            mCallbackQueues[i] = new CallbackQueue();
        }
    }
	// input callback
	public static final int CALLBACK_INPUT = 0;
	// animation callback
	public static final int CALLBACK_ANIMATION = 1;
	// traversal callback
	public static final int CALLBACK_TRAVERSAL = 2;

Choreographer的构造函数是私有构造函数，则该构造函数中定义每一帧的时间，创建CallBackQueue队列，有三种类型的CallBackQueue：Input CallBack、 Animation CallBack、Traversal CallBack。

Choreographer是线程相关的，每个线程都有一个相关的Choreographer，所以可以使用ThreadLocal来实现线程相关。

	// Thread local storage for the choreographer.
    private static final ThreadLocal<Choreographer> sThreadInstance =
            new ThreadLocal<Choreographer>() {
        @Override
        protected Choreographer initialValue() {
			// 获取当前线程的Looper
            Looper looper = Looper.myLooper();
            if (looper == null) {
                throw new IllegalStateException("The current thread must have a looper!");
            }
            return new Choreographer(looper);
        }
    };

	public static Choreographer getInstance() {
        return sThreadInstance.get();
    }

2. FrameDisplayEventReceiver初始化

		private final class FrameDisplayEventReceiver extends DisplayEventReceiver
            implements Runnable {
			public FrameDisplayEventReceiver(Looper looper) {
            	super(looper);
        	}
		}
调用DisplayEventReceiver的构造方法。

		public DisplayEventReceiver(Looper looper) {
        if (looper == null) {
            throw new IllegalArgumentException("looper must not be null");
        }
		
		// 获取Looper对应的消息队列
        mMessageQueue = looper.getQueue();
		// 获取本地方法初始化
        mReceiverPtr = nativeInit(new WeakReference<DisplayEventReceiver>(this), mMessageQueue);

        mCloseGuard.open("dispose");
    	}

### 关键方法

1. postCallback
该方法的主要作用是将一个callback放在下一帧执行。callback执行完之后，就会被移除。

	// 让CallBack在下一个帧时间内执行
	public void postCallback(int callbackType, Runnable action, Object token) {
        postCallbackDelayed(callbackType, action, token, 0);
    }

	public void postCallbackDelayed(int callbackType,
            Runnable action, Object token, long delayMillis) {
        if (action == null) {
            throw new IllegalArgumentException("action must not be null");
        }
        if (callbackType < 0 || callbackType > CALLBACK_LAST) {
            throw new IllegalArgumentException("callbackType is invalid");
        }

        postCallbackDelayedInternal(callbackType, action, token, delayMillis);
    }

	private void postCallbackDelayedInternal(int callbackType,
            Object action, Object token, long delayMillis) {
        synchronized (mLock) {
            final long now = SystemClock.uptimeMillis();
			// 当前时间加上延迟时间
            final long dueTime = now + delayMillis;
			// 将CallBack添加到指定类型的队列中，根据时间决定插入顺序
            mCallbackQueues[callbackType].addCallbackLocked(dueTime, action, token);
	
            if (dueTime <= now) {
			    //立即执行帧绘制
                scheduleFrameLocked(now);
            } else {
				//延迟到dueTime时间执行
                Message msg = mHandler.obtainMessage(MSG_DO_SCHEDULE_CALLBACK, action);
                msg.arg1 = callbackType;
                msg.setAsynchronous(true);
                mHandler.sendMessageAtTime(msg, dueTime);
            }
        }
    }
可以看到，postCallbackDelayedInternal方法的主要作用是将CallBack添加到相应类型的队列中，添加的规则是根据执行时间的先后顺序排列。接着如果是立即执行的CallBack，则调用scheduleFrameLocked函数，否则要等到指定的延迟的时间才能执行CallBack，但最终都会调用到scheduleFrameLocked方法。

addCallbackLocked方法的实现如下：

	public void addCallbackLocked(long dueTime, Object action, Object token) {
            CallbackRecord callback = obtainCallbackLocked(dueTime, action, token);
            CallbackRecord entry = mHead;
            if (entry == null) {
                mHead = callback;
                return;
            }
            if (dueTime < entry.dueTime) {
                callback.next = entry;
                mHead = callback;
                return;
            }
            while (entry.next != null) {
                if (dueTime < entry.next.dueTime) {
                    callback.next = entry.next;
                    break;
                }
                entry = entry.next;
            }
            entry.next = callback;
        }

2. scheduleFrameLocked

	private void scheduleFrameLocked(long now) {
        if (!mFrameScheduled) {
			// 更新mFrameScheduled变量，当下一个VSYNC信号到来时，将根据该标志决定是否执行帧绘制操作
            mFrameScheduled = true;
			// 使用SYNC信号更新帧
            if (USE_VSYNC) {
				
				// 如果运行在Looper线程上，则直接发送VSYNC信号，否则的话，从UI线程发送一个VSYNC消息来发送SYNC信号。
                if (isRunningOnLooperThreadLocked()) {
                    scheduleVsyncLocked();
                } else {
                    Message msg = mHandler.obtainMessage(MSG_DO_SCHEDULE_VSYNC);
                    msg.setAsynchronous(true);
                    mHandler.sendMessageAtFrontOfQueue(msg);
                }
            } else {
                final long nextFrameTime = Math.max(
                        mLastFrameTimeNanos / TimeUtils.NANOS_PER_MS + sFrameDelay, now);
                Message msg = mHandler.obtainMessage(MSG_DO_FRAME);
                msg.setAsynchronous(true);
                mHandler.sendMessageAtTime(msg, nextFrameTime);
            }
        }
    }
在scheduleFrameLocked方法中，主要是通过VSYNC信号更新帧，如果是运行在Looper所在的线程，则直接调用scheduleVsyncLocked方法，否则通过发送一个MSG_DO_SCHEDULE_VSYNC消息间接来调用scheduleVsyncLocked方法，不管通过哪种方式，都是会调用到scheduleVsyncLocked方法中。

3. scheduleVsyncLocked

	private void scheduleVsyncLocked() {
        mDisplayEventReceiver.scheduleVsync();
    }

	public void scheduleVsync() {
        if (mReceiverPtr == 0) {
            Log.w(TAG, "Attempted to schedule a vertical sync pulse but the display event "
                    + "receiver has already been disposed.");
        } else {
			// 调用本地方法产生单个垂直信号VSYNC脉冲
            nativeScheduleVsync(mReceiverPtr);
        }
    }

scheduleVsync方法的主要作用是调度产生垂直脉冲信号VSYNC。

4. dispatchVsync

当VSYNC信号到来时，会首先先回调的DisplayEventReceiver的dispatchVsync方法。

	// Called from native code.
    @SuppressWarnings("unused")
    private void dispatchVsync(long timestampNanos, int builtInDisplayId, int frame) {
        onVsync(timestampNanos, builtInDisplayId, frame);
    }
当收到一个垂直信号脉冲VSYNC，则会回调该方法。VSYNC信号的接收者需要渲染一帧，然后调用scheduleVsync来产生下一个VSYNC信号。

onVsync方法在FrameDisplayEventReceiver类中实现：

	@Override
        public void onVsync(long timestampNanos, int builtInDisplayId, int frame) {
		// 如果不是主屏幕，则发送下一个VSYNC信号，即只处理主屏幕的SYNC信号
		if (builtInDisplayId != SurfaceControl.BUILT_IN_DISPLAY_ID_MAIN) {
                Log.d(TAG, "Received vsync from secondary display, but we don't support "
                        + "this case yet.  Choreographer needs a way to explicitly request "
                        + "vsync for a specific display to ensure it doesn't lose track "
                        + "of its scheduled vsync.");
                scheduleVsync();
                return;
            }
		// 获取系统的时间
		long now = System.nanoTime();
		
		if (timestampNanos > now) {
                Log.w(TAG, "Frame time is " + ((timestampNanos - now) * 0.000001f)
                        + " ms in the future!  Check that graphics HAL is generating vsync "
                        + "timestamps using the correct timebase.");
                timestampNanos = now;
         }

		if (mHavePendingVsync) {
                Log.w(TAG, "Already have a pending vsync event.  There should only be "
                        + "one at a time.");
            } else {
                mHavePendingVsync = true;
         }
		
		// 保留时间戳、帧号码，并发送消息到Handler
		mTimestampNanos = timestampNanos;
        mFrame = frame;
		// 当前消息的CallBack为当前对象FrameDisplayEventReceiver
        Message msg = Message.obtain(mHandler, this);
		// 消息类型为异步消息
        msg.setAsynchronous(true);
        mHandler.sendMessageAtTime(msg, timestampNanos / TimeUtils.NANOS_PER_MS);
	}
在OnVsync方法中，通过FrameHandler向主线程Looper发送了一个自带Runnable的FrameDisplayEventReceiver，当主线程执行到该消息时，会执行run方法。

	public void run() {
            mHavePendingVsync = false;
            doFrame(mTimestampNanos, mFrame);
    }

5. doFrame

doFrame方法是在Choreographer中定义的。

	void doFrame(long frameTimeNanos, int frame) {
		final long startNanos;
		synchronized (mLock) {
			if (!mFrameScheduled) {
                return; // no work to do
            }
			// 期望帧绘制时间
			long intendedFrameTimeNanos = frameTimeNanos;
			startNanos = System.nanoTime();//开始时间
			// 开始时间减去帧预期绘制的时间，即抖动时间
			final long jitterNanos = startNanos - frameTimeNanos;
			// 如果抖动时间大于帧间隔时间，即大于16ms
			if (jitterNanos >= mFrameIntervalNanos) {
				// 计算已经跳过的帧数
                final long skippedFrames = jitterNanos / mFrameIntervalNanos;
                if (skippedFrames >= SKIPPED_FRAME_WARNING_LIMIT) {
                    Log.i(TAG, "Skipped " + skippedFrames + " frames!  "
                            + "The application may be doing too much work on its main thread.");
                }
				// 算出最后一帧的偏移
                final long lastFrameOffset = jitterNanos % mFrameIntervalNanos;
                if (DEBUG_JANK) {
                    Log.d(TAG, "Missed vsync by " + (jitterNanos * 0.000001f) + " ms "
                            + "which is more than the frame interval of "
                            + (mFrameIntervalNanos * 0.000001f) + " ms!  "
                            + "Skipping " + skippedFrames + " frames and setting frame "
                            + "time to " + (lastFrameOffset * 0.000001f) + " ms in the past.");
                }
				// 重新计算帧绘制时间
                frameTimeNanos = startNanos - lastFrameOffset;
            }
			// 如果重新计算后的帧绘制时间小于上一帧绘制时间，则等待下一个VSYNC信号到来
			if (frameTimeNanos < mLastFrameTimeNanos) {
                if (DEBUG_JANK) {
                    Log.d(TAG, "Frame time appears to be going backwards.  May be due to a "
                            + "previously skipped frame.  Waiting for next vsync.");
                }
                scheduleVsyncLocked();
                return;
            }
			// 将期望帧绘制时间以及实际帧绘制时间保持在FrameInfo中
			mFrameInfo.setVsync(intendedFrameTimeNanos, frameTimeNanos);
            mFrameScheduled = false;
			// 更新上一帧绘制的时间
            mLastFrameTimeNanos = frameTimeNanos;
		}

		try {
			// 用TraceView追踪doFrame的执行
            Trace.traceBegin(Trace.TRACE_TAG_VIEW, "Choreographer#doFrame");
			//加载动画时钟
            AnimationUtils.lockAnimationClock(frameTimeNanos / TimeUtils.NANOS_PER_MS);
            //依次调用intput、animation、traversal、commit的回调方法，在FrameInfo中记录这些操作的开始时间
            mFrameInfo.markInputHandlingStart();
            doCallbacks(Choreographer.CALLBACK_INPUT, frameTimeNanos);

            mFrameInfo.markAnimationsStart();
            doCallbacks(Choreographer.CALLBACK_ANIMATION, frameTimeNanos);

            mFrameInfo.markPerformTraversalsStart();
            doCallbacks(Choreographer.CALLBACK_TRAVERSAL, frameTimeNanos);

            doCallbacks(Choreographer.CALLBACK_COMMIT, frameTimeNanos);
        } finally {
            AnimationUtils.unlockAnimationClock();
            Trace.traceEnd(Trace.TRACE_TAG_VIEW);
        }
	}

可以看到，在doFrame方法中，主要是计算出帧绘制时间，并且分别调用input、animation、traversal、commit的回调方法：

- input： 输入事件
- animation： 动画
- traversal ： 窗口刷新

6.doCallBacks

	void doCallbacks(int callbackType, long frameTimeNanos) {
		CallbackRecord callbacks;
		synchronized (mLock) {
			// 以当前时间为基准，从CallBackQueue中取CallbackRecord，找出第一个执行时间大于当前时间的CallbackRecord
			final long now = System.nanoTime();
            callbacks = mCallbackQueues[callbackType].extractDueCallbacksLocked(
                    now / TimeUtils.NANOS_PER_MS);
			
			if (callbacks == null) {
                return;
            }
            mCallbacksRunning = true;
			// 如果回调类型为CALLBACK_COMMIT
			if (callbackType == Choreographer.CALLBACK_COMMIT) {
				// 计算抖动时间
				final long jitterNanos = now - frameTimeNanos;
				Trace.traceCounter(Trace.TRACE_TAG_VIEW, "jitterNanos", (int) jitterNanos);
				// 如果抖动时间大于2个帧的时间，即大于32ms，则更新绘制帧的开始时间以及上一帧的时间
                if (jitterNanos >= 2 * mFrameIntervalNanos) {
                    final long lastFrameOffset = jitterNanos % mFrameIntervalNanos
                            + mFrameIntervalNanos;
                    if (DEBUG_JANK) {
                        Log.d(TAG, "Commit callback delayed by " + (jitterNanos * 0.000001f)
                                + " ms which is more than twice the frame interval of "
                                + (mFrameIntervalNanos * 0.000001f) + " ms!  "
                                + "Setting frame time to " + (lastFrameOffset * 0.000001f)
                                + " ms in the past.");
                        mDebugPrintNextFrameTimeDelta = true;
                    }
					// 计算帧开始绘制的时间
                    frameTimeNanos = now - lastFrameOffset;
					// 保留上一帧的时间
                    mLastFrameTimeNanos = frameTimeNanos;
                }
			}
		}
		
		try {
            Trace.traceBegin(Trace.TRACE_TAG_VIEW, CALLBACK_TRACE_TITLES[callbackType]);
			// 依次执行callbacks各个回调任务里面的回调方法
            for (CallbackRecord c = callbacks; c != null; c = c.next) {
				// 调用CallBackRecord里面的run方法
                c.run(frameTimeNanos);
            }
        } finally {
            synchronized (mLock) {
				//执行完成，将该callbacks里面的各个回调任务销毁
                mCallbacksRunning = false;
                do {
                    final CallbackRecord next = callbacks.next;
                    recycleCallbackLocked(callbacks);
                    callbacks = next;
                } while (callbacks != null);
            }
            Trace.traceEnd(Trace.TRACE_TAG_VIEW);
        }
	}

可以看到在doCallBacks方法中，主要是以当前时间为基准，从CallBackQueue中取出callbacks，然后重新计算帧绘制的时间，最后依次调用CallBackRecord里的方法。CallBackRecord是以链表的形式组织的，每个CallBackRecord都保存都下一个需要执行的CallBackRecord。

	private static final class CallbackRecord {
        public CallbackRecord next;//保存下一个CallBackRecord；
        public long dueTime;//执行时间
        public Object action; // Runnable or FrameCallback
        public Object token;//用于区分任务执行方法

        public void run(long frameTimeNanos) {
            if (token == FRAME_CALLBACK_TOKEN) {
                ((FrameCallback)action).doFrame(frameTimeNanos);
            } else {
                ((Runnable)action).run();
            }
        }
    }

在执行CallBackRecord中的run方法时，会有两种执行情况：

- 当token的数据类型为FRAME_CALLBACK_TOKEN，则执行该对象的doFrame()方法;
- 当token为其他类型，则执行该对象的run()方法。

可以看到CallBackRecord可以看出是单链表中的一个节点，具体节点的管理是通过CallbackQueue来管理的。每一种任务类型都有一个CallBackQueue，在Choreographer中维护了4个这样的CallBackQueue。
通过CallBackQueue可以找出需要执行的任务CallBackRecord。

	//任务链表
	private final class CallbackQueue {
		//任务链表头指针
        private CallbackRecord mHead;
		// 是否有任务需要执行
        public boolean hasDueCallbacksLocked(long now) {
            return mHead != null && mHead.dueTime <= now;
        }
        
		// 根据now时间，从链表中选取第一个执行时间大于now的任务，即找出满足执行条件的第一个任务
        public CallbackRecord extractDueCallbacksLocked(long now) {
            CallbackRecord callbacks = mHead;
            if (callbacks == null || callbacks.dueTime > now) {
                return null;
            }

            CallbackRecord last = callbacks;
            CallbackRecord next = last.next;
            while (next != null) {
                if (next.dueTime > now) {
                    last.next = null;
                    break;
                }
                last = next;
                next = next.next;
            }
            mHead = next;
            return callbacks;
        }
		
		// 根据执行时间dueTime，添加一个任务到链表中
        public void addCallbackLocked(long dueTime, Object action, Object token) {
            CallbackRecord callback = obtainCallbackLocked(dueTime, action, token);
            CallbackRecord entry = mHead;
            if (entry == null) {
                mHead = callback;
                return;
            }
            if (dueTime < entry.dueTime) {
                callback.next = entry;
                mHead = callback;
                return;
            }
            while (entry.next != null) {
                if (dueTime < entry.next.dueTime) {
                    callback.next = entry.next;
                    break;
                }
                entry = entry.next;
            }
            entry.next = callback;
        }
		
		// 从链表中移除一个任务
        public void removeCallbacksLocked(Object action, Object token) {
            CallbackRecord predecessor = null;
            for (CallbackRecord callback = mHead; callback != null;) {
                final CallbackRecord next = callback.next;
                if ((action == null || callback.action == action)
                        && (token == null || callback.token == token)) {
                    if (predecessor != null) {
                        predecessor.next = next;
                    } else {
                        mHead = next;
                    }
                    recycleCallbackLocked(callback);
                } else {
                    predecessor = callback;
                }
                callback = next;
            }
        }
    }

在doFrame方法中，有一个重要的变量mFrameScheduled，用来控制是否需要执行后续的绘制流程。该变量在执行scheduleAnimationLocked时被置为true，在执行完doFrame时将该变量置为false。

对于底层VSYNC信号，每间隔16ms，上层都会接收到该信号，然后执行帧的绘制流程。但是有些场景，例如显示动画，可以不能等到VSYNC信号到来，而主动触发该执行过程。具体可以操作Animation动画的显示过程文章。








## ConcurrentHashMap简介

### 1.概述

> HashMap是一个Entry对象的数组，数组中的每一个Entry元素，又是一个链表的头结点。

HashMap不是线程安全的。在高并发环境下做插入操作，有可能出现带环链表，让下一次读操作出现死循环。

那什么样的哈希数据结构可以保证线程安全？

- HashTable
- Collections.synchronizedMap
- ConcurrentHashMap

HashTable和Collections.synchronizedMap虽然都可以保证线程安全，但是他们有一个共同问题：**性能**。无论读操作还是写操作，它们都会给**整个集合加锁**，导致同一时间的其他操作都阻塞。例如HashTable的get()和put()方法都是同步方法：

1.HashTable.get()和HashTable.put()方法

	public synchronized V get(Object key) {
        Entry<?,?> tab[] = table;
        int hash = key.hashCode();
        int index = (hash & 0x7FFFFFFF) % tab.length;
        for (Entry<?,?> e = tab[index] ; e != null ; e = e.next) {
            if ((e.hash == hash) && e.key.equals(key)) {
                return (V)e.value;
            }
        }
        return null;
    }

	public synchronized V put(K key, V value) {
        // Make sure the value is not null
        if (value == null) {
            throw new NullPointerException();
        }

        // Makes sure the key is not already in the hashtable.
        Entry<?,?> tab[] = table;
        int hash = key.hashCode();
        int index = (hash & 0x7FFFFFFF) % tab.length;
        @SuppressWarnings("unchecked")
        Entry<K,V> entry = (Entry<K,V>)tab[index];
        for(; entry != null ; entry = entry.next) {
            if ((entry.hash == hash) && entry.key.equals(key)) {
                V old = entry.value;
                entry.value = value;
                return old;
            }
        }

        addEntry(hash, key, value, index);
        return null;
    }

可以看到，在HashTable中是对整个集合进行加锁的，读和写都必须获得到内置锁才能继续进行下去。


2.Collections.synchronizedMap()

	public static <K,V> Map<K,V> synchronizedMap(Map<K,V> m) {
        return new SynchronizedMap<>(m);
    }

该方法返回一个包装的同步Map——SynchronizedMap。

	private static class SynchronizedMap<K,V>
        implements Map<K,V>, Serializable {
		
		private final Map<K,V> m;     // 包装的map
        final Object      mutex;      // 同步锁对象

        SynchronizedMap(Map<K,V> m) {
            this.m = Objects.requireNonNull(m);//保存包装的map
            mutex = this;//将该对象保存为同步锁对象
        }
        
        // 同步方法
        public V put(K key, V value) {
            synchronized (mutex) {
				return m.put(key, value);
			}
        }
        // 同步方法
        public V get(Object key) {
            synchronized (mutex) {
				return m.get(key);
			}
        }

        // 同步方法
		public Set<Map.Entry<K,V>> entrySet() {
            synchronized (mutex) {
                if (entrySet==null)
                    entrySet = new SynchronizedSet<>(m.entrySet(), mutex);
                return entrySet;
            }
        }
        
        // 同步方法
		public Set<K> keySet() {
            synchronized (mutex) {
                if (keySet==null)
                    keySet = new SynchronizedSet<>(m.keySet(), mutex);
                return keySet;
            }
        }
		.....
	}

可以看到，SynchronizedMap是对Map进行了包装，然后给每个方法的调用加上同步锁mutex，该同步锁mutex是SynchronizedMap本身，相当于调用同步方法。有一点需要特别注意，在迭代SynchronizedMap集合时，需要在SynchronizedMap集合上同步，例如：

	Map m = Collections.synchronizedMap(new HashMap());
    ...
    Set s = m.keySet();  // Needn't be in synchronized block
    ...
    synchronized (m) {  // Synchronizing on m, not s!
    	Iterator i = s.iterator(); // Must be in synchronized block
    	while (i.hasNext())
    	foo(i.next());
    }

那么，在并发场景下，ConcurrentHashMap是怎么保证线程安全的？又是怎么实现高性能读写的？


### 2.ConcurrentHashMap

由于在JDK 1.7中和JDK 1.8中，ConcurrentHashMap实现的发生了很大的改变，下面将以JDK 1.8中的ConcurrentHashMap实现来分析其内部实现原理。

1.ConcurrentHashMap的构造函数

	/*
	* 构造一个默认容量为16的空Map
	*/
	public ConcurrentHashMap() {
    }
    private static final int DEFAULT_CAPACITY = 16;

不带参数的ConcurrentHashMap构造方法的默认容量是16。
	
	/*
	* 创建一个新的ConcurrentHashMap，其初始化容量为initialCapacity
	*/
	public ConcurrentHashMap(int initialCapacity) {
        if (initialCapacity < 0)
            throw new IllegalArgumentException();
        int cap = ((initialCapacity >= (MAXIMUM_CAPACITY >>> 1)) ?
                   MAXIMUM_CAPACITY :
                   tableSizeFor(initialCapacity + (initialCapacity >>> 1) + 1));
        this.sizeCtl = cap;
    }
如果initialCapacity不是2的幂次方，则将容量调整为小于initialCapacity值的最大2的幂次方。例如，initialCapacity为17的话，经过调整后为16 = 2^4。

	private static final int tableSizeFor(int c) {
        int n = c - 1;
        n |= n >>> 1;
        n |= n >>> 2;
        n |= n >>> 4;
        n |= n >>> 8;
        n |= n >>> 16;
        return (n < 0) ? 1 : (n >= MAXIMUM_CAPACITY) ? MAXIMUM_CAPACITY : n + 1;
    }

	private transient volatile int sizeCtl;

ConcurrentHashMap的sizeCtl用来控制table的初始化和扩容。sizeCtl有以下几种取值：

- -1，表示初始化；
- -(1+调整容量的线程数量)，表示正在调整容量的线程数量；
- 0，为默认值；
- 大于0的整数，表示的是下一次table扩容的阀值；

带加载因子的ConcurrentHashMap构造函数如下：

	/*
	* 创建一个初始容量为initialCapacity，加载因子为loadFactor的ConcurrentHashMap
	*/
	public ConcurrentHashMap(int initialCapacity, float loadFactor) {
        this(initialCapacity, loadFactor, 1);
    }

    /*
	* 创建一个初始容量为initialCapacity，加载因子为loadFactor，并发水平为concurrencyLevel的ConcurrentHashMap
	* /
	public ConcurrentHashMap(int initialCapacity,
                             float loadFactor, int concurrencyLevel) {
        if (!(loadFactor > 0.0f) || initialCapacity < 0 || concurrencyLevel <= 0)
            throw new IllegalArgumentException();
        if (initialCapacity < concurrencyLevel)   // Use at least as many bins
            initialCapacity = concurrencyLevel;   // as estimated threads
        long size = (long)(1.0 + (long)initialCapacity / loadFactor);
        int cap = (size >= (long)MAXIMUM_CAPACITY) ?
            MAXIMUM_CAPACITY : tableSizeFor((int)size);//调整table的容量为2的幂次方
        this.sizeCtl = cap;//初始化table的容量
    }

	
2.ConcurrentHashMap.get()方法

	/*
	* 返回指定key映射的value值，如果没有找到映射的value，则返回null
	* key不能为null，否则抛空指针异常
	*/
	public V get(Object key) {
        Node<K,V>[] tab; 
		Node<K,V> e, p; 
		int n, eh; 
		K ek;
        int h = spread(key.hashCode());//对可以的hash值进行处理
        if ((tab = table) != null && (n = tab.length) > 0 &&
            (e = tabAt(tab, (n - 1) & h)) != null) {
            // 判断头结点key的hash值是否相等，并且key相同，则找到，返回结果
            if ((eh = e.hash) == h) {
                if ((ek = e.key) == key || (ek != null && key.equals(ek)))
                    return e.val;
            }else if (eh < 0)//key的hash值小于0，则通过Node的find()方法查找，如果存在则返回，否则返回null
                return (p = e.find(h, key)) != null ? p.val : null;
            // 循环查找，看是否存在匹配的key值，如果存在，则返回
			while ((e = e.next) != null) {
                if (e.hash == h &&
                    ((ek = e.key) == key || (ek != null && key.equals(ek))))
                    return e.val;
            }
        }
        return null;
    }

可以看到，spread()操作的作用是将hash值的高16位与低16进行异或操作，并将最高位设置为0。这样做的话，可以减少冲突发生的概率。

	static final int spread(int h) {
        return (h ^ (h >>> 16)) & HASH_BITS;
    }
	static final int HASH_BITS = 0x7fffffff; // usable bits of normal node hash

tabAt()操作的是从table数组中获取指定索引index对应的Node，并且保证获取的是最新的table[index]值。这个是通过底层的Unsafe类来保证的。

	static final <K,V> Node<K,V> tabAt(Node<K,V>[] tab, int i) {
        return (Node<K,V>)U.getObjectVolatile(tab, ((long)i << ASHIFT) + ABASE);
    }

sun.misc.Unsafe类里面提供了一些支持硬件指令集操作的方法，例如比较并设置(Compare-and-Swap，CAS)操作，CAS指令需要3个操作数，分别是内存位置V,旧的预期值A，新值B。CAS指令执行时，当前仅当V符合旧预期值A时，处理器才用新B更新V的值，否则它就不执行更新。但是无论是否更新了V的值，都会返回V的旧值，上述的处理过程是一个原子操作。

在JDK 1.5之后，Java程序才可以使用CAS操作，该操作由sun.misc.Unsafe类里面的compareAndSwapInt()和compareAndSwapObject()等几个包装方法提供，虚拟机在内部对这些方法做了特殊处理，即时编译出来的结果就是一条平台相关的处理器CAS指令。

由于Unsafe类不是提供给用户程序调用的类(Unsafe.getUnsafe()的代码中限制了只有启动类加载器(Bootstrap ClassLoader)加载的Class才能访问它)，如果不采用反射手段，我们只能通过其他的Java API来间接使用它，例如在java.util.concurrent包中的原子类，其中的compareAndSet()和getAndIncrement()等方法都使用了Unsafe类的CAS操作。ConcurrentHashMap是由启动类加载器加载的，所以可以直接使用Unsafe类。Unsafe类的使用如下所示：

	// Unsafe mechanics
    private static final sun.misc.Unsafe U;
    private static final long SIZECTL;
    private static final long TRANSFERINDEX;
    private static final long BASECOUNT;
    private static final long CELLSBUSY;
    private static final long CELLVALUE;
    private static final long ABASE;
    private static final int ASHIFT;

    static {
        try {
            U = sun.misc.Unsafe.getUnsafe();
            Class<?> k = ConcurrentHashMap.class;//指定的类为ConcurrentHashMap
            SIZECTL = U.objectFieldOffset
                (k.getDeclaredField("sizeCtl"));//获取ConcurrentHashMap类中定义的sizeCtl变量
            TRANSFERINDEX = U.objectFieldOffset
                (k.getDeclaredField("transferIndex"));//获取ConcurrentHashMap类中定义的transferIndex变量
            BASECOUNT = U.objectFieldOffset
                (k.getDeclaredField("baseCount"));//获取ConcurrentHashMap类中定义的baseCount变量
            CELLSBUSY = U.objectFieldOffset
                (k.getDeclaredField("cellsBusy"));//获取ConcurrentHashMap类中定义的cellsBusy变量
            Class<?> ck = CounterCell.class;
            CELLVALUE = U.objectFieldOffset
                (ck.getDeclaredField("value"));//获取ConcurrentHashMap类中定义的value变量
            Class<?> ak = Node[].class;//Node类
            ABASE = U.arrayBaseOffset(ak);//Node数组基准位置
            int scale = U.arrayIndexScale(ak);//Node数组的索引的范围
            if ((scale & (scale - 1)) != 0)//如果scale不为2的幂次方，则报错
                throw new Error("data type scale not a power of two");
            ASHIFT = 31 - Integer.numberOfLeadingZeros(scale);//索引偏移的位置，例如scale为16，则ASHIFT为4
        } catch (Exception e) {
            throw new Error(e);
        }
    }

由于table[]数组是一个volatile类型的变量，因此可以保证可见性。通过Unsafe的getObjectVolatile()方法，可以获取到table数组的相应索引index的最新值。

	transient volatile Node<K,V>[] table;

可以看到，get()方法的逻辑还是比较简单，主要有以下操作：

1. 首先对key的hash值进行处理，高16位与低16位进行异或操作，这样可以减少冲突发生的概率；
2. 查看table数组中对应索引index = (n-1)&h是否存在头结点，如果不存在头结点，则直接返回null；
3. 如果存在头结点，则从头结点开始沿着链表查找，查看是否存在满足条件的key；如果存在，则返回key对应的value值，如果不存在，则返回null。
4. 当Node的hash值小于0时，则通过findNode()方法，查找对应key值的Node是否存在，如果存在，则返回Node对应的value值，否则返回null。

find()方法定义在Node<K,V>类中，如下所示：

	Node<K,V> find(int h, Object k) {
    	Node<K,V> e = this;
        if (k != null) {
        	do {
              	K ek;
                if (e.hash == h &&((ek = e.key) == k || (ek != null && k.equals(ek))))
                	return e;
            } while ((e = e.next) != null);
        }
        return null;
    }


3.ConcurrentHashMap.put()方法

	/*
	* 将指定的key值映射到指定的value值
	* key和value都不能为null，否则抛空指针异常
	*/
	public V put(K key, V value) {
        return putVal(key, value, false);
    }
put方法最终调用的是putVal()方法，该方法实现了put和putIfAbsent方法的功能。

	final V putVal(K key, V value, boolean onlyIfAbsent) {
        if (key == null || value == null) throw new NullPointerException();
        int hash = spread(key.hashCode());//hash值处理
        int binCount = 0;
        for (Node<K,V>[] tab = table;;) {
            Node<K,V> f; 
			int n, i, fh;
			// 1.table为空，则创建一个新的table
            if (tab == null || (n = tab.length) == 0)
                tab = initTable();//见3.1
			// 2.table指定索引index = (n-1)&hash位置没有节点，则插入一个新节点
            else if ((f = tabAt(tab, i = (n - 1) & hash)) == null) {
                if (casTabAt(tab, i, null,
                             new Node<K,V>(hash, key, value, null)))//见3.2
                    break;                   // no lock when adding to empty bin
            }// 3.头结点的hash值为-1，则表示在执行转移操作
            else if ((fh = f.hash) == MOVED)
                tab = helpTransfer(tab, f);//见3.3
            else {
            // 4.从头结点开始，遍历链表，查找是否存在对应key的节点，如果存在，则更新值，如果不存在，则在链表的尾部插入一个新的Node节点，该操作是通过同步代码块实现的。
                V oldVal = null;
                synchronized (f) {//同步代码块
                    if (tabAt(tab, i) == f) {//判断对应索引index位置的头结点是否已经被改动了，即是否有其他线程并发修改了它，如果有的话，则再重新尝试一下。
                        if (fh >= 0) {//节点的hash值是否大于0，hash值小于0，则表示在转移操作
                            binCount = 1;
							//从头结点开始循环查找，是否存在key值对应的节点Node
                            for (Node<K,V> e = f;; ++binCount) {
                                K ek;
                                // 找到了key值对应的Node节点，用新值更新旧值
                                if (e.hash == hash &&
                                    ((ek = e.key) == key ||
                                     (ek != null && key.equals(ek)))) {
                                    oldVal = e.val;
                                    if (!onlyIfAbsent)
                                        e.val = value;
                                    break;
                                }
                                Node<K,V> pred = e;
                                // 如果没有找到key值对应的Node节点，则在链表的尾部插入一个新的节点Node
                                if ((e = e.next) == null) {
                                    pred.next = new Node<K,V>(hash, key,
                                                              value, null);
                                    break;
                                }
                            }
                        }
                        else if (f instanceof TreeBin) {//与TreeBin相关的，暂不考虑
                            Node<K,V> p;
                            binCount = 2;
                            if ((p = ((TreeBin<K,V>)f).putTreeVal(hash, key,
                                                           value)) != null) {
                                oldVal = p.val;
                                if (!onlyIfAbsent)
                                    p.val = value;
                            }
                        }
                    }
                }
                if (binCount != 0) {
					// 如果循环比较的次数大于了TREEIFY_THRESHOLD = 8，则将table中指定索引index位置的单链表改为树结构
                    if (binCount >= TREEIFY_THRESHOLD)
                        treeifyBin(tab, i);
                    if (oldVal != null)
                        return oldVal;//返回旧的值
                    break;//退出循环
                }
            }
        }
        addCount(1L, binCount);//5.如果是新插入Node<K,V>节点，则更新count值，见3.4
        return null;
    }

可以看到，在put()方法的处理逻辑是：

1. 先判断table是否空，如果是首次插入元素的话，则先初始化一个新的table数组；
2. 判断table的索引位置(index = (n-1)&hash)是否有头结点存在，如果不存在，则创建一个头结点，并插入指定的索引位置；
3. 如果索引位置index对应的头结点存在，并且头结点的hash值为-1，则表示正在执行转移操作；
4. 如果索引位置index对应的头结点存在，并且头结点的hash值大于0，则开始从头结点开始遍历，查找是否存在对应的key值，如果存在，则用新的value更新key值对应的旧value，如果不存在，则在链表的尾部插入一个新的节点Node<K,V>；
5. 如果是新插入的Node<K,V>节点，则更新count值；

在遍历链表的头结点时，都会先检查一下对应索引index位置的头结点是否已经被改动了，即是否有其他线程并发修改了它，如果有的话，则再重新尝试一下。这样的思想是实际是一种失败重试的机制，在每次修改前先判断是否有其他线程已经修改过了它，如果已经修改了，则再重新尝试，直到没有其他线程干扰时，才进行插入操作。

3.1 ConcurrentHashMap.initTable()

	/**
     * 初始化table，使用sizeCtl中记录的大小来初始化table的容量
     */
    private final Node<K,V>[] initTable() {
        Node<K,V>[] tab; 
		int sc;
        while ((tab = table) == null || tab.length == 0) {
            if ((sc = sizeCtl) < 0)
                Thread.yield(); // lost initialization race; just spin
            else if (U.compareAndSwapInt(this, SIZECTL, sc, -1)) {//首先将sizeCtl设置为-1，表示正在初始化操作
                try {
                    if ((tab = table) == null || tab.length == 0) {
                        int n = (sc > 0) ? sc : DEFAULT_CAPACITY;//获取table的大小，为sc
                        @SuppressWarnings("unchecked")
                        Node<K,V>[] nt = (Node<K,V>[])new Node<?,?>[n];//创建一个容量为n的Node<K,V>数组
                        table = tab = nt;
                        sc = n - (n >>> 2);//将sc设置为3n/4,即0.75n，因为sc代表的是下一次扩容时阀值
                    }
                } finally {
                    sizeCtl = sc;//将sc更新到sizeCtrl中，代表的table的阀值
                }
                break;
            }
        }
        return tab;
    }
可以看到，在initTable()方法中，主要是创建一个sizeCtl大小的Node<K,V>数组,然后将sizeCtrl更新为0.75sizeCtrl，表示下一次table数组扩容的阀值。例如，需要初始化容量为16的Node数组，初始化完之后，接着会将sizeCtl设置为12 = 16 * 0.75，表示下一次扩容的阀值为12。

3.2 ConcurrentHashMap.casTabAt()
	
	/*
	* 调用Unsafe类的CAS操作，将对应索引位置index的值c更新为v
	*/
	static final <K,V> boolean casTabAt(Node<K,V>[] tab, int i,
                                        Node<K,V> c, Node<K,V> v) {
        return U.compareAndSwapObject(tab, ((long)i << ASHIFT) + ABASE, c, v);
    }
casTabAt的作用是调用Unsafe类的CAS操作，更新指定索引位置index的值。在前面的put操作中，主要是用来在指定索引index位置上，插入一个的新的节点。

	casTabAt(tab, i, null,new Node<K,V>(hash, key, value, null))

3.3 ConcurrentHashMap.helpTransfer()

	/*
	* 如果正在扩容操作，则辅助转移元素
	*/
	final Node<K,V>[] helpTransfer(Node<K,V>[] tab, Node<K,V> f) {
        Node<K,V>[] nextTab; 
		int sc;
		// table不为空，并且节点是ForwardingNode，并且ForwardingNode的nextTab不为空
        if (tab != null && (f instanceof ForwardingNode) &&
            (nextTab = ((ForwardingNode<K,V>)f).nextTable) != null) {
            int rs = resizeStamp(tab.length);
            while (nextTab == nextTable && table == tab &&
                   (sc = sizeCtl) < 0) {//sizeCtl表示正在转移元素
                if ((sc >>> RESIZE_STAMP_SHIFT) != rs || sc == rs + 1 ||
                    sc == rs + MAX_RESIZERS || transferIndex <= 0)
                    break;
                if (U.compareAndSwapInt(this, SIZECTL, sc, sc + 1)) {
                    transfer(tab, nextTab);//将tab中元素转移到nextTab中
                    break;
                }
            }
            return nextTab;
        }
        return table;
    }

3.4 ConcurrentHashMap.addCount()

	/*
	* 添加数量
	* 如果table太小了并且还没有扩容，则启动转移操作；
	* 如果已经在扩容了，则帮助扩容；
	* 转移操作后，还有再次检查，是否需要另外一个扩容操作，因为扩容是滞后于添加操作
	* 如果check小于0，则不检查扩容；如果check <= 1仅检查是否竞争
	*/

	private final void addCount(long x, int check) {
        CounterCell[] as; 
		long b, s;
        if ((as = counterCells) != null ||
            !U.compareAndSwapLong(this, BASECOUNT, b = baseCount, s = b + x)) {//添加x大小
            CounterCell a; 
			long v; 
			int m;
            boolean uncontended = true;
            if (as == null || (m = as.length - 1) < 0 ||
                (a = as[ThreadLocalRandom.getProbe() & m]) == null ||
                !(uncontended =
                  U.compareAndSwapLong(a, CELLVALUE, v = a.value, v + x))) {
                fullAddCount(x, uncontended);
                return;
            }
            if (check <= 1)
                return;
            s = sumCount();//计算存储元素总的大小
        }
        
        if (check >= 0) {
            Node<K,V>[] tab, nt; 
			int n, sc;
			// 如果总的元素大小大于扩容的阀值sizeCtl，则进行扩容操作
            while (s >= (long)(sc = sizeCtl) && (tab = table) != null &&
                   (n = tab.length) < MAXIMUM_CAPACITY) {
                int rs = resizeStamp(n);
                if (sc < 0) {//正在扩容，则辅助转移元素
                    if ((sc >>> RESIZE_STAMP_SHIFT) != rs || sc == rs + 1 ||
                        sc == rs + MAX_RESIZERS || (nt = nextTable) == null ||
                        transferIndex <= 0)
                        break;
                    if (U.compareAndSwapInt(this, SIZECTL, sc, sc + 1))
                        transfer(tab, nt);
                }
                else if (U.compareAndSwapInt(this, SIZECTL, sc,
                                             (rs << RESIZE_STAMP_SHIFT) + 2))//更新sizeCtrl
                    transfer(tab, null);
                s = sumCount();//重新计算元素的数量
            }
        }
    }

	final long sumCount() {
        CounterCell[] as = counterCells; 
		CounterCell a;
        long sum = baseCount;
        if (as != null) {
            for (int i = 0; i < as.length; ++i) {
                if ((a = as[i]) != null)
                    sum += a.value;
            }
        }
        return sum;
    }

可以看到，在addCount中，主要是添加元素的数量，如果元素的数量超过了table的阀值sizeCtrl，则进行扩容操作，执行transfer操作。

4.ConcurrentHashMap.size()
	
	 /*
	 * 返回Table数组中的元素个数
	 */
	 public int size() {
        long n = sumCount();//计算所有计数单元的值
        return ((n < 0L) ? 0 :
                (n > (long)Integer.MAX_VALUE) ? Integer.MAX_VALUE :
                (int)n);
    }

**小结**

可以看到在JDK1.8中，ConcurrentHashMap底层的同步操作是借助Unsafe类中包装的一些方法，这些包装方法可以转换为相应平台的硬件指令集，可以实现基于冲突检测的乐观并发策略，这样可以避免同步阻塞(Synchronized关键字)线程阻塞和唤醒所带来的性能问题。

Unsafe类中的包装方法都是一些原子操作，这样就可以确保正确的同步；每次加锁和同步都是以table数组中一个索引值index对应的头结点为单位，这样只要操作的两个节点Node<K,V>不是对应同一个头结点，则可以安全的进行操作。如果操作的是同一个头结点上元素，则可以采取基于冲突检测的机制，在确保没有其他线程干扰的情况下，进行修改，这样可以减少加锁的操作。可以看到，在put方法中，还是有加锁操作，但那时在却没有其他线程干扰的情况下，进行加锁修改数据，这样可以避免能安全的修改数据。


### 3.小结

实现线程安全的HashMap有以下三种途径：

1. HashTable；
2. Collections.synchronizedMap;
3. ConcurrentHashMap

前两种实现都存在一个问题：“性能”问题，那是因为他们都是对整个集合元素进行加锁操作。他们采取的悲观的加锁技术，即在确保没有其他外在干扰的情况下，才进行数据的修改。而ConcurrentHashMap则对集合中的元素进行分段加锁操作，以table数组中每一个index对应的头结点为一个单位进行加锁，他们采取的乐观的加锁技术 ，基于冲突检测机制，当发现在修改数据时，没有其他线程干扰，则修改成功，如果有其他线程干扰，则采取一种补偿措施(失败重试机制)。这样ConcurrentHashMap就可以做到安全与性能的均衡。

TODO: JDK 1.7中ConcurrentHashMap的实现

对于JDK 1.7中ConcurrentHashMap的实现可以参考文章[漫画：什么是ConcurrentHashMap？](https://mp.weixin.qq.com/s/1yWSfdz0j-PprGkDgOomhQ)

## ContentProvider

### 1.简介

在Android应用程序之间，可以通过SharedPreferences、文件或数据库等方式来共享数据，但是这些方式都比较麻烦，而且存在严重的安全漏洞。

ContentProvider是不同应用程序之间进行数据交换的标准API，当一个应用程序需要把自己的数据暴露给其他程序使用时，该应用程序就可以通过提供ContentProvider来实现；而其他应用程序就可以通过ContentResolver来操作ContentProvider暴露的数据。

ContentProvider所操作的大部分数据都来自数据库，但也可以操作文件，XML或者网络等其他形式的数据。

### 2.Uri以及相关工具类

如何来区分不同的ContentProvider呢？

通过Uri来区别不同的ContentProvider，在AndroidManifest.xml文件中，需要给ContentProvider指定authorities属性；然后在ContentResolver中通过相应的Uri来操作ContentProvider。

Uri类似于隐式的Intent，用来查找ContentProvider。



**2.1 ContentUris**

**2.2 UriMatcher**

### 3.ContentResolver


### 4.ContentObserver

### 5.SQLite数据库

SQLite只是一个嵌入式的数据库引擎，专门适用于资源有限的设备。

SQLite数据库本质上是一个文件。

#### SQLiteDatabase

SQLiteDatabase代表一个数据库。

#### Cursor对象

#### SQLiteOpenHelper类



### 6.ListView

### 7.系统ContentProvider




### 参考文章

[Android开发之内容提供者——创建自己的ContentProvider(详解)](http://blog.csdn.net/dmk877/article/details/50387741)

[ContentProvider数据库共享之——读写权限与数据监听](http://blog.csdn.net/harvic880925/article/details/44651967)

[ContentProvider数据库共享之——MIME类型与getType()](http://blog.csdn.net/harvic880925/article/details/44620851)


ContentProvider实例：[Demo地址](https://github.com/qiubing/ContentProviderDemo)


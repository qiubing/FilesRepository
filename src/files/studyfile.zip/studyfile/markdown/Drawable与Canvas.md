## Drawable与Canvas

### Drawable

> Drawable就是“Something that can be drawn”的抽象，也就是说，它表达了我们希望在屏幕上绘制的图像。

一个Bitmap就是Drawable，因为它承载了图片的数据，这些数据不依赖于设备平台，只是图片自身内容的反映。

**View也有数据存储功能，它与Drawable的主要区别在于View不仅仅可以包含图片数据，还需要处理各种事件（比如触摸事件、按键事件等）**。

	public abstract class Drawable {
		public abstract void draw(@NonNull Canvas canvas);

		public void setBounds(@NonNull Rect bounds) {
        setBounds(bounds.left, bounds.top, bounds.right, bounds.bottom);
    	}
		
		public boolean getPadding(@NonNull Rect padding) {
        padding.set(0, 0, 0, 0);
        return false;
    	}

		public boolean getPadding(@NonNull Rect padding) {
        padding.set(0, 0, 0, 0);
        return false;
    	}
		
		public final boolean setLevel(@IntRange(from=0,to=10000) int level) {
        if (mLevel != level) {
            mLevel = level;
            return onLevelChange(level);
        }
        return false;
    	}

        // 通过CallBack接口，Drawable可以执行动画
		public interface Callback {
			void invalidateDrawable(@NonNull Drawable who);
			void scheduleDrawable(@NonNull Drawable who, @NonNull Runnable what, long when);
			void unscheduleDrawable(@NonNull Drawable who, @NonNull Runnable what);
		}
	}


Drawable出现的几种形式：

- **Bitmap**

	这是最简单的Drawable，除了图像本身，基本上不带任何附加信息，比如一张PNG或者JPEG图。

		public final class Bitmap implements Parcelable {
			
		}

- **Nine Patch**

	Android系统自定义的一种格式，是PNG的扩展。它的初衷是使图片在伸缩时不至于严重变形，因而文件本身会附加关于拉伸操作的具体信息。

- **Shape**

	它不仅包含了原始的图片数据，而且还提供了简单的绘图命令来保证我们在某些图片尺寸变化的场合能产生较好的效果。

		public abstract class Shape implements Cloneable {

		}

- **Layers**

	复合Drawable的一种。Layer表示“层”，复数形式表示会有多个“层”,这些层会叠加在彼此之上。

- **States**
	
	复合Drawable的一种。State代表“状态”，因此States表示多种状态以及每种状态所对应的图像。

- **Levels**

	复合Drawable的一种，和上面的States有点类似。区别在于它是以Level值来决定需要采用哪种图片的，而不是State。

- **Scale**

	复合Drawable中的一种。它主要运用于需要调整尺寸大小的场合，即根据level值来决定图像的尺寸。


### Canvas

Canvas的字面意思是“画布”，“The Canvas class holds the draw calls”，它是将“图像”数据写入Bitmap中的一个**工具集**。

绘制图像需要具备的4个条件：

- **Bitmap**

这是存储像素的地方，类似于画家所用的纸张。

- **Canvas**

作画的工具集，即辅助画家完成画画的一个工具箱。

- **Drawing Primitive**

表示不可分割的元素，例如Rect、Path、Text等基础元素

- **Paint**

画笔，可以设置画笔的颜色，风格样式等。

### Surface

与View直接打交道的是Canvas，而不是Drawable，比如View类的绘制函数是：

	draw(Canvas canvas);

而应用进程与SurfaceFlinger进行交互的是Surface，而不是Canvas。所以从View到SurfaceFlinger的交互过程大致如下：

View——>Canvas——>Surface——>SurfaceFlinger

WMS原则上只负责管理“窗口”的层级和属性，而SurfaceFlinger才是真正将窗口数据合成并最终显示到屏幕上的系统服务。




## HandlerThread

Handler与Thread的结合体，启动一个新的线程，里面就包含了一个Looper，该Looper可以用来创建Handler对象。注意start()方法必须被调用。

### HandlerThread源码分析
	public class HandlerThread extends Thread {
		public HandlerThread(String name) {
        	super(name);
        	mPriority = Process.THREAD_PRIORITY_DEFAULT;//线程的优先级为默认的优先级
    	}
	}
	
	//创建一个线程，名字为name
	public Thread(String name) {
        init(null, null, name, 0);
    }
	 /**
     * Standard priority of application threads.
     */
	public static final int THREAD_PRIORITY_DEFAULT = 0;
	
	/**
     * Standard priority background threads.  This gives your thread a slightly
     * lower than normal priority, so that it will have less chance of impacting
     * the responsiveness of the user interface.
     */
	public static final int THREAD_PRIORITY_BACKGROUND = 10;

	 /**
     * Standard priority of threads that are currently running a user interface
     * that the user is interacting with.  Applications can not normally
     * change to this priority; the system will automatically adjust your
     * application threads as the user moves through the UI。
     */
    public static final int THREAD_PRIORITY_FOREGROUND = -2;

	//可以设置优先级的HandlerThread
	public HandlerThread(String name, int priority) {
        super(name);
        mPriority = priority;
    }

可以看到HandlerThread是一个Thread，具有默认的线程优先级。当创建完HandlerThread之后，需要调用start()方法来启动Thread。方法如下：

    @Override
    public void run() {
        mTid = Process.myTid();//返回当前线程的id
        Looper.prepare();//调用Looper的prepare方法，创建Looper对象以及MessageQueue对象。
		//同步方法
        synchronized (this) {
            mLooper = Looper.myLooper();//获取当前线程的Looper对象
			//获取到Looper对象之后，通知等待Looper对象的线程
            notifyAll();
        }
        Process.setThreadPriority(mPriority);//设置线程的优先级
        onLooperPrepared();//回调方法，在Looper执行loop方法前的一些初始化设置
        Looper.loop();//执行loop()方法。
        mTid = -1;
    }

	 /**
     * Call back method that can be explicitly overridden if needed to execute some
     * setup before Looper loops.
     */
    protected void onLooperPrepared() {
    }

可以看到，当HandlerThread启动后，会去创建一个Looper对象，并调用Looper.loop()方法。

接下来可以通过getLooper()方法获取Looper对象，然后来创建Handler对象。

	 /**
     * This method returns the Looper associated with this thread. If this thread not been started
     * or for any reason is isAlive() returns false, this method will return null. If this thread 
     * has been started, this method will block until the looper has been initialized.  
     * @return The looper.
     */
    public Looper getLooper() {
		//当前线程是否存活，如果没有的话，则直接返回null
        if (!isAlive()) {
            return null;
        }
        
        // If the thread has been started, wait until the looper has been created.
        synchronized (this) {
			//如果线程已经启动了，并且Looper对象为空，则等待创建Looper对象
            while (isAlive() && mLooper == null) {
                try {
                    wait();//等待Looper对象创建完成
                } catch (InterruptedException e) {
                }
            }
        }
        return mLooper;
    }

可以看到，getLooper()方法其实返回的就是前面HandlerThread调用start方法创建的Looper对象。需要注意的是，他们使用了同步方法，并且调用了wait和notifyAll方法来等待Looper对象创建完成。

### 总结
HandlerThread是一个线程，里面包含了Looper的创建和Looper的loop()方法的调用,HandlerThread可以提供Looper对象给其他Handler使用，但使用之前一定要先调用HandlerThread的start()方法来创建Looper对象，然后才可以调用getLooper()方法来获取Looper对象。

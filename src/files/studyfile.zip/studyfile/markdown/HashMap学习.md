## HashMap分析

### 1.为什么HashMap的元素要实现equals和hashCode方法？

equals和hashCode方法是Object类中的两个方法，equals方法的默认实现是判断是否为同一个对象。

    /*
     * @param   obj   the reference object with which to compare.
     * @return  {@code true} if this object is the same as the obj
     *  argument; {@code false} otherwise.
     * @see #hashCode()
     * @see java.util.HashMap
     */
    public boolean equals(Object obj) {
    	return (this == obj);
    }

hashCode返回该对象的哈希值，调用的是底层实现：

	public native int hashCode();

在覆写equals方法的时候，总是也要覆写hashCode方法。设计HashCode方法时，需要考虑的因素是，无论何时，对同一个对象调用hashCode方法都应该产生同样的值。如果在将一个对象用put方法添加进HashMap时产生一个hashCode值，而get取出时却产生了另外一个hashCode值，那么就无法获取该对象了。所以HashCode方法的返回值不要依赖对象中的易变数据。

equals与hashCode方法应该满足如下关系：

**如果hashCode不同，则equals一定为false；如果hashCode相同，equals可能为true。**所以理论上，hashCode可能存在冲突，当发生冲突时，计算出来的hashCode相同，此时需要借助equals方法来判断两个对象是否为同一对象。

HashMap通过hashCode和equals方法最终判断出键值key是否已经存在了，如果已经存在了，则用新的Value替换旧的Value；如果键值key不存在，则将新的键值对象<key,value>加入到单链表的尾部。所以HashMap的put方法存在三种情况：

1. key的hashCode值对应的位置，没有元素，则直接将键值对象<key，value>插入；
2. key的hashCode值对应的位置，有元素，并且equals相等，则用新的value替换旧的value；
3. key的hashCode值对应的位置，有元素，并且equals相等，则在单链表的尾部插入键值对<key,value>；

HashMap的put方法实现如下：

	
    /**
     * Associates the specified value with the specified key in this map.
     * If the map previously contained a mapping for the key, the old
     * value is replaced.
     *
     * @param key key with which the specified value is to be associated
     * @param value value to be associated with the specified key
     * @return the previous value associated with <tt>key</tt>, or
     *         <tt>null</tt> if there was no mapping for <tt>key</tt>.
     *         (A <tt>null</tt> return can also indicate that the map
     *         previously associated <tt>null</tt> with <tt>key</tt>.)
     */
    public V put(K key, V value) {
        return putVal(hash(key), key, value, false, true);
    }

	static final int hash(Object key) {
        int h;
        return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
    }
	
	
    /**
     * Implements Map.put and related methods
     *
     * @param hash hash for key
     * @param key the key
     * @param value the value to put
     * @param onlyIfAbsent if true, don't change existing value
     * @param evict if false, the table is in creation mode.
     * @return previous value, or null if none
     */
    final V putVal(int hash, K key, V value, boolean onlyIfAbsent,
                   boolean evict) {
        //存放node节点的数组
        Node<K,V>[] tab;
		Node<K,V> p; 
		int n, i;
        //如果node数组为空，则重新给node数组分配大小，数组的大小始终为2的倍数
        if ((tab = table) == null || (n = tab.length) == 0)
            n = (tab = resize()).length;
        //1.如果hash值对应的位置没有元素，则创建一个新的node，并将该node添加到数组中
        if ((p = tab[i = (n - 1) & hash]) == null)
            tab[i] = newNode(hash, key, value, null);
        else {
        //如果hash值对应的位置有元素，则说明有冲突了，需要先判断key值是否相等，即equals是否返回true
            Node<K,V> e;
    		K k;//key值
            //2.如果key值的hash值相等，并且是equals也返回true，或者==返回true，则说明是key是同一个对象，需要用旧的value替换新的value
            if (p.hash == hash &&
                ((k = p.key) == key || (key != null && key.equals(k))))
                e = p;
            else if (p instanceof TreeNode)
                e = ((TreeNode<K,V>)p).putTreeVal(this, tab, hash, key, value);
            else {
            //3.如果key值的hash值相等，但equals返回false，则说明hash冲突了，需要寻找一个新的位置插入键值对<key,value>。
                for (int binCount = 0; ; ++binCount) {
                    //如果没有找到key值相等的，则在链表的尾部插入该键值对<key,value>
                    if ((e = p.next) == null) {
                        p.next = newNode(hash, key, value, null);
                        if (binCount >= TREEIFY_THRESHOLD - 1) // -1 for 1st
                            treeifyBin(tab, hash);
                        break;
                    }
					//如果找到了key值相等的，则直接返回
                    if (e.hash == hash &&
                        ((k = e.key) == key || (key != null && key.equals(k))))
                        break;
                    p = e;
                }
            }
			//如果e不为空，则说明前面找到了与key值相等的对象，说明该key已经存在了，所以需要更新旧的value值
            if (e != null) { // existing mapping for key
                V oldValue = e.value;
                //如果onlyIfAbsent为true的话，则只能是旧的value为null时，才能更新value值
                if (!onlyIfAbsent || oldValue == null)
                    e.value = value;
                //回调节点被访问的方法
                afterNodeAccess(e);
                return oldValue;
            }
        }
        ++modCount;
		//如果添加元素后，大于HashMap的大小的临界值，则重新分配HashMap大小
        if (++size > threshold)
            resize();
        afterNodeInsertion(evict);
        return null;
    }
	
	transient Node<K,V>[] table;

	Node<K,V> newNode(int hash, K key, V value, Node<K,V> next) {
        return new Node<>(hash, key, value, next);
    }
	
	//单链表的定义
	static class Node<K,V> implements Map.Entry<K,V> {
        final int hash;//保存key的hash值
        final K key;//保存key值
        V value;//保存value值
        Node<K,V> next;//指向下一个node节点

        Node(int hash, K key, V value, Node<K,V> next) {
            this.hash = hash;
            this.key = key;
            this.value = value;
            this.next = next;
        }
	}


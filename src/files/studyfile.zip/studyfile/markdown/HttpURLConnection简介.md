## HttpURLConnection介绍

### 简介

HttpURLConnection是一种多用途、轻量极的HTTP客户端，使用它来进行HTTP操作可以适用于大多数的应用程序。虽然HttpURLConnection的API提供的比较简单，但是同时这也使得我们可以更加容易地去使用和扩展它。

[Android中HttpURLConnection使用详解](http://blog.csdn.net/iispring/article/details/51474529)

### 使用例子


### 源码解析


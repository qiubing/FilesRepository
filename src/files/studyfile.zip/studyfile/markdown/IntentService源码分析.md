## IntentService

IntentService是一个Service类，用来处理异步请求。客户端通过startService来发起请求，通过使用一个工作线程来处理请求。

使用IntentService比较简单，只需简单实现onHandleIntent(Intent)方法。IntentService将接收到Intent，启动工作线程，并且能正常地停止服务。

所有的请求都在单个工作线程中处理，每次只能处理一个请求。


### 源码分析

	public abstract class IntentService extends Service {
	/**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     * @param name Used to name the worker thread, important only for debugging.
     */
   	public IntentService(String name) {
        super();
        mName = name;//给服务赋值一个名字
    }
	}

下面来看下IntentService的周期函数：

1.onCreate()
	
	@Override
    public void onCreate() {
		...
        super.onCreate();
		//创建一个HandlerThread对象
        HandlerThread thread = new HandlerThread("IntentService[" + mName + "]");
		//启动HandlerThread
        thread.start();

        mServiceLooper = thread.getLooper();//获取HandlerThread中的Looper对象
		//用Looper对象创建一个Handler
        mServiceHandler = new ServiceHandler(mServiceLooper);
    }

	//ServiceHandler是一个Handler对象
	private final class ServiceHandler extends Handler {
        public ServiceHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
			//接收到请求后，交由onHandleIntent方法处理，该方法在子线程中处理
            onHandleIntent((Intent)msg.obj);
            stopSelf(msg.arg1);
        }
    }
可以看到在onCreate方法中，创建了一个HandlerThread，并且利用该HandlerThread的Looper对象创建一个Handler，用来处理请求。

2. onStartCommand()

	 /**
     * You should not override this method for your IntentService. Instead,
     * override {@link #onHandleIntent}, which the system calls when the IntentService
     * receives a start request.
     * @see android.app.Service#onStartCommand
     */
    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        onStart(intent, startId);
		//默认返回START_NOT_STICKY，表示该服务不会自重起
        return mRedelivery ? START_REDELIVER_INTENT : START_NOT_STICKY;
    }

	@Override
    public void onStart(@Nullable Intent intent, int startId) {
		//获取一个消息，并把Intent以及startId参数保存在Message的参数中
        Message msg = mServiceHandler.obtainMessage();
        msg.arg1 = startId;
        msg.obj = intent;
		//将消息发送到HandlerThread中的消息队列中
        mServiceHandler.sendMessage(msg);
    }

可以看到，通过startService方法，会调用到Service的onStartCommand方法，在方法中，通过Handler的sendMessage方法将请求发送给对应的Handler处理。请求的参数Intent以及startId是封装在Message中。


3. onDestroy()

	@Override
    public void onDestroy() {
        mServiceLooper.quit();//请求处理消息，并销毁队列
    }

4.ServiceHandler的handleMessage方法
在onStartCommand方法中，将请求通过Message的方法，放入线程的消息队列中，然后有该消息对应的Handler来处理。具体处理消息的Handler是ServiceHanlder，处理方法是handleMessage方法。

	    @Override
        public void handleMessage(Message msg) {
            onHandleIntent((Intent)msg.obj);//在这个方法中执行耗时操作
            stopSelf(msg.arg1);//执行完耗时操作后，主动停止IntentService，不用用户操心
        }

	 /**
     * This method is invoked on the worker thread with a request to process.
     * Only one Intent is processed at a time, but the processing happens on a
     * worker thread that runs independently from other application logic.
     * So, if this code takes a long time, it will hold up other requests to
     * the same IntentService, but it will not hold up anything else.
     * When all requests have been handled, the IntentService stops itself,
     * so you should not call {@link #stopSelf}.
     *
     * @param intent The value passed to {@link
     *               android.content.Context#startService(Intent)}.
     *               This may be null if the service is being restarted after
     *               its process has gone away; see
     *               {@link android.app.Service#onStartCommand}
     *               for details.
     */
    @WorkerThread
    protected abstract void onHandleIntent(@Nullable Intent intent);//抽象方法，有子类实现，耗时的操作放在这里执行

可以看到，在handleMessage方法中主要是调用执行具体请求操作的方法onHandleIntent，该方法在工作线程中执行。执行完onHandleIntent方法后，会主动调用stopSelf方法来停止IntentService，不用用户担心服务关闭问题。

### 总结
使用IntentService服务比较简单，只需实现onHandleIntent方法来执行具体的服务请求操作。IntentService是基于HanlderThread来做的，其实就是Handler+Thread的实现，只是它已经封装地很好了，用户只需简单的调用，而且不用担心服务是否正常关闭的问题。


	


## JNI学习笔记
[TOC]

### 1.概述

> JNI(Java Native Interface,Java本地接口)，用于打通Java层与Native层(C/C++)层。这不是Android系统所有，而是Java所有。

众所周知，Java语言是跨平台语言，而这跨平台的背后都是依靠**Java虚拟机**，虚拟机采用**C/C++编写**，适配各个系统，通过JNI为上层Java提供各种服务，保证跨平台型。

跨平台是Java的优点，但是作为优点的同时，其在和本地交互的时候就出现了短板。Java的跨平台特性导致其本地交互的能力不够强大，一些和操作系统相关的特性Java无法完成，于是Java提供了JNI专门用于和本地代码交互，这样就增强了Java语言的本地交互能力。通过Java JNI，用户可以调用C/C++所编写的本地代码。

**NDK是Android所提供的一个工具集合**，通过NDK可以在Android中更加方便地通过JNI来访问本地代码。NDK还提供了交叉编译器，开发人员只需简单的修改mk文件就可以生成特定CPU平台的动态库。

**Java如何调用C代码？**

1. 首先C代码需要打包成动态库(Linux/Android为SO库，Window为dll)。
2. Java代码在调用C代码接口之前，需将动态库加载到虚拟机中，加载方法为System.load()/System.loadLibrary()。
3. Java声明本地方法，用native关键字，方法实现在native代码中。

		public native void printHello();

4. 静态注册/动态注册。

静态注册：通过javah获取一组带签名的函数，然后实现这些函数。

动态注册：通过覆盖JNI\_OnLoad方法，用JNIEnv的registerNatives函数，实现动态的函数替换。当系统中调用System.loadLibrary时，会加载动态库，然后去库里查找JNI\_OnLoad函数，如果存在则执行。

### 2.JNI注册方式

JNI注册方式有两种：

1.在Android系统启动Zygote进程的过程中注册；

2.通过System.loadLibrary方式注册；该方法最终会调用相应库中的JNI_OnLoad()函数指针，并执行相应的函数。

最终都会调用到jni.h文件中的RegisterNatives方法，将Java层的Native方法映射到Native层相应的native方法。

### 3.JavaVM和JNIEnv

> **JavaVm**:是指进程虚拟机环境，每个进程有且只有一个JavaVM实例；

> **JNIEnv**：是指线程上下文环境，每个线程有且仅有一个JNIEnv实例；


### 4.Native类型转换

Java <——> Native <——> C/C++

**基本数据类：** 强转或默认转型，因为基本类型都是值传递。

**引用类型：** 

1.字符串

- char* 转化为jstring


C/C++编程环境中使用方法：

	(*env)->NewStringUTF(env , "123") ;

- jstring转化为const char*

	
	const char* GetStringUTFChars(JNIEnv*env, jstring string, jboolean *isCopy);

isCopy有两种取值：

- 当为JNI_TRUE时，则获得jstring原始字符串的一个copy。

- 当为JNI_FALSE时，则和原始字符串指向的是JVM中的同一份数据，Java String是不能被修改的，所以返回值定义为const char*。


**需要注意的是：**

- Java内部是使用16位的unicode编码（UTF-16）来表示字符串的，无论是中文英文都是2个字节。
- JNI内部是使用UTF-8编码来表示字符串的，UTF-8是变长编码的unicode，一般ascii字符是1个字节，中文是3个字节；
- C/C++使用的是原始数据，ascii码就是1个字节，中文一般是GB2312编码，用两个字节来表示一个汉字。
- 当Java和Native字符串中都有中文字符时，此时需要编码转化，较复杂。建议在编程时采用byte[]及native层的jbyteArray代替，然后在java层做GB2312的字符串编解码，这种方式较简单。

### 5.数组及字符串的释放

**数组的释放**

调用了get<TYPE>ArrayElements时，需要释放数组。

通过release<TYPE>ArrayElements释放数组，其中有一个mode参数，有三个取值，分别表示：

- 0
	- 原始数组：允许原始数组被垃圾回收。
	- copy： 数据会从get返回的buffer copy回去，同时buffer也会被释放。

- JNI_COMMIT
	- 原始数组：什么也不做
	- copy： 数据会从get返回的buffer copy回去，同时buffer不会被释放。


- JNI_ABORT
	- 原始数组：允许原数组被垃圾回收。之前由JNI_COMMIT提交的对数组的修改将得以保留。
	- copy： buffer会被释放，同时buffer中的修改将不会copy回数组。


**字符串的释放**

- 从jstring中获取字符串：const char* GetStringUTFChars(JNIEnv*env, jstring string, jboolean *isCopy);

- 释放字符串：void ReleaseStringUTFChars(JNIEnv*env, jstring string,const char* buff)


### 6.局部引用和全局引用

**全局引用**

	jobject NewGlobalRef(JNIEnv *env,jobject obj)
	void DeleteGlobalRef(JNIEnv *env,jobject obj)

**局部引用**

	jobject NewLocalRef(JNIEnv *env,jobject obj)
	void DeleteLocalRef(JNIEnv *env,jobject obj)

大多数JNI方法创建的对象引用都属于**局部引用**，例如FindClass方法，NewObject方法等。局部引用不能作为静态变量、也不能作为全局变量。

**弱全局引用**

	jweak NewWeakGlobalRef(JNIEnv *env,jobject obj)
	void DeleteWeakGlobalRef(JNIEnv *env,jobject obj)


### 7.本地线程调用Java

在本地方法中如果启动了一个线程，例如通过pthread_create函数启动一个线程，如果想在此线程里发起jni调用需要执行下面操作：

	jint AttachCurrentThread(JavaVM* vm,JNIEnv** envPtr,void* thread_args)

	jint AttachCurrentThreadAsDaemon(JavaVM* vm,JNIEnv** envPtr,void* thread_args)
其中void *为：

	struct JavaVMAttachArgs{
		jint 		version;
		const char* name;
		jobject 	group;
	}

线程结束一定要使用DetachCurrentThread函数：

	jint DetachCurrentThread(JavaVM* vm)

判断当前线程是否附加到JavaVM上可以通过下面函数进行判断以及获取JNIEnv

	jint GetEnv(JavaVM* vm,void** env,jint)

### 8.JNI线程同步

本地代码中可以通过调用JNI函数来达到与上述JAVA代码中等效的同步目的。这要用到两个JNI函数：

**MonitorEnter负责进入同步块，MonitorExit用来退出同步块**。

	if ((*env)->MonitorEnter(env, obj) != JNI_OK) {
		... /* error handling */
	}

	if ((*env)->MonitorExit(env, obj) != JNI_OK) {
		... /* error handling */
	};


### 9.JNI异常处理

**Java层出现异常，虚拟机会直接抛出异常，这时需要try...catch或者继续往外throw**。

但是对于JNI出现异常时，即执行到JNIEnv中某个函数异常时，并不会立即抛出异常来中断程序的执行，还可以继续执行内存之类的清理工作，直到**返回到Java层**时才抛出相应的异常。

另外，Dalvik虚拟机有些情况下JNI函数出错可能返回NULL，但ART虚拟机在出错时更多的是抛出异常。这样导致的问题就可能是在Dalvik版本能正常运行的程序，在ART虚拟机上由于没有正确处理异常而崩溃。

### 10.JNI垃圾回收

对于Java开发人员来说，无需关心垃圾回收，完全由虚拟机GC来负责垃圾回收。

而对于JNI开发人员，对于内存释放需要谨慎处理。需要的时候申请，使用完了要记得释放内容，以免发生内存泄漏。

在JNI中提供了三种Reference类型，Local Reference（本地引用）、Global Reference（全局引用）、Weak Global Reference(全局弱引用)。其中Global Reference如果不主动释放，则一直不会释放；对于其他两个类型的引用都有释放的可能性，那是不是意味着不需要手动释放呢？答案是否定的，不管是这三种类型的哪种引用，都尽可能在某个内存不再需要时，立即释放，这对系统更为安全可靠，以减少不可预知的性能与稳定性问题。

参考文章：

[JNI原理分析](http://gityuan.com/2016/05/28/android-jni/)




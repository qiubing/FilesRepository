## Java I/O系统
[TOC]
### 1.简介
**流**，它代表任何有能力产出数据的数据源对象或者是有能力接收数据的接收端对象。“流”屏蔽了实际的I/O设备中处理数据的细节。

Java类库的中I/O类分成输入和输出两部分。通过继承，任何自InputStream或Reader派生而来的类都含有read()的基本方法，用于读取单个字节或者字节数组。同样，任何自OutputStream或Writer派生而来的类都含有write()的基本方法，用于写单个字节或者字节数组。

在Java1.0中，类库的设计者首先限定与输入有关的所有类都应该从InputStream继承，而与输出有关的所有类都应该从OutputStream继承。

### 2.InputStream类型和OutputStream类型
#### 2.1InputStream类型
InputStream的作用是用来表示那些从不同数据源产生输入的类。这些数据源包括：

- 字节数组 **ByteArrayInputStream** 允许将内存的缓冲区当作InputStream使用
- String对象	**StringBufferInputStream** 将String转换为InputStream
- 文件 **FileInputStream** 用于从文件中读取信息
- 管道 **PipedInputStream** 产生用于写入相关PipedOutputStream的数据
- 其他数据源

每一种数据源都有相应的InputStream子类，其中，FilterInputStream也属于一种InputStream，为“装饰器”类提供基类。其中，装饰器类可以把属性或者有用的接口与输入流连接在一起。

#### 2.2OutputStream类型

OutputStream类决定了输出所要去往的目标：

- 字节数组 **ByteArrayOutputStream** 在内存中创建缓冲区，所有送往“流”的数据都要放置在此缓冲区
- 文件 **FileOutputStream** 用于将信息写至文件
- 管道 **PipedOutputStream** 任何写入其中的信息都会自动作为相关PipedInputStream的输出。

FilterOutputStream也属于一种OutputStream，作为装饰器类基类。

### 3.FilterInputStream和FilterOutputStream
FilterInputStream和FilterOutputStream是用来提供装饰器类接口以控制特定输入流（InputStream）和输出流（OutputStream）的两个类。

FilterInputStream的常用子类有：

- DataInputStream 允许我们读取不同的基本类型数据以及String对象，所有方法都以read开头。搭配相应的DataOutputStream，就可以通过数据“流”将基本类型的数据从一个地方迁移到另一个地方。
- BufferedInputStream 使用它可以防止每次读取时都得进行实际的写操作，代表使用缓存区
- LineNumberInputStream 跟踪输入流中的行号，可调用getLineNumber()

FilterInputStream类的子类主要是在内部修改InputStream的行为方式：是否缓冲，是否保留它所读过的行，以及是否吧单一字符推回输入流等等。

FilterOutputStream与FilterInputStream类型，不在介绍。

### 4.Reader和Writer
InputStream和OutputStream是以**面向字节**形式存在的I/O。

Reader和Writer则提供兼容Unicode与面向字符的I/O功能，是**面向字符的I/O**。

设计Reader和Writer继承层次结构主要是为了**国际化**。老的I/O流继承层次结构仅支持**8位字节流**，并且不能很好处理16位的Unicode字符。由于Unicode用于字符国际化（java本身的Char也是16位的Unicode），所以添加Reader和Writer继承层次结构就是为了在所有I/O操作中都支持Unicode。

有时候，我们需要把来自“字节”层次结构中的类和“字符”层次结构中的类结合起来使用。为实现这个目的，要用到“适配器（adapter）类”：**InputStreamReader可以把InputStream转换为Reader，而OutputStreamWriter可以把OutputStream转为Writer**。


几乎所有的原始Java I/O流都有相应的Reader和Writer类来提供天然的Unicode操作，但是某些场合，面向字节的InputStream和OutputStream才是正确的解决方案。

来源与去处：Java 1.0类  | 相应的Java 1.1类
--------------------- | -----------------
InputStream           | Reader 适配器：InputStreamReader
OutputStream          | Writer 适配器：OutputStreamWriter
FileInputStream       | FileReader
FileOutputStream      | FileWriter
StringBufferInputStream | StringReader
                      | StringWriter
ByteArrayInputStream  | CharArrayReader
ByteArrayOutputStream | CharArrayWriter
PipedInputStream      | PipedReader
PipedOutputStream     | PipedWriter


Reader与Writer的装饰器


过滤器：Java 1.0类  | 相应的Java 1.1类
--------------------- | -----------------
FilterInputStream     | FilterReader 
FilterOutputStream    | FilterWriter(抽象类，没有子类)
BufferedInputStream   | BufferedReader
BufferedOutputStream  | BufferedWriter
PrintStream           | PrintWriter
LineNumberInputStream | LineNumberReader

FilterWriter是抽象类，没有任何子类。

无论我们何时使用readline，都不应该使用DataInputStream，而应该使用BufferedReader，除此之外，DataInputStream仍是I/O类库的首选成员。

![字符流框架](http://orbohk5us.bkt.clouddn.com/17-7-10/51151038.jpg)

### 5.自我独立的类：RandomAccessFile

RandomAccessFile适用于由大小已知的记录组成的文件，所以可以使用seek()将记录从一处转移到另一处，然后读取或者修改记录。

RandomAccessFile是一个完全独立的类，从头开始编写器所有的方法，可以在一个文件内向前和向后移动。在任何情况下，它都是自我独立的，直接从Object派生而来。




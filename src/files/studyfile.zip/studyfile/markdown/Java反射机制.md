## Java反射

### 概念

JAVA反射机制是指**在运行态可直接操作任意类或对象的所有属性和方法**的功能。

### 反射的用途

1. 在运行时获取任意对象所属的类 Class<?> clazz = Class.forName(String className);
2. 在运行时构造任意类的对象 Object obj = clazz.newInstance();
3. 在运行时获取任意类所具有的成员变量和方法 field.set(Object obj, Object value)； field.get(Object obj)；
4. 在运行时调用任意对象的方法 （最常见的需求，尤其是当该方法是私有方法或者隐藏方法） method.invoke(Object obj, Object... args)；

### 反射
#### 1.核心类
- java.lang.Class： 代表类 
- java.lang.reflect.Constructor: 代表类的构造方法 
- java.lang.reflect.Field: 代表类的属性 
- java.lang.reflect.Method: 代表类的方法 
- java.lang.reflect.Modifier：代表类、方法、属性的描述修饰符

	其中Modifier取值范围如下： public, protected, private, abstract, static, final, transient, volatile, synchronized, native, strictfp, interface。

Constructor， Field， Method这三个类都继承**AccessibleObject**，该对象有一个非常重要的方法**setAccessible(boolean flag)**, 借助该方法，能直接调用非Public的属性与方法。

#### 2.核心方法
1. 成员属性(Field)

		getFields()：获得类的public类型的属性。
		getDeclaredFields()：获得类的所有属性。
		getField(String name)
		getDeclaredField(String name)：获取类的特定属性

2. 成员方法(Method)

		getMethods()：获得类的public类型的方法。
		getDeclaredMethods()：获得类的所有方法。
		getMethod(String name, Class[] parameterTypes)：获得类的特定方法
		getDeclaredMethod(String name, Class[] parameterTypes)：获得类的特定方法

3. 构造方法(Constructor)

		getConstructors()：获得类的public类型的构造方法。
		getDeclaredConstructors()：获得类的所有构造方法。
		getConstructor(Class[] parameterTypes)：获得类的特定构造方法
		getDeclaredConstructor(Class[] params)；获得类的特定方法

#### 3.Class类

Java所有的类都是继承于Oject类，其内声明了多个应该被所有Java类覆写的方法：hashCode()、equals()、clone()、toString()、notify()、wait()、getClass(）等，其中getClass返回的便是一个Class类的对象。Class类也同样是继承Object类，拥有相应的方法。

Java程序在运行时，系统会对每一个对象都有一项**类型标识**，用于记录对象所属的类。虚拟机使用运行时**类型标识**来选择相应方法去执行，**保存所有对象类型信息的类便是Class类**。

**Class类没有公共构造方法，Class对象是在加载类时由 Java 虚拟机通过调用ClassLoader的defineClass 方法自动构造的**，因此不能显式地声明一个Class对象。

虚拟机为每种**类型**管理一个独一无二的**Class对象**。也就是说，每个类（型）都有一个Class对象。运行程序时，Java虚拟机(JVM)首先检查是否所要加载的类对应的Class对象是否已经加载。如果没有加载，JVM就会根据类名查找.class文件，并将其Class对象载入。

基本的 Java 类型（boolean、byte、char、short、int、long、float 和 double）和关键字 void 也都对应一个 Class 对象。 每个数组属于被映射为 Class 对象的一个类，所有具有相同元素类型和维数的数组都共享该 Class 对象。**一般某个类的Class对象被载入内存，它就用来创建这个类的所有对象**。






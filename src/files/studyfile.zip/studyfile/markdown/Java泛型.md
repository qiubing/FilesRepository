## Java泛型

[TOC]

### 1.概述
为什么需要泛型？

在没有使用泛型之前，我们可以在List当中添加一个字符串和整数，看起来没有问题，如下面所示：

	List list = new ArrayList();
	list.add("apple");
	list.add(new Interger(10));
但是使用者就麻烦了，他必须知道第一个元素是String类型，第二个元素是Integer类型，还得**强制类型转型**，要不然就会出错。

上面的做法会**增加使用者的责任，编译器也无法帮忙，在运行时才会抛出Class Cast异常**。


泛型能够在**编译期检查出错误**，还能帮忙**强制类型转换**，减少使用者的责任。泛型可以按照以下方式定义：

	public class ArrayList<T> implements List<T>{
		public void add(T e){
			....
		}
		
		public T get(int index){
			....
		}
	}

我们可以把T想象成一个**占位符**，将来可以传入**任意的类型**，例如Integer、String等等。

### 2.泛型实现

在C++泛型中，每次去实例化一个泛型/模板类都会**生成一个新类**,例如模板类是List，然后你用int、double、string分别去实例化，那么编译的时候，我们就会生成四个新类出来，例如List_int、List_double、List_string。

C++的泛型生成，会产生很多类，导致类膨胀。

而在Java中的泛型实现，使用**擦除法**。泛型只在程序源码中存在，在编译后的字节码文件中，就已经替换为原来的原生类型(Raw Type,也称为裸类型)了，并且在**相应的地方插入了强制转型代码**。因此，对于运行期的Java语言来说，ArrayList<int>与ArrayList<String>就是同一个类，Java语言中的泛型实现方法称为类型擦除。

擦除法所谓的擦除，仅仅是**对方法的Code属性中的字节码进行擦除，实际上元数据中还是保留了泛型的信息**，这也是我们能通过反射手段取得参数化类型的根据依据。


简单来说，就是一个参数化的类型经过擦除后会去除参数，例如ArrayList<T>会被擦除为ArrayList。那传入的String、Integer等都会消失吗？不会的，他们会转变成Object对象，例如ArrayList<Integer> 其实被擦除成了原始的ArrayList：

	public class ArrayList implements List{
		public void add(Object e){
			....
		}

		public Object get(int index){
			....
		}
	}
类型被擦除了，都变成了Object了，那该怎么处理？

其实，在编译的时候，做了点手脚，**自动加了个强制类型转换**：例如Integer i = (Integer) list.get(0);

#### 2.1 泛型方法

当我们需要对参数类型进行限制时，例如需要元素类型可以比较大小，那么就需要元素实现Comparable接口，否则无法比较大小，此时就需要使用一些**类型的限定符**。

**extends和super关键字**

通过extends关键字，可以限定所有的元素类型都是T的子类，例如传入的类型T都是Comparable的子类，才可以参与比较操作。

	public static <T extends Comparable<T>> T max(List<T> list){
		....
	}

除了extends之前，Java泛型还支持super关键字，表示限定所有的元素类型都是T的父类。

#### 2.2 泛型与继承

假设Apple和Orange都是Fruit的子类，那么ArrayList<Apple>和ArrayList<Orange>是ArrayList<Fruit>的子类吗？

显然这不能成立，如果ArrayList<Apple>是ArrayList<Fruit>的子类，那么不但可以向这个list中添加Apple，还可以加入Orange，这样泛型就被破坏了。因此ArrayList<Apple>不是ArrayList<Fruit>的子类，实际上他们俩之间没有关系的，不能做转型操作。

	ArrayList<Apple> appleList = new ArrayList<Apple>();
	
	//假设可以转型
	ArrayList<Fruit> list = appleList；
	list.add(new Apple());
	// 破坏了原来的ArrayList中只能存放Apple类型的规定
	list.add(new Orange());

为了，我们需要引入一个**通配符**来解决这个问题，把函数的输入参数改为下面这样：

	public void print(ArrayList<? extend Fruit> list){
		for(Fruit e : list){
			System.out.println(e);
		}
	}

也就是说，传进来的参数，只要是Fruit或者Fruit的子类都可以。这样，就可以接收ArrayList<Fruit>和ArrayList<Apple>、ArrayList<Orange>这样的参数。

#### 2.3 泛型类型

- **标准类型**

标准类型参数：

	E：元素
    K：键
    V：值
    T：值
    N：数字
无法将原始类型用于泛型，只能使用引用类型。自动装箱和拆箱操作能够在使用泛型对象时将值存储为原始类型并检索原始类型的值。

- **有界类型**

通过在参数类型部分指定extends或super关键字，分别限定上限和下限限制类型，从而限制泛型类型的边界。

	<T extends UpperBoundType>   限定上限
    <T super LowerBoundType>     限定下限

- **通配符**

某些情况下，编写指定**未知类型**的代码会很有用。**问号（？）通配符可用于使用泛型代码表示未知类型**。通配符可以用于参数、字段、局部变量和返回类型，但最好不要在返回类型中使用通配符，因为确切知道方法返回的类型更安全。

**当赋值的类型不确定时的时候，使用通配符（？）代替**。

- 1.无限定通配符，<?>。
- 2.上限通配符,<?  extends  Number>。表示参数类型只能是Number的子类。
- 3.下限通配符，<?  supper Number>。表示参数类型只能是Number的父类。

泛型与通配符的区别：

如果把一个对象分为声明、使用两部分的话：**泛型侧重于类型的声明上代码复用，通配符则侧重于使用上的代码复用**。**泛型用于定义内部数据类型的不确定性，通配符则用于定义使用的对象类型不确定性**。

### 3.泛型的使用场景

使用场景：开发一个用于在应用中传递对象的容器，但是对象类型并不总是相同的。需要开发一个能够存储各种对象的容器。

思路一：开发一个可以存储和检索Object对象的容器，在取出对象时，进行强制类型转换。缺点是：它不是类型安全的。

思路二：使用泛型，泛型类型是一种**类型参数化的类和接口**。优点：**无需类型转换，提供编译时更强的类型检查**。

泛型的好处：

- 1.**更强的类型检查**，因为避开了运行时可能引发的ClassCastException可以节省时间；
- 2.**消除了类型转换**，可以用更少的代码，因为编译器确切知道集合中存储的是何种类型。


### 4.小结

Java从1.5后支持泛型，泛型的本质是**参数化类型**，也就是说所操作的数据类型被指定为一个参数。这种参数可以用在类、接口和方法的创建中，分别称为泛型类、泛型接口、泛型方法。

泛型可以**消除代码中的强制类型转换，同时获得一个附加的类型检查层**，该检查层可以防止有人将错误类型的键或者值保持在集合中。这就是泛型所做的工作。

Java泛型在编译后的字节码文件中，已经被替换为原来的原生类型，并且在相应的地方插入了强制转型的代码。

对于泛型，擦除法是去除了Code属性里面的泛型，但是实际元数据中还有泛型的存在，然后就是解语法糖。




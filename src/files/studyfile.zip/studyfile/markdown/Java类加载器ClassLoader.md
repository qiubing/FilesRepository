## Java类加载器

[TOC]

![框架图](http://orbohk5us.bkt.clouddn.com/17-7-6/93173635.jpg)

### 1.概述

ClassLoader即常说的类加载器，其功能是用于**从Class文件加载所需的类**，主要场景用于**热部署、代码热替换**等场景。

系统提供3种的类加载器：**Bootstrap ClassLoader**、**Extension ClassLoader**、**Application ClassLoader**。

#### 1.1 Bootstrap ClassLoader

**启动类加载器，一般由C++实现，是虚拟机的一部分。该类加载器主要职责是将JAVA_HOME路径下的\lib目录中能被虚拟机识别的类库(比如rt.jar)加载到虚拟机内存中。Java程序无法直接引用该类加载器。**

#### 1.2 Extension ClassLoader

扩展类加载器，由Java实现，独立于虚拟机的外部。该类加载器主要职责将JAVA_HOME路径下的\lib\ext目录中的所有类库，开发者可直接使用扩展类加载器。 该加载器是由sun.misc.Launcher$ExtClassLoader实现。

#### 1.3 Application ClassLoader

应用程序类加载器，该加载器是由sun.misc.Launcher$AppClassLoader实现，该类加载器负责加载用户类路径上所指定的类库。开发者可通过ClassLoader.getSystemClassLoader()方法直接获取，故又称为系统类加载器。当应用程序没有自定义类加载器时，默认采用该类加载器。

ClassLoader.java

	@CallerSensitive
    public static ClassLoader getSystemClassLoader() {
        initSystemClassLoader();//初始化系统类加载器
        if (scl == null) {
            return null;
        }
        SecurityManager sm = System.getSecurityManager();
        if (sm != null) {
            checkClassLoaderPermission(scl, Reflection.getCallerClass());
        }
		//返回系统加载器
        return scl;
    }


	private static synchronized void initSystemClassLoader() {
		// 如果还未设置系统类加载器
        if (!sclSet) {
			// 如果系统类加载器已经定义了，则抛出异常
            if (scl != null)
                throw new IllegalStateException("recursive invocation");
			//获取sun.misc.Launcher实例，在rt.jar包内，在获取Launcher的过程中，同时也创建了ExtClassLoader和AppClassLoader
            sun.misc.Launcher l = sun.misc.Launcher.getLauncher();
            if (l != null) {
                Throwable oops = null;
				//获取AppClassLoader
                scl = l.getClassLoader();
                try {
                    scl = AccessController.doPrivileged(
                        new SystemClassLoaderAction(scl));
                } catch (PrivilegedActionException pae) {
                    oops = pae.getCause();
                    if (oops instanceof InvocationTargetException) {
                        oops = oops.getCause();
                    }
                }
                if (oops != null) {
                    if (oops instanceof Error) {
                        throw (Error) oops;
                    } else {
                        // wrap the exception
                        throw new Error(oops);
                    }
                }
            }
            sclSet = true;
        }
    }

	// The class loader for the system
    // @GuardedBy("ClassLoader.class")
    private static ClassLoader scl;

    // Set to true once the system class loader has been set
    // @GuardedBy("ClassLoader.class")
    private static boolean sclSet;

	class SystemClassLoaderAction
    implements PrivilegedExceptionAction<ClassLoader> {
    private ClassLoader parent;

    SystemClassLoaderAction(ClassLoader parent) {
        this.parent = parent;
    }

    public ClassLoader run() throws Exception {
		// 获取系统类加载器
        String cls = System.getProperty("java.system.class.loader");
        if (cls == null) {
            return parent;
        }

		//通过反射创建系统类加载器
        Constructor<?> ctor = Class.forName(cls, true, parent)
            .getDeclaredConstructor(new Class<?>[] { ClassLoader.class });
        ClassLoader sys = (ClassLoader) ctor.newInstance(
            new Object[] { parent });
		//设置当前线程的类加载器为创建出来的classLoader
        Thread.currentThread().setContextClassLoader(sys);
        return sys;
    }
	}


##### **Launcher的创建**

sun.misc.Launcher在rt.jar包中，rt.jar包由启动加载器加载，Launcher是通过单例的方式来定义。

	public static Launcher getLauncher() {
        return launcher;
    }

	private static Launcher launcher = new Launcher();

	public Launcher() {
        Launcher.ExtClassLoader var1;//扩展类加载器
        try {
			//获取扩展类加载器
            var1 = Launcher.ExtClassLoader.getExtClassLoader();
        } catch (IOException var10) {
            throw new InternalError("Could not create extension class loader", var10);
        }

        try {
			//获取应用程序类加载器
            this.loader = Launcher.AppClassLoader.getAppClassLoader(var1);
        } catch (IOException var9) {
            throw new InternalError("Could not create application class loader", var9);
        }
		
		//把应用程序类加载器设置给当前线程。
        Thread.currentThread().setContextClassLoader(this.loader);
		//获取安全管理类
        String var2 = System.getProperty("java.security.manager");
        if(var2 != null) {
            SecurityManager var3 = null;
            if(!"".equals(var2) && !"default".equals(var2)) {
                try {
					//通过应用程序类加载器加载SecurityManager，并创建该实例
                    var3 = (SecurityManager)this.loader.loadClass(var2).newInstance();
                } catch (IllegalAccessException var5) {
                    ;
                } catch (InstantiationException var6) {
                    ;
                } catch (ClassNotFoundException var7) {
                    ;
                } catch (ClassCastException var8) {
                    ;
                }
            } else {
                var3 = new SecurityManager();
            }

            if(var3 == null) {
                throw new InternalError("Could not create SecurityManager: " + var2);
            }
			将安全管理类设置到System当中
            System.setSecurityManager(var3);
        }

    }

可以看到，在构建Launcher的时候，创建了扩展类加载器和应用程序类加载器，并通过应该程序类加载器加载SecurityManager管理类，最后将SecurityManager类设置到系统中。

##### **ExtClassLoader类加载器的构建**

扩展类加载器是由ExtClassLoader类实现的，它是Launcher类的一个内部类，创建ExtClassLoader的过程如下：

	static class ExtClassLoader extends URLClassLoader {
        public static Launcher.ExtClassLoader getExtClassLoader() throws IOException {
            
			final File[] var0 = getExtDirs();//获取扩展类加载器加载的目录

            try {
                return (Launcher.ExtClassLoader)AccessController.doPrivileged(new PrivilegedExceptionAction() {
                    public Launcher.ExtClassLoader run() throws IOException {
                        int var1 = var0.length;

                        for(int var2 = 0; var2 < var1; ++var2) {
                            MetaIndex.registerDirectory(var0[var2]);
                        }
						// 调用ExtClassLoader的构造器方法
                        return new Launcher.ExtClassLoader(var0);
                    }
                });
            } catch (PrivilegedActionException var2) {
                throw (IOException)var2.getException();
            }
        }

		private static File[] getExtDirs() {
			//获取java.ext.dirs目录
            String var0 = System.getProperty("java.ext.dirs");
            File[] var1;//目录集合
            if(var0 != null) {
                StringTokenizer var2 = new StringTokenizer(var0, File.pathSeparator);
                int var3 = var2.countTokens();
                var1 = new File[var3];

                for(int var4 = 0; var4 < var3; ++var4) {
                    var1[var4] = new File(var2.nextToken());
                }
            } else {
                var1 = new File[0];
            }

            return var1;
        }
		
		// 执行特定的PrivilegedExceptionAction操作，该操作具体特权，可以通过很多权限限制检查。
		public static native <T> T doPrivileged(PrivilegedExceptionAction<T> action)
        throws PrivilegedActionException;

		// 构造ExtClassLoader
		public ExtClassLoader(File[] var1) throws IOException {
            super(getExtURLs(var1), (ClassLoader)null, Launcher.factory);
            SharedSecrets.getJavaNetAccess().getURLClassPath(this).initLookupCache(this);
        }

ExtClassLoader继承自URLClassLoader，而URLClassLoadery又继承自SecureClassLoader，SecureClassLoader又继承自ClassLoader。他们之间的继承关系是ExtClassLoader——>URLClassLoader——>SecureClassLoader——>ClassLoader。 URLClassLoader的构造器如下：

	/**
     * Constructs a new URLClassLoader for the specified URLs, parent
     * class loader, and URLStreamHandlerFactory. The parent argument
     * will be used as the parent class loader for delegation. The
     * factory argument will be used as the stream handler factory to
     * obtain protocol handlers when creating new jar URLs.
     *
     * <p>If there is a security manager, this method first
     * calls the security manager's {@code checkCreateClassLoader} method
     * to ensure creation of a class loader is allowed.
     *
     * @param urls the URLs from which to load classes and resources
     * @param parent the parent class loader for delegation
     * @param factory the URLStreamHandlerFactory to use when creating URLs
     *
     * @exception  SecurityException  if a security manager exists and its
     *             {@code checkCreateClassLoader} method doesn't allow
     *             creation of a class loader.
     * @exception  NullPointerException if {@code urls} is {@code null}.
     * @see SecurityManager#checkCreateClassLoader
     */
    public URLClassLoader(URL[] urls, ClassLoader parent,
                          URLStreamHandlerFactory factory) {
        super(parent);
        // this is to make the stack depth consistent with 1.1
		//获取之前创建的SecurityManager
        SecurityManager security = System.getSecurityManager();
        if (security != null) {
			//检查是否有创建ClassLoader的权限
            security.checkCreateClassLoader();
        }
		//创建一个URLClassPath，里面保存了URL的路径以及创建了一个jarHandler
        ucp = new URLClassPath(urls, factory);
        acc = AccessController.getContext();
    }

从ExtClassLoader类加载器的构建过程来，其主要是加载ext扩展目录下的jar文件。


##### **AppClassLoader类加载器的构建**

在Launcher中创建完扩展类加载器后，接着构建应用程序类加载器AppClassLoader，AppClassLoader也是Launcher中的一个内部类，继承自URLClassLoader。

	    static class AppClassLoader extends URLClassLoader {
        final URLClassPath ucp = SharedSecrets.getJavaNetAccess().getURLClassPath(this);

        public static ClassLoader getAppClassLoader(final ClassLoader var0) throws IOException {
			//获取class类的路径
            final String var1 = System.getProperty("java.class.path");
            final File[] var2 = var1 == null?new File[0]:Launcher.getClassPath(var1);
			//通过AccessController的doPrivileged方法，执行一些需要特殊权限的操作
            return (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
                public Launcher.AppClassLoader run() {
					//将class文件的目录路径转换为URL形式
                    URL[] var1x = var1 == null?new URL[0]:Launcher.pathToURLs(var2);
					//通过AppClassLoader的构造方法创建实例
                    return new Launcher.AppClassLoader(var1x, var0);
                }
            });
        }

		//AppClassLoader的构造方法
		AppClassLoader(URL[] var1, ClassLoader var2) {
			//调用URLClassLoader的构造方法，其中parent属性为ExtClassLoader
            super(var1, var2, Launcher.factory);
            this.ucp.initLookupCache(this);
        }

从AppClassLoader类加载器的构造过程可以看到，它加载的主要是class路径下的类。并且APPClassLoader的父加载器是ExtClassLoader加载器。

### 双亲委派模型

ClassLoader的双亲委派模型中，各个ClassLoader之间的关系是通过组合关系来复用父加载器。**当一个ClassLoader收到来类加载的请求，首先把该请求委派该父类ClassLoader处理，当父类ClassLoader无法处理时，才由当前类ClassLoader来处理**。对于每个ClassLoader这个方式，也就是**父类的优先于子类处理类加载的请求**，那么也就是说任何一个请求第一次处理的便是最顶层的Bootstrap ClassLoader(启动类加载器)。

类加载器的层级查找顺序依次为：**启动类加载器，扩展类加载器，系统类加载器**。系统类加载器是默认的应用程序类加载器。
![ClassLoader加载器](http://gityuan.com/images/jvm/classloader.png)

双亲委派模型的好处是**不同层次的类加载器具有不同优先级**，比如所有Java对象的超级父类java.lang.Object，位于rt.jar，无论哪个类加载器加载该类，最终都是由启动类加载器进行加载，**保证安全**。即使用户自己编写一个java.lang.Object类并放入程序中，虽能正常编译，但不会被加载运行，保证不会出现混乱。那么有人会继续追问，如果自己再自定义一个类加载器来加载自己定义的java.lang.Object类呢? 这样做也是不会成功的，虚拟机将会抛出一异常。

#### 1. 类的加载过程

类的加载是通过ClassLoader类中的loadClass方法来完成的。


	public Class<?> loadClass(String name) throws ClassNotFoundException {
        return loadClass(name, false);
    }
	/*
	* 加载指定name对应的class。
	* 该方法的默认实现顺序是：
	* 1.调用findLoadedClass方法来检查该class是否已经被加载了
	* 2.调用父加载器的LoadClass方法，如果父类的ClassLoader为null，则使用JVM默认的虚拟机加载器
	* 3.调用findClass方法来加载类
	* 如果通过上面的方法找到了class对象，则resolve将返回true，后面将触发resolveClass()方法来解析Class类
	* 子ClassLoader可以覆写findClass()方法来加载类
	*/
    protected Class<?> loadClass(String name, boolean resolve)
        throws ClassNotFoundException
    {
		//同步方法
        synchronized (getClassLoadingLock(name)) {
            // First, check if the class has already been loaded
			//1.检查是否已经加载过该class
            Class<?> c = findLoadedClass(name);
			//如果没有被加载，则调用父加载器的loadClass方法
            if (c == null) {
                long t0 = System.nanoTime();
                try {
                    if (parent != null) {
						//2.调用父类的加载器加载类
                        c = parent.loadClass(name, false);
                    } else {
						//调用引导类加载器加载类
                        c = findBootstrapClassOrNull(name);
                    }
                } catch (ClassNotFoundException e) {
                    // ClassNotFoundException thrown if class not found
                    // from the non-null parent class loader
                }

				//如果class为null，则说明通过父类或者引导类加载器都没有找到合适的类
                if (c == null) {
                    // If still not found, then invoke findClass in order
                    // to find the class.
                    long t1 = System.nanoTime();
					//3.通过findClass方法来查找类
                    c = findClass(name);

                    // this is the defining class loader; record the stats
                    sun.misc.PerfCounter.getParentDelegationTime().addTime(t1 - t0);
                    sun.misc.PerfCounter.getFindClassTime().addElapsedTimeFrom(t1);
                    sun.misc.PerfCounter.getFindClasses().increment();
                }
            }
			//如果找到了类，则resolve为true，解析Class类
            if (resolve) {
                resolveClass(c);
            }
            return c;
        }
    }

	//检查name对应的类是否已经被加载了
	protected final Class<?> findLoadedClass(String name) {
        if (!checkName(name))
            return null;
        return findLoadedClass0(name);
    }

    private native final Class<?> findLoadedClass0(String name);


	 /**
     * Returns a class loaded by the bootstrap class loader;
     * or return null if not found.
     */
	// 通过系统引用加载器加载name对应的类
    private Class<?> findBootstrapClassOrNull(String name)
    {
        if (!checkName(name)) return null;

        return findBootstrapClass(name);
    }

	// return null if not found
    private native Class<?> findBootstrapClass(String name);
	

	/**
     * Finds the class with the specified <a href="#name">binary name</a>.
     * This method should be overridden by class loader implementations that
     * follow the delegation model for loading classes, and will be invoked by
     * the {@link #loadClass <tt>loadClass</tt>} method after checking the
     * parent class loader for the requested class.  The default implementation
     * throws a <tt>ClassNotFoundException</tt>.
     *
     * @param  name
     *         The <a href="#name">binary name</a> of the class
     *
     * @return  The resulting <tt>Class</tt> object
     *
     * @throws  ClassNotFoundException
     *          If the class could not be found
     *
     * @since  1.2
     */
	
	// 调用子类的findClass方法，可以自定义实现该方法
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        throw new ClassNotFoundException(name);
    }

可以看到，LoadClass方法将按以下顺序来执行：

1. 调用findLoadedClass方法来检查该class是否已经被加载了。
2. 调用父类的加载器加载类
3. 通过findClass方法来查找类

当开发者需要自定义类加载器时，可通过覆写loadClass()方法或者findClass()。

### 自定义类加载器

**每一个ClassLoader都拥有自己独立的类名称空间**，**类是由ClassLoader将其加载到Java虚拟机中**，**故类是由加载它的ClassLoader和该类本身一起确定其在Java 运行时环境的唯一性**。故只有同一个ClassLoader加载的同一个类，才能算是Java 运行时环境中的相同的两个类。哪怕是来自同一个Class文件，即使被同一个虚拟机加载的两个类，只要ClassLoader不同，那么也属于不同的类。**对于equals()、isinstanceof()等方法来判断对象的相等或所属关系都是需要基于同一个ClassLoader**。

**通过Class.forName()方法加载的类，采用的是系统类加载器**。

使用示例：

	public class ClassLoadDemo {

    public static void main(String[] args) throws Exception{
        ClassLoader classLoader = new ClassLoader() {
            @Override
            public Class<?> loadClass(String name) throws ClassNotFoundException {
                try {
                    String clsName = name.substring(name.lastIndexOf(".")+1) + ".class";

                    InputStream is = getClass().getResourceAsStream(clsName);
                    if (is == null){
                        return super.loadClass(name);
                    }
                    byte[] b = new byte[is.available()];
                    is.read(b);
                    return defineClass(name,b,0,b.length);
                } catch (IOException e) {
                    throw new ClassNotFoundException(name);
                }

            }
        };

        String currentClass = "ClassLoadDemo";
        Class<?> clazz = classLoader.loadClass(currentClass);
        Object obj = clazz.newInstance();

        System.out.println(obj.getClass());
        System.out.println(obj instanceof ClassLoadDemo);

    }
	}



参考文章： [Java类加载器(ClassLoader)](http://gityuan.com/2016/01/24/java-classloader/)



	
## Java输入流类库

### InputStream
InputStream是一个抽象类，是所有输入流的父类。InputStream里面定义了一些方法来读取字节流。

	public abstract class InputStream implements Closeable {
	/**
     * Reads the next byte of data from the input stream. The value byte is
     * returned as an int in the range 0 to
     * 255. If no byte is available because the end of the stream
     * has been reached, the value -1 is returned. This method
     * blocks until input data is available, the end of the stream is detected,
     * or an exception is thrown.
     *
     * <p> A subclass must provide an implementation of this method.
     *
     * @return     the next byte of data, or -1 if the end of the
     *             stream is reached.
     * @exception  IOException  if an I/O error occurs.
     */
    public abstract int read() throws IOException;
	}

	/**
     * Reads some number of bytes from the input stream and stores them into
     * the buffer array b. The number of bytes actually read is
     * returned as an integer.  This method blocks until input data is
     * available, end of file is detected, or an exception is thrown.
     *
     * <p> If the length of b is zero, then no bytes are read and
     * 0 is returned; otherwise, there is an attempt to read at
     * least one byte. If no byte is available because the stream is at the
     * end of the file, the value -1 is returned; otherwise, at
     * least one byte is read and stored into b.
     *
     * <p> The first byte read is stored into element b[0], the
     * next one into b[1], and so on. The number of bytes read is,
     * at most, equal to the length of b. Let k be the
     * number of bytes actually read; these bytes will be stored in elements
     * b[0] through b[k-1],leaving elements b[k] through b[b.length-1] unaffected.
     * 
     * <p> The read(b) method for class InputStream has the same effect as: read(b, 0, b.length)
     *
     * @param      b   the buffer into which the data is read.
     * @return     the total number of bytes read into the buffer, or
     *             -1 if there is no more data because the end of
     *             the stream has been reached.
     * @exception  IOException  If the first byte cannot be read for any reason
     * other than the end of the file, if the input stream has been closed, or
     * if some other I/O error occurs.
     * @exception  NullPointerException  if b is null.
     * @see        java.io.InputStream#read(byte[], int, int)
     */
    public int read(byte b[]) throws IOException {
        return read(b, 0, b.length);
    }

	/**
     * Reads up to len bytes of data from the input stream into
     * an array of bytes.  An attempt is made to read as many as
     * len bytes, but a smaller number may be read.
     * The number of bytes actually read is returned as an integer.
     *
     * This method blocks until input data is available, end of file is
     * detected, or an exception is thrown.
     *
     *  If len is zero, then no bytes are read and0 is returned; otherwise, there is an attempt to read at
     * least one byte. If no byte is available because the stream is at end of
     * file, the value -1 is returned; otherwise, at least one byte is read and stored into b.
     *
     * @param      b     the buffer into which the data is read.
     * @param      off   the start offset in array b at which the data is written.
     * @param      len   the maximum number of bytes to read.
     * @return     the total number of bytes read into the buffer, or
     *             -1 if there is no more data because the end of
     *             the stream has been reached.
     * @exception  IOException If the first byte cannot be read for any reason
     * other than end of file, or if the input stream has been closed, or if
     * some other I/O error occurs.
     * @exception  NullPointerException If <code>b</code> is <code>null</code>.
     * @exception  IndexOutOfBoundsException If <code>off</code> is negative,
     * <code>len</code> is negative, or <code>len</code> is greater than
     * <code>b.length - off</code>
     * @see        java.io.InputStream#read()
     */
    public int read(byte b[], int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException();
        } else if (off < 0 || len < 0 || len > b.length - off) {
            throw new IndexOutOfBoundsException();
        } else if (len == 0) {
            return 0;
        }

        int c = read();//调用InputStream的read方法
        if (c == -1) {
            return -1;
        }
        b[off] = (byte)c;//从第一个off位置开始

        int i = 1;
		//循环读取
        try {
            for (; i < len ; i++) {
                c = read();
                if (c == -1) {
                    break;
                }
                b[off + i] = (byte)c;
            }
        } catch (IOException ee) {
        }
        return i;//返回读取的数目
    }

	  /**
     * Skips over and discards n bytes of data from this input
     * stream. The skip method may, for a variety of reasons, end
     * up skipping over some smaller number of bytes, possibly 0.
     * This may result from any of a number of conditions; reaching end of file
     * before n bytes have been skipped is only one possibility.
     * The actual number of bytes skipped is returned. If {@code n} is
     * negative, the {@code skip} method for class {@code InputStream} always
     * returns 0, and no bytes are skipped. Subclasses may handle the negative
     * value differently.
     *
     * <p> The skip method of this class creates a byte array and then repeatedly reads into it until nbytes
     * have been read or the end of the stream has been reached. Subclasses are
     * encouraged to provide a more efficient implementation of this method.
     * For instance, the implementation may depend on the ability to seek.
     *
     * @param      n   the number of bytes to be skipped.
     * @return     the actual number of bytes skipped.
     * @exception  IOException  if the stream does not support seek,
     *                          or if some other I/O error occurs.
     */
    public long skip(long n) throws IOException {

        long remaining = n;
        int nr;

        if (n <= 0) {
            return 0;
        }
        //MAX_SKIP_BUFFER_SIZE 为2048，表示最大可以丢弃的数目
        int size = (int)Math.min(MAX_SKIP_BUFFER_SIZE, remaining);
		//创建一个新的byte数组，用来保存需要忽略跳过的字节
        byte[] skipBuffer = new byte[size];
        while (remaining > 0) {
            nr = read(skipBuffer, 0, (int)Math.min(size, remaining));
            if (nr < 0) {
                break;
            }
            remaining -= nr;
        }

        return n - remaining;
    }

	/**
     * Returns an estimate of the number of bytes that can be read (or
     * skipped over) from this input stream without blocking by the next
     * invocation of a method for this input stream. The next invocation
     * might be the same thread or another thread.  A single read or skip of this
     * many bytes will not block, but may read or skip fewer bytes.
     *
     * <p> Note that while some implementations of {@code InputStream} will return
     * the total number of bytes in the stream, many will not.  It is
     * never correct to use the return value of this method to allocate
     * a buffer intended to hold all data in this stream.
     *
     * <p> A subclass' implementation of this method may choose to throw an
     * {@link IOException} if this input stream has been closed by
     * invoking the {@link #close()} method.
     *
     * <p> The {@code available} method for class {@code InputStream} always
     * returns {@code 0}.
     *
     * <p> This method should be overridden by subclasses.
     *
     * @return     an estimate of the number of bytes that can be read (or skipped
     *             over) from this input stream without blocking or {@code 0} when
     *             it reaches the end of the input stream.
     * @exception  IOException if an I/O error occurs.
     */
    public int available() throws IOException {
        return 0;
    }

	/**
     * Closes this input stream and releases any system resources associated
     * with the stream.
     *
     * <p> The <code>close</code> method of <code>InputStream</code> does
     * nothing.
     *
     * @exception  IOException  if an I/O error occurs.
     */
    public void close() throws IOException {}

	}

InputStream的常见实现子类有ByteArrayInputStream、StringBufferInputStream、FileInputStream。

#### ByteArrayInputStream
ByteArrayInputStream内部包含一个buffer来保存从输入流读取的字节。关闭一个ByteArrayInputStream是没有任何效果的。

#### StringBufferInputStream
StringBufferInputStream允许应用创建一个InputStream，读取的是字符的内容。只有字符的低8位被使用。因为该类不能有效将字符转换为字节byte，因此该类已经被废弃了，建议使用StringReader。

#### FileInputStream
FileInputStream从一个文件中获取输入字节。FileInputStream主要用于读取原始的字节流，例如图片数据。如果需要读取字符流，考虑使用FileReader。


### FilterInputStream

FilterInputStream是InputStream类的一个装饰类，它同样包含了一个InputStream，可以提供数据的转换或者是添加一些额外的操作。

	public class FilterInputStream extends InputStream {
		/**
     	* The input stream to be filtered.
     	*/
		// 持有一个InputStream实例
    	protected volatile InputStream in;

	/**
     * Creates a <code>FilterInputStream</code>
     * by assigning the  argument <code>in</code>
     * to the field <code>this.in</code> so as
     * to remember it for later use.
     *
     * @param   in   the underlying input stream, or <code>null</code> if
     *          this instance is to be created without an underlying stream.
     */
    protected FilterInputStream(InputStream in) {
        this.in = in;
    }
	
	/**
     * Reads the next byte of data from this input stream. The value
     * byte is returned as an <code>int</code> in the range
     * <code>0</code> to <code>255</code>. If no byte is available
     * because the end of the stream has been reached, the value
     * <code>-1</code> is returned. This method blocks until input data
     * is available, the end of the stream is detected, or an exception
     * is thrown.
     * <p>
     * This method
     * simply performs <code>in.read()</code> and returns the result.
     *
     * @return     the next byte of data, or <code>-1</code> if the end of the
     *             stream is reached.
     * @exception  IOException  if an I/O error occurs.
     * @see        java.io.FilterInputStream#in
     */
    public int read() throws IOException {
        return in.read();//调用InputStream的read方法
    }
	....
	//其他方法都是调用对应InputStream的方法
	}

FilterInputStream是InputStream的一个基础装饰类，它的常用子类有：DataInputStream、LineNumberInputStream、BufferedInputStream。这些类都是具体的装饰者，都是用来装饰InputStream的。

#### BufferedInputStream
BufferedInputStream是一个具体的装饰者，它加入了两种行为：利用缓冲区输入来改进性能。用readline方法（用来一次读取一行文本输入数据）来增强接口。

### Java输入流类图

![Java输入流类图](http://orbohk5us.bkt.clouddn.com/17-7-8/80655015.jpg)

Java输入流是一个典型的装饰器模式的应用。

InputStream是抽象的组件。

FileInputStream、StringBufferInputStream和ByteArrayInputStream是可以被装饰者包装起来的具体组件。

FilterInputStream是抽象的装饰者。

LineNumberInputStream、BufferedInputStream和DataInputStream是具体的装饰者。

具体的可以参考[装饰者设计模式]()。



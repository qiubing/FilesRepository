## WindowManager.LayoutParams与ViewGroup.LayoutParams对比

1. WindowManager的LayoutParams继承自ViewGroup的LayoutParams参数。里面包含的参数主要是针对该窗口设计的。


		public static class LayoutParams extends ViewGroup.LayoutParams implements Parcelable {
		public int x;//窗口放置的位置
		public int y;

		public int type;//窗口的类型，Application、Sub、System
		public int flags;//窗口的标记
		public int gravity;
		public int format;//bitmap格式
		public IBinder token = null;//标识该窗口的Token
		public String packageName = null;// 拥有该窗口的包名
		public int systemUiVisibility;//控制状态栏的可见性
	}
2. ViewGroup的LayoutParams被**子View视图用来指示父View它们该如何布局**。基础的LayoutParams类只是用来描述view的宽和高，每个取值都可以为：

	- MATCH_PARENT：和父View一样大（不包含padding）
	- WRAP_CONTENT：只需包含内容大小（包含padding）
	- 具体的值。

3. 针对不同的ViewGroup子类，有对应的LayoutParams子类相对应。例如绝对布局有它自己的LayoutParams子类，里面包含了一个X和Y。

4. ViewGroup.LayoutParams的定义如下:

		public static class LayoutParams {
			public static final int MATCH_PARENT = -1;
			public static final int WRAP_CONTENT = -2;
			public int width;//view的宽度
			public int height;//view的高度

			public LayoutParams(int width, int height) {
            this.width = width;
            this.height = height;
        	}
			
			LayoutParams() {
        	}
		}

## WindowManager.addView与ViewGroup.addView的区别

1.WindowManager.addView方法由WindowManagerImpl类来实现，然后调用WindowMangerGlobal对应的addView方法。对应的调用堆栈如下：

	WindowManagerImpl.addView
		WindowManagerGlobal.addView
			ViewRootImpl.setView
				Session.addToDisplay
					WindowManagerService.addWindow

接下来分析一下WindowManagerGlobal的addView方法：

	public void addView(View view, ViewGroup.LayoutParams params,
            Display display, Window parentWindow) {
		// 将参数转化为WindowManger类型的参数
		final WindowManager.LayoutParams wparams = (WindowManager.LayoutParams) params;

		ViewRootImpl root;//定义ViewRootImpl
        View panelParentView = null;//定义sub View类型
		
		//查找View是否已经添加过
		int index = findViewLocked(view, false);
		//如果已经添加过了，则直接抛出异常
		if (index >= 0) {
                if (mDyingViews.contains(view)) {
              
                    mRoots.get(index).doDie();
                } else {
                    throw new IllegalStateException("View " + view
                            + " has already been added to the window manager.");
                }
            }
		// 如果是Sub Window，则寻找它所依附的Window
		if (wparams.type >= WindowManager.LayoutParams.FIRST_SUB_WINDOW &&
                    wparams.type <= WindowManager.LayoutParams.LAST_SUB_WINDOW) {
                final int count = mViews.size();
                for (int i = 0; i < count; i++) {
                    if (mRoots.get(i).mWindow.asBinder() == wparams.token) {
                        panelParentView = mViews.get(i);
                    }
                }
            }
		// 根据该View的Context以及display创建一个ViewRootImpl对象。ViewRootImpl是用来与WindowManagerService进行通信的桥梁。
		root = new ViewRootImpl(view.getContext(), display);
		// 设置View的参数
		view.setLayoutParams(wparams);

		// 将View、ViewRootImpl、LayoutParams分别添加到集合中，他们之间是一一对应的，即同一个index取出来的View、ViewRootImpl、LayoutParams是针对同一个View的。
		mViews.add(view);
        mRoots.add(root);
        mParams.add(wparams);
		
		//通过ViewRootImpl来添加View。
		root.setView(view, wparams, panelParentView);
	}

可以看到，在WindowManagerGlobal的addView方法中，首先判断是否已经添加过该View，接着如果是Sub Window，则还需要查找其对应依附的父窗口。随后创建一个ViewRootImpl对象，并将View、ViewRootImpl以及参数Params添加到集合中，最后调用ViewRootImpl的setView方法来添加View。

在构建ViewRootImpl的时候，创建了一些关键变量：

	public ViewRootImpl(Context context, Display display) {
		mContext = context;
		// 调用openSession方法打开到WMS的连接
        mWindowSession = WindowManagerGlobal.getWindowSession();
		mDisplay = display;
		mThread = Thread.currentThread();//获取当前线程
		mWidth = -1;
        mHeight = -1;
			
		mWindow = new W(this);//本地窗口的Binder代理
		mViewVisibility = View.GONE;
		// 创建AttachInfo，包含一系列View的信息，当View依附到其浮窗口时
		mAttachInfo = new View.AttachInfo(mWindowSession, mWindow, display, this, mHandler, this);

		mChoreographer = Choreographer.getInstance();
        mDisplayManager = (DisplayManager)context.getSystemService(Context.DISPLAY_SERVICE);
	}

ViewRootImpl的setView方法主要工作如下：

	public void setView(View view, WindowManager.LayoutParams attrs, View panelParentView) {
		synchronized (this) {
            if (mView == null) {
                mView = view;//保留需要设置的View
				mWindowAttributes.copyFrom(attrs);//复制参数属性

				attrs = mWindowAttributes;
				
				mAttachInfo.mRootView = view;//将View设置为RootView
				mAdded = true;
				// 在添加View到WindowManager之前，先执行布局操作
				requestLayout();

				// 创建输入通道
				if ((mWindowAttributes.inputFeatures
                        & WindowManager.LayoutParams.INPUT_FEATURE_NO_INPUT_CHANNEL) == 0) {
                    mInputChannel = new InputChannel();
                }

				try {
					// 保存原始的属性
                    mOrigWindowType = mWindowAttributes.type;
                    mAttachInfo.mRecomputeGlobalAttributes = true;
					// 收集View的属性
                    collectViewAttributes();
					// 调用Session的addToDisplay方法添加View到WindowManager中
                    res = mWindowSession.addToDisplay(mWindow, mSeq, mWindowAttributes,
                            getHostVisibility(), mDisplay.getDisplayId(),
                            mAttachInfo.mContentInsets, mAttachInfo.mStableInsets,
                            mAttachInfo.mOutsets, mInputChannel);
                } catch (RemoteException e) {
                    ....
                } finally {
				}
	
			if (mInputChannel != null) {
                    // 注册输入通道，用来接收底层返回的输入事件
                    mInputEventReceiver = new WindowInputEventReceiver(mInputChannel,
                            Looper.myLooper());
                }
			// 将该View的ParentView设置为ViewRootImpl
			view.assignParent(this);
		}
	}

可以看到在ViewRootImpl的setView方法中，首先执行了requestLayout()方法重新布局，随后调用Session的addToDisplay()方法连接到WMS服务中，完成添加View的操作，最后将该View的ParentView设置为ViewRootImpl，并注册输入通道监听。

2. ViewGroup.addView方法是为了将一个View添加到一个View的容器中，注意不要执行onDraw方法的时候调用该方法。


		public void addView(View child) {
        	addView(child, -1);
    	}

		// index表示child view需要添加到集合的位置，如果为-1则表示添加到末尾
		public void addView(View child, int index) {
			// 参数判断
        	if (child == null) {
            throw new IllegalArgumentException("Cannot add a null child view to a ViewGroup");
        	}
			// 获取View设置的参数
        	LayoutParams params = child.getLayoutParams();
       	 	// 如果View设置的参数为空，则使用ViewGroup的参数作为View的参数
			if (params == null) {
            	params = generateDefaultLayoutParams();
            	if (params == null) {
                throw new IllegalArgumentException("generateDefaultLayoutParams() cannot return null");
            	}
        	}
		
        	addView(child, index, params);
    	}

		public void addView(View child, int index, LayoutParams params) {

        	if (child == null) {
            throw new IllegalArgumentException("Cannot add a null child view to a ViewGroup");
        	}

			// 首先调用请求layout
        	requestLayout();
			// 调用invalidte方法进行重绘
        	invalidate(true);
			// 将View添加到View集合中
        	addViewInner(child, index, params, false);
    		}

		protected LayoutParams generateDefaultLayoutParams() {
        	return new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
    	}

可以看到在ViewGroup的addView方法中，主要是将View添加到集合中，如果没有设置参数，则使用ViewGroup的参数。在添加View的集合中时，会调用requestLayout和invalidate方法进行布局以及重绘。

	




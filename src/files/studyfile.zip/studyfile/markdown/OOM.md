## OOM

### 1.什么是OOM？

**OOM**，全称是“OutOfMemory”，内存溢出。

**当JVM因为没有足够的内存来为对象分配空间并且垃圾回收器也已经没有空间可回收时，就会抛出这个Error**。（OOM不是Exception,因为这个问题以已经严重到不足以被应用处理）

OOM发生的条件：

- JVM没有足够的内存来为对象分配空间；
- 垃圾回收器已经没有空间可回收了；

OutOfMemoryError继承自VirtualMachineError类，而VirtualMachineError又继承自Error类，Error类又继承Throwable类。

	public class OutOfMemoryError extends VirtualMachineError {
		...
	}

VirtualMachineError错误被抛出来，表示JVM被中断了或者耗尽了资源导致无法继续执行。

	abstract public class VirtualMachineError extends Error {
		...
	}

Error是Throwable的一个子类，表示很严重的问题，应用不应该尝试捕获此类错误。尽管线程死亡(ThreadDeath)是一个“普通”的场景，但是因为ThreadDeath类也是Error的子类，因此应用也不应该捕获它。

方法不需要在运行过程中，声明可能抛出的Error子类异常。

**Error以及它的子类都被当作是未受检(unchecked)异常**。

	public class Error extends Throwable {
		....
	}

### 2.为什么会OOM？

OOM产生的原因有两点：

1. 分配的少了：比如虚拟机本身可用的内存(一般通过启动时的VM参数指定)太少了。
2. 应用用的太多了，并且用完了没有释放，浪费了。此时就会造成内存泄漏或者内存溢出。

**内存泄漏**： 申请使用完的内存没有释放，导致虚拟机不能再次使用该内存，此时这段内存就泄露了，因为申请者不用了，而又不能被虚拟机分配给别人用。

**内存溢出**：申请的内存超出了JVM能提供的内存大小，此时称之为溢出。

### 3.常见的OOM情况有哪些？

最常见的OOM情况有以下四种：

**1.堆内存溢出——Java Heap**

**异常信息**： java.lang.OutOfMemoryError: Java heap space

Java堆用于存储对象实例，我们只要不断的创建对象，并且保证GC Roots到对象之间有可达路径来避免垃圾回收机制清除这些对象，就会在对象数量达到最大堆容量限制后产生内存溢出异常。

此种情况最常见，一般由于**内存泄露**或者**堆的大小**设置不当引起。对于内存泄露，需要通过内存监控软件查找程序中的泄露代码，而堆大小可以通过虚拟机参数-Xms,-Xmx等修改。

出现这种异常，一般手段是先通过内存映像分析工具(如Eclipse Memory Analyzer)对dump出来的堆转存快照进行分析，重点是确认内存中的对象是否是必要的，先分清是因为内存泄漏(Memory Leak)还是内存溢出(Memory Overflow)。

如果是内存泄漏，可进一步通过工具查看泄漏对象到GC Roots的引用链。于是就能找到泄漏对象时通过怎样的路径与GC Roots相关联并导致垃圾收集器无法自动回收。

如果不存在泄漏，那就应该检查虚拟机的参数(-Xmx与-Xms)的设置是否适当。

**2.Java虚拟机栈和本地方法栈溢出**

**异常信息**：java.lang.StackOverflowError

**JAVA虚拟机栈溢出**，一般是由于程序中存在死循环或者深度递归调用造成的，栈大小设置太小也会出现此种溢出。可以通过虚拟机参数-Xss来设置栈的大小。

如果线程请求的栈深度大于虚拟机所允许的最大深度，将抛出StackOverflowError异常。

如果虚拟机在扩展栈时无法申请到足够的内存空间，则抛出OutOfMemoryError异常。

这里需要注意**当栈的大小越大可分配的线程数就越少**。

**3.方法区溢出或永久代溢出**

**异常信息**：java.lang.OutOfMemoryError:PermGen space

方法区用于存放Class的相关信息，如类名、访问修饰符、常量池、字段描述、方法描述等。

**方法区溢出或永久代溢出**，一般出现于大量Class或者jsp页面，或者采用cglib等反射机制的情况，因为上述情况会产生大量的Class信息存储于方法区。此种情况可以通过更改方法区的大小来解决，使用类似-XX:PermSize=64m -XX:MaxPermSize=256m的形式修改。

GC在主程序运行期间不会对永久区进行清理，默认是64M大小，当程序需要加载的对象比较多时，超过64M就会报这部分内存溢出了，需要加大内存分配，一般128m足够。 

**4.运行时常量池溢出**

**异常信息**：java.lang.OutOfMemoryError:PermGen space

过多的常量尤其是字符串也会导致**运行时常量溢出**。**如果要向运行时常量池中添加内容，最简单的做法就是使用String.intern()这个Native方法**。该方法的作用是：

> 如果池中已经包含一个等于此String的字符串，则返回代表池中这个字符串的String对象；否则，将此String对象包含的字符串添加到常量池中，并且返回此String对象的引用。

由于常量池分配在方法区内，我们可以通过-XX:PermSize和-XX:MaxPermSize限制方法区的大小，从而间接限制其中常量池的容量。


### 4.OOM可以被try-catch吗？

如下代码是否可行：

	try {
    	代码A
	} catch (OutOfMemoryError ignored) {
    	代码B
	}

只有在一种情况下，这样做是可行的：

在try语句中申明了很大的对象，导致OOM，并且可以确认OOM是由于try语句中的对象声明导致的，那么在catch语句中，可以释放掉这些对象，解决OOM的问题，继续执行剩余语句。

但是这通常不是合适的做法。

Java中管理内存除了显式地catch OOM之外，还有更多有效的方法：比如SoftReference、WeakReference、硬盘缓存等。

在JVM用光内存之前，会多次触发GC，这些GC会降低程序的运行效率。

如果OOM的原因不是try语句中的对象(比如内存泄漏)，那么在catch语句中会继承抛出OOM。

try-catch虽然可以捕获到OOM异常，但在这里发生OOM不是简单因为这里申请了内存导致OOM，往往这里是压死骆驼的一根稻草，在这里catch住了，它又会在下一个地方崩溃。

try-catch 是可以解决oom后出现的崩溃，然后采取补救的措施，例如缩小图片，减少内存占用。但是这并不是解决oom的根本方法，要解决oom还必须知道oom的出现原因，来提前做出应对措施。



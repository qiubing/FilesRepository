## SEAndroid安全机制

[TOC]

Android是一个基于Linux内核的移动操作系统。Linux是一个支持多用户的系统，系统中的文件的访问权限是通过用户ID(UID)和用户组ID(GID)来控制的。

Linux的安全机制是基于UID和GID来实现的。Android在Linux内核提供的基于UID和GID的安全机制的基础上，又实现了一套称为Permission的安全机制。

![Linux的UID/GID安全机制与Android的Permission安全机制](http://img.blog.csdn.net/20131206014813656)


### Linux基于UID和GID的安全机制

Linux基于UID和GID的安全机制，它包含三个基本角色：**用户**、**进程**和**文件**。

![Linux基于UID/GID的安全机制的三个角色](http://img.blog.csdn.net/20131206014917421)

Linux中的每一个用户都分配有一个UID，然后所有的用户又按组来进行划分，每一个用户组都分配有一个GID。注意，一个用户可以属于多个用户组，也就是说，一个UID可以对应多个GID。在一个用户所对应的用户组中，其中有一个称为主用户组，其他的称为补充用户组。

Linux中的每一个文件，都具有三种权限：Read、Write和Execute。这三种权限又按照用户属性划分为三组：Owner、Group和Other。

Linux中的每一个进程都关联有一个用户，也就是对应有一个UID。

由于每一个用户都对应有一个主用户组，以及若干个补充用户组，因此，每一个进程除了有一个对应的UID之外，还对应于有一个主GID，以及若干个Supplementary GIDs。这些UID和GID就决定了一个进程所能访问的文件或者所能调用的系统API。

一个进程的UID是怎么来的呢？在默认情况下，进程的UID就等于创建它的进程的UID，也就是它的父进程的UID。Linux的第一个进程是init进程，它是由内核在启动完成后创建的，它的UID是root。然后系统中的所有其它进程都是直接由init进程或者间接由init进程的子进程来创建。所以默认情况下，系统的所有进程的UID都应该是root。但是实际情况并非如此，因为父进程在创建子进程之后，也就是fork之后，可以调用setuid来改变它的UID。例如，在PC中，init进程启动之后，会先让用户登录。用户登录成功后，就对应有一个shell进程，该shell进程的UID就会被setuid修改为所登录的用户。之后系统中创建的其余进程的UID为所登录的用户。

进程的UID除了来自于父进程之外，还有另外一种途径。通过**SUID权限**。Linux文件除了有Read、Write和Execute权限外，还有一种权限称为SUID。例如，我们对Android手机进行root的过程中，会在里面放置一个su文件。这个su文件就具有SUID权限。

一个可执行文件一旦被设置了SUID位，那么当它被一个进程通过exec加载之后，该进程的UID就会变成该可执行文件所有者的UID。也就是说，当上述的su被执行的时候，它所运行在的进程的UID是root，于是它就具有最高级别的权限，想干什么就干什么。

与SUID类似，文件还有另外一个称为SGID的权限，不过它描述的是用户组。也就是说，一个可执行文件一旦被设置了GUID位，么当它被一个进程通过exec加载之后，该进程的主UID就会变成该可执行文件的所有者的主UID。

Android手机root的原理：一个普通的进程通过执行su，从而获得一个具有root权限的进程。有了这个具有root权限的进程之后，就可以想干什么就干什么了。su所做的事情其实很简单，它再fork另外一个子进程来做真正的事情，也就是我们在执行su的时候，后面所跟的那些参数。由于su所运行在的进程的UID是root，因此由它fork出来的子进程的UID也是root。于是，子进程也可以想干什么就干什么了。

用来root手机的su还会配合另外一个称为superuser的app来使用。su在fork子进程来做真正的事情之前，会将superuser启动起来，询问用户是否允许fork一个UID是root的子进程。这样就可以对root权限进行控制，避免被恶意应用偷偷地使用。

在传统的UNIX以及类UNIX系统中，进程的权限只划分两种：**特权和非特权**。UID等于0的进程就是特权进程，它们可以通过一切的权限检查。UID不等于0的进程就非特权进程，它们在访问一些敏感资源或者调用一个敏感API时，需要进行权限检查。这种纯粹通过UID来做权限检查的安全机制过于粗放了。Linux在此基础之上，对进程的权限进行了细分，称为Capability。一个进程所具有Capabilities可以通过capset和prctl等系统API来设置。也就是说，当一个进程调用一个敏感的系统API时，Linux内核除了考虑它的UID之外，还会考虑它是否具有对应的Capability。


### Android基于Permission的安全机制

Android基于Permission的安全机制，也有三个角色：**apk**、**signature**和**permission**。

Android的APK经过PackageManagerService安装之后，就相当于Linux里面的User，它们都会被分配到一个UID和一个主GID。而APK所申请的Permission就相当于是Linux里面的Supplementary GID。

Android的APK都是运行在独立的应用程序进程里面的，并且这些应用程序进程都是Zygote进程fork出来的。Zygote进程又是由init进程fork出来的，并且它被init进程fork出来后，没有被setuid降权，也就是它的uid仍然是root。应用程序进程被Zygote进程fork出来的时候，它的UID也应当是root。但是，它们的UID会被setuid修改为所加载的APK被分配的UID。

Signature有两个作用：1.控制哪些APK可以共享同一个UID；2.控制哪些APK可以申请哪些Permission；

如果要让两个APK共享同一个UID，那么就需要在AndroidManifest中配置android:sharedUserId属性。PackageManagerService在安装APK的时候，如果发现两个APK具有相同的android:sharedUserId属性，那么它们就会被分配到相同的UID。当然这有一个前提，就是这两个APK必须具有相同的Signature。这很重要，否则的话，如果我知道别人的APK设置了android:sharedUserId属性，那么我也在自己的APK中设置相同的android:sharedUserId属性，就可以去访问别人APK的数据了。

有些Permission，例如INSTALL_PACKAGE，不是谁都可以申请的，必须要具有系统签名才可以，这样就可以控制Suppementary GID的分配，从而控制应用程序进程的权限。

了解了Android的Permission机制之后，我们就可以知道：

1. Android的APK就相当于是Linux的UID；
2. Android的Permission就相当于是Linux的GID；
3. Android的Signature就是用来控制APK的UID和GID分配的；

这就是Android基于Permission的安全机制与Linux基于UID/GID的安全机制的关系。

[从NDK在非Root手机上的调试原理探讨Android的安全机制](http://blog.csdn.net/luoshengyang/article/details/17131835)






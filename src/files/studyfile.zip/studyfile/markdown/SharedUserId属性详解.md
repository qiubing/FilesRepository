## SharedUserId属性详解

### userid的概念
Android会给每个APK进程分配一个单独的空间，manifest中的userid就是对应一个分配给Linux用户的ID，并且为它创建一个沙箱，以防止影响其他程序（或者其他程序影响它）。userid在应用程序安装时被分配，并且在这个设备中保持它的持久性。

通常，不同的APK会具有不同的userid，因此运行在不同的进程中，而不同进程中的资源是不共享的。


**那么不同的APK之间要相互访问数据应该怎么办？**

Android为我们提供了两种数据互访的方法：

1. 使用SharedPreference/ContentProvider；

APK通过指定的接口和数据供其他APK读取，开发者需要实现接口和指定的shared数据。

2. 在配置文件manifest中配置相同的userid；

通过sharedUserId，具有相同的userid可以配置成运行在同一个进程中，因此默认是可以相互访问**任意数据**；也可以配置成运行在不同的进程中，可以访问其他APK的数据目录下的**数据库和文件**，就像访问本程序的数据一样。


需要注意的是出于安全考虑，具有相同的SharedUserId需要有相同的签名，否则程序是安装不上去的。如果要想在不同APK之间通过SharedUserId共享数据，需要满足以下条件：

1. APK的签名必须相同；
2. android:sharedUserId值必须相同；
3. 如果想要运行在同一个进程中，android:process的值必须相同；

APK的签名是通过在Android.mk文件中配置LOCAL_CERTIFICATE属性来定义的，**只有具有相同的签名和相同的SharedUserId标签的两个应用程序才会被分配相同的用户ID。**


**举例来说：**

系统中所有使用android.uid.system作为共享的UID的APK，都会首先在manifest节点中增加android:sharedUserId="android.uid.system"，然后在Android.mk中增加LOCAL_CERTIFICATE := platform。可以参见Settings，Telecom等。

系统中所有使用android.uid.shared作为共享UID的APK，都会在manifest节点中增加android:sharedUserId="android.uid.shared"，然后在Android.mk中增加LOCAL_CERTIFICATE := shared。可以参见Launcher等。

系统中所有使用android.media作为共享UID的APK，都会在manifest节点中增加android:sharedUserId="android.media"，然后在Android.mk中增加LOCAL_CERTIFICATE := media。可以参见Gallery等。

**关于签名**

在build/target/product/security目录中有四组默认签名供Android.mk在编译APK使用：

- testkey：普通APK，默认情况下使用。
- platform：该APK完成一些系统的核心功能。经过对系统中存在的文件夹的访问测试，这种方式编译出来的APK所在进程的UID为system。
- shared：该APK需要和home/contacts进程共享数据。
- media：该APK是media/download系统中的一环。

应用程序的Android.mk中有一个LOCAL_CERTIFICATE字段，由它指定用哪个key签名，未指定的默认用testkey。


参考文章：[Android权限之sharedUserId和签名](http://blog.csdn.net/hmg25/article/details/6447067)


## Strict Mode严格模式
[TOC]

严格模式是Android 2.3开始，基于代码审视的调试方法。目的是**帮助应用开发者找出执行流程中可能产生性能/安全/内存问题的行为**。

### 严格模式的监控策略

严格模式分为以下两种策略

- 线程监控策略（Thread Policy）：抓出可能造成长时间执行的存取行为。如磁盘的读写，数据库存取（同磁盘读写），主要应用在主线程上的监控。
- VM虚拟机监控策略（VMPolicy）：抓出可能造成内存泄漏的代码。

利用线程监控策略找出在主线程上的磁盘读写，通过**避免磁盘读写**改善手机卡顿问题。

**为何主线程上的磁盘读写会产生手机卡顿问题？**

- 不像处理器，磁盘的并发处理速度慢。当短时间多个应用同时进行磁盘读写，读写速度将明显加长，甚至达“秒级”。
- 手机长期使用后，不但存量变少且磁盘碎片化问题严重。过低的磁盘存量或碎片化将大幅降低磁盘读写速度。

**严格模式有哪些好处？**

- 减缓手机越用越慢或是突然卡顿的问题。
- 提升应用启动时间及减少ANR发生的概率。举例来说，数据库存取时间过长会连带拉长应用启动时间。
- 严格模式能查出跨进程通讯而产生的磁盘读写，远比以代码评审来的有效率。

### 如何使用严格模式？

1. 安装在/data分区且非系统应用更新之应用在Activity.onCreate()或Application.onCreate()中加入使能线程监控策略的代码。以下是范例：

	
		public class FooActivity extends Activity{
		
			...
		
			public void onCreate(){
				StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()

											.detectDiskReads()
											.detectDiskWrites()
											.detectNetwork()
											.penaltyLog()
											.penaltyFlashScreen()
											.build());
				super.onCreate();
			}
		}

deleteDiskReads表示要监控磁盘读操作，而deleteDiskWrites表示要监控磁盘写操作，deleteNetwork表示要监控网络问题。penaltyLog()表示发生严格模式问题时，要打印日志，penaltyFlashScreen表示发生严格模式问题时，闪红框。



2. 对于安装在/system/app下或其在/data/app下更新的系统应用，请在开发者选项中开启严格模式。

注意：建议设定完严格模式后，要重新开机，确保所有系统应用开启严格模式。


### 严格模式日志

严格模式问题的日志样式

- duration：严格模式造成的时间延迟。
- 可由堆栈第一个项判断严格模式问题种类
- 每一个严格模式问题都会对应一个堆栈。
- 在堆栈中出现“#via Binder call with stack”字样表示该问题为跨进程调用。

### 严格模式问题
存在的严格模式问题的类型：

1. 来自应用自行触发的磁盘存取；
2. 使用SharedPreference读写资料；
3. 系统级应用发送非保护性广播(protected broadcast),触发system server写入Dropbox
  
	系统级应用指的是persist应用或者uid为SYSTEM_UID/PHONE_UID/SHELL_UID/BLUETOOTH_UID/NFC_UID的应用
4. 磁盘读写对象是文件形式的虚拟文件


**解决办法**：

- 直接拿掉不需要的代码。

	- 已经不再维护的功能。
	- 以不需要磁盘读取的方式实现
		例如系统应用以system properties取代数据库存储资料
	
	- 假如是必要的磁盘读写，将其移动到子线程中执行。但必须注意以下子线程的设置：
		- 建议以HandlerThread或是AsyncTask，让子线程中的磁盘读取以队列方式执行。
		- AsyncTask优先级设置默认是Process.THREAD_PRIORITY_BACKGROUND。假如以默认优先级执行使用AsyncTask读取重要资料时，其将被分配到较少比例的处理器资源，而影响处理速度。建议处理重要资料时，先调整AsyncTask的优先级为Process.THREAD_PRIORITY_DEFAULT。
		- 数据库存取可考虑利用AsyncQueryHandler简化子线程存取数据库操作。AsyncQueryHandler的默认优先级已设置为Process.THREAD_PRIORITY_DEFAULT。
		- 非必要的话，避免直接产生新线程类（new Thread()）来执行磁盘存取，这方法容易造成线程泄漏错误。

**SharedPreference**

- SharedPreference的架构中需要写入对应的XML文件于应用的文件夹以保存其内容，也因此产生磁盘存取于执行线程中。

	- 解决办法：使用SharedPreferences.Editor.apply()取代SharedPreferences.Editor.commit()以避免在主线程上读取磁盘。
		- Android提供SharedPreferences.Editor.apply()与SharedPreferences.Editor.commit()作为写入对应的XML文件的接口。不同的是commit()直接产生磁盘存取于执行的线程中。 apply()则产生子线程来执行磁盘存取。
		- commit()执行于的主线程便会产生严格模式问题。

- 执行SharedPreferences取值 (例如SharedPreference.getInt())时，也可能对应的XML尚未载入完成，而产生磁盘读取的严格模式问题。
	
	- 解决办法：为避免载入的磁盘读取发生在主线程，请利用子线程执行SharedPreferences取值
	
**保护性广播**

- Android认为有一些广播只能由系统发送的，并且提供了<protected-broadcast>标记让系统级应用在AndroidManifest.xml明确宣告。在系统运作起来之后，如果某个**普通应用**不具有系统权限的应用试图发送“保护性广播” ，AMS会抛出异常，提示"Permission Denial: not allowed to send broadcast"。
 - 系统级应用指的是Persistent应用或user id为SYSTEM_UID/PHONE_UID/SHELL_UID/BLUETOOTH_UID/NFC_UID的应用。
 
- 反之，**系统级应用**发出的broadcast必须宣告成”保护性广播”，否则会触发system server记录WTF时间而产生写入dropbox的磁盘存取。

- 解决办法：将所用代码中会发出的广播名字符串，在应用的AndroidManifest.xml明确宣告成保护性广播。

	<protected-broadcast android:name="android.intent.action.SHOW_MISSED_CALLS_NOTIFICATION" />

### 广义严格模式问题

- 严格模式关注的问题本质上在主线程上执行时间过长，便会让使用者感到卡顿，甚至产生ANR。这也是但影响因素是多面向的，不仅有不当的磁盘存取问题。

- 应用每个动作执行时间的长度都可能影响应用响应时间，进而让使用者感到卡顿。我们可以从以下的事件日志(event log)中，审视可能的长执行时间发生点。随后的我们将一一介绍其日志样式与对应方法。

	- 界面启动时间 **am_activity_launch_time**
	- 数据库查询时间 **content_query_sample**
	  
		与严格模式互为对照，确认应用执行的数据库存取
	- 数据库内容更新时间 **content_update_sample**
	 
		与严格模式互为对照，确认应用执行的数据库存取
	- 跨进程通讯执行时间 **binder_sample**
	- 线程被锁定时时间 **dvm_lock_sample**

- 打印事件日志
 adb logcat -b events


**卡顿的影响因素**：

![卡顿影响因素](https://ooo.0o0.ooo/2017/06/30/595639b67cf21.png)

1. 界面启动时间： am_activity_launch_time
	- 界面启动时间过长，不仅使用者会感到卡顿，严重会导致Key Dispatch Timeout ANR。
	- 对应方法：在一般功能性测试中，需在800ms内完成。
		- 优化在主线程的长执行时间的代码
		- 将磁盘读写移到子线程
		- 若需要做跨进程通讯，移到子线程。


2. 数据库查询时间 ： content_query_sample
	- 对应方法
		- 将在主线程上的数据库查询，移至子线程。
		- 若是该数据库查询结果将显示给使用者，则在子线程上的数据库查询建议少于1000ms
		- 若是该数据库查询仅供后台之用，则在子线程上的数据库查询也因少于2000ms，以避免其他应用被数据库同步锁延迟过久。
		
3. 数据库内容更新时间 ： content_update_sample 
	- 更新指令有：insert / bulkinsert / delete / update
	- 对应方法
		- 若是该数据库查询结果将显示给使用者，则在子线程上的数据库查询建议少于1000ms
		- 若是该数据库查询仅供后台之用，则在子线程上的数据库查询也因少于2000ms，以避免其他应用被数据库同步锁延迟过久。
		- 将在主线程上的数据库查询，移至子线程。
		- 其他执行流程上的优化。

4. 跨进程通讯执行时间 binder_sample
	- 跨进程通讯执行时间计算始自客户端执行接口，终于客户端收到服务端回复
	- 对应方法
		- 优化在客户端的长执行时间的代码。例如磁盘读写，缩短执行流程等。
		- 优化空间有限的跨进程通讯，避免在主线程执行。

5. 同步锁锁定时间 ： dvm_lock_sample
	- 对应方法
		- 审查同步锁的必要性，拿掉不需要的同步锁。假如是必要的，优化执行同步锁子线程需要持续抓住同步锁的时间。建议不超过50ms。
















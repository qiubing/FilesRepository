## SurfaceFlinger服务概述


**SurfaceFlinger服务运行在Android系统的System进程中，它负责管理Android系统的帧缓冲区(Frame Buffer)**。Android应用程序为了能够将自己的UI绘制在系统的帧缓冲区上，它们必须要与SurfaceFlinger服务进行通信。

![Android应用程序与SurfaceFlinger服务的关系](http://my.csdn.net/uploads/201208/11/1344636393_8412.jpg)

Android应用程序与SurfaceFlinger服务是运行在不同的进程中的，它们采用**Binder进程间通信机制**来进行通信。

每一个Android应用程序与SurfaceFlinger服务都有一个连接，这个连接是通过一个类型为Client的Binder对象来描述的。这些Client对象是Android应用程序连接到SurfaceFlinger服务的时候由SurfaceFlinger服务创建的，而当Android应用程序成功连接到SurfaceFlinger服务之后，就可以获得一个对应的Client对象的Binder代理接口了。有了这些Binder代理接口之后，Android应用程序就可以通知SurfaceFlinger服务来绘制自己的UI了。

Android应用程序在通知SurfaceFlinger服务来绘制自己的UI的时候，需要将UI元数据传递给SurfaceFlinger服务，例如绘制UI的区域、位置等信息。一个Android应用程序可能会有很多个窗口，而每一个窗口都有自己的UI元数据，因此，Android应用程序需要传递给SurfaceFlinger服务的UI元数据是相当可观的。在这种情况下，通过Binder进程间通信机制来在Android应用程序与SurfaceFlinger服务之间传递UI元数据是不合适的，这时候Android系统的**匿名共享内存机制（Anonymous Shared Memory）**就派上用场了。

Android应用程序采用**Binder机制通知**SurfaceFlinger服务来绘制自己的UI，采用**匿名共享内存机制**来**传递需要绘制的UI元数据**。

![](http://my.csdn.net/uploads/201208/11/1344638220_6419.jpg)

但是Android应用程序与SurfaceFlinger服务之间不会直接使用**原生的匿名共享内存块**，而是使用**结构化的匿名共享内存块**SharedClient。

![结构化后的用来传递UI元数据的匿名共享内存块](http://my.csdn.net/uploads/201208/11/1344639130_1845.jpg)

SharedClient的定义如下：

![用来描述Android应用程序的UI元数据的SharedClient](http://my.csdn.net/uploads/201208/11/1344639472_1989.jpg)

在每一个SharedClient里面，有至多**31**个SharedBufferStack。字面上来看，SharedBufferStack就是**共享缓冲区堆栈**。首先，**Shared表明这个堆栈共享的**。那么由谁来共享呢？当然就是Android应用程序和SurfaceFlinger服务了。其次，**Buffer表明这个堆栈的内容是缓冲区**。什么样的缓冲区呢？当然就是用来描述UI元数据的缓冲区了。再者，**Stack表明用来描述UI元数据的缓冲区是需要按照一定的规则来访问的**。综合起来，我们就可以认为每一个SharedBufferStack就是**用来描述一系列需要按照一定规则来访问的缓冲区**。

在Android 2.3以前，采用的是**双缓冲技术**。双缓冲意味着要使用两个缓冲区，其中一个称为Front Buffer，另外一个称为Back Buffer。UI总是先在Back Buffer中绘制，然后再和Front Buffer交换，渲染到显示设备中。在Android 4.1之后，采用的是**三缓冲技术**。

在SurfaceFlinger服务中，**每一个SharedBufferStack都对应一个Surface**，即一个窗口。这样，我们就可以知道为什么每一个SharedClient里面包含的是一系列SharedBufferStack而不是单个SharedBufferStack：一个SharedClient对应一个Android应用程序，而一个Android应用程序可能包含有多个窗口，即Surface。从这里也可以看出，一个Android应用程序至多可以包含31个Surface。

![SharedBufferStack的结构示意图](http://my.csdn.net/uploads/201208/11/1344640651_6649.jpg)

为了方便描述，我们假设图中的SharedBufferStack有5个Buffer，其中，Buffer-1和Buffer-2是已经使用了的，而Buffer-3、Buffer-4和Buffer-5是空闲的。指针head和tail分别指向空闲缓冲区列表的头部和尾部，而指针queue_head指向已经使用了的缓冲区列表的头部。从这里就可以看出，从指针tail到head之间的Buffer即为空闲缓冲区表，而从指针head到queue_head之间的Buffer即为已经使用了的缓冲区列表。注意，图中的5个Buffer是循环使用的。

SharedBufferStack中的缓冲区只是用来描述UI元数据的，这意味着它们不包含真正的UI数据,真正的UI数据保存在GraphicBuffer中。因此，为了完整地描述一个UI，SharedBufferStack中的每一个已经使用了的缓冲区都对应有一个GraphicBuffer，用来描述真正的UI数据。当SurfaceFlinger服务缓制Buffer-1和Buffer-2的时候，就会找到与它们所对应的GraphicBuffer，这样就可以将对应的UI绘制出来了。

当Android应用程序需要更新一个Surface的时候，它就会找到与它所对应的SharedBufferStack，并且从它的空闲缓冲区列表的尾部取出一个空闲的Buffer。我们假设这个取出来的空闲Buffer的编号为index。接下来Android应用程序就请求SurfaceFlinger服务为这个编号为index的Buffer分配一个图形缓冲区GraphicBuffer。SurfaceFlinger服务分配好图形缓冲区GraphicBuffer之后，会将它的编号设置为index，然后再将这个图形缓冲区GraphicBuffer返回给Android应用程序访问。Android应用程序得到了SurfaceFlinger服务返回的图形缓冲区GraphicBuffer之后，就在里面写入UI数据。写完之后，就将与它所对应的缓冲区，即编号为index的Buffer，插入到对应的SharedBufferStack的已经使用了的缓冲区列表的头部去。这一步完成了之后，Android应用程序就通知SurfaceFlinger服务去绘制那些保存在已经使用了的缓冲区所描述的图形缓冲区GraphicBuffer了。用图5的例子来说，SurfaceFlinger服务需要绘制的是编号为1和2的Buffer所对应的图形缓冲区GraphicBuffer。由于SurfaceFlinger服务知道编号为1和2的Buffer所对应的图形缓冲区GraphicBuffer在哪里，因此，Android应用程序只需要告诉SurfaceFlinger服务要绘制的Buffer的编号就OK了。当一个已经被使用了的Buffer被绘制了之后，它就重新变成一个空闲的Buffer了。

**SharedBufferStack是在Android应用程序和SurfaceFlinger服务之间共享的**，但是，Android应用程序和SurfaceFlinger服务使用SharedBufferStack的方式是不一样的，具体来说，就是**Android应用程序关心的是它里面的空闲缓冲区列表**，而**SurfaceFlinger服务关心的是它里面的已经使用了的缓冲区列表**。从SurfaceFlinger服务的角度来看，**保存在SharedBufferStack中的已经使用了的缓冲区其实就是在排队等待渲染**。

为了方便SharedBufferStack在Android应用程序和SurfaceFlinger服务中的访问，Android系统分别使用**SharedBufferClient**和**SharedBufferServer**来描述SharedBufferStack，其中，**SharedBufferClient用来在Android应用程序这一侧访问SharedBufferStack的空闲缓冲区列表，而SharedBufferServer用来在SurfaceFlinger服务这一侧访问SharedBufferStack的排队缓冲区列表**。

![图形缓冲区Graphic的结构示意图](http://my.csdn.net/uploads/201208/11/1344643974_9844.jpg)

每一个GraphicBuffer内部都包含有一块用来保存UI数据的缓冲区，这块缓冲区使用一个buffer_handle_t对象来描述。由HAL层的Gralloc模块分配的图形缓冲区的是**使用一个buffer_handle_t对象**来描述的，而由buffer_handle_t对象所描述的图形缓冲区要么是在系统帧缓冲区（Frame Buffer）或者匿名共享内存（Anonymous Shared Memory）中分配的。



后续文章：

1.[Android应用程序与SurfaceFlinger服务的连接过程分析](http://blog.csdn.net/luoshengyang/article/details/7857163)



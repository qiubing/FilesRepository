## Systrace文件分析

### 简介
Systrace是Android4.1中新增的性能数据采样和分析工具。它可帮助开发者收集Android关键子系统（如surfaceflinger、WindowManagerService等Framework部分关键模块、服务，View系统等）的运行信息，从而帮助开发者更直观的分析系统瓶颈，改进性能。

Systrace的功能包括跟踪**系统的I/O操作**、**内核工作队列**、**CPU负载以及Android各个子系统**的运行状况等。在Android平台中，它主要由3部分组成：

- **内核部分**：Systrace利用了Linux Kernel中的**ftrace功能**。所以，如果要使用Systrace的话，必须开启kernel中和ftrace相关的模块。


- **数据采集部分**：Android定义了一个**Trace类**。应用程序可利用该类把统计信息输出给ftrace。同时，Android还有一个atrace程序，它可以从ftrace中读取统计信息然后交给数据分析工具来处理。


- **数据分析工具**：Android提供一个systrace.py（python脚本文件，位于Android SDK目录/tools/systrace中，其内部将调用atrace程序）用来配置数据采集的方式（如采集数据的标签、输出文件名等）和收集ftrace统计数据并生成一个结果网页文件供用户查看。 从本质上说，**Systrace是对Linux Kernel中ftrace的封装**。应用进程需要利用Android提供的Trace类来使用Systrace.


### Systrace使用方法
你可以通过Python systrace.py -h 来查看systrace 的使用帮助

**Usage:** systrace.py [options] [category1 [category2 ...]]

**Example:** systrace.py -b 32768 -t 15 gfx input view sched freq

	Options:
  	-h, --help            show this help message and exit
  	
	-o FILE               write HTML to FILE
 	
	-t N, --time=N        trace for N seconds
  	
	-b N, --buf-size=N    use a trace buffer size of N KB
  	
	-k KFUNCS, --ktrace=KFUNCS specify a comma-separated list of kernel functions to trace
  	
	-l, --list-categories list the available categories and exit
  	
	-a APP_NAME, --app=APP_NAME enable application-level tracing for comma-separated list of app cmdlines
 	
	--link-assets   link to original CSS or js resources instead of embedding them
  	
	--from-file=FROM_FILE read the trace from a file (compressed) rather than	running a live trace
  	
	--asset-dir=ASSET_DIR
  	
	-e DEVICE_SERIAL, --serial=DEVICE_SERIAL adb device serial number

生成的trace 文件 需要Chrome 来打开。


### 如何在代码中添加trace

Systrace并不会追踪应用的所有工作，所以你可以在有需求的情况下自己添加要追踪的代码部分。在Android 4.3及以上的代码中，你可以通过 Trace 类来实现这个功能。它能够让你在任何时候跟踪应用的一举一动。在你获取trace的过程中， **Trace.beginSection()**与**Trace.endSection()** 之间代码工作会一直被追踪。

举个例子来说：

	public void ProcessPeople() {
    Trace.beginSection("ProcessPeople");
    try {
        Trace.beginSection("Processing Jane");
        try {
           // 待追踪的代码
        } finally {
            Trace.endSection(); // 结束 "Processing Jane"
        }

        Trace.beginSection("Processing John");
        try {
            // 待追踪的代码
        } finally {
            Trace.endSection(); // 结束 "Processing John"
        }
    } finally {
        Trace.endSection(); // 结束 "ProcessPeople"
    }
	}

注意：在Trace是被嵌套在另一个Trace中的时候， endSection() 方法只会结束理它最近的一个 beginSection(String) 。即在一个Trace的过程中是无法中断其他Trace的。所以你要保证 endSection() 与 beginSection(String) 调用次数匹配。

注意：Trace的begin与end必须在同一线程之中执行！

### 分析Trace报告

参考文章: [使用Systrace分析UI性能](http://www.tuicool.com/articles/jMfiUjj)
#### 监视帧数

#### 调查警告事件




	

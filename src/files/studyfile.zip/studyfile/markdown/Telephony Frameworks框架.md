## Telephony Framework框架
Telephony Frameworks主要涉及Frameworks框架层中的以下三部分：

- **Call**：手机通话
- **ServiceState**：服务状态
- **DataConnection**：手机数据连接上网

通话功能运行框架在Telephony Framework层主要涉及GSMPhone、GSMCall、GSMCallTracker这几个关键类。

### 1.1 Telephony Framework层解析
Telephony Framework层中通话功能涉及的关键类为：

- GSMPhone.java
- GSMCallTracker.java
- GSMCall.java
- GSMConnection.java
- TelephonyManager.java
- ITelephonyRegistry.java

Telephony层的代码主要在framework/opt/telephony/目录下。

### 1.2 通话功能关键类
Telephony Frameworks层中通话功能相关代码的关键类图如下：
![通话功能关键类](https://ooo.0o0.ooo/2017/06/24/594dfec6245ca.jpg)

如上图所示，以**GSMCallTracker**为核心，其他三个关键类为：**Phone、Call、Connection**。

在com.android.internal.telephony.gsm包路径下分别继承和实现这些接口或抽象类，他们分别是CallTracker、GSMPhone、GsmCall和GsmConnection类。

三种枚举类型**DriverCall.State**、**Call.State**和**PhoneConstants.State**，这些状态能完整体现Telephony Frameworks层中涉及的所有通话状态。

### 1.3 Telephony通信能力模型

Telephony Frameworks层中抽象并实现了以Phone接口为核心的对象模型。**Phone对象是一个自定义的Handler消息处理对象，主要包含三方面的通信管理能力：Call手机通话、ServiceState服务状态和DataConnection手机上网。**

**Phone对象提供了运行和管理手机通信能力的程序框架**。**Call手机通话、ServiceState服务状态和DataConnection手机上网**这三个主要的通信能力，Phone对象将他们分别交给了三个不同的Tracker对象具体负责实施和管理，其对应关系详情如下：

- **CallTracker**: 负责手机通话能力的管理；
- **ServiceStateTracker**： 负责服务状态的管理；
- **DataConnectionTracker**： 负责手机上网能力的管理；

通过分析这三个Tracker机制，可以抽象出Android Telephony通信能力的基本模型：

![通信能力模型](https://ooo.0o0.ooo/2017/06/24/594e089c7c977.jpg)

### 1.4 GSMPhone对象详解

GSMPhone对象的主要作用有以下几个方面：

- 获取当前手机通话状态：IDLE、RINGING、OFFHOOK。
- 获取一些参数，如系统参数、Phone对象类型等；
- 获取不同的Call对象，如phone.getRingingCall、phone.getForegroundCall和Phone.getBackgroundCall。

#### 1.4.1 GSMPhone类层次继承关系

Telephony Frameworks中将现实生活中的手机通信相关的应用模型抽象为**Phone对象**，所有相关通信能力都围绕它来工作和运转，Phone对象的属性和方法分别体现手机在**通信过程中的状态**和**具体的通信控制能力**。

- **通信过程中的状态**：比如getForegroundCall方法，得到第一路通话Call对象，此对象保存着当前第一路通话的所有状态和信息；getState方法可获得电话的当前状态。
- **通信能力**：比如dial、acceptCall、rejectCall等方法，说明Phone对象具有通话管理和控制的能力。

Phone对象在Telephony Framework框架层中有着重要的作用，它的类层次和继承关系如下：

![Phone对象类层次图](https://ooo.0o0.ooo/2017/06/24/594e0d9535f61.jpg)


如图所示，共有三层的继承关系，从上到下分别为：Phone接口定义、PhoneBase抽象类、GSMPhone类或者CDMAPhone类。

IMEI：International Mobile Station Equipment Identity,国际移动设备身份码，一个移动终端有一个全球唯一的IMEI串号。


#### 1.4.2 PhoneFactory工厂方法实现类

PhoneFactory类采用工厂方法设计模式，用来创建基本的Phone对象。PhoneFactory有一个静态类方法makeDefaultPhones方法来创建Phone对象。其代码如下：

	PhoneFactory.makeDefaultPhones(this);
进入PhoneFactory类中的makeDefaultPhones方法，它接着会调用当前类的makeDefaultPhone方法，具体完成Phone对象的创建。

PhoneFactory工厂类创建完Phone对象后，返回的是PhoneProxy代理对象。PhoneProxy对象的构造方法如下：

	public PhoneProxy(PhoneBase phone){
		mActivePhone = phone;
		mCommandsInterface = ((PhoneBase)mActivePhone).mCi;
		mPhoneId = phone.getPhoneId();
		....
	}

	public PhoneConstans.State getState(){
		return mActivePhone.getState();
	}

在PhoneApp类中的onCreate方法，其中对Phone对象的处理逻辑如下：
	
	PhoneFactory.makeDefaultPhones(this);
	phone = PhoneFactory.getDefaultPhone();//PhoneFactory返回的是PhoneProxy对象。

Phone应用中获取的对象是PhoneProxy对象，即GSMPhone或CDMAPhone对象的代理对象，并不会直接保存GSMPhone或CDMAPhone对象的引用。为什么要这样做呢？

从PhoneProxy类的构造方法可以看到，在PhoneProxy类的构造方法中将创建GSMPhone对象，并设置为mActivePhone属性。在PhoneProxy实现PhoneBase抽象类中的所有抽象方法，这些方法的实现逻辑均通过mActivePhone对象调用对应的方法完成。

使用PhoneProxy代理模式的原因有以下两点：

- Phone应用中不能直接获取GSMPhone或CDMAPhone对象，只能获取Phone的代理类PhoneProxy对象，间接地访问Phone对象的属性和方法，增加了GSMPhone或CDMAPhone对象访问的**安全性**。
- Phone实际的对象不论是GSMPhone还是CDMAPhone对象，都能通过PhoneFactory代理对象正常访问其实际对象的属性和方法，向上屏蔽了底层的具体实现细节。

需要注意的是，**RIL和PhoneNotifier对象**的创建在PhoneFactory中完成，GSMPhone的构造方法将这两个对象的引用传递给PhoneBase，进程mCM和mNotifier属性的初始化。


GSMPhone类，其父类是PhoneBase抽象类，**它不仅实现了Phone接口，并且继承了Handler类**，说明了它是一个自定义的Handler消息处理类。


#### 1.4.3 GSMPhone类通话管理实现机制

在GSMPhone对象中，有关Call通话功能的实现机制，主要体现在以下两个方面：

- 负责通话状态的管理；
- 提供通话控制的能力；

GSMPhone对象对通话状态的管理以及通话控制能力都是通过GSMCallTracker来实现的，例如获取Call对象，实际获取的mCT的Call对象相关属性：foregroundCall、backgroundCall、ringingCall，这些**Call对象保存着通话状态及通话连接的基本信息**。

### 1.5 CallTracker运行机制

**GSMPhone对象将通话能力交给GSMCallTracker管理和维护**，主要完成以下两个方面的处理逻辑：

- 通话状态的管理；
- 提供对手机通话控制的能力；

CallTracker抽象类是一个自定义的Handler消息处理类，CallTracker抽象类有两个子类：CdmaCallTracker和GsmCallTracker，分别完成CDMA和GSM手机网络制式的通话能力管理和控制的处理逻辑。

**GsmCallTracker类的关键属性**如下：

属性 | 类型 | 描述
---  | ---  | ---
pendingOperations  | int | 挂起的请求操作计数器
cm | CommandsInterface | RIL对象
connections[] | GsmConnection[7] | GsmConnection对象列表，最大支持7个电话连接
pendingMO | GSMConnection | 保存主动呼叫时创建的GsmConnection对象
ringingCall | GsmCall | 接收到新来电请求的Call对象
foregroundCall | GsmCall | 第一路通话Call对象
backgroundCall | GsmCall | 第二路通话Call对象
phone | GSMPhone | GSMPhone对象
state | PhoneConstants.State | 手机状态

需要注意的是：**connections[]最多可以保持7个GSMConnection和12个IMS SRVCC。**


**GSMCallTracker关键方法如下：**
	
![GSMCallTracker关键方法](https://ooo.0o0.ooo/2017/06/24/594e1f3d27e68.jpg)

需要注意的是operationComplete方法与pollCallsWhenSafe方法的处理逻辑相同，都是向RIL对象查询当前CallList列表，最后都是由handlePollCalls方法来处理查询CallList列表。

#### 1.5.1 GsmCallTracker与RIL对象的交互机制

GSMCallTracker与RIL对象的交互完成了**通话的控制，以及通话状态和通话基本信息的保存、更新**，在Telephony Frameworks层中非常重要和关键。通过这两个对象谁主动发起交互请求，它们之间的交互方式可分为两大类：

- CallTracker对象主动发起；
- CallTracker对象被动接收；

**1.主动发起请求**

在CallTracker对象中发起dial、acceptCall、rejectCall等通话管理和控制请求方法调用时，会调用RIL对象中对应的通话管理和控制方法。

	void acceptCall(){
		if(mRingingCall.getState() == GsmCall.State.INCOMING){
			setMute(false);
			mCi.acceptCall(obtainCompleteMessage());
		}
	}
	
	private Message obtainCompleteMessage(){
		return obtainCompleteMessage(EVENT_OPERATION_COMPLETE);
	}

RIL层处理完CallTracker对象发出的通话管理和控制请求后，在RIL Java对象中使用Message消息对象发出Handler消息通知，CallTracker对象中的handleMessage方法接收和响应此消息，至此，完成了第一次的Handler消息回调的处理。

	public void handleMessage(Message msg){
		case EVENT_OPERATION_COMPLETE:
			ar = (AsyncResult)msg.obj;
			operationComplete();
		break;
	}

接着，CallTracker对象会进行第二次的Handler消息回调处理流程，继续调用operationComplete方法，查询当前最新的CallList列表，代码详情如下：

	private void operationComplete(){
		mPendingOperations--;//等待操作数量减1
		if（mPendingOperations == 0 && mNeedsPoll）{
			mLastRelevantPoll = obtainMessage(EVENT_POLL_CALLS_RESULT)；
			mCi.getCurrentCalls(mLastRelevantPoll)；
		}
	}

RIL层处理完CallTracker对象发出查询当前Call List列表后，在RIL java对象中使用Message消息对象发出Handler消息通知，CallTracker对象中的handleMessage方法接收和响应此消息，至此，完成了第二次的Handler消息回调的处理。

CallTracker对象主动向RIL对象发起通话管理和控制的交互，包括两次Handler消息回调的处理过程，详情如下：

![CallTracker主动向RIL对象发起通话请求过程](https://ooo.0o0.ooo/2017/06/24/594e26b8da400.jpg)


需要注意的是：RIL对象中的通话管理和控制方法都采用了**异步方式**的处理机制，RIL层中异步处理通话管理和控制，RIL对象的方法调用将得到立即的返回。


**2.RIL主动发起的通话状态变化到CallTracker**

RIL主动发起的通话状态变化到CallTracker的过程如下：
![RIL主动发起的通话状态变化到CallTracker](https://ooo.0o0.ooo/2017/06/24/594e28f7db3ee.jpg)

1. 手机在启动过程中会创建GSMCallTracker对象，同时此对象会向RIL对象注册EVENT_CALL_STATE_CHANGE等三个类型的的Handler消息。
2. RIL层接收到BP Modem发出的通话状态变化消息RIL_UNSOL_RESPONSE_CALL_STATE_CHANGED时，会向CallTracker对象发出EVENT_CALL_STATE_CHANGE类型的Handler消息通知，注意这两个消息类型在RIL层中得到了转换。
3. CallTracker对象在handleMessage方法中接收并处理EVENT_CALL_STATE_CHANGE消息，最终会调用pollCallsWhenSafe方法。
4. pollCallsWhenSafe方法，首先会生成EVENT_POLL_CALLS_RESULT类型的Handler消息对象，接着使用此对象作为参数调用cm.getCurrentCalls方法，即向RIL对象发出查询最新Call List列表的消息。
5. RIL层与Modem交互，完成查询最新Call List列表后，最后由RIL Java对象向CallTracker对象发起查询CallList完成的EVENT_POLL_CALLS_RESULT消息通知。
6. CallTracker对象进入hanldeMessage方法，处理EVENT_POLL_CALLS_RESULT消息，最终交给hanldePollCalls方法处理。

**注意**： CallTracker对象与RIL对象之间的交互方式不论采用了什么样的形式，所有的问题和处理逻辑都汇总到了HandlePollCalls方法。**它根据RIL对象返回的Call List列表，更新通话状态并且发出相关的消息通知。**


### 1.6 以GSMCall为核心的通话管理模型

GSMCallTracker类中共有三个GsmCall对象，分别代表三路通话：foregroundCall和backgroundCall代表第一路通话和第二路通话,而ringingCall代表来电通话。因此，**Phone应用实际最多支持三路通话，在每一路通话中可以包含多个通话连接。**

GSMCallTracker获取GSMCall对象的主要目的有两个：

- 获取**GsmCall.State**，它保存当前这一路通话的最新状态；
- 获取**GsmCall.connections**，它保存当前这一路通话中包含的每一个通话连接的基本信息。

在创建GSMCallTracker对象时，同步创建了三个GsmCall对象，这三个对象分别代表了三路通话。**每个GsmCall对象都有独立的state状态和connections通话连接对象列表**。以GSMCall为核心的通话模型主要集中在GSMCall、GsmConnection和DriverCall这三个关键类，他们共同构建了Telephony Frameworks层中的通话模型；GsmConnection和DriverCall对象作为基石构建成了GsmCall对象的通话模型框架。

当DriverCall List列表中的DriverCall对象发生变化时，根据DriverCall对象的基本信息创建或更新GsmConnection对象，在此同时，会同步更新GsmConnection对象的parent属性，即更新GsmCall对象的state和connections属性，从而更新通话模型中的通话信息；因此，GsmCall对象的状态更新驱动入口是在GsmConnection对象的创建或更新的方法。

更新的顺序是：

DriverCall ——> GsmConnection ——> GsmCall

#### 1.6.1 GsmCall类的属性

GsmCall和CdmaCall类都继承于Call抽象类。GsmCall类的关键属性如下表：

属性 | 类型 | 描述
---- | ---- | ----
State | enum | 通话状态的枚举类型，在父类中定义
state | State | GsmCall对象具有state属性，它保存GsmCall对象当前的通话状态
connections | List<Connection> | 保存通话连接对象列表
owner | GsmCallTracker | 它的所有者是GsmCallTracker


GsmCall的关键方法如下：
![GsmCall关键方法](https://ooo.0o0.ooo/2017/06/24/594e3233b0a10.jpg)

![GsmCall关键方法](https://ooo.0o0.ooo/2017/06/24/594e323b2fd1d.jpg)


#### 1.6.2 GsmConnection类

Call类中涉及Connection对象，GsmConnection类CdmaConnection类都继承于Connection抽象类。

**1. GsmConnection类的属性**
GsmConnection抽象类的关键属性如下所示：

![GsmConnection类关键属性](https://ooo.0o0.ooo/2017/06/24/594e3494349c3.jpg)

**2. GsmConnection类的方法**

GsmConnection类的关键方法如下：

![GsmConnection类的关键方法](https://ooo.0o0.ooo/2017/06/24/594e355cc87d9.jpg)

**需要注意的是：**

parent属性，即GsmCall对象，说明任意一个Connection对象都属于一个Call对象；通俗来讲，任意一个通话连接都属于三路通话中的任何一路通话。

通过GsmConnection对象也可以获取当前通话状态，实现原理是，首先获取它的parent对象，然后再获取Call.State通话状态，parent对象即GsmCall对象。


**GsmCall和GsmConnection的owner都是GsmCallTracker。**


**3.GsmCall与GsmConnection的关系**

**GsmConnection作为基石，保存了通话连接的基本信息，多个GsmConnection对象组合成一路通话**；而**GsmCall作为框架，主要管理state和connections，一路通话中有多个通话连接**。


GsmCall与GsmConnection之间的关系如下：

![GsmCall和GsmConnection之间的关系](https://ooo.0o0.ooo/2017/06/24/594e378f8c386.jpg)

可以看到：

- GsmCall类中的connections属性可以保存多个GsmConnection对象；而GsmConnection对象的parent属性，则是它对应的唯一GsmCall对象。这里体现了基本的通话模型，**一路通话可以有多个通话连接**，多方通话就是一个典型的实例；任意一个通话连接都属于GsmCallTracker的三路通话中的一路通话。
- GsmCall和GsmConnection两个类的owner属性都指向GsmCallTracker对象。

**4. DriverCall与GsmCall、GsmConnection的关系**

DriverCall是**RIL类中创建的对象**，Modem执行完成CLCC命令后，返回给RIL层**固定格式的字符串**，RIL对象将这些字符串信息创建了**DriverCall对象列表，一行字符串信息可创建一个DriverCall对象**。**DriverCall对象列表**能真实反映出Modem无线通信模块中所有通话连接的真实信息。

在RIL类的responseCallList方法中会根据读取出来的字符串信息创建DriverCall列表。

**DriverCall对象与GsmConnection对象之间的关系**

在GsmConnection的构建方法中，GsmConnection对象是根据DriverCall对象的一些基本信息来创建的。在GsmConnection对象创建成功后，还能通过新的DriverCall对象更新自身的一些基本信息，他们之间的匹配是通过index下标来标识的。

关于GsmConnection类的构造方法和update更新方法中的主要处理逻辑，注意以下3点：

- GsmConnection对象的创建或是更新，其数据来源和依据是DriverCall对象。
- GsmConnection对象创建或者更新的同时，同步调用parent的更新方法来更新它所属的GsmCall对象，主要是parent.attach、parent.detach和parent.update这三个方法。
- update方法中可能会**完成parent的切换**，在parentFromDCState方法中可以找到通过DriverCall.State获取对应parent的逻辑代码。DriverCall对象的基本信息产生变化以后，由它**创建的或通过index下标关联的GsmConnection对象也会跟着调整**，这些更新和调整中，最重要的就是更新了GsmConnection对象的parent对象。我们需要关注的是在这个过程汇中，**不会创建新的GsmCall对象**，只会在GsmCallTracker对象中的三个GsmCall对象之间进行切换，其中的逻辑在parentFromDCState方法中可以体现出来。

GsmConnection对象parent取值与DriverCall状态的对应关系如下：

![GsmConnection对象parent取值与DriverCall状态的对应关系](https://ooo.0o0.ooo/2017/06/24/594e3ee163f24.jpg)


**DriverCall对象与GsmCall对象之间的关系**

GsmCall对象可以保存多个GsmConnection通话连接基本信息对象，并且在GsmConnection对象中调用其attach、detach和update三个方法更新GsmCall对象。

GsmCall类中的三个更新方法attach、detach和update，它们主要完成两方面的更新操作:

- 更新sate；
- 更新connections；

**注意：**

attch、detach和update方法更新GsmCall对象，仅在GsmConnection类中有相关方法的调用，意味着RIL层上报的DriverCall对象发送变化后，首先通过创建或更新GsmConnection对象，与此同时，同步调用GsmCall对象的更新方法，从而更新GsmCall对象的state和connections。

更新顺序是：DriverCall ——> GsmConnection ——> GsmCall ——>GsmCallTracker ——> GsmPhone

stateFromDcState方法非常重要，它的逻辑能够体现出Call.State与DriverCall.State的状态关系，其代码详情如下：

	static State stateFromDCState(DriverCall.State dcState){
		switch(dcState){
			case ACTIVE: return State.ACTIVE;
			case HOLDING: return State.HOLDING;
			case DIALING: return State.DIALING;
			case ALERTING: return State.ALERTING;
			case INCOMING: return State.INCOMING;
			case WAITING: return State.WAITING;
			default: throw new RuntimeException("illegal call State " + dcState);		
		}
	}

Call.State与DriverCall.State的枚举类型关系是一一对应的。


### 1.7 GsmCallTracker类的handlePollCalls方法处理逻辑

CallTracker对象主动发起的通话管理或是被动接收到RIL对象发起的通话状态变化的相关通知，都会调用cm.getCurrentCalls方法查询当前Call List列表，然后将查询结果交给handlePollCalls方法处理，完成CallTracker对象的更新。

因此，GsmCallTracker类中的handlePollCalls方法根据RIL类上报的CALL List对象列表，更新GsmCallTracker类的Call对象和connections通话连接列表，它主要有以下几个处理逻辑：

1. 初始化操作，获取Call List列表。
2. 更新通话相关信息，主要是CallTracker对象中的state、connections、foregroundCall、backgroundCall和ringingCall对象的更新。
3. 收尾处理，根据最新的通话状态发出通话状态消息通知。

#### 1.7.1 初始化操作

handlePollCalls方法的初始化操作最重要的是通过接收到的Message消息获取Call list对象，然后声明一些重要的变量，其代码如下：

	@Override
    protected synchronized void
    handlePollCalls(AsyncResult ar) {
        List polledCalls;//声明Call List对象，它将保存RIL查询出的当前Call对象列表

        if (ar.exception == null) {
			// 将RIL返回的消息结果对象，强制转换成List对象
            polledCalls = (List)ar.result;
        } .....

        Connection newRinging = null; //接收到新来电请求，会创建的通话连接对象
        // 除了通话连接断开的其他任何通话状态改变的标志
        boolean hasNonHangupStateChanged = false;   // Any change besides
                                                    // a dropped connection
        boolean hasAnyCallDisconnected = false;
        boolean needsPollDelay = false;//是否需要延迟查询Call List的标志
        boolean unknownConnectionAppeared = false;//是否出现未知通话连接的标志
	}

从上面代码可以看到，Call List列表对象的获取是RIL对象发给GsmCallTracker对象的Handler消息中的result，通过强制类型转换成List列表对象。


#### 1.7.2 更新通话相关信息

GsmCallTracker对象通过Handler消息获取最新的DriverCall List对象列表，紧接着遍历connections保存的通话连接对象列表，通过DriverCall List中对应的DriverCall对象，更新GsmCallTracker对象中的通话相关信息。

GsmCallTracker遍历connections列表的代码如下：

	for (int i = 0, curDC = 0, dcSize = polledCalls.size(); i < mConnections.length; i++) {//会完成19次循环处理
		GsmConnection conn = mConnections[i];//依次获取connections中的对象
        DriverCall dc = null;
  
        if (curDC < dcSize) {
			//可以确认polledCalls保存的是DriverCall对象列表
        	dc = (DriverCall) polledCalls.get(curDC);
			//DriverCall对象与connections中对象的关系，通过下标对应
        	if (dc.index == i+1) {
            	curDC++;//conn与dc对象匹配成功，获取dc对象的下标加1，下次循环则获取下一个dc对象
        	} else {
            	dc = null;//Conn与dc对象未匹配成功，则不取出dc对象待下一次获取
        	}
    	}

        if (conn == null && dc != null) {
           ......//通话状态处理
        }

在遍历connections数组的过程中，包含两个主要的处理逻辑：

**1.获取conn对象和dc对象**

conn对象与dc对象之间的对应关系是通过索引值来匹配的，当dc.index == i + 1时，则说明conn对象与dc是匹配的。conn对象与dc对象的关系是：
	dc.index == i + 1。

为什么是相差1呢？因为connections数组是下标是从0开始，而DriverCall对象的下标是从1开始，所以需要加1,这样才能满足这个关系。

因此，在遍历connections列表的过程中，只要满足dc.index == i + 1条件，当前的conn对象是由dc对象创建的，只要dc对象的一些基本信息发生了变化，conn对象也就进行相应的调整和更新。

**2.通话状态的变化**

根据conn和dc这两个对象基本信息的组合关系，可以得出4种通话状态的变化，分别是：

- **出现新的通话连接**；
- **通话连接断开**；
- **通话连接断开并且有新的来电**；
- **通话状态发生变化**；

这4个处理逻辑完全覆盖了通话状态变化的所有应用场景，下面将展开这4种通话状态变化下的处理逻辑。

1) 出现新的通话连接

条件判断

	conn == null && dc != null

老的通话连接为null，新的通话连接不为null，说明接收到新的通话连接，这样出现的场景主要在接收到新的来电请求。

	if (conn == null && dc != null) {
        if (mPendingMO != null && mPendingMO.compareTo(dc)) {
                mConnections[i] = mPendingMO;
                mPendingMO.mIndex = i;
                mPendingMO.update(dc);
                mPendingMO = null;
				//....省略挂断电话操作
		}else {
			//通过dc创建新的GsmConnection对象
            mConnections[i] = new GsmConnection(mPhone, dc, this, i);

            Connection hoConnection = getHoConnection(dc);
            if (hoConnection != null) {
                     ....
            } else if ( mConnections[i].getCall() == mRingingCall ) { 
                newRinging = mConnections[i];//非常关键，设置newRinging
                } else {
                   //....出现未知的通话连接
                }
            }
            hasNonHangupStateChanged = true;//只要出现新的通话连接，取值为true。
		}

2）通话连接断开

判断条件：

	conn != null && dc == null

老的通话连接对象已经存在，新的通话连接为空，也就是说这个通话连接已经清空，即通话连接已断开，处理逻辑详情如下：

	 else if (conn != null && dc == null) {
          mDroppedDuringPoll.add(conn);//增加老的conn对象到删除通话连接列表中
          mConnections[i] = null;//设置老的通话连接对象为null，与dc匹配

3） 通话连接断开并且有新的来电

在通话应用中，这样的情景出现的概率比较小，conn和dc都不为null，但是它们的信息并不匹配，主要体现在通话号码发生了改变，其处理逻辑详情如下：

	else if (conn != null && dc != null && !conn.compareTo(dc)) {
        // we were tracking. Assume dropped call and new call
		mDroppedDuringPoll.add(conn);//增加老的conn对象删除通话连接列表中
        mConnections[i] = new GsmConnection (mPhone, dc, this, i);

        if (mConnections[i].getCall() == mRingingCall) {
            newRinging = mConnections[i];//非常关键，设置newRinging
        } // else something strange happened
        hasNonHangupStateChanged = true;
	}

4）通话状态发生变化
	
这种情况非常多，如拨号状态变为通话中状态、通话中变为保持通话状态等，详情如下：

	} else if (conn != null && dc != null) { /* implicit 	conn.compareTo(dc) */
        boolean changed;
		//通过dc对象更新conn对象，返回通话状态是否已经更新的标志
       	changed = conn.update(dc);
		//只要通话状态已经更新，hasNonHangupStateChanged取值为true
        hasNonHangupStateChanged = hasNonHangupStateChanged || changed;
    }


回顾这四种通话状态变发生变化的判断条件及处理逻辑，他们之间的关系如下：

![conn与dc的状态组合关系](https://ooo.0o0.ooo/2017/06/24/594e5a9bdd255.jpg)

#### 1.7.3 根据最新的通话状态发出通知

收尾处理，根据最新的通话状态发出通话状态消息通知。代码如下：

	if (newRinging != null) {//如果是接收到来电请求的通话状态
        mPhone.notifyNewRingingConnection(newRinging);//通过GSMPhone对象发出收到新来电请求的通知消息
    }

	....//省略通话连接断开的逻辑处理
	
	if (newRinging != null || hasNonHangupStateChanged || 	hasAnyCallDisconnected) {
        internalClearDisconnected();//清除通话连接已断开的GsmConnection对象
    }

	updatePhoneState();//这里非常重要，同步更新Phone.State手机状态

	//非通话连接断开的情况或者接收到新的来电请求
	if (hasNonHangupStateChanged || newRinging != null || 	hasAnyCallDisconnected) {
        mPhone.notifyPreciseCallStateChanged();//发出通话状态变化的消息通知
    }

其实handlePollCalls方法中的收尾处理逻辑比较简单，完成循环connections数组，从而更新GsmCallTracker对象通话相关的信息后，根据这些更新后的通话基本信息发出通话状态变化相关消息通知。

其中最为关键的内容为：

- conn与dc对象的匹配关系，dc.index == i + 1说明conn对象是通过dc对象创建的。
- conn与dc对象的状态组合关系，这些关键组合构成了通话状态变化的所有应用场景。
- connections数组的下标与其保存的GsmConnection对象的index的对应关系，通过代码分析，其实它们是一一对应的，即connections[0]对象的index肯定也是0。

#### 1.7.4 更新手机状态

在handlePollCalls方法中，不论查询的Call List发生什么变化，或者根本没有发生变化，都会调用updatePhoneState方法更新GsmCallTracker对象的Phone.State手机状态，这样Phone.State和Call.State这两个状态保持同步。其代码详情如下：

	private void updatePhoneState() {
        PhoneConstants.State oldState = mState;
        if (mRingingCall.isRinging()) {
            mState = PhoneConstants.State.RINGING;
        } else if (mPendingMO != null ||
                !(mForegroundCall.isIdle() && mBackgroundCall.isIdle())) {
            mState = PhoneConstants.State.OFFHOOK;
        } else {
            ImsPhone imsPhone = (ImsPhone)mPhone.getImsPhone();
            if ( mState == PhoneConstants.State.OFFHOOK && (imsPhone != null)){
                imsPhone.callEndCleanupHandOverCallIfAny();
            }
            mState = PhoneConstants.State.IDLE;
        }

        if (mState == PhoneConstants.State.IDLE && oldState != mState) {
            mVoiceCallEndedRegistrants.notifyRegistrants(
                new AsyncResult(null, null, null));
        } else if (oldState == PhoneConstants.State.IDLE && oldState != mState) {
            mVoiceCallStartedRegistrants.notifyRegistrants (
                    new AsyncResult(null, null, null));
        }

        if (mState != oldState) {
            mPhone.notifyPhoneStateChanged();
        }
    }
	

Call.State和Phone.State之间的状态转换过程如下图所示:

![Call.State与Phone.State的转换](https://ooo.0o0.ooo/2017/06/24/594e602ea04e2.jpg)

可以看到，Call.State共有9个状态，Phone.State共有3个状态，Call.State状态在除了IDLE和INCOMING这两个状态以外的其他7个状态，提炼出的Phone.State状态为OFFHOOK。

最终可以总结出从DriverCall的状态到Call的状态，最后到Phone的状态的转变。
DriverCall.State ——> Call.State ——> Phone.State


### 1.8 GsmCallTracker通话连接断开的处理机制

引起通话连接断开主要分两种情况：

- 本地主动挂断电话；
- 远端断开通话连接；

#### 1.8.1 本地主动挂断通话

本地主动挂断电话有两种实现方式，通过**Call对象或Connection对象**调用hangup方法挂断电话。使用Connection对象挂断电话主要是针对多方通话和CDMA手机制式相关的挂断电话方法。

本地挂断电话时，会更新Call对象的状态为DISCONNECTING状态，这个状态在DriverCall.State中是没有定义的。同时将Call对象对应的Connection对象中的通话链接断开原因设置为DisconnectCause.LOCAL。


#### 1.8.3 远端断开通话连接的处理机制

主动挂断通话连接时会将对应的conn对象的通话断开原因设置为Local，而远端断开通话连接时，**CallTracker对象会向RIL层查询通话断开的原因**。

GsmCallTracker类是如何区分远端挂断电话的呢？

在handlePollCalls方法中，在处理完成本地主动挂断通话连接的处理逻辑后，接着会处理是否远程挂断电话的逻辑，代码详情如下：

	if (mDroppedDuringPoll.size() > 0) {
            mCi.getLastCallFailCause(//向RIL层查询最后一次通话连接断开的原因
                obtainNoPollCompleteMessage(EVENT_GET_LAST_CALL_FAIL_CAUSE));
     }
	
	case EVENT_GET_LAST_CALL_FAIL_CAUSE:
         int causeCode;//声明断开连接的原因
         String vendorCause = null;
         ar = (AsyncResult)msg.obj;//获取RIL层返回的查询结果对象
         operationComplete();//完成查询操作

         if (ar.exception != null) {
            causeCode = CallFailCause.NORMAL_CLEARING;//设置通话连接断开默认失败编号
                   
         } else {
            LastCallFailCause failCause = (LastCallFailCause)ar.result; //非常关键，获取真实的通话连接断开的原因编号
            causeCode = failCause.causeCode;
            vendorCause = failCause.vendorCause;
         }
               
        for (int i = 0, s =  mDroppedDuringPoll.size(); i < s ; i++) {
            GsmConnection conn = mDroppedDuringPoll.get(i);//获取通话连接断开的conn对象
			conn.onRemoteDisconnect(causeCode, vendorCause);//重点更新conn及parent对象
                }

            updatePhoneState();//更新Phone.State状态并发出消息通知
            mPhone.notifyPreciseCallStateChanged();//通知GSMPhone对象发出通话状态变化的消息通知
            mDroppedDuringPoll.clear();//清理DroppedDuringPoll列表
            break;

上面的代码逻辑有两个:

- 获取causeCode，作为参数调用conn.onRemoteDisconnect()方法完成通话连接断开相关信息的处理。
- 更新Phone.State并发出通话状态变化的消息通知。


conn.onRemoteDisconnect方法的处理逻辑如下：

	void onRemoteDisconnect(int causeCode){
		onDisconnect(disconnectCauseFromCode(causeCode));
	}

首先将causeCode通话断开原因编号变成DisconnectCause的枚举类型，其次，调用onDisconnect方法处理。

可以看到：无论是本地主动挂断通话连接还是远程断开通话连接，其差异在于**获取通话连接断开的原因**，最后都会调用conn.onDisconnect更新conn及parent通话相关消息。本地主动挂断电话连接，首先将对应某一路通话对象GsmCall对象的状态修改给DISCONNECTING，同时更新对应的GsmConnection对象通话连接断开的原因是LOCAL；而远端断开通话连接，GsmCall对象不会进入DISCONNECTING状态而直接变为DISCONNECTED状态，而对应的GsmConnection对象通话连接断开的原因是通过**查询Modem获取**。	

DriverCall.State与Call.State对应关系，DriverCall.State缺少DISCONNECTING和DISCONNECTED状态与Call.State对应。

## View动画
[TOC]

### 简介
Animation is the rapid display of a sequence of images to create an illusion of movement。

> 动画的本质是时间和图像的关系。

在Android系统中，需要实施一个View动画需要以下几个步骤：

- 定义xml动画资源文件
- 从xml文件中加载出动画

在xml资源文件中，可以描述alpha、scale、translate、rotate属性，以及各种属性的组合set，对应的实现类是AnimationSet。

除了上面的动画属性外，还需要指定动画执行的时间android:duration，以及动画的变化速率：Interpolater。常见的Interpolater有线性动画变化率LinearInterpolater以及加速动画变化率AccelerateInterpolater。

通过动画xml文件，可以描绘出以下信息：

- 有几个动画（rotate、scale、translate、alpha）需要执行；
- 每个动画的起始和最终效果；
- 每个动画的起始时间和结束时间；
- 完成每个动画的Interpolater；

在应用中使用一个xml动画资源时，通常可以这么做：

	ImageView image = （ImageView） findViewById(R.id.image);
	Animation exampleAnimation = AnimationUtils.loadAnimation(this,R.anim.example_anim);
	image.startAnimation(exampleAnim);

当应用程序通过loadAnimation加载一个xml动画资源文件时，返回的是一个Animation对象，不过大多数情况下是一个AnimationSet对象。AnimationSet对象继承于Animation类，有点类似于ViewGroup与View之间的关系。在AnimationSet内部，有一个mAnimations的ArrayList变量来记录它包含的所有动画。

Animation类的最终目的是提供getTransformation接口实现，这个函数将返回当前时间点的Transformation给View进行相应处理。

一个View的位移、旋转、缩放是可以用matrix来表达的，但是Alpha这个属性时Matrix不能表示的，所以需要一个Transformation变量来包含Matrix以及Alpha。

	public class Transformation {
		protected Matrix mMatrix;
    	protected float mAlpha;
	}

	
Animation通过解析XML文件得到用户希望产生的动画效果，并进行初始化。然后在Interpolater的约束下不断地与View进行交互（Transformation），从而产生动画过程。

View如何与Animation进行交互的呢？

View会主动调用Animation进行查询，即getTransformation。在View.startAnimation方法中，其内部会最后调用invalidate方法请求重绘，并在后续过程中处理与Animation相关的操作。

### View动画的类图如下：


![View动画类图](http://orbohk5us.bkt.clouddn.com/17-8-4/29990680.jpg)

### View动画的关键方法：

#### 1.AnimationUtils.loadAnimation

	public static Animation loadAnimation(Context context, @AnimRes int id)
            throws NotFoundException {
		// XML解析器
        XmlResourceParser parser = null;
        try {
            parser = context.getResources().getAnimation(id);
            return createAnimationFromXml(context, parser);
        } catch (XmlPullParserException ex) {
            ....
        } finally {
            if (parser != null) parser.close();
        }
    }
该方法的主要作用是从xml文件中加载动画资源。

	private static Animation createAnimationFromXml(Context c, XmlPullParser parser)
            throws XmlPullParserException, IOException {

        return createAnimationFromXml(c, parser, null, Xml.asAttributeSet(parser));
    }

	 private static Animation createAnimationFromXml(Context c, XmlPullParser parser,
            AnimationSet parent, AttributeSet attrs) throws XmlPullParserException, IOException {

        Animation anim = null;

        // Make sure we are on a start tag.
        int type;
        int depth = parser.getDepth();
		// 循环解析xml文件
        while (((type=parser.next()) != XmlPullParser.END_TAG || parser.getDepth() > depth)
               && type != XmlPullParser.END_DOCUMENT) {

            if (type != XmlPullParser.START_TAG) {
                continue;
            }
			// 获取标签名字
            String  name = parser.getName();
			// 构建AnimationSet
            if (name.equals("set")) {
                anim = new AnimationSet(c, attrs);
				// 递归调用
                createAnimationFromXml(c, parser, (AnimationSet)anim, attrs);
            } else if (name.equals("alpha")) {
				// 构建透明度动画
                anim = new AlphaAnimation(c, attrs);
            } else if (name.equals("scale")) {
				// 构建缩放动画
                anim = new ScaleAnimation(c, attrs);
            }  else if (name.equals("rotate")) {
				// 构建旋转动画
                anim = new RotateAnimation(c, attrs);
            }  else if (name.equals("translate")) {
				// 构建移动动画
                anim = new TranslateAnimation(c, attrs);
            } else {
                throw new RuntimeException("Unknown animation name: " + parser.getName());
            }
			// 将Animation添加到AnimationSet集合中
            if (parent != null) {
                parent.addAnimation(anim);
            }
        }

        return anim;

    }

#### 2.View.startAnimation

	public void startAnimation(Animation animation) {
		// 设置动画的起始时间
        animation.setStartTime(Animation.START_ON_FIRST_FRAME);
		// 设置View需要执行的动画
        setAnimation(animation);
		// 通知父View清除缓存，这样可以让父View重建它的显示列表
        invalidateParentCaches();
		// 触发View的重绘流程
        invalidate(true);
    }
该方法的主要作用是为View设置一个动画，并启动该动画。

### 3.Animation.getTransformation

	public boolean getTransformation(long currentTime, Transformation outTransformation) {
		// 如果mStartTime为-1，则将当前时间设置动画起始时间
        if (mStartTime == -1) {
            mStartTime = currentTime;
        }
		// 获取动画偏移时间
        final long startOffset = getStartOffset();
		// 动画执行时长
        final long duration = mDuration;
		// 归一化时间，1表示已经执行完了，0表示还未开始执行
        float normalizedTime;
        if (duration != 0) {
			
            normalizedTime = ((float) (currentTime - (mStartTime + startOffset))) /
                    (float) duration;
        } else {
            // time is a step-change with a zero duration
            normalizedTime = currentTime < mStartTime ? 0.0f : 1.0f;
        }

		// 是否过期了
        final boolean expired = normalizedTime >= 1.0f || isCanceled();
		// 是否还有执行
        mMore = !expired;
	    // 调整归一化的值
        if (!mFillEnabled) normalizedTime = Math.max(Math.min(normalizedTime, 1.0f), 0.0f);
        
        if ((normalizedTime >= 0.0f || mFillBefore) && (normalizedTime <= 1.0f || mFillAfter)) {
            if (!mStarted) {
				// 开始执行动画
                fireAnimationStart();
                mStarted = true;
                if (NoImagePreloadHolder.USE_CLOSEGUARD) {
                    guard.open("cancel or detach or getTransformation");
                }
            }
			
            if (mFillEnabled) normalizedTime = Math.max(Math.min(normalizedTime, 1.0f), 0.0f);

            if (mCycleFlip) {
                normalizedTime = 1.0f - normalizedTime;
            }
			// 获取时间差值器的值，这个值也是归一化的值
            final float interpolatedTime = mInterpolator.getInterpolation(normalizedTime);
			// 将归一化的值应用到转换中，由子类来实现该方法
            applyTransformation(interpolatedTime, outTransformation);
        }
		
		// 如果已经过期了
        if (expired) {
            if (mRepeatCount == mRepeated || isCanceled()) {
                if (!mEnded) {
                    mEnded = true;
                    guard.close();
					// 结束动画
                    fireAnimationEnd();
                }
            } else {
                if (mRepeatCount > 0) {
                    mRepeated++;
                }

                if (mRepeatMode == REVERSE) {
                    mCycleFlip = !mCycleFlip;
                }
				// 重新修改开始时间
                mStartTime = -1;
                mMore = true;
                // 重复动画
                fireAnimationRepeat();
            }
        }

        if (!mMore && mOneMoreTime) {
            mOneMoreTime = false;
            return true;
        }

        return mMore;
    }

	protected void applyTransformation(float interpolatedTime, Transformation t) {
    }

该方法的主要作用是获取在特定时间点的转换，并将该转换应用到动画中。


### Property Animation 属性动画

### View Animation 视图动画

### Drawable Animation
通过连续放映图片来产生动画的效果。


### Winodw Animation
系统内部实现的一种动画，目的在于加强窗口切换时的显示效果。
## View框架中的几种关系
[TOC]

应用程序的View框架如下所示：

![应用程序的View框架](http://orbohk5us.bkt.clouddn.com/17-8-3/58453986.jpg)

------
### View与ViewRootImpl的关系

ViewRootImpl不是View树的根，与View对象并没有任何“血缘关系”，它即非View的子类，也非View的父类。

ViewRootImpl可以**理解为View树的管理者，它有一个成员变量mView，指向的是它所管理的View树的根**。

ViewRootImpl的核心任务是**与WindowManagerService进行通信**。

-----
### Activity和Window的关系
Activity并不直接与View树打交道，而是通过一个中间对象————Window建立联系，Activity内部有一个mWindow 成员变量，具体如下：

	private Window mWindow；

Window的字面意思是“窗口”，Window是基类，根据不同的产品可以衍生出不同的子类————具体则由系统在Activity.attch时给mWindow进行赋值，手机窗口默认是PhoneWindow。

### Window与WindowManagerImpl的关系

Window有两层含义：第一层，Window是面向Activity的，表示“UI界面的外框”；而“框里面”具体包含的布局和内容等，由具体的Window子类，例如PhoneWindow来规划。但无论最终生成的窗口怎样，Activity都不需要修改。Window的另外一层含义是要与WindowManagerService进行通信，但它自身没有实现该功能。原因就是，一个应用程序中很可能存在多个Window，如果他们单独与WMS通信，即浪费资源，也效率低下。所以有了WindowManager，它是专门用来管理窗口的，在Window类中有一个成员变量mWindowManager，指向的就是WindowManager。

WindowManager是一个接口类，具体的实现由WindowManagerImpl来完成，它是整个应用程序中所有Window的管理者。

Window.java

	private WindowManager mWindowManager;
	public void setWindowManager(WindowManager wm, IBinder appToken, String appName,
            boolean hardwareAccelerated) {
		// 传递过来的AppToken
        mAppToken = appToken;
        mAppName = appName;
        mHardwareAccelerated = hardwareAccelerated
                || SystemProperties.getBoolean(PROPERTY_HARDWARE_UI, false);
        if (wm == null) {
            wm = (WindowManager)mContext.getSystemService(Context.WINDOW_SERVICE);
        }
		// 创建本地窗口管理者，父窗口为当前窗口
        mWindowManager = ((WindowManagerImpl)wm).createLocalWindowManager(this);
    }
	
	public WindowManagerImpl createLocalWindowManager(Window parentWindow) {
        return new WindowManagerImpl(mContext, parentWindow);
    }

	private WindowManagerImpl(Context context, Window parentWindow) {
        mContext = context;
        mParentWindow = parentWindow;
    }

	
Activity.attach
	
	mWindow.setWindowManager(
                (WindowManager)context.getSystemService(Context.WINDOW_SERVICE),
                mToken, mComponent.flattenToString(),
                (info.flags & ActivityInfo.FLAG_HARDWARE_ACCELERATED) != 0);
将Activity的AppToken传递给Window。


### ViewRootImpl与WindowManagerService的关系

每一个ViewRootImpl内部，都有一个全局变量——sWindowSesion：

	static IWindowSession sWindowSession;
这个变量用于ViewRootImpl到WMS的连接，它是ViewRootImpl利用WMS的openSession()接口来创建得到的。在此基础之上，ViewRootImpl也会通过IWindowSession的add方法提供一个IWindow对象给WMS，从而也让WMS可以通过这个Binder对象来与ViewRootImpl进行双向通信。

每个Application都有一个ActivityThread主线程以及mActivities全局变量，后者记录运行在应用程序中的所有Activity对象。一个Activity对象对应唯一的WindowManager以及ViewRootImpl。

WindowManagerGlobal作为全局管理者，其内部的mRoots和mViews记录了各Activity的ViewRootImpl和View树的顶层元素。ViewRootImpl的另一个重要角色是负责与WMS通信。从ViewRootImpl到WMS间的通信利用的是IWindowSession，而反方向则是由IWindow来完成的。


### View、ViewGroup、ViewParent之间的关系

View确切地说是一个抽象的视图对象，它定义了一个视图所需具有的属性和基本操作方法。

ViewGroup本质上也是一个View，可以理解为ViewGroup中Content是由若干个View组成的。

ViewParent是一个View的“父亲”，这个父亲既可能是ViewGroup，也可以是ViewRootImpl。也就是，对于View树的根，它的父亲是ViewRootImpl，而其他元素的父亲是ViewGroup。

![View与ViewGroup之间的关系](http://orbohk5us.bkt.clouddn.com/17-8-3/175534.jpg)









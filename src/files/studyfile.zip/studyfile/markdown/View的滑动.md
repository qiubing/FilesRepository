## View的滑动

### 1.概述

有三种方式，可以实现View的滑动：

- 第一种是通过View本身提供的scrollTo/scrollBy方法来实现滑动；
- 第二种是通过View动画给View施加平移效果来实现滑动；
- 第三种是通过改变View的LayoutParams使得View重新布局从而实现滑动；

1.scrollTo/scrollBy

在滑动过程中，mScrollX的值总是等于View左边缘和View内容左边缘在水平方向的距离，而mScrollY的值总是等于View上边缘和View内容上边缘在竖直方向的距离。

View边缘是指View的位置，由四个顶点组成，而View内容边缘是指View中的内容的边缘，scrollTo和scrollBy只能改变**View内容的位置**而不能改变View在布局中的位置。


2.使用动画

通过动画我们能够让一个View进行平移，而平移就是一种滑动。使用动画来移动View，主要是操作View的translationX和translationY属性，既可以采用传统的View动画，也可以采用属性动画。

View动画是对View的影像做操作，它并不能真正改变View的位置参数，包括宽/高,并且如果希望动画后的状态得以保留还必须将fillAfter属性设置为true，否则动画完成后其动画结果会消失。

属性动画可以让View的影像与View的真身一起移动。


3.改变布局参数

改变布局参数，即改变LayoutParams参数。

对比：

- scrollTo/scrollBy是View提供的原生方法，其作用是专门用于View的滑动，它可以比较方便地实现滑动效果并且不影响内部元素的单击事件。但是它的缺点是很显然的：它只能滑动View的内容，并不能滑动View本身。操作简单，适合对View内容的滑动；
- 动画：操作简单，主要适用于没有交互的View和实现复杂的动画效果；
- 改变布局参数：操作稍微复杂，适用于有交互的View；

### 2.弹性滑动

弹性滑动的实现思想是将一次大的滑动分成若干次小的滑动，并在一个时间段内完，弹性滑动的具体实现方式有很多，比如通过Scroller、Handler.postDelayed以及Thread.sleep等方法。

1.Scroller

Scroller的典型用法如下：

	Scroller scoller = new Scroller(mContext);
	
	private void soomthScrollTo(int destX,int destY){
		int scrollX = getScrollX();
		int deltaX = destX - scrollX;
		mScroller.startScroll(scrollX,0,deltaX,0,1000);// 在1000ms内滑向destX，效果就是慢慢滑动
		invalidate();
	}

	public void computeScroll(){
		if(mScroller.computeScrollOffset()){
			scrollTo(mScroller.getCurrX(),mScroller.getCurrY());
			postInvalidate();
		}
	}

2.通过动画

动画的典型用法如下：

	final int startX = 0；
	final int deltaX = 100；
	ValueAnimator animator = ValueAnimator.ofInt(0,1).setDuration(1000);
	animator.addUpdateListener(new AnimatorUpdateListener(){
		public void onAnimationUpdate(ValueAnimator animator){
			float fraction = animator.getAnimatedFraction();
			mButton.scrollTo(startX + (int)(deltaX * fraction),0);
		}
	})
	animator.start();


3.使用延时策略

延时策略的核心思想是，通过发送一系列延时消息从而达到一种渐进式的效果，具体来说，可以使用Handler或View的postDelayed方法，也可以使用线程的sleep方法。

	private static final int MESSAGE_SCROLL_TO = 1;
	private static final int FRAME_COUNT = 30;
	private static final int DELAYED_TIME = 33;

	private int mCount = 0;
	
	private Handler mHandler = new Handler(){
		public void handleMessage(Message msg){
			switch(msg.what){
				case MESSAGE_SCROLL_TO:{
					float fraction = mCount / (float) FRAME_COUNT;
					int scrollX = (int) (fraction * 100);
					mButton.scrollTo(scrollX,0);
					mHandler.sendEmptyMessageDelayed(MESSAGE_SCROLL_TO,DELAY_TIME);
				}
				break;
			}

		default:
			break;
		};
	};

### 3.滑动冲突

1.外部拦截法

所谓外部拦截法是指点击事件都先经过父容器的拦截处理，如果父容器需要此事件就拦截，如果不需要此事件就不拦截，这样就可以解决滑动冲突的问题。外部拦截法需要重写父容器的onInterceptTouchEvent()方法，在内部做相应的拦截即可。

	public boolean onInterceptTouchEvent(MotionEvent event){
        boolean intercepted = false;
        int x = (int) event.getX();
        int y = (int) event.getY();
        
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                intercepted = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (condition){//父容器需要当前点击事件
                    intercepted = true;
                }else {
                    intercepted = false;
                }
                break;
            case MotionEvent.ACTION_UP:
                intercepted = false;
                break;
            default:
                break;
        }
        return intercepted;
    }

上述代码是外部拦截法的典型逻辑，针对不同的滑动冲突，只需要修改父容器需要当前点击事件这个条件即可。在onInterceptorTouchEvent方法中，首先是ACTION\_DOWN这个事件，父容器必须返回false，即不拦截ACTION\_DOWN事件，这是因为一旦父容器拦截了ACTION\_DOWN，那么后续的ACTION\_MOVE和ACTION\_UP事件都会直接交由父容器处理，这个时候事件没法再传递给子元素了；其次是ACITON\_MOVE事件，这个事件可以根据需要来决定是否拦截，如果父容器需要拦截就返回true，否则返回false；最后是ACTION\_UP事件，这里必须要返回false，因为ACTION\_UP事件本身没有太多意义。

2.内部拦截法

内部拦截法是指父容器不拦截任何事件，所有的事件都传递子元素，如果子元素需要此事件就直接消耗掉，否则就交由父容器进行处理，这种方法和Android中的事件分发机制不一致，需要配合requestDisallowInterceptTouchEvent方法才能正常工作，使用起来较外部拦截法稍显复杂。

	@Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();

        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                parent.requestDisallowInterceptTouchEvent(true);
                break;
            case MotionEvent.ACTION_MOVE:
                int deltaX = x - mLastX;
                int deltaY = y - mLastY;
                if (condition){//父容器需要此点击事件
                    parent.requestDisallowInterceptTouchEvent(false);
                }
                break;
            case MotionEvent.ACTION_UP:
                break;
            default:
                break;
        }

        mLastX = x;
        mLastY = y;
        return super.dispatchTouchEvent(event);
    }

父元素需要拦截除了ACTION_DOWN以外的其他事件，这样当子元素调用parent.requestDisallowInterceptTouchEvent(false)方法时，父元素才能继续拦截所需的事件。父元素所做的修改如下所示：

	public boolean onInterceptTouchEvent(MotionEvent event){
		int action = event.getAction();
		if(action == MotionEvent.ACTION_DOWN){
			return false;
		}else{
			return true;
		}
	}




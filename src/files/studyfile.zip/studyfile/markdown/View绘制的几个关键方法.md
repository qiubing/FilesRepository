## View绘制的几个关键方法

### 1.View.requestLayout()方法
requestLayout方法在ViewParent接口中定义，ViewParent接口主要是定义一个父View所拥有的一些职责。

	public interface ViewParent {
		 // 当父View的子View发生了一些变化，则需要invalidate布局，并传递到整个View树。
		 public void requestLayout();
	}
ViewGroup是一个抽象的类，并没有实现requestLayout方法，而是调用View的requestLayout方法。

1.View.requestLayout()
	public void requestLayout() {
        ......
		// 设置一些标志位
        mPrivateFlags |= PFLAG_FORCE_LAYOUT;
        mPrivateFlags |= PFLAG_INVALIDATED;
		
		// 父View不为空，并且没有在layout
        if (mParent != null && !mParent.isLayoutRequested()) {
			// 调用该View依附的父View的requestLayout方法
            mParent.requestLayout();
        }
        .....
    }
可以看到View的requestLayout方法会调用父View的requestLayout方法。同样父View也会调用它的父View的requestLayout方法，直至到达最底层的父View——**ViewRootImpl**。

2. ViewRootImpl.requestLayout()

	public void requestLayout() {
        if (!mHandlingLayoutInLayoutRequest) {
			// 检查是否在当前线程
            checkThread();
            mLayoutRequested = true;
            scheduleTraversals();
        }
    }
3. ViewRootImpl.scheduleTraversals()

	void scheduleTraversals() {
        if (!mTraversalScheduled) {
            mTraversalScheduled = true;
			// 设置同步障碍
			mTraversalBarrier = mHandler.getLooper().getQueue().postSyncBarrier();
      		......
			// 将请求放入CallBack队列中，等待调用
            mChoreographer.postCallback(
                    Choreographer.CALLBACK_TRAVERSAL, mTraversalRunnable, null);
            // 通知硬件加速渲染处理新到来的帧
            notifyRendererOfFramePending();
            pokeDrawLockIfNeeded();
        }
    }

其中mTraversalRunnable是一个Runnable，在适当的时机执行。

	final class TraversalRunnable implements Runnable {
        @Override
        public void run() {
            doTraversal();
        }
    }
    final TraversalRunnable mTraversalRunnable = new TraversalRunnable();

4.Choreographer.postCallback()

首先来看下Choreographer的构造过程。

	private Choreographer(Looper looper) {
        mLooper = looper;
		// 构建FrameHandler
        mHandler = new FrameHandler(looper);
		// 如果是VSYNC信号来更新界面，则使用FrameDisplayEventReceiver
        mDisplayEventReceiver = USE_VSYNC ? new FrameDisplayEventReceiver(looper) : null;
        mLastFrameTimeNanos = Long.MIN_VALUE;
		// 帧更新时间间隔，每一帧16ms
        mFrameIntervalNanos = (long)(1000000000 / getRefreshRate());
		// 创建CallBackQueue数组，每一种类型都对应一种CallBackQueue。
        mCallbackQueues = new CallbackQueue[CALLBACK_LAST + 1];
        for (int i = 0; i <= CALLBACK_LAST; i++) {
			初始化CallBackQueue
            mCallbackQueues[i] = new CallbackQueue();
        }
    }
在Choreographer的构造方法中，主要是定义了帧更新间隔，帧处理Handler，帧显示处理器，创建CallBackQueue队列。

Choreographer的构造函数是私有的，应该是通过getInstance方法获取的。

	public static Choreographer getInstance() {
        return sThreadInstance.get();
    }
通过ThreadLocal变量，保证获取的Choreographer对象是线程相关的。

	// Thread local storage for the choreographer.
    private static final ThreadLocal<Choreographer> sThreadInstance =
            new ThreadLocal<Choreographer>() {
        @Override
        protected Choreographer initialValue() {
			// 获取当前的线程的Looper
            Looper looper = Looper.myLooper();
            if (looper == null) {
                throw new IllegalStateException("The current thread must have a looper!");
            }
            return new Choreographer(looper);
        }
    };

下面来看下postCallback函数实现。

	// 让CallBack在下一个帧时间内执行
	public void postCallback(int callbackType, Runnable action, Object token) {
        postCallbackDelayed(callbackType, action, token, 0);
    }

	public void postCallbackDelayed(int callbackType,
            Runnable action, Object token, long delayMillis) {
        if (action == null) {
            throw new IllegalArgumentException("action must not be null");
        }
        if (callbackType < 0 || callbackType > CALLBACK_LAST) {
            throw new IllegalArgumentException("callbackType is invalid");
        }

        postCallbackDelayedInternal(callbackType, action, token, delayMillis);
    }

	private void postCallbackDelayedInternal(int callbackType,
            Object action, Object token, long delayMillis) {
        synchronized (mLock) {
            final long now = SystemClock.uptimeMillis();
			// 当前时间加上延迟时间
            final long dueTime = now + delayMillis;
			// 将CallBack添加到指定类型的队列中，根据时间决定插入顺序
            mCallbackQueues[callbackType].addCallbackLocked(dueTime, action, token);
	
            if (dueTime <= now) {
			    //立即执行
                scheduleFrameLocked(now);
            } else {
				//延迟到dueTime时间执行
                Message msg = mHandler.obtainMessage(MSG_DO_SCHEDULE_CALLBACK, action);
                msg.arg1 = callbackType;
                msg.setAsynchronous(true);
                mHandler.sendMessageAtTime(msg, dueTime);
            }
        }
    }
可以看到，postCallbackDelayedInternal方法的主要作用是将CallBack添加到相应类型的队列中，添加的规则是根据执行时间的先后顺序排列。接着如果是立即执行的CallBack，则调用scheduleFrameLocked函数，否则要等到指定的延迟的时间才能执行CallBack，但最终都会调用到scheduleFrameLocked方法。

addCallbackLocked方法的实现如下：

	public void addCallbackLocked(long dueTime, Object action, Object token) {
            CallbackRecord callback = obtainCallbackLocked(dueTime, action, token);
            CallbackRecord entry = mHead;
            if (entry == null) {
                mHead = callback;
                return;
            }
            if (dueTime < entry.dueTime) {
                callback.next = entry;
                mHead = callback;
                return;
            }
            while (entry.next != null) {
                if (dueTime < entry.next.dueTime) {
                    callback.next = entry.next;
                    break;
                }
                entry = entry.next;
            }
            entry.next = callback;
        }

5.Choreographer.scheduleFrameLocked()
	
	 private void scheduleFrameLocked(long now) {
        if (!mFrameScheduled) {
            mFrameScheduled = true;
			// 使用SYNC信号更新帧
            if (USE_VSYNC) {
				
				// 如果运行在Looper线程上，则直接发送VSYNC信号，否则的话，从UI线程发送一个VSYNC消息来发送SYNC信号。
                if (isRunningOnLooperThreadLocked()) {
                    scheduleVsyncLocked();
                } else {
                    Message msg = mHandler.obtainMessage(MSG_DO_SCHEDULE_VSYNC);
                    msg.setAsynchronous(true);
                    mHandler.sendMessageAtFrontOfQueue(msg);
                }
            } else {
                final long nextFrameTime = Math.max(
                        mLastFrameTimeNanos / TimeUtils.NANOS_PER_MS + sFrameDelay, now);
                Message msg = mHandler.obtainMessage(MSG_DO_FRAME);
                msg.setAsynchronous(true);
                mHandler.sendMessageAtTime(msg, nextFrameTime);
            }
        }
    }
在scheduleFrameLocked方法中，主要是通过VSYNC信号更新帧，如果是运行在Looper所在的线程，则直接调用scheduleVsyncLocked方法，否则通过发送一个MSG_DO_SCHEDULE_VSYNC消息间接来调用scheduleVsyncLocked方法，不管通过哪种方式，都是会调用到scheduleVsyncLocked方法中。

6.Choreographer.scheduleVsyncLocked()

	private void scheduleVsyncLocked() {
        mDisplayEventReceiver.scheduleVsync();
    }

7.DisplayEventReceiver.scheduleVsync()
	
	public void scheduleVsync() {
        if (mReceiverPtr == 0) {
            Log.w(TAG, "Attempted to schedule a vertical sync pulse but the display event "
                    + "receiver has already been disposed.");
        } else {
			// 调用本地方法产生单个垂直信号VSYNC脉冲
            nativeScheduleVsync(mReceiverPtr);
        }
    }

scheduleVsync方法的主要作用是调度产生垂直脉冲信号VSYNC。

当下一个VSYNC脉冲到来时，将调用TraversalRunnable里run方法。即调用ViewRootImpl的doTraversal()方法,开始新的一轮View的绘制操作。

8.ViewRootImpl.doTraversal()

	void doTraversal() {
		
        if (mTraversalScheduled) {
            mTraversalScheduled = false;
			// 移除同步障碍
            mHandler.getLooper().getQueue().removeSyncBarrier(mTraversalBarrier);
            .....
			// 开始遍历的过程
            performTraversals();
			....
        }
    }
doTraversal方法主要的作用是调用performTraversals()开始遍历的过程，该方法是View的Measure、Layout()、Draw方法的起始过程。

整体流程如下：

	View.requestLayout()
		ViewRootImpl.requestLayout()
			ViewRootImpl.scheduleTraversals()
				Choreographer.postCallback()
					Choreographer.scheduleFrameLocked()
						Choreographer.scheduleVsyncLocked()
							DisplayEventReceiver.scheduleVsync()
			ViewRootImpl.doTraversal()
			ViewRootImpl.performTraversals()
	
			
### 2.View.invalidate()方法
invalidate是失效的意思，即绘制缓存无效，需要重新绘制。可以绘制整个部分，也可以只绘制一部分。

1.View.invalidate()

	// invalidateCache表示View的绘制缓存是否应该无效
	void invalidate(boolean invalidateCache) {
        invalidateInternal(0, 0, mRight - mLeft, mBottom - mTop, invalidateCache, true);
    }
	
	 void invalidateInternal(int l, int t, int r, int b, boolean invalidateCache,
            boolean fullInvalidate) {

        if (mGhostView != null) {
            mGhostView.invalidate(true);
            return;
        }

		// 是否需要跳过绘制，如果View是不可见的话并且没有在运行动画，则调用跳过绘制过程。
        if (skipInvalidate()) {
            return;
        }
		
		
        if ((mPrivateFlags & (PFLAG_DRAWN | PFLAG_HAS_BOUNDS)) == (PFLAG_DRAWN | PFLAG_HAS_BOUNDS)
                || (invalidateCache && (mPrivateFlags & PFLAG_DRAWING_CACHE_VALID) == PFLAG_DRAWING_CACHE_VALID)
                || (mPrivateFlags & PFLAG_INVALIDATED) != PFLAG_INVALIDATED
                || (fullInvalidate && isOpaque() != mLastIsOpaque)) {
			
			// 是否要全部绘制
            if (fullInvalidate) {
                mLastIsOpaque = isOpaque();
                mPrivateFlags &= ~PFLAG_DRAWN;
            }
			
			// 标志该绘制区域为脏区域
            mPrivateFlags |= PFLAG_DIRTY;
			
			// 需要绘制缓存失效
            if (invalidateCache) {
                mPrivateFlags |= PFLAG_INVALIDATED;
                mPrivateFlags &= ~PFLAG_DRAWING_CACHE_VALID;
            }


            final AttachInfo ai = mAttachInfo;
            final ViewParent p = mParent;
            if (p != null && ai != null && l < r && t < b) {
                final Rect damage = ai.mTmpInvalRect;
                damage.set(l, t, r, b);
				// 调用父View的invalidateChild方法，层层向上传递，直至ViewRootImpl
                p.invalidateChild(this, damage);
            }

            
            if (mBackground != null && mBackground.isProjected()) {
                final View receiver = getProjectionReceiver();
                if (receiver != null) {
                    receiver.damageInParent();
                }
            }

            if (isHardwareAccelerated() && getZ() != 0) {
                damageShadowReceiver();
            }
        }
    }
在invalidateInternal方法中，主要是设置一些绘制的标志，并调用父View的invalidateChild方法，最终层层传递到ViewRootImpl中。

2.ViewGroup.invalidateChild()

	public final void invalidateChild(View child, final Rect dirty) {
		ViewParent parent = this;
		final AttachInfo attachInfo = mAttachInfo;
		if (attachInfo != null) {
			final boolean drawAnimation = (child.mPrivateFlags & PFLAG_DRAW_ANIMATION)
                    == PFLAG_DRAW_ANIMATION;
			 Matrix childMatrix = child.getMatrix();
            final boolean isOpaque = child.isOpaque() && !drawAnimation &&
                    child.getAnimation() == null && childMatrix.isIdentity();

			
			int opaqueFlag = isOpaque ? PFLAG_DIRTY_OPAQUE : PFLAG_DIRTY;

            if (child.mLayerType != LAYER_TYPE_NONE) {
                mPrivateFlags |= PFLAG_INVALIDATED;
                mPrivateFlags &= ~PFLAG_DRAWING_CACHE_VALID;
            }
			
			// 获取child View需要绘制的区域起始位置
			final int[] location = attachInfo.mInvalidateChildLocation;
            location[CHILD_LEFT_INDEX] = child.mLeft;
            location[CHILD_TOP_INDEX] = child.mTop;
			....

			// 只要parent不为null，则一直循环
			do {
                View view = null;
				// parent为View的情况
                if (parent instanceof View) {
                    view = (View) parent;
                }
				
				// 需要绘制动画
                if (drawAnimation) {
                    if (view != null) {
                        view.mPrivateFlags |= PFLAG_DRAW_ANIMATION;
					// parent为ViewRootImpl
                    } else if (parent instanceof ViewRootImpl) {
                        ((ViewRootImpl) parent).mIsAnimating = true;
                    }
                }
				
                if (view != null) {
                    if ((view.mViewFlags & FADING_EDGE_MASK) != 0 &&
                            view.getSolidColor() == 0) {
                        opaqueFlag = PFLAG_DIRTY;
                    }
                    if ((view.mPrivateFlags & PFLAG_DIRTY_MASK) != PFLAG_DIRTY) {
                        view.mPrivateFlags = (view.mPrivateFlags & ~PFLAG_DIRTY_MASK) | opaqueFlag;
                    }
                }
				
				// 关键方法，调用parent的invalidateChildInParent方法
                parent = parent.invalidateChildInParent(location, dirty);
				.......
                }
            } while (parent != null);
		}
	}

在invalidateChild方法中，会循环调用invalidateChildInParent方法，直至parent为null。这样会层层传递到上层的parent View，最终到达ViewRootImpl。

3.ViewRootImpl.invalidateChildInParent()

	public ViewParent invalidateChildInParent(int[] location, Rect dirty) {
        checkThread();
       	
        if (dirty == null) {
            invalidate();
            return null;
        } else if (dirty.isEmpty() && !mIsAnimating) {
            return null;
        }
		
        if (mCurScrollY != 0 || mTranslator != null) {
            //保存脏的绘制区域
			mTempRect.set(dirty);
            dirty = mTempRect;
            if (mCurScrollY != 0) {
                dirty.offset(0, -mCurScrollY);
            }
            if (mTranslator != null) {
                mTranslator.translateRectInAppWindowToScreen(dirty);
            }
            if (mAttachInfo.mScalingRequired) {
                dirty.inset(-1, -1);
            }
        }
		
        invalidateRectOnScreen(dirty);
		// 返回的父View为空，因为ViewRootImpl已经是最顶层的父View
        return null;
    }

invalidateChildInParent方法主要用来给父View来绘制部分或者所有child View。location数组是一个包含两个整数值的数组，分别代表child view的left和top位置。如果指定的矩形区域rect在父View中必须失效，则需要返回该父View，否则返回一个null的父View。


4.ViewRootImpl.invalidateRectOnScreen()

	private void invalidateRectOnScreen(Rect dirty) {
        final Rect localDirty = mDirty;
        if (!localDirty.isEmpty() && !localDirty.contains(dirty)) {
            mAttachInfo.mSetIgnoreDirtyState = true;
            mAttachInfo.mIgnoreDirtyState = true;
        }

        // Add the new dirty rect to the current one
        localDirty.union(dirty.left, dirty.top, dirty.right, dirty.bottom);
        // Intersect with the bounds of the window to skip
        // updates that lie outside of the visible region
        // 只更新Window窗口内的内容，忽略窗口外部的内容
		final float appScale = mAttachInfo.mApplicationScale;
        final boolean intersected = localDirty.intersect(0, 0,
                (int) (mWidth * appScale + 0.5f), (int) (mHeight * appScale + 0.5f));
        if (!intersected) {
            localDirty.setEmpty();
        }
        if (!mWillDrawSoon && (intersected || mIsAnimating)) {
			// 开始遍历过程
            scheduleTraversals();
        }
    }

在invalidateRectOnScreen方法中，会最终调用到scheduleTraversals方法，开始View的绘制三个过程。

整理流程如下：

	View.invalidate()
		ViewGroup.invalidateChild()
			ViewRootImpl.invalidateChildInParent()
				ViewRootImpl.invalidateRectOnScreen()
					ViewRootImpl.scheduleTraversals()
						ViewRootImpl.doTraversal()
							ViewRootImpl.performTraversals()


### View.measure() 方法
1. View.measuere()

该方法的主要作用是计算出View应该显示多大，父View将提供宽度和高度的限制信息。真正的测量是在onMeasure方法中，需要测量的View应该覆写该方法。

	public final void measure(int widthMeasureSpec, int heightMeasureSpec) {
		......
		// 是否强制layout
		final boolean forceLayout = (mPrivateFlags & PFLAG_FORCE_LAYOUT) == PFLAG_FORCE_LAYOUT;
		
		// 一些优化，避免重复计算已经为EXACTLY模式的View
		final boolean specChanged = widthMeasureSpec != mOldWidthMeasureSpec
                || heightMeasureSpec != mOldHeightMeasureSpec;
        final boolean isSpecExactly = MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.EXACTLY
                && MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.EXACTLY;
        final boolean matchesSpecSize = getMeasuredWidth() == MeasureSpec.getSize(widthMeasureSpec)
                && getMeasuredHeight() == MeasureSpec.getSize(heightMeasureSpec);
		// 是否需要layout
        final boolean needsLayout = specChanged
                && (sAlwaysRemeasureExactly || !isSpecExactly || !matchesSpecSize);

		if (forceLayout || needsLayout) {
			// 首先清除PFLAG_MEASURED_DIMENSION_SET标志
			mPrivateFlags &= ~PFLAG_MEASURED_DIMENSION_SET;
			// 获取缓存的索引，判断是否已经测量过
			int cacheIndex = forceLayout ? -1 : mMeasureCache.indexOfKey(key);

			if (cacheIndex < 0 || sIgnoreMeasureCache) {
                // measure ourselves, this should set the measured dimension flag back
				// 自己测量
                onMeasure(widthMeasureSpec, heightMeasureSpec);
                mPrivateFlags3 &= ~PFLAG3_MEASURE_NEEDED_BEFORE_LAYOUT;
            } else {
                long value = mMeasureCache.valueAt(cacheIndex);
                // Casting a long to int drops the high 32 bits, no mask needed
                setMeasuredDimensionRaw((int) (value >> 32), (int) value);
                mPrivateFlags3 |= PFLAG3_MEASURE_NEEDED_BEFORE_LAYOUT;
            }
			// 设置需要layout的标志
			mPrivateFlags |= PFLAG_LAYOUT_REQUIRED;
		}
		//保存原来测量的值
		mOldWidthMeasureSpec = widthMeasureSpec;
        mOldHeightMeasureSpec = heightMeasureSpec;
		
		// 缓存已测量的值
		mMeasureCache.put(key, ((long) mMeasuredWidth) << 32 |
                (long) mMeasuredHeight & 0xffffffffL);
	}

在View的measure()方法中,首先判断是否已经测量过，如果没有则通过onMeasure方法进行测量，并把测量结果保存在缓存中。

2.View.onMeasure()

	 protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		//设置
        setMeasuredDimension(getDefaultSize(getSuggestedMinimumWidth(), widthMeasureSpec),
                getDefaultSize(getSuggestedMinimumHeight(), heightMeasureSpec));
    }

该方法的主要作用是测量View以及它的内容大小，并通过setMeasuredDimension方法将View的测量出宽和高分别保存在mMeasuredWidth和mMeasuredHeight变量中。注意，在onMeasure方法中，一定要记得调用setMeasuredDimension方法来设置测量计算出来的宽和高，要不然mMeasuredWidth和mMeasuredHeight的值都是无效的。

View有三种测量模式：EXACTLY、AT_MOST和UNSPECIFIED。

EXACTLY：父View决定子View准确的大小。

AT_MOST：子View可以达到它所想要的大小。

UNSPECIFIED： 父View没有限制子View的大小，子View可以想要多大就多大。

总而言之，**如果测量模式是EXACTLY，则子View的大小完全由父View决定；如果测试模式是AT_MOST或者UNSPECIFIED，则子View的大小由子View自己决定**。

具体可以看View的getDefaultSize()方法实现：

	public static int getDefaultSize(int size, int measureSpec) {
        int result = size;
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);

        switch (specMode) {
        case MeasureSpec.UNSPECIFIED:
            result = size;
            break;
        case MeasureSpec.AT_MOST:
        case MeasureSpec.EXACTLY:
            result = specSize;
            break;
        }
        return result;
    }



### View.layout() 方法

View的layout方法主要是给View以及它的子View分配一个大小和位置。这是View绘制的第二阶段，每个父View都会在它的子View上调用layout方法来确定他们的位置。layout过程会用到在measure过程中测量的值。

继承类不应该覆写该方法，而应该覆写onLayout方法。在onLayout方法中，应该给每个View进行布局。

	public void layout(int l, int t, int r, int b) {
		// 是否主要在layout前，进行measure
		if ((mPrivateFlags3 & PFLAG3_MEASURE_NEEDED_BEFORE_LAYOUT) != 0) {
            onMeasure(mOldWidthMeasureSpec, mOldHeightMeasureSpec);
            mPrivateFlags3 &= ~PFLAG3_MEASURE_NEEDED_BEFORE_LAYOUT;
        }
		// 保存以前的值
		int oldL = mLeft;
        int oldT = mTop;
        int oldB = mBottom;
        int oldR = mRight;
		
		// 调用setFrame设置View的位置
		 boolean changed = isLayoutModeOptical(mParent) ?
                setOpticalFrame(l, t, r, b) : setFrame(l, t, r, b);
		
		if (changed || (mPrivateFlags & PFLAG_LAYOUT_REQUIRED) == PFLAG_LAYOUT_REQUIRED) {
			// 调用onLayout方法
			onLayout(changed, l, t, r, b);
			
			// 清除标志
			mPrivateFlags &= ~PFLAG_LAYOUT_REQUIRED;
			
			ListenerInfo li = mListenerInfo;
            if (li != null && li.mOnLayoutChangeListeners != null) {
                ArrayList<OnLayoutChangeListener> listenersCopy =
                        (ArrayList<OnLayoutChangeListener>)li.mOnLayoutChangeListeners.clone();
                int numListeners = listenersCopy.size();
                for (int i = 0; i < numListeners; ++i) {
					// 回调布局改变的方法
                    listenersCopy.get(i).onLayoutChange(this, l, t, r, b, oldL, oldT, oldR, oldB);
                }
            }
		}
		mPrivateFlags &= ~PFLAG_FORCE_LAYOUT;
        mPrivateFlags3 |= PFLAG3_IS_LAID_OUT;
	}

在layout方法中，主要调用onLayout方法，并且清除布局的标志为。

2.View.setFrame()

	protected boolean setFrame(int left, int top, int right, int bottom) {
		boolean changed = false;
		if (mLeft != left || mRight != right || mTop != top || mBottom != bottom) {
			// 位置已经发生了变化
			changed = true;
			//保留绘制标志
			int drawn = mPrivateFlags & PFLAG_DRAWN;

			int oldWidth = mRight - mLeft;
            int oldHeight = mBottom - mTop;
			// 计算View新的大小
            int newWidth = right - left;
            int newHeight = bottom - top;
			// 大小是否改变了
			boolean sizeChanged = (newWidth != oldWidth) || (newHeight != oldHeight);
			// 调用invalidte方法进行重绘
			invalidate(sizeChanged);
			//保存新值
			mLeft = left;
            mTop = top;
            mRight = right;
            mBottom = bottom;
			
			mRenderNode.setLeftTopRightBottom(mLeft, mTop, mRight, mBottom);

			mPrivateFlags |= PFLAG_HAS_BOUNDS;

			if (sizeChanged) {
				// 回调sizeChanged方法
                sizeChange(newWidth, newHeight, oldWidth, oldHeight);
            }

			if ((mViewFlags & VISIBILITY_MASK) == VISIBLE || mGhostView != null) {
				// 如果View是可见的，强制设置PFLAG_DRAWN标志，让invalidate过程执行。
				mPrivateFlags |= PFLAG_DRAWN;
                invalidate(sizeChanged);
				invalidateParentCaches();
			}
			// 恢复绘制标志
			mPrivateFlags |= drawn;

			mBackgroundSizeChanged = true;
            if (mForegroundInfo != null) {
                mForegroundInfo.mBoundsChanged = true;
            }

            notifySubtreeAccessibilityStateChangedIfNeeded();
		}
		return changed;
	}
该方法主要是给View分配一个大小和位置。如果View的大小发生了变化，则需要调用invalidate方法进行重绘。执行完该方法，会将布局的位置保存在mLeft，mTop，mRight，mBottom。通过getWidth（）方法返回的是View的宽度，其实就是通过mRight减去mLeft的大小，View的高度也类似。

	public final int getWidth() {
        return mRight - mLeft;
    }

一般通过getWidth()和getHeight()方法返回的宽和高与measure中测量的mMeasuredWidth和mMeasuredHeight是一样大的。


3.View.onLayout()

	protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
    }
View的onLayout方法是一个空实现，子类可以覆写该方法。

### View.draw() 方法

View.draw()方法主要是用来手动渲染该View以及它的子View到给定的Canvas。在调用该方法之前，必须以及执行过layout过程。该方法不应该被覆写，而应该覆写onDraw()方法。

1.View.onDraw()
	
	public void draw(Canvas canvas) {
        final int privateFlags = mPrivateFlags;
        final boolean dirtyOpaque = (privateFlags & PFLAG_DIRTY_MASK) == PFLAG_DIRTY_OPAQUE &&
                (mAttachInfo == null || !mAttachInfo.mIgnoreDirtyState);
        mPrivateFlags = (privateFlags & ~PFLAG_DIRTY_MASK) | PFLAG_DRAWN;

        /*
         * Draw traversal performs several drawing steps which must be executed
         * in the appropriate order:
         *
         *      1. Draw the background
         *      2. If necessary, save the canvas' layers to prepare for fading
         *      3. Draw view's content
         *      4. Draw children
         *      5. If necessary, draw the fading edges and restore layers
         *      6. Draw decorations (scrollbars for instance)
         */

        // Step 1, draw the background, if needed
        int saveCount;

        if (!dirtyOpaque) {
            drawBackground(canvas);
        }

        // skip step 2 & 5 if possible (common case)
        final int viewFlags = mViewFlags;
        boolean horizontalEdges = (viewFlags & FADING_EDGE_HORIZONTAL) != 0;
        boolean verticalEdges = (viewFlags & FADING_EDGE_VERTICAL) != 0;
        if (!verticalEdges && !horizontalEdges) {
            // Step 3, draw the content
            if (!dirtyOpaque) onDraw(canvas);

            // Step 4, draw the children
            dispatchDraw(canvas);

            // Overlay is part of the content and draws beneath Foreground
            if (mOverlay != null && !mOverlay.isEmpty()) {
                mOverlay.getOverlayView().dispatchDraw(canvas);
            }

            // Step 6, draw decorations (foreground, scrollbars)
            onDrawForeground(canvas);

            // we're done...
            return;
        }
	 .......
	
	}

一个绘制过程大致会包含六个步骤：

1. 绘制背景
2. 如果需要，保存Canvas层
3. 绘制View的内容
4. 绘制子View
5. 如果需要，绘制渐变边缘
6. 绘制装饰

2.View.onDraw()

	protected void onDraw(Canvas canvas) {
    }
onDraw()方式是一个空实现，子View可以覆写该方法实现内容的绘制。

整体流程：

	View.draw()
		View.drawBackground()
		View.onDraw()
		View.dispatchDraw()
		View.onDrawForeground()

### View和ViewGroup实现方法对比
我们知道ViewGroup继承了View，所以它本身也是一个View，在View中的一些方法在ViewGroup中通用也有实现，只是含义不同而已。



 方法名 |  View | ViewGroup 
 ----- | ----- | ---------
 onMeasure| 空实现 | 未实现
 onLayout | 空实现 | 抽象方法
 onDraw   | 空实现 | 未实现

 

					


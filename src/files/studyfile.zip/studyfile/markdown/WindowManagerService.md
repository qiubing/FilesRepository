## WindowMangerService解析

### 1.简介
WindowManagerService是窗口管理员。Window是一个抽象的概念：

- 从用户的角度来讲，它是一个“界面”；
- 从SurfaceFlinger的角度来看，它是一个Layer，承载着和“界面”有关的数据和属性；
- 从WMS的角度来看，它是一个WindowState，用于管理和“界面”有关的数据和熟悉；

一个完整的窗口管理器，至少需要涉及以下元素：

1. WindowManagerService(WMS)

WMS也是系统服务的一部分，由SystemServer负责启动；

2. SurfaceFlinger

3. 有图形显示需求的程序

	- Application Window 普通应用程序申请显示的窗口
	- System Window 系统窗口，例如系统状态栏、壁纸
	- Sub Window 子窗口，受限于父窗口

4. InputManagerService（IMS）

WMS是派发系统按键和触摸消息这一“重任”的最佳人选。当IMS收到一个按键或者触摸事件，它需要找到一个最合适的“窗口”来处理消息。WMS是窗口管理者，因此是处理消息派发的最佳人选。

5. ActivityManagerService(AMS)

AMS是管理系统中所有Activity的“大总管”，而Activity的状态变化通常会带来“界面”上的改变。

6. Binder通信

无论是SurfaceFlinger，AMS还是应用进程，他们与WMS间的通信都是通过Binder来完成的。

### WMS包含的功能
WindowManagerService需要包含以下子功能：

- 窗口的添加与删除
 
当某个进程（无论是普通应用程序还是系统进程）有显式需求时，它可以请求WMS添加一个窗口，并在不需要显示时移除该窗口。

- 启动窗口

当我们增加一个新窗口时，在某些条件下需要添加一个“启动窗口”

- 窗口动画

当窗口间切换时，采用“窗口动画”可以加强UI特效，窗口动画是允许定制的。

- 窗口大小

Android系统支持显示不同尺寸大小的窗口，例如StatusBar就是屏幕最顶层的一条Bar，类似的还有对话框、悬浮窗等。

- 窗口层级

即Z-Order的调整是由WMS来完成的。

- 事件派发

事件派发也是WMS一个必不可少的功能。

![WMS设计](http://orbohk5us.bkt.clouddn.com/17-7-26/12218204.jpg)

### WMS，AMS与Activity间的关系

一个Activity在启动过程中，需要多个系统服务的支持，其中就包括AMS和WMS。

Activity运行在应用程序进程中，而AMS和WMS运行在SystemServer进程中，他们之间是通过Binder机制通信的。

WMS是实名Binder Server，WMS还需要对每个Activity提供另外一种匿名的实现，即IWindowSession。同样，每个应用程序也实现了一个匿名的Binder——W类，用于WMS回访应用进程的匿名Binder Server。

![](http://orbohk5us.bkt.clouddn.com/17-7-26/5977382.jpg)

当一个新的Activity被启动时，它首先需要在AMS中注册——此时AMS会在内部生成一个新的ActivityRecord来记录这个Activity；另外因为Activity是四大组件中专门用于UI显示的，所以WMS也会对它进行记录——以WindowState来表示。

WMS除了利用WindowState来保存一个“窗口”相关的信息外，还使用AppWindowToken来对应AMS中的一个ActivityRecord。

![](http://orbohk5us.bkt.clouddn.com/17-7-26/21876315.jpg)
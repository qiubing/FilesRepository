## WindowManagerService简介

### 1.概述
几个关键的类：

- Surface类：代表画布；
- WMS:添加Window的过程主要功能是添加Surface，管理所有的Surface布局，以及Z轴排序问题。
- SurfaceFinger：将应用UI绘制到frameBuffer(帧缓冲区),最终由硬件完成渲染到屏幕上。
- ActivityManagerService:管理系统四大组件以及进程管理，尤其是Activity的各种栈以及状态切换管理。
- WindowToken：一组相关窗口的容器，通常WindowToken是一个AppWindowToken，表示一个Activity的handle，用来显示窗口。
- APPWindowToken： 继承于WindowToken，用来描述一个特定的应用程序或者真实的Activity显示窗口。
- ActivityStackSupervisor：管理所有运行所有的ActivityStacks


WMS的类图：

![WMS类图](http://gityuan.com/images/wms/wms_relation.jpg)

- WMS继承于IWindowManager.Stub, 作为Binder服务端;
- WMS的成员变量mSessions保存着所有的Session对象,Session继承于IWindowSession.Stub, 作为Binder服务端;
- 成员变量mPolicy: 实例对象为PhoneWindowManager,用于实现各种窗口相关的策略;
- 成员变量mChoreographer: 用于控制窗口动画,屏幕旋转等操作;
- 成员变量mDisplayContents: 记录一组DisplayContent对象,这个跟多屏输出相关;
- 成员变量mTokenMap: 保存所有的WindowToken对象; 以IBinder为key,可以是IAppWindowToken或者其他Binder的Bp端;
	- 另一端情况:ActivityRecord.Token extends IApplicationToken.Stub
- 成员变量mWindowMap: 保存所有的WindowState对象;以IBinder为key, 是IWindow的Bp端;
	- 另一端情况: ViewRootImpl.W extends IWindow.Stub
- 一般地,每一个窗口都对应一个WindowState对象, 该对象的成员变量mClient用于跟应用端交互,成员变量mToken用于跟AMS交互。

### 2.WMS的初始化

1.SystemServer.startOtherServices

	private void startOtherServices() {
		 ......
		 wm = WindowManagerService.main(context, inputManager,
                    mFactoryTestMode != FactoryTest.FACTORY_TEST_LOW_LEVEL,
                    !mFirstBoot, mOnlyCore);
		.......
		wm.displayReady();
		......
		wm.systemReady();
	}

2.WindowManagerService.main

	public static WindowManagerService main(final Context context,
            final InputManagerService im,
            final boolean haveInputMethods, final boolean showBootMsgs,
            final boolean onlyCore) {
        final WindowManagerService[] holder = new WindowManagerService[1];
		// 在android.display线程中初始化WindowManagerService类
        DisplayThread.getHandler().runWithScissors(new Runnable() {
            @Override
            public void run() {
                holder[0] = new WindowManagerService(context, im,
                        haveInputMethods, showBootMsgs, onlyCore);
            }
        }, 0);
        return holder[0];
    }

DisplayThread类定义如下：

	public final class DisplayThread extends ServiceThread {
    private static DisplayThread sInstance;
    private static Handler sHandler;

    private DisplayThread() {
		// 线程名字为android.display，线程优先级为THREAD_PRIORITY_DISPLAY
        super("android.display", android.os.Process.THREAD_PRIORITY_DISPLAY, false /*allowIo*/);
    }

    private static void ensureThreadLocked() {
        if (sInstance == null) {
            sInstance = new DisplayThread();
            sInstance.start();
            sInstance.getLooper().setTraceTag(Trace.TRACE_TAG_ACTIVITY_MANAGER);
            sHandler = new Handler(sInstance.getLooper());
        }
    }

    public static DisplayThread get() {
        synchronized (DisplayThread.class) {
            ensureThreadLocked();
            return sInstance;
        }
    }

    public static Handler getHandler() {
        synchronized (DisplayThread.class) {
            ensureThreadLocked();
            return sHandler;
        }
    }
	}

3.WindowManagerService的构造函数

	    private WindowManagerService(Context context, InputManagerService inputManager,
            boolean haveInputMethods, boolean showBootMsgs, boolean onlyCore) {
        mContext = context;
        mOnlyCore = onlyCore;
		......

        mInputManager = inputManager; // Must be before createDisplayContentLocked.
        
		// 将PhoneWindowPolicy添加到本地服务中
        LocalServices.addService(WindowManagerPolicy.class, mPolicy);

		// 获取DisplayManager服务
        mDisplayManager = (DisplayManager)context.getSystemService(Context.DISPLAY_SERVICE);
        mDisplays = mDisplayManager.getDisplays();
        for (Display display : mDisplays) {
			// 创建DisplayContent
            createDisplayContentLocked(display);
        }

        licy);

		// 初始化PowManager
        mPowerManager = (PowerManager)context.getSystemService(Context.POWER_SERVICE);
        
        // 初始化AppTransition
        mAppTransition = new AppTransition(context, this);
        //初始化ActivityManagerService
        mActivityManager = ActivityManagerNative.getDefault();
        
        mAppOps = (AppOpsManager)context.getSystemService(Context.APP_OPS_SERVICE);
        
        // 初始化窗口动画
        mAnimator = new WindowAnimator(this);

        
        LocalServices.addService(WindowManagerInternal.class, new LocalService());
        
		// 初始化窗口策略
		initPolicy();
		......
    }

	final WindowManagerPolicy mPolicy = new PhoneWindowManager();

4.WMS.initPolicy

	private void initPolicy() {
		// 在android.ui线程初始化Policy策略，线程的优先级是THREAD_PRIORITY_FOREGROUND
        UiThread.getHandler().runWithScissors(new Runnable() {
            @Override
            public void run() {
				// 用WindowManagerPolicyThread来保存当前线程和Looper
                WindowManagerPolicyThread.set(Thread.currentThread(), Looper.myLooper());
				// 初始化WindowManagerPolicy策略
                mPolicy.init(mContext, WindowManagerService.this, WindowManagerService.this);
            }
        }, 0);
    }

5.PhoneWindowManager.init

PhoneWindowManager是Android手机UI的WindowManagerPolicy策略实现。

	public void init(Context context, IWindowManager windowManager, WindowManagerFuncs windowManagerFuncs) {
		mContext = context;
        mWindowManager = windowManager;
        mWindowManagerFuncs = windowManagerFuncs;
		mWindowManagerInternal = LocalServices.getService(WindowManagerInternal.class);
        mActivityManagerInternal = LocalServices.getService(ActivityManagerInternal.class);
        mInputManagerInternal = LocalServices.getService(InputManagerInternal.class);
        mDreamManagerInternal = LocalServices.getService(DreamManagerInternal.class);
		
		// 运行在android.ui线程中
		mHandler = new PolicyHandler();
		
	}

在前面的方法中，主要是构造WMS，构造完成后，将执行WMS.displayReady()方法。


6.WMS.displayReady
	
	public void displayReady() {
        for (Display display : mDisplays) {
            displayReady(display.getDisplayId());
        }

        synchronized(mWindowMap) {
            final DisplayContent displayContent = getDefaultDisplayContentLocked();
            readForcedDisplayPropertiesLocked(displayContent);
            mDisplayReady = true;
        }

        try {
            mActivityManager.updateConfiguration(null);
        } catch (RemoteException e) {
        }

        synchronized(mWindowMap) {
            mIsTouchDevice = mContext.getPackageManager().hasSystemFeature(
                    PackageManager.FEATURE_TOUCHSCREEN);
            configureDisplayPolicyLocked(getDefaultDisplayContentLocked());
        }

        try {
            mActivityManager.updateConfiguration(null);
        } catch (RemoteException e) {
        }

        updateCircularDisplayMaskIfNeeded();
    }

7.WMS.systemReady

	public void systemReady() {
        mPolicy.systemReady();
    }

8.PhoneWindowManager.systemReady

	public void systemReady() {
        mKeyguardDelegate = new KeyguardServiceDelegate(mContext,
                this::onKeyguardShowingStateChanged);
        mKeyguardDelegate.onSystemReady();

        readCameraLensCoverState();
        updateUiMode();
        boolean bindKeyguardNow;
        synchronized (mLock) {
            updateOrientationListenerLp();
            mSystemReady = true;
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    updateSettings();
                }
            });

            bindKeyguardNow = mDeferBindKeyguard;
            if (bindKeyguardNow) {
                mDeferBindKeyguard = false;
            }
        }

        if (bindKeyguardNow) {
            mKeyguardDelegate.bindService(mContext);
            mKeyguardDelegate.onBootCompleted();
        }
		//系统手势准备好了
        mSystemGestures.systemReady();
        mImmersiveModeConfirmation.systemReady();
    }

### 3.小结

在WMS的初始化过程中，涉及到三个线程：SystemServer主线程、“android.display”、“android.ui”，整个过程是采用阻塞方式执行的（Handler.runWithScissors），其中WMS的mH的Looper运行在“android.display”线程中。

![WMS启动流程](http://gityuan.com/images/wms/wms_startup.jpg)


	




	
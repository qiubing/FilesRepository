## Window属性

[TOC]

### 1.窗口类型与层级

Android支持的窗口类型很多，可以化为三大类：

- Application Window 应用窗口
- System Window 系统窗口
- Sub Window 子窗口

窗口类型定义在WindowManager.java类中，WindowManager接口简介：

> WindowManager是一个接口，用来与应用交互的。通过Context.getSystemService(Context.WINDOW_SERVICE)获取WindowManager服务，每个WindowManger都绑定到一个特定的Display。为了获取特定Display对应的WindowManger，需要通过Context#createDisplayContext方法获取一个Context，然后通过Context来获取对应的WindowManager服务。

在Display上显示一个窗口的最简单方法是创建一个Presentation，Presentation将自动获取Display对应的WindowManager和Context。


#### 1.1 Application Window

普通应用窗口是普通顶级应用窗口，其取值从1到99。该类型窗口的Token必须设置为所属Activity的Token。

Type | 描述
-----| -------
FIRST_APPLICATION_WINDOW = 1 | 应用程序窗口类型的起始值 
TYPE_BASE_APPLICATION   = 1 |  应用程序窗口类型的基础值，其他窗口类型以此为基础
TYPE_APPLICATION        = 2 | 普通应用程序的窗口类型 
TYPE_APPLICATION_STARTING = 3 | 应用程序的启动窗口类型，它不能由应用程序本身使用，而是Android系统为应用程序启动前设计的窗口，当真正的窗口启动后就消失了
LAST_APPLICATION_WINDOW = 99 | 应用程序窗口类型的最大值

#### 1.2 Sub-Window
Sub Window是依附到其他类型的窗口，该类型的窗口token必须是依附窗口的Token。其取值从1000到1999。

Type | 描述
----- | -------
FIRST_SUB_WINDOW = 1000 | 子窗口类型的起始值
TYPE_APPLICATION_ATTACHED_DIALOG = FIRST_SUB_WINDOW + 3 | Dialog子窗口
LAST_SUB_WINDOW = 1999 | 子窗口类型的结束值

#### 1.3 System Window
系统窗口是特殊类型的窗口，用来给系统特定用途使用。不能被应用程序直接使用。

系统窗口类型的取值从2000到2999。

Type | 描述
------ | ------
FIRST_SYSTEM_WINDOW     = 2000 | 系统窗口开始
TYPE_STATUS_BAR         = FIRST_SYSTEM_WINDOW | 系统状态栏窗口
TYPE_SEARCH_BAR         = FIRST_SYSTEM_WINDOW+1 | 搜索条窗口
TYPE_PHONE              = FIRST_SYSTEM_WINDOW+2 | 通话窗口，位于状态栏之下，应用程序窗口之上
TYPE_INPUT_METHOD       = FIRST_SYSTEM_WINDOW+11 | 输入法窗口
LAST_SYSTEM_WINDOW      = 2999 | 系统窗口结束


当某个进程向WMS申请一个窗口时，需要指定所需要的窗口类型。然后WMS根据用户申请的窗口类型以及当前系统中已有窗口的情况来给它分配一个最终的“层级值”。

数值越大的窗口，其在WMS中的优先级越高，最终在屏幕上显示就越靠近用户。

### 2.窗口的层级值计算


### 3.窗口策略（Window Policy）

窗口策略应用到WMS中，则代表了Android显示系统所遵循的统一的**窗口显示规则**。

在Android源码中，与Window Policy相关的类主要有两个，即WindowManagerPolicy，PhoneWindowManager。

WindowManagerPolicy是窗口管理策略的接口类，它定义了一个窗口策略所要遵循的通用规范以及需要提供的相关接口。PhoneWindowManager是具体的窗口管理策略，这里为手机窗口显示。



### 4.窗口属性（LayoutParams）
窗口的属性放置在WindowManager.LayoutParams中，其中有几个重要的变量。
#### 4.1 Type
	public int type;
窗口类型，有三种窗口类型：Application Window、Sub Window、System Window。

### 4.2 Flags
 	 public int flags;
窗口标志，默认值是0。flags支持的值有

 Flags | 描述
 ------| --------
FLAG_ALLOW_LOCK_WHILE_SCREEN_ON | 只要此窗口可见，即便屏幕处于开启状态也允许锁屏
FLAG_KEEP_SCREEN_ON | 只要这个窗口可见，屏幕就亮着
FLAG_FULLSCREEN | 影藏所有的屏幕装饰窗口，如StatusBar。对于视频播放器之类的应用程序是很有用的
FLAG_SHOW_WHEN_LOCKED | 使窗口能在锁屏窗口之上显示
FLAG_TURN_SCREEN_ON | 窗口显示时将屏幕点亮
FLAG_DISMISS_KEYGUARD | 设置这个标志可以解除屏幕锁，只要这个锁不是安全锁

使用方法：

	Window w = activity.getWindow();
	w.setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED，WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)

4.3 systemuiVisibility
	
		/**
         * Control the visibility of the status bar.
         *
         * @see View#STATUS_BAR_VISIBLE
         * @see View#STATUS_BAR_HIDDEN
         */
        public int systemUiVisibility;
控制着状态栏的可见性。systemuiVisibility的值定义在View类中，常见的取值如下：

SYSTEM_UI_FLAG_VISIBLE ： View视图请求显示System UI

SYSTEM_UI_FLAG_LOW_PROFILE： View请求进入“low profile”模式

SYSTEM_UI_FLAG_FULLSCREEN ： 整个View将进入全屏模式下，它和WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN的视觉效果基本一致。如果是暂时的全屏显示需求，可以采用SYSTEM_UI_FLAG_FULLSCREEN，而如果长时间的全屏显示，建议使用Window的FLAG_LAYOUT_IN_SCREEN标志

我们只能对一个View而不是Window设置它的systemUiVisibility。如果希望某个Activity中的整颗View树都使用同一个systemUIVisibility，可以在Activity的onCreate方法中，加入类似代码,在调用setContentView之前：

	int newVis = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
	getWindow().getDecorView().setSystemVisibility(newVis)；

默认情况下，系统是从StatusBar下面的部分开始给应用程序做UI布局的。SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN标志会保留包括StatusBar在内的系统窗口，同时会让View全屏显示。也就说，你的View页面布局是从屏幕的(0,0)开始，但屏幕上方的一部分内容会被StatusBar所覆盖。



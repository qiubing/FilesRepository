## 窗口的添加
[TOC]

Android系统中的窗口类型主要有来两类：一是由系统进程管理的，称之为“系统窗口”，二是应用程序产生的，用于显示UI界面的“应用窗口”。

### 系统窗口的添加
系统窗口的添加以StatusBar的添加为例来说。

StatusBar窗口的添加是从addStatusBarWindow开始的，在PhoneStatusBar类中定义。

1.PhoneStatusBar.addStatusBarWindow
	
	private void addStatusBarWindow() {
		// 构建StatusBarView
        makeStatusBarView();
        mStatusBarWindowManager = new StatusBarWindowManager(mContext);
        mRemoteInputController = new RemoteInputController(mStatusBarWindowManager,
                mHeadsUpManager);
		// 将StatusBarView添加到WMS中
        mStatusBarWindowManager.add(mStatusBarWindow, getStatusBarHeight());
    }

2.PhoneStatusBar.makeStatusBarView

	protected PhoneStatusBarView makeStatusBarView() {
		final Context context = mContext;
		// 更新屏幕的尺寸大小
		updateDisplaySize(); // populates mDisplayMetrics
        // 更新资源
		updateResources();
		// 从xml文件中构建出StatusBarView
		inflateStatusBarWindow(context);

		mStatusBarWindow.setService(this);
        mStatusBarWindow.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                checkUserAutohide(v, event);
                checkRemoteInputOutside(event);
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (mExpandedVisible) {
                        animateCollapsePanels();
                    }
                }
                return mStatusBarWindow.onTouchEvent(event);
            }
        });

		mNotificationPanel = (NotificationPanelView) mStatusBarWindow.findViewById(
                R.id.notification_panel);
        mNotificationPanel.setStatusBar(this);
        mNotificationPanel.setGroupManager(mGroupManager);

        mStatusBarView = (PhoneStatusBarView) mStatusBarWindow.findViewById(R.id.status_bar);
        mStatusBarView.setBar(this);
        mStatusBarView.setPanel(mNotificationPanel);
		
		return mStatusBarView;
	}

该函数的主要功能是从xml文件构建出StatusBarView。

	protected void inflateStatusBarWindow(Context context) {
        mStatusBarWindow = (StatusBarWindowView) View.inflate(context,
                R.layout.super_status_bar, null);
    }
	
3.StatusBarWindowManager.add

	public void add(View statusBarView, int barHeight) {
		// 构建LayoutParams参数
        mLp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                barHeight,
                WindowManager.LayoutParams.TYPE_STATUS_BAR,//窗口类型为系统窗口
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE //不需要获取焦点 
                        | WindowManager.LayoutParams.FLAG_TOUCHABLE_WHEN_WAKING
                        | WindowManager.LayoutParams.FLAG_SPLIT_TOUCH
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
                PixelFormat.TRANSLUCENT);
        mLp.flags |= WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        mLp.gravity = Gravity.TOP;
        mLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;//硬件加速标志
        mLp.setTitle("StatusBar");//设置标题为StatusBar
        mLp.packageName = mContext.getPackageName();//获取包名
        mStatusBarView = statusBarView;//设置StatusBarView
        mBarHeight = barHeight;//设置状态栏的高度
        mWindowManager.addView(mStatusBarView, mLp);//将StatusBarView添加到WMS中
        mLpChanged = new WindowManager.LayoutParams();
        mLpChanged.copyFrom(mLp);//获取修改后的LayoutParams
    }
该方法的主要作用是添加StatusBarView到WMS中。

4.WindowManagerImpl.addView

WindowManagerImpl实现了WindowManager接口，WindowManagerImpl提供更低层次的与系统窗口管理者交互，该交互操作是与特定的Context，Display和parent窗口是相关的。WindowManagerImpl是与当前应用紧密相关的。

WindowManagerImpl同样实现了ViewManager接口，允许你添加任何View的子类作为屏幕上的顶层窗口。另外WindowManager指定LayoutParams参数，用来指示该窗口是如何显示在屏幕上。

应用通常不会直接使用WindowManager，而是依赖更高层次的元素例如Activity和Dialog。

需要注意的是通过android.app.Activity#getWindowManager获取的WindowManager只能添加与Activity相关联的Window，而不能添加任意的Window。

	private final WindowManagerGlobal mGlobal = WindowManagerGlobal.getInstance();
	public WindowManagerImpl(Context context) {
        this(context, null);
    }

    private WindowManagerImpl(Context context, Window parentWindow) {
        mContext = context;
        mParentWindow = parentWindow;
    }

	public void addView(@NonNull View view, @NonNull ViewGroup.LayoutParams params) {
        applyDefaultToken(params);
		// 通过WindowManagerGlobal的addView方法来添加View
        mGlobal.addView(view, params, mContext.getDisplay(), mParentWindow);
    }

5.WindowManagerGlobal.addView

WindowManagerGlobal类提供更低层次的与系统窗口管理者交互，该交互操作是与特定的Context相关的。

	    public void addView(View view, ViewGroup.LayoutParams params,
            Display display, Window parentWindow) {
		// 一系列参数检查
        if (view == null) {
            throw new IllegalArgumentException("view must not be null");
        }
		// 当前Context关联的Display设备
        if (display == null) {
            throw new IllegalArgumentException("display must not be null");
        }
        if (!(params instanceof WindowManager.LayoutParams)) {
            throw new IllegalArgumentException("Params must be WindowManager.LayoutParams");
        }
		
		// 获取WindowManager.LayoutParams参数
        final WindowManager.LayoutParams wparams = (WindowManager.LayoutParams) params;

        if (parentWindow != null) {
			// 如果父窗口不为null，则根据参数调整父窗口
            parentWindow.adjustLayoutParamsForSubWindow(wparams);
        } else {
       		// 没有父窗口，硬件加速从应用加速设置上获取
            final Context context = view.getContext();
            if (context != null
                    && (context.getApplicationInfo().flags
                            & ApplicationInfo.FLAG_HARDWARE_ACCELERATED) != 0) {
                wparams.flags |= WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
            }
        }

        ViewRootImpl root;
        View panelParentView = null;

        ......
		// 查找以前是否已经添加过这个View对象
        int index = findViewLocked(view, false);
        if (index >= 0) {// 已经添加过了，禁止重复操作
            if (mDyingViews.contains(view)) {
                    mRoots.get(index).doDie();
                } else {
                    throw new IllegalStateException("View " + view
                            + " has already been added to the window manager.");
                }
         }
		// 窗口类型为子窗口类型
        if (wparams.type >= WindowManager.LayoutParams.FIRST_SUB_WINDOW &&
                    wparams.type <= WindowManager.LayoutParams.LAST_SUB_WINDOW) {
                final int count = mViews.size();
                for (int i = 0; i < count; i++) {
                    if (mRoots.get(i).mWindow.asBinder() == wparams.token) {
                        panelParentView = mViews.get(i);
                    }
                }
         }
		//构建ViewRootImpl对象
        root = new ViewRootImpl(view.getContext(), display);
		// 设置View的参数
        view.setLayoutParams(wparams);

         mViews.add(view);//将View添加到Views集合中
         mRoots.add(root);// 将root添加到ViewRootImpl集合中
         mParams.add(wparams);//将wparams参数添加到LayoutParams集合中


         try {
			// 调用ViewRootImpl的addView方法
             root.setView(view, wparams, panelParentView);
            } catch (RuntimeException e) {
                .....
            }
        }
    }
	
可以看到，在该方法中，首先查找是否已经添加过该View，如果已经添加过了，则直接返回。否则构建ViewRootImpl对象，并把View、ViewRootImpl以及LayoutParams添加到相应的集合中，最后调用ViewRootImpl的setView方法。

6.ViewRootImpl.setView

	public void setView(View view, WindowManager.LayoutParams attrs, View panelParentView) {
		synchronized (this) {
            if (mView == null) {
                mView = view;// 一个ViewRootImpl对应一颗View Tree
			.....
			// 发起Layout请求
			requestLayout();

			try {
                    ........
					// 调用Session接口
                    res = mWindowSession.addToDisplay(mWindow, mSeq, mWindowAttributes,
                            getHostVisibility(), mDisplay.getDisplayId(),
                            mAttachInfo.mContentInsets, mAttachInfo.mStableInsets,
                            mAttachInfo.mOutsets, mInputChannel);
                } catch (RemoteException e) {
					.....
				}
				
	}

在将View添加打WMS之前，需要执行一次layout，也就是requestLayout。因为WMS除了管理窗口外，还负责各种事件的派发，所以在向WMS注册前应用程序要确保这颗View树已经做好了接收事件的准备。

ViewRoot起到了中介的作用，作为整颗View树的“管理者”，它同时也担负着与WMS进行IPC通信的重任。具体而言，就是通过IWindowSession建立起双方通信的桥梁。

mWindowSession是在ViewRootImpl的构造函数中创建的：

	public ViewRootImpl(Context context, Display display) {
        mContext = context;
        mWindowSession = WindowManagerGlobal.getWindowSession();
        mDisplay = display;
		// 获取Window对象，继承自IWindow.Stub接口
		mWindow = new W(this);
	}

	public static IWindowSession getWindowSession() {
        synchronized (WindowManagerGlobal.class) {
            if (sWindowSession == null) {
                try {
                    InputMethodManager imm = InputMethodManager.getInstance();
                    IWindowManager windowManager = getWindowManagerService();
					//通过openSession打开到对端的连接
                    sWindowSession = windowManager.openSession(
                            new IWindowSessionCallback.Stub() {
                                @Override
                                public void onAnimatorScaleChanged(float scale) {
                                    ValueAnimator.setDurationScale(scale);
                                }
                            },
                            imm.getClient(), imm.getInputContext());
                } catch (RemoteException e) {
                    throw e.rethrowFromSystemServer();
                }
            }
            return sWindowSession;
        }
    }

	static class W extends IWindow.Stub {
        private final WeakReference<ViewRootImpl> mViewAncestor;
        private final IWindowSession mWindowSession;

        W(ViewRootImpl viewAncestor) {
            mViewAncestor = new WeakReference<ViewRootImpl>(viewAncestor);
            mWindowSession = viewAncestor.mWindowSession;
        }
	}

通过mWindowSession的addToDisplay方法，将最终调用到服务端实现Session.java中的函数。

7.Session.addToDisplay

	public int addToDisplay(IWindow window, int seq, WindowManager.LayoutParams attrs,
            int viewVisibility, int displayId, Rect outContentInsets, Rect outStableInsets,
            Rect outOutsets, InputChannel outInputChannel) {
		// 调用WMS的addWindow方法
        return mService.addWindow(this, window, seq, attrs, viewVisibility, displayId,
                outContentInsets, outStableInsets, outOutsets, outInputChannel);
    }
参数IWindow是WMS回调ViewRoot时需要用到的。

8.WindowManagerService.addWindow

WMS并不关心View树所表达的具体内容，它只要知道各应用进程显示界面的大小、“层级值”。(这些信息已经包含在WindowManager.LayoutParams中)。


	public int addWindow(Session session, IWindow client, int seq,
            WindowManager.LayoutParams attrs, int viewVisibility, int displayId,
            Rect outContentInsets, Rect outStableInsets, Rect outOutsets,
            InputChannel outInputChannel) {
		// 1.权限检查
		int[] appOp = new int[1];
        int res = mPolicy.checkAddPermission(attrs, appOp);
        if (res != WindowManagerGlobal.ADD_OKAY) {
            return res;
        }
		// 适用于Sub Window
		WindowState attachedWindow = null;
		final int type = attrs.type;//窗口类型
		synchronized(mWindowMap) {
			// 2.子窗口
			if (type >= FIRST_SUB_WINDOW && type <= LAST_SUB_WINDOW) {
				// 寻找父窗口
                attachedWindow = windowForClientLocked(null, attrs.token, false);
			}

			.....
			// 用来标识后面是否有添加Token操作
			boolean addToken = false;
            WindowToken token = mTokenMap.get(attrs.token);
            AppWindowToken atoken = null;

			// 创建WindowState
			WindowState win = new WindowState(this, session, client, token,
                    attachedWindow, appOp[0], seq, attrs, viewVisibility, displayContent);

			if (win.mDeathRecipient == null) {
              // 客户端已经死亡了，不要继续往下执行
                Slog.w(TAG_WM, "Adding window client " + client.asBinder()
                        + " that is dead, aborting.");
                return WindowManagerGlobal.ADD_APP_EXITING;
            }
			// 3.调整Window属性
			mPolicy.adjustWindowParamsLw(win.mAttrs);
			res = mPolicy.prepareAddWindowLw(win, attrs);
			if (res != WindowManagerGlobal.ADD_OKAY) {
                return res;
            }
			
			// 4.新增Token元素
			if (addToken) {
                mTokenMap.put(attrs.token, token);
            }

			win.attach();
            mWindowMap.put(client.asBinder(), win);
			// 5.将Windows按顺序排列
			addWindowToListInOrderLocked(win, true);

			// 6.分配层级值
			mLayersController.assignLayersLocked(displayContent.getWindowList());
		}
		return res;
	}
	
	// 映射IWindow Binder到服务端的WindowState
	final HashMap<IBinder, WindowState> mWindowMap = new HashMap<>();
	
	// 映射Token Binder到WindowToken
	final HashMap<IBinder, WindowToken> mTokenMap = new HashMap<>();

可以看到，该函数完成了以下功能：

1. 首先对用户的窗口权限进行检查；
2. 判断是否已经添加了该Window；
3. 调整Window属性；
4. 添加Token元素
5. 将Window按顺序排列
6. 分配层级值

这里有几个Token变量需要区分：

- WindowToken： 用来在WMS中表示一系列相关的窗口，通常它是一个AppWindowToken，AppWindowToken继承于WindowToken。
- mWindowMap：保存的是IWindow与WindowState之间的映射关系；
- mTokenMap：保存的是ActivityRecord与WindowToken之间的映射关系；

![](http://orbohk5us.bkt.clouddn.com/17-7-27/80851438.jpg)

 整体的流程如下：

	WindowManagerImpl.addView
		WindowManagerGlobal.addView
			ViewRootImpl.setView
				Session.addToDisplay
					WindowManagerService.addWindow

### 应用窗口的添加
Activity从启动到最终在屏幕上显示出来，分别需要经历onCreate->onStart——>onResume三个状态迁移。其中onResume是当界面即将可见时才会调用的，紧接着ActivityThread就会通过WindowManagerImpl来把应用程序窗口添加到系统中。

1.ActivityThread.handleResumeActivity

	final void handleResumeActivity(IBinder token,
            boolean clearHide, boolean isForward, boolean reallyResume, int seq, String reason) {
		// 根据Token取出相应的ActivityClientRecord
        ActivityClientRecord r = mActivities.get(token);
        .....

		// 执行Activity的onResume方法
        r = performResumeActivity(token, clearHide, reason);

        if (r != null) {
            final Activity a = r.activity;
			......
            final int forwardBit = isForward ?
                    WindowManager.LayoutParams.SOFT_INPUT_IS_FORWARD_NAVIGATION : 0;
             ......
			// 如果Window还没有被添加到WindowManger中，并且该Activity还没有被finish掉，则添加该Window。
            boolean willBeVisible = !a.mStartedActivity;
            if (!willBeVisible) {
                try {
                    willBeVisible = ActivityManagerNative.getDefault().willActivityBeVisible(
                            a.getActivityToken());
                } catch (RemoteException e) {
                    throw e.rethrowFromSystemServer();
                }
            }
            if (r.window == null && !a.mFinished && willBeVisible) {
				// 获取该Activity所包含的Window
                r.window = r.activity.getWindow();
				// 获取该Window里的装饰DecorView
                View decor = r.window.getDecorView();
				// 设置装饰View的可见性
                decor.setVisibility(View.INVISIBLE);
				// 获取的是WindowManagerImpl
                ViewManager wm = a.getWindowManager();
				// 获取窗口的参数
                WindowManager.LayoutParams l = r.window.getAttributes();
				// 将DecorView赋值给Activity的DecorView
                a.mDecor = decor;
				// 设置窗口的类型为应用窗口
                l.type = WindowManager.LayoutParams.TYPE_BASE_APPLICATION;
                l.softInputMode |= forwardBit;

                if (r.mPreserveWindow) {
                    a.mWindowAdded = true;
                    r.mPreserveWindow = false;
                    ViewRootImpl impl = decor.getViewRootImpl();
                    if (impl != null) {
                        impl.notifyChildRebuilt();
                    }
                }
				// 窗口可见，并且窗口还未添加
                if (a.mVisibleFromClient && !a.mWindowAdded) {
                    a.mWindowAdded = true;
					// 将DecorView添加到WindowManagerService中
                    wm.addView(decor, l);
                }

            
            } else if (!willBeVisible) {
               .....
            }

            ......
            mNumVisibleActivities++;
            if (r.activity.mVisibleFromClient) {
				// 使Activity可见
                r.activity.makeVisible();
             }
           
            // Tell the activity manager we have resumed.
            if (reallyResume) {
                try {
					// 告诉ActivityManager，Activity已经Resume了
                    ActivityManagerNative.getDefault().activityResumed(token);
                } catch (RemoteException ex) {
                    throw ex.rethrowFromSystemServer();
                }
            }

        } else {
        	// 发生异常了，结束Activity
            try {
                ActivityManagerNative.getDefault()
                    .finishActivity(token, Activity.RESULT_CANCELED, null,
                            Activity.DONT_FINISH_TASK_WITH_ACTIVITY);
            } catch (RemoteException ex) {
                throw ex.rethrowFromSystemServer();
            }
        }
    }

在该方法中，首先执行Activity的onResume方法，然后获取该Activity所包含的Window，并将该Window所包含的DecorView通过WindowManagerImpl的addView方法添加到WMS中。详情见前面的分析。


### 相关类图

![](http://orbohk5us.bkt.clouddn.com/17-7-26/83859717.jpg)
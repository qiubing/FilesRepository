## 基本命令

1.查看当前运行的模拟器

	adb devices 

2.将电脑的文件复制到模拟器中
	
	adb push d:\abc.txt /sdcard

3.将手机模拟器中的文件拷贝到电脑中
  
	adb pull /sdcard/xyz.txt d:\
4.启动模拟器的shell窗口
  
	adb shell
5.安装和卸载APK程序
  
	adb install [-r] [-s] <file>
  	参数-r表示重装，-s表示把应用安装到SD卡上，默认是安装到内部存储器。
  	adb uninstall [-k] <package>
  	参数-k表示只删除该应用程序，但保留该程序所用的数据和缓存目录。

6.紧急刷机模式

	adb reboot edload

7.查看应用的包名

	adb shell dumpsys package > a.txt
	adb shell ps | grep u0
8.启动ADB服务

	adb start-server
9.停止ADB服务

	adb kill-server

## logcat

- logcat -c 清空log并退出
- logcat -t <count> 打印最近的count
- logcat -v <format>， 格式化输出Log，其中format有如下可选值：
	- brief — 显示优先级/标记和原始进程的PID (默认格式)
	- process — 仅显示进程PID
	- tag — 仅显示优先级/标记
	- thread — 仅显示进程：线程和优先级/标记
	- raw — 显示原始的日志信息，没有其他的元数据字段
	- time — 显示日期，调用时间，优先级/标记，PID
	- long —显示所有的元数据字段并且用空行分隔消息内容

1.抓取main的log日志

	adb logcat -c 
	adb logcat -b main -v time >.\main.txt

2.抓取radio的log日志

	adb logcat -b radio -c
	adb logcat -b radio -v time >.\radio.txt

3.抓取System的log日志

	adb logcat -b system -c
	adb logcat -b system -v time >.\system.txt

4.抓取event的log日志

	adb logcat -b events -c
	adb logcat -b events -v time >.\event.txt

5.抓取Crash的log日志

	adb logcat -c
	adb logcat -b crash -v threadtime >.\crash.txt
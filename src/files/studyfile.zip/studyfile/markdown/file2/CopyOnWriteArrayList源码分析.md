## CopyOnWriteArrayList源码分析

[TOC]

### 概述

CopyOnWriteArrayList是线程安全的ArrayList，所有的可变操作，如add、set、remove等都是通过复制一份原始相关数组来实现的。


### 构造函数
```
public CopyOnWriteArrayList() {
        setArray(new Object[0]);
    }


    /**
     * Sets the array.
     */
    final void setArray(Object[] a) {
        array = a;
    }

    /** The array, accessed only via getArray/setArray. */
    // 注意array被Volatile关键字修饰
    private transient volatile Object[] array;
    
    
    /**
     * Creates a list holding a copy of the given array.
     *
     * @param toCopyIn the array (a copy of this array is used as the
     *        internal array)
     * @throws NullPointerException if the specified array is null
     */
    public CopyOnWriteArrayList(E[] toCopyIn) {
        setArray(Arrays.copyOf(toCopyIn, toCopyIn.length, Object[].class));
    }

```

### 添加元素
```
    /**
     * Appends the specified element to the end of this list.
     *
     * @param e element to be appended to this list
     * @return {@code true} (as specified by {@link Collection#add})
     */
    public boolean add(E e) {
        //获取该集合的可重入锁
        final ReentrantLock lock = this.lock;
        //锁定
        lock.lock();
        try {
            Object[] elements = getArray();
            int len = elements.length;
            //拷贝一份原始的数据，并将数组的容量增加1，因为是添加元素
            Object[] newElements = Arrays.copyOf(elements, len + 1);
            //将元素添加到新数组的末尾
            newElements[len] = e;
            //更新元素数组为新数组
            setArray(newElements);
            return true;
        } finally {
            //释放锁
            lock.unlock();
        }
    }
    
    /** The lock protecting all mutators */
    // 可重入锁
    final transient ReentrantLock lock = new ReentrantLock();
    
    /**
     * Gets the array.  Non-private so as to also be accessible
     * from CopyOnWriteArraySet class.
     */
    final Object[] getArray() {
        return array;
    }
    
    /**
     * Sets the array.
     */
    final void setArray(Object[] a) {
        array = a;
    }
```

### 获取元素

```
public E get(int index) {
        return get(getArray(), index);
    }
    
private E get(Object[] a, int index) {
        return (E) a[index];
    }
```

### 移除元素

```
    /**
     * Removes the element at the specified position in this list.
     * Shifts any subsequent elements to the left (subtracts one from their
     * indices).  Returns the element that was removed from the list.
     *
     * @throws IndexOutOfBoundsException {@inheritDoc}
     */
    public E remove(int index) {
        //获取可重入锁
        final ReentrantLock lock = this.lock;
        lock.lock();
        try {
            //获取原始数据
            Object[] elements = getArray();
            int len = elements.length;
            //获取需要删除的元素
            E oldValue = get(elements, index);
            int numMoved = len - index - 1;
            //删除的是最后一个元素
            if (numMoved == 0)
                //先拷贝原来的数组元素，再更新新的数组元素
                setArray(Arrays.copyOf(elements, len - 1));
            else {
                //创建一个新的数组
                Object[] newElements = new Object[len - 1];
                System.arraycopy(elements, 0, newElements, 0, index);
                System.arraycopy(elements, index + 1, newElements, index,
                                 numMoved);
                setArray(newElements);
            }
            return oldValue;
        } finally {
            //释放锁
            lock.unlock();
        }
    }
```

### 总结

CopyOnWriteArrayList的缺点，就是修改代价十分昂贵，每次修改都伴随着一次的数组复制；

但同时优点也十分明显，就是在并发下不会产生任何的线程安全问题，也就是绝对的线程安全，这也是为什么我们要使用CopyOnWriteArrayList的原因。


随着CopyOnWriteArrayList中元素的增加，CopyOnWriteArrayList的修改代价将越来越昂贵，因此，CopyOnWriteArrayList适用于**读操作远多于修改操作的并发场景中**。

- 读写分离

  我们读取CopyOnWriteArrayList的时候读取的是CopyOnWriteArrayList中的Object[] array，但是修改的时候，操作的是一个新的Object[] array，读和写操作的不是同一个对象，这就是读写分离。



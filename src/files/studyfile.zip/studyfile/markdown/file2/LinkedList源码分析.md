## LinkedList源码分析
[TOC]

Linked是基于**双向链表**实现的。

### 构造方法
```
    /**
     * Constructs an empty list.
     */
    public LinkedList() {
    }
```

### 添加元素
```
    /**
     * 添加一个元素到列表的末尾
     * 该方法等价于addLast
     *
     * @param e element to be appended to this list
     * @return {@code true} (as specified by {@link Collection#add})
     */
    public boolean add(E e) {
        linkLast(e);
        return true;
    }
    
    /**
    * 将元素e添加为最后一个元素
    */
    void linkLast(E e) {
        //指向最后一个节点
        final Node<E> l = last;
        //创建一个新的节点
        final Node<E> newNode = new Node<>(l, e, null);
        //让last指针指向新的节点
        last = newNode;
        //如果l为null，则说明这是第一个添加的元素，将first指向新的节点
        //否则，将l的next指针指向新的节点
        if (l == null)
            first = newNode;
        else
            l.next = newNode;
        //将链表元素的数量加1
        size++;
        modCount++;
    }
    
    //指向第一个节点
    transient Node<E> first;
    
    //指向最后一个节点
    transient Node<E> last;
    
    //双向链表
    private static class Node<E> {
        E item;//节点元素值
        Node<E> next;//指向下一个节点
        Node<E> prev;//指向前一个节点

        Node(Node<E> prev, E element, Node<E> next) {
            this.item = element;
            this.next = next;
            this.prev = prev;
        }
    }
    
    
    /**
     * Inserts the specified element at the specified position in this list.
     * Shifts the element currently at that position (if any) and any
     * subsequent elements to the right (adds one to their indices).
     *
     * @param index index at which the specified element is to be inserted
     * @param element element to be inserted
     * @throws IndexOutOfBoundsException {@inheritDoc}
     */
    public void add(int index, E element) {
        checkPositionIndex(index);
        //如果index等于列表的大小，则等同于add(E)方法
        //否则在指定的index位置，插入元素element
        if (index == size)
            linkLast(element);
        else
            linkBefore(element, node(index));
    }
    
    /**
     * Inserts element e before non-null Node succ.
     */
    void linkBefore(E e, Node<E> succ) {
        // assert succ != null;
        //获取succ的前继节点
        final Node<E> pred = succ.prev;
        //创建一个新的节点，同时将前继节点设置为pred，后继节点设置为succ
        final Node<E> newNode = new Node<>(pred, e, succ);
        succ.prev = newNode;
        if (pred == null)
            first = newNode;
        else
            pred.next = newNode;
        size++;
        modCount++;
    }
    
```

### 获取元素

```
    /**
     * Returns the element at the specified position in this list.
     *
     * @param index index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException {@inheritDoc}
     */
    public E get(int index) {
        //检查索引范围
        checkElementIndex(index);
        return node(index).item;
    }
    
    
    /**
     * Returns the (non-null) Node at the specified element index.
     */
    Node<E> node(int index) {
        // assert isElementIndex(index);
        // 这里有一个小小的优化，如果index小于链表数量的一半，则从第一个元素开始遍历查找
        // 如果index大于链表数量的一半，则从最后一个元素开始遍历查找
        if (index < (size >> 1)) {
            // x为临时节点，指向第一个元素
            Node<E> x = first;
            for (int i = 0; i < index; i++)
                x = x.next;
            return x;
        } else {
        // x为临时节点，指向最后一个元素
            Node<E> x = last;
            for (int i = size - 1; i > index; i--)
                x = x.prev;
            return x;
        }
    }

```

### 删除元素

```
    /**
     * 
     * 移除list列表中的第一个元素
     * @return the head of this list
     * @throws NoSuchElementException if this list is empty
     * @since 1.5
     */
    public E remove() {
        return removeFirst();
    }
    
    
    /**
     * Removes and returns the first element from this list.
     *
     * @return the first element from this list
     * @throws NoSuchElementException if this list is empty
     */
    public E removeFirst() {
        //获取头指针
        final Node<E> f = first;
        if (f == null)
            throw new NoSuchElementException();
        return unlinkFirst(f);
    }
    
    
    /**
     * Unlinks non-null first node f.
     */
    private E unlinkFirst(Node<E> f) {
        // assert f == first && f != null;
        final E element = f.item;
        //获取头指针的下一个元素
        final Node<E> next = f.next;
        //将头指针置为空，这样可以被垃圾回收
        f.item = null;
        f.next = null; // help GC
        //让头指针指向下一个元素
        first = next;
        if (next == null)
            last = null;
        else
            next.prev = null;
        size--;
        modCount++;
        return element;
    }
    
    
    
    /**
     * Removes the element at the specified position in this list.  Shifts any
     * subsequent elements to the left (subtracts one from their indices).
     * Returns the element that was removed from the list.
     *
     * @param index the index of the element to be removed
     * @return the element previously at the specified position
     * @throws IndexOutOfBoundsException {@inheritDoc}
     */
    public E remove(int index) {
        checkElementIndex(index);
        return unlink(node(index));
    }
    
    
    /**
     * 将节点x断开连接，并将节点x置为null，以便垃圾回收
     */
    E unlink(Node<E> x) {
        // assert x != null;
        final E element = x.item;
        //获取节点x的前一个节点和后一个节点值
        final Node<E> next = x.next;
        final Node<E> prev = x.prev;

        // 如果x节点是头结点
        if (prev == null) {
            first = next;
        } else {
            prev.next = next;
            x.prev = null;
        }

        //如果x节点是尾节点
        if (next == null) {
            last = prev;
        } else {
            next.prev = prev;
            x.next = null;
        }
        
        //是否x节点存储的元素值
        x.item = null;
        size--;
        modCount++;
        return element;
    }
```

### 总结

1. **切勿用普通for循环遍历LinkedList**，在大量数据的情况下，其遍历速度太慢了。这可以从get()方法实现中可以看出来。
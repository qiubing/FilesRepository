## Java内存模型

导致一个线程无法看到变量的最新值的因素有：

- 在编译器中生成的指令顺序，可以与源码中的顺序不同；
- 编译器还会把变量保存在**寄存器**而不是内存中；
- 处理器可以采用**乱序或并行**等方式来执行指令；
- **缓存**可能会改变将写入变量提交到主内存的次序；
- 保存在处理器本地缓存中的值，对于其他处理器是不可见的；

如果没有使用正确的**同步**，线程可能无法看到变量的最新值，并且会导致其他线程中的**内存操作**似乎是在**乱序中执行**。


通过对**指令重排序**来实现优化执行，以及使用成熟的全局寄存器分配算法。

### 1.平台的内存模型

在**共享内存**的多处理器体系架构中，每个处理器都拥有**自己的缓存**，并且**定期地与主内存进行协调**。

在架构定义的**内存模型**中将告诉应用可以从内存系统中获得怎样的保证，此外还定义了一些特殊的指令——**内存栅栏**，当需要共享数据时，这些指令就能实现额外的存储协调保证。

为了使Java开发人员无须关心不同架构上内存模型之间的差异，Java还提供了**自己的内存模型**，并且JVM通过在适当的位置**插入内存栅栏**来屏蔽在JMM与底层平台内存模型之间的差异。

### 2.重排序

内存级的**重排序**会程序的行为变得不可测。如果没有同步，那么推断出执行顺序将是非常困难的，而要确保在程序中正确地使用同步却是非常容易的。

**同步将限制编译器、运行时和硬件对内存操作重排序的方式**，从而在实施重排序时不会破坏JMM提供的可见性保证。

### 3.Java内存模型简介

**Java内存模型是通过各种操作来定义的**，其中包括：

- **对变量的读/写操作**；
- **监视器的加锁和释放操作**；
- **线程的启动和合并操作**；

Java为程序中的所有操作都定义了一个偏序关系，即**Happens—Before**。要想保证执行操作B的线程看到操作A的结果，那么在A和B之间必须满足Happens—Before关系。**如果两个操作之间缺乏Happen-Before关系，那么JVM可以对它们任意地重排序**。

Happen-Before的规则包括：

- **程序顺序规则**。如果程序中操作A在操作B之前，那么在线程中A操作将在B操作之前执行。
- **监视器锁规则**。在监视器锁上的解锁操作必须在同一个监视器锁上的加锁操作之前执行。
- **Volatile变量规则**。对Volatile变量的写入操作必须在对该变量的读操作之前执行。
- **线程启动规则**。在线程上对Thread.start的调用必须在对该线程中执行任何操作之前执行。
- **线程结束规则**。线程中的任何操作都必须在其他线程检测到该线程已经结束之前执行，或者从Thread.join中成功返回，或者在调用Thread.isAlive时返回false。
- **中断规则**。当一个线程在另一个线程上调用interrupt时，必须在被中断线程检测到interrupt之前执行（通过抛出InterruptException，或者调用isInterrupted和interrupted）。
- **终结器规则**。对象的构造函数必须在启动该对象的终结器之前执行完成。
- **传递性**。如果操作A在操作B之前执行，并且操作B在操作C之前执行，那么操作A必须在操作C之前执行。

### 4.同步

在FutureTask中，AQS维护了一个表示**同步器状态**的整数，FutureTask用这个整数来保存任务的状态：正在运行，已完成和已取消。但FutureTask还维护了其他一些变量，例如计算的结果。当一个线程调用set来保存结果并且另一个线程调用get来获取该结果时，这两个线程最好按照Happens-Before进行排序。这可以通过将执行结果的引用声明为volatile类型来实现，但利用现有的同步机制可以更容易实现相同的功能。


### 5.发布

当缺少Happen-Before关系时，就可能出现重排序的问题。

错误的延迟初始化将导致不正确的发布。

> 除了不可变对象以外，使用被另一个线程初始化的对象通常都是不安全的，除非对象的发布操作是在使用该对象的线程开始使用之前执行。


#### 5.1 安全的发布

通过使用一个由**锁保护共享变量或者使用共享的volatile类型的变量**，也可以确保对该变量的读取操作和写入操作按照Happens-Before关系来排序。


静态初始化器是由JVM在类的初始化阶段执行，即在**类被加载后并且被线程使用之前**。由于JVM将在初始化期间**获得一个锁**，并且每个线程都至少获得一次这个锁以确保这个类已经加载，因此在静态初始化期间，内存写入操作将自动对所有线程可见，因此无论是在被构造期间还是被引用时，静态初始化的对象都不需要显式的同步。

**提前初始化**


	public class EagerInitialization{
		private static Resource resource = new Resource();

		public static Resource getResource() { return resource}
	}

**延迟初始化**

	public class ResourceFactory{
		private static class ResourceHolder{
			public static Resource resource = new Resource();
		}

		public static Resource getResource(){
			return ResourceHolder.resource;
		}
	}

**双重加锁**

	public class DoubleCheckedLocking{
		private static volatile Resource resource;
		
		public static Resource getInstance(){
			if(resource == null){
				synchronized(DoubleCheckedLocking.class){
					if(resouce == null){
						resource = new Resource();
					}
				}
			}
			return resource;
		}
	}








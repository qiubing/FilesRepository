## JSON解析

### 1.简介

JSON(JavaScript Object Notation)是一种轻量级的数据交换格式，采用完全独立于语言的文本格式。

JSON本质是一串字符串，只不过元素会使用特定的符号标注。

[JSON的官方网址](http://www.json.org/)

### 2.JSON数据结构

在JSON中有两种数据结构：对象和数组

#### 2.1JSON对象

JSON对象是以**key/value对**形式存在的，以左花括号“{”开始，以右花括号“}”结束。key值的类型为String，value值的类型可以为String、number、Object、Array等。key与value之间以冒号“：”分割，而key/value对之间以分号分割。JSON对象里面的key/value对是无序的。

![](http://www.json.org/object.gif)

举个例子：

	{"firstName":"John","lastName":"Smith"}

#### 2.2JSON数组

JSON数组是一个有序的value集合，以左中括号“[”开始，以右中括号“]”结束，value值之间以逗号“，”分割。

![](http://www.json.org/array.gif)

举个例子：

	{"employee"：
				[
				{"firstname":"John","lastName":"Smith"},
				{"firstname":"Anna","lastName":"Jones"}
				]
	}

value值的类型如下如图所示：

![](http://www.json.org/value.gif)


### 3.JSON数据生成

JSON数据的生成一般是在服务器端中完成，通常，客户端在请求服务数据时，服务器可以选择XML文档、JSON数据或者HTML的形式将数据发送给客户端。

可以通过JSONObject类的put方法将键值对存入JSONObject对象中，然后通过JSONObject的toString方法，将JSONObject对象转换为JSON数据。JSON数据本质上就是字符串。

例如下面的方法是用来生成JSON数据

	public static String createJsonString(String key,Object value){
		JSONObject jsonObject = new JSONObject();// 创建一个JSONObject对象
		jsonObject.put(key,value);//将数据填充至JSONObject对象中
		return jsonObject.toString();// 生成JSON数据并返回
	}

### 4.JSON数据解析

#### 4.1 传统解析

通过JSON数据来获取JSONObject对象，然后通过JSONObject对象以及JSONArray对象获取属性。

例如，定义一个Person对象，里面有id、name、age属性。

	public class Person {
    private int id;
    private String name;
    private int age;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public Person(int id,String name,int age){
        this.id = id;
        this.name = name;
        this.age = age;
    }
    public Person(){

    }
 	}

生成JSON数据的方法如下：

	 public static String createJsonString(String key,Object value){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(key,value);
        return jsonObject.toString();
    }

	 public List<Person> getListPerson(){
        List<Person> list = new ArrayList<Person>();
        Person person1 = new Person(1,"zhangsan",18);
        Person person2 = new Person(2,"lisi",20);
        Person person3 = new Person(3,"wangwu",28);
        list.add(person1);
        list.add(person2);
        list.add(person3);
        return list;
    }

    public String createPersonJsonString(){
        List<Person> listPerson = getListPerson();
        String str = JSONUtils.createJsonString("persons",listPerson);
        System.out.println("str = " + str);
        return str;
    }

生成处理的JSON数据为：

	{"persons":[{"age":18,"id":1,"name":"zhangsan"},{"age":20,"id":2,"name":"lisi"},{"age":28,"id":3,"name":"wangwu"}]}

从JSON数据中解析出Person对象的方法如下：

	public static List<Person> getListPerson(String key,String jsonString){
        List<Person> list = new ArrayList<Person>();

        try {
            JSONObject jsonObject = JSONObject.fromObject(jsonString);//从JSON数据中创建JSONObject对象
            JSONArray jsonArray = jsonObject.getJSONArray(key);//获取JSONObject对象的值，该值是一个JSONArray数组
            for (int i = 0; i < jsonArray.size(); i++){
                JSONObject personObject = jsonArray.getJSONObject(i);// 获取JSON数组中的每一个JSONObject对象
                Person person = new Person();
				// 将JSONObject对象中键所对应的值取出来
                int id = personObject.getInt("id");
                String name = personObject.getString("name");
                int age = personObject.getInt("age");
                person.setId(id);
                person.setName(name);
                person.setAge(age);
                list.add(person);
            }
        }catch (JSONException e){
            e.printStackTrace();
        }
        return list;
    }

#### 4.2 GSON解析

生成JSON数据的方法：

	 public static String createJsonStringByGSON(Object obj){
        Gson gson = new Gson();
        String str = gson.toJson(obj);
        return str;
    }

解析JSON对象的方法：

	public static <T> T parseJsonWithGson(String jsonData,Class<T> type){
        Gson gson = new Gson();
        T result = gson.fromJson(jsonData,type);
        return result;
    }

解析JSON数组的方法：

	public static <T> List<T> parseJsonArrayWithGson(String jsonData,Class<T> clazz){
       Type type = new TypeToken<ArrayList<JSONObject>>(){}.getType();
        ArrayList<JSONObject> jsonObjects = new Gson().fromJson(jsonData,type);
        ArrayList<T> arrayList = new ArrayList<T>();

        for (JSONObject jsonObject : jsonObjects){
            arrayList.add(new Gson().fromJson(jsonObject.toString(),clazz));
        }
        return arrayList;
    }

#### 4.3 FastJSON解析

生成JSON数据的方法：

	public static String createJSONStringByFastJSON(Object obj){
        return JSON.toJSONString(obj);
    }

解析JSON对象的方法：

	 public static <T> T parseJsonWithFastJSON(String jsonData,Class<T> clazz){
        T result = JSON.parseObject(jsonData,clazz);
        return result;
    }

解析JSON数组的方法：

	public static <T> List<T> parseJsonArrayWithFastJSON(String jsonData,Class<T> clazz){
        List<T> list = new ArrayList<T>();
        list = JSON.parseArray(jsonData,clazz);
        return list;
    }

完整的代码如下：

	import com.alibaba.fastjson.JSON;
	import com.google.gson.Gson;
	import com.google.gson.reflect.TypeToken;
	import net.sf.json.JSONArray;
	import net.sf.json.JSONException;
	import net.sf.json.JSONObject;
	import java.lang.reflect.Type;
	import java.util.ArrayList;
	import java.util.List;

	/**
 	* Created by bing on 2017-08-10.
 	*/
	public class JSONUtils {
    // 传统JSON解析
    public static String createJsonString(String key,Object value){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(key,value);
        return jsonObject.toString();
    }

    public static List<Person> getListPerson(String key,String jsonString){
        List<Person> list = new ArrayList<Person>();

        try {
            JSONObject jsonObject = JSONObject.fromObject(jsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(key);
            for (int i = 0; i < jsonArray.size(); i++){
                JSONObject personObject = jsonArray.getJSONObject(i);
                Person person = new Person();
                int id = personObject.getInt("id");
                String name = personObject.getString("name");
                int age = personObject.getInt("age");
                person.setId(id);
                person.setName(name);
                person.setAge(age);
                list.add(person);
            }
        }catch (JSONException e){
            e.printStackTrace();
        }
        return list;
    }

    public static String createPersonJsonString(){
        List<Person> listPerson = getListPerson();
        String str = JSONUtils.createJsonString("persons",listPerson);
        System.out.println("str = " + str);
        return str;
    }

    public static List<Person> getListPerson(){
        List<Person> list = new ArrayList<Person>();
        Person person1 = new Person(1,"zhangsan",18);
        Person person2 = new Person(2,"lisi",20);
        Person person3 = new Person(3,"wangwu",28);
        list.add(person1);
        list.add(person2);
        list.add(person3);
        return list;
    }


    // GSON解析
    public static String createJsonStringByGSON(Object obj){
        Gson gson = new Gson();
        String str = gson.toJson(obj);
        return str;
    }

    public static <T> T parseJsonWithGson(String jsonData,Class<T> type){
        Gson gson = new Gson();
        T result = gson.fromJson(jsonData,type);
        return result;
    }

    public static <T> List<T> parseJsonArrayWithGson(String jsonData,Class<T> clazz){
       Type type = new TypeToken<ArrayList<JSONObject>>(){}.getType();
        ArrayList<JSONObject> jsonObjects = new Gson().fromJson(jsonData,type);
        ArrayList<T> arrayList = new ArrayList<T>();

        for (JSONObject jsonObject : jsonObjects){
            arrayList.add(new Gson().fromJson(jsonObject.toString(),clazz));
        }
        return arrayList;
    }

    // FastJSON解析
    public static String createJSONStringByFastJSON(Object obj){
        return JSON.toJSONString(obj);
    }

    public static <T> T parseJsonWithFastJSON(String jsonData,Class<T> clazz){
        T result = JSON.parseObject(jsonData,clazz);
        return result;
    }

    public static <T> List<T> parseJsonArrayWithFastJSON(String jsonData,Class<T> clazz){
        List<T> list = new ArrayList<T>();
        list = JSON.parseArray(jsonData,clazz);
        return list;
    }
 	}

可以看到使用GSON和FastJSON解析JSON数据要方便一些。

例子代码路径： [完整代码路径](https://github.com/qiubing/JSONParseDemo)
## OKHttp源码分析

### 关键类
1.**OkHttpClient类**

OKHttpClient类用来发送Http请求，读取Http响应。

OkHttpClient应该被共享，即在一个应用中，应该只有一个OkHttpClient实例。因为每一个OkHttpClient都持有它自己的**连接池**和**线程池**。复用连接池以及线程池可以减少延迟以及节省内存。

OkHttpClient有两种方式可以创建：

- 1.通过new OkHttpClient()方法创建一个拥有默认配置OkHttpClient

		public final OkHttpClient client = new OkHttpClient();

- 2.或者通过new OkHttpClient.Builder()方式创建一个自定义配置的OkHttpClient

		public final OkHttpClient client = new OkHttpClient.Builder()
       		.addInterceptor(new HttpLoggingInterceptor())
        	.cache(new Cache(cacheDir, cacheSize))
        	.build();

通过OkHttpClient的newBuilder()可以自定义实现OkHttpClient配置需求。

	OkHttpClient eagerClient = client.newBuilder()
		.readTimeout(500, TimeUnit.MILLISECONDS)
		.build();
	Response response = eagerClient.newCall(request).execute();


**资源的关闭**

1. 除非显式请求关闭线程和连接，空闲的线程和请求将自动被释放关闭。

2. 分发服务关闭需要通过ExecutorService.shutdown()方法关闭，例如：

		client.dispatcher().executorService().shutdown();

3. 连接池的关闭需要通过ConnectionPool.evictAll()方法关闭，例如：

		client.connectionPool().evictAll();

4.  缓存的关闭需要通过Cache.close()方法，例如：

		client.cache().close();

5. OkHttp使用的守护线程在保持空闲的时候会自动退出。


2.**StreamAllocation类**

该类主要是协调三个实体之间的关系：

- **Connections**：连接到远端服务器Socket套接字连接。
- **Streams**：逻辑上的HTTP request/response对，位于connections之上的。每个Connection都有它的分配限制，HTTP/1.x Connection可以同时携带一个Stream，而HTTP/2可以同时携带多个Stream。
- **Calls**:Streams的逻辑序列，通常是一个初始化request和后续相关request。

该类支持异步取消方法cancel()。

3.**HttpCodec**

HttpCodeC是一个接口，主要是用于编码HTTP请求和解码HTTP响应。

HttpCodeC的实现类有两个，分别是Http1Codec和Http2Codec。

Http1Codec是一个套接字连接，可以被用来发送HTTP/1.1协议消息。该类严格执行以下生命周期：

- **writeRequest**：发送请求头部（request headers）；
- **newFixedLengthSink/newChunkedSink**:打开一个sink来写入请求体（request body）；
- 将请求写入sink，并关闭sink；
- **readResponseHeaders：** 读取响应头部（Response headers）
- **newFixedLengthSource/newChunkedSource/newUnknownLengthSource**:打开资源来读取响应体（Response body）；
- 读取资源并关闭资源。

整体过程分为6步：

1. Send **request headers**.

2. Open a sink to write the **request body**.

3. Write to and then close that sink.

4. Read **response headers**.

5. Open a source to read the **response body**.

6. Read from and close that source.


Http2Codec是用来请求和解析HTTP/2协议的。

HttpCodeC接口定义如下：

	public interface HttpCodec {
		// 返回一个可以用来写入请求体的输出流
		Sink createRequestBody(Request request, long contentLength);
		// 写入请求头部
		void writeRequestHeaders(Request request) throws IOException;
		// 写入请求到相关的socket中
		void flushRequest() throws IOException;
		// 写入请求到相关的socket并通知没有更多字节需要传输
		void finishRequest() throws IOException;
		// 从一个HTTP传输中，解析响应头部字节。
		Response.Builder readResponseHeaders(boolean expectContinue) throws IOException;
		// 返回一个读取响应体的流
		ResponseBody openResponseBody(Response response) throws IOException;
		// 取消流，被流持有的资源将会被释放。
		 void cancel();
	}

4.**Connection接口**

Connection代表HTTP、HTTPS、HTTPs+HTTP/2连接的套接字和流。

Connection可以直接连接到服务器或者是通过代理连接到服务器。

应用可以通过连接池ConnectionPool来监控管理HTTP连接。

每个Connection可以包含多个Streams。HTTP/1.x Connection可以包含0个或者1个Streams。而HTTP/2 Connection可以包含任意数量的Streams。

当一个Call需要多个Stream时，例如重定向或者验证身份，则可以使用同一个物理连接来依次处理多个Stream。

Connection接口定义如下：

	public interface Connection {
		// 返回连接使用的路由
		Route route();
	
		// 返回该连接使用的套接字，如果是Https，则返回一个SSLSocket套接字，如果是HTTP/2，则返回一个可以被多个连接共享的套接字。
		Socket socket();

		// 返回用来建立该连接的TLS握手，只是针对HTTPS而言
		@Nullable Handshake handshake();

		// 返回该连接协商后的协议，可以取值为HTTP_1_0、HTTP_1_1、SPDY_3、HTTP_2
		Protocol protocol();
	}


5.**ConnectionPool类**

ConnectionPool是用来管理HTTP和HTTP/2连接的复用，较少网络延迟。拥有相同地址的Http请求可以共享同一个连接。

ConnectionPool决定了使用哪个连接来处理请求。

默认的连接池将持有最多5个空闲连接，5分钟的空闲时间。

6.**Route类**

Route类代表被Connection使用的具体路由来到达一个原始的服务器。当创建一个连接时，Client有很多选项：

- **HTTP proxy:** 为Client显式配置一个代理服务器。
- **IP address:** 是否直接连接到原始服务器还是通过一个代理服务器，打开一个套接字时需要一个IP地址。DNS服务器可能返回多个IP地址去尝试。

**每一个Route都是Proxy和Address的特定组合**。

7.**Http2Connection类**

Http2Connection代表一个到远程对端的套接字连接。该连接持有Streams来发送和接收数据。

在Http2Connection类中的很多方法都是同步的。

8.**Request类**

Request代表一个HTTP请求。Request是通过Builder模式来构建的。

9.**Response类**

Response代表一个HTTP响应。Response body是一个一次性的值，只能被读取一次，然后就被关闭了。







### 调用分析

**源码分析**


1.OkHttpClient构造函数

	public OkHttpClient() {
    	this(new Builder());
  	}

	public Builder() {
      dispatcher = new Dispatcher();//异步请求执行的策略
      protocols = DEFAULT_PROTOCOLS;//默认的支持的协议，有HTTP/1.1和HTTP2
      connectionSpecs = DEFAULT_CONNECTION_SPECS;//套接字连接配置
      eventListenerFactory = EventListener.factory(EventListener.NONE);
      proxySelector = ProxySelector.getDefault();
      cookieJar = CookieJar.NO_COOKIES;// 禁用cookies机制
      socketFactory = SocketFactory.getDefault();//创建Socket的工厂
      hostnameVerifier = OkHostnameVerifier.INSTANCE;
      certificatePinner = CertificatePinner.DEFAULT;
      proxyAuthenticator = Authenticator.NONE;
      authenticator = Authenticator.NONE;
      connectionPool = new ConnectionPool();//连接池
      dns = Dns.SYSTEM;// 使用系统的DNS服务
      followSslRedirects = true;
      followRedirects = true;
      retryOnConnectionFailure = true;//失败重传
      connectTimeout = 10_000;//连接超时为10s
      readTimeout = 10_000;//读取超时为10s
      writeTimeout = 10_000;//写超时为10s
      pingInterval = 0;
    }

	//将builder里的值拷贝到OkHttpClient中对应的字段值
	OkHttpClient(Builder builder) {
    this.dispatcher = builder.dispatcher;
    this.proxy = builder.proxy;
    this.protocols = builder.protocols;
    this.connectionSpecs = builder.connectionSpecs;
    this.interceptors = Util.immutableList(builder.interceptors);
    this.networkInterceptors = Util.immutableList(builder.networkInterceptors);
    this.eventListenerFactory = builder.eventListenerFactory;
    this.proxySelector = builder.proxySelector;
    this.cookieJar = builder.cookieJar;
    this.cache = builder.cache;
    this.internalCache = builder.internalCache;
    this.socketFactory = builder.socketFactory;

    boolean isTLS = false;
    for (ConnectionSpec spec : connectionSpecs) {
      isTLS = isTLS || spec.isTls();
    }

    if (builder.sslSocketFactory != null || !isTLS) {
      this.sslSocketFactory = builder.sslSocketFactory;
      this.certificateChainCleaner = builder.certificateChainCleaner;
    } else {
      X509TrustManager trustManager = systemDefaultTrustManager();
      this.sslSocketFactory = systemDefaultSslSocketFactory(trustManager);
      this.certificateChainCleaner = CertificateChainCleaner.get(trustManager);
    }

    this.hostnameVerifier = builder.hostnameVerifier;
    this.certificatePinner = builder.certificatePinner.withCertificateChainCleaner(
        certificateChainCleaner);
    this.proxyAuthenticator = builder.proxyAuthenticator;
    this.authenticator = builder.authenticator;
    this.connectionPool = builder.connectionPool;
    this.dns = builder.dns;
    this.followSslRedirects = builder.followSslRedirects;
    this.followRedirects = builder.followRedirects;
    this.retryOnConnectionFailure = builder.retryOnConnectionFailure;
    this.connectTimeout = builder.connectTimeout;
    this.readTimeout = builder.readTimeout;
    this.writeTimeout = builder.writeTimeout;
    this.pingInterval = builder.pingInterval;
  	}

可以看到，通过new OkHttpClient()方法创建的是一个拥有默认配置的OkHttpClient。

还有一种创建OKHttpClient的方法是通过Builder模式构建。Builder类的build方法如下：
	
	public OkHttpClient build() {
      return new OkHttpClient(this);
    }

通过Builder模式，可以自定义OkHttpClient，例如通过Builder设置缓存：

	public Builder cache(@Nullable Cache cache) {
      this.cache = cache;
      this.internalCache = null;
      return this;
    }

2.OkHttpClient.newCall()

newCall方法在Factory接口中定义，用来表示将要执行一个Request。

	interface Factory {
    	Call newCall(Request request);
  	}

具体的实现在OkHttpClient类中。

	@Override 
	public Call newCall(Request request) {
    	return new RealCall(this, request, false /* for web socket */);
  	}

Call是一个接口类型，具体的实现在RealCall类中。

3.RealCall类的构造方法

	RealCall(OkHttpClient client, Request originalRequest, boolean forWebSocket) {
    final EventListener.Factory eventListenerFactory = client.eventListenerFactory();

    this.client = client;//指向OkHttpClient
    this.originalRequest = originalRequest;//原始请求Request
    this.forWebSocket = forWebSocket;//是否为socket
    this.retryAndFollowUpInterceptor = new RetryAndFollowUpInterceptor(client, forWebSocket);//设置重传拦截器

    // TODO(jwilson): this is unsafe publication and not threadsafe.
    this.eventListener = eventListenerFactory.create(this);
  	}

在该方法中，主要是初始化一些操作。

4.RealCall.execute()

execute方法是一个同步方法，将一直阻塞到响应返回。为了避免内存泄漏，调用者应该在调用该方法后关闭Response。可以参考如下方法：

	try (Response response = client.newCall(request).execute()) {
        ...
    }

execute方法实现如下：

	@Override 
	public Response execute() throws IOException {
    	synchronized (this) {
		// 已经执行过，抛异常
      	if (executed) throw new IllegalStateException("Already Executed");
      		executed = true;
    	}
    	captureCallStackTrace();
    	try {
			// 1.通过Dispatcher执行请求
      		client.dispatcher().executed(this);
			// 2.获取响应结果
      		Response result = getResponseWithInterceptorChain();
      		if (result == null) throw new IOException("Canceled");
			// 返回结果
      		return result;
    	} finally {
			// 3.结束该请求
      		client.dispatcher().finished(this);
    	}
  	}

可以看到，在execute方法中，主要是通过Dispatcher执行请求，然后获取响应结果，最后结束该请求。

5.Dispatcher.executed()

Dispatcher主要是使用ExecutorService来执行Call请求，用户可以自定义实现executor。

	synchronized void executed(RealCall call) {
		// 将请求添加到双端队列尾部中
    	runningSyncCalls.add(call);
  	}
executed方法比较简单，只是将一个请求添加到双端队列尾部中，然后等待从线程从队列中请求执行。


6.RealCall.getResponseWithInterceptorChain()


	Response getResponseWithInterceptorChain() throws IOException {
    // Build a full stack of interceptors.
	// 构建拦截链
    List<Interceptor> interceptors = new ArrayList<>();
    interceptors.addAll(client.interceptors());
    interceptors.add(retryAndFollowUpInterceptor);
    interceptors.add(new BridgeInterceptor(client.cookieJar()));
    interceptors.add(new CacheInterceptor(client.internalCache()));
    interceptors.add(new ConnectInterceptor(client));
    if (!forWebSocket) {
	// 添加网络拦截器
      interceptors.addAll(client.networkInterceptors());
    }
    interceptors.add(new CallServerInterceptor(forWebSocket));
	// 构造拦截链
    Interceptor.Chain chain = new RealInterceptorChain(
        interceptors, null, null, null, 0, originalRequest);
    return chain.proceed(originalRequest);
  	}

Interceptor是一个接口，用来观察，修改以及可能短路的请求输出和响应请求的回来。通常情况下拦截器用来添加，移除或者转换请求或者响应的头部信息。
拦截器的接口定义如下：

	public interface Interceptor {
  		Response intercept(Chain chain) throws IOException;

  		interface Chain {
    		Request request();
    		Response proceed(Request request) throws IOException;
    		@Nullable Connection connection();
  		}
	}


7.RealInterceptorChain.proceed()

	@Override 
	public Response proceed(Request request) throws IOException {
    	return proceed(request, streamAllocation, httpCodec, connection);
  	}

	public Response proceed(Request request, StreamAllocation streamAllocation, HttpCodec httpCodec,
      RealConnection connection) throws IOException {
	// index初始化的值为0
    if (index >= interceptors.size()) throw new AssertionError();
	// 调用的次数递增
    calls++;

    // If we already have a stream, confirm that the incoming request will use it.
    if (this.httpCodec != null && !this.connection.supportsUrl(request.url())) {
      throw new IllegalStateException("network interceptor " + interceptors.get(index - 1)
          + " must retain the same host and port");
    }

    // If we already have a stream, confirm that this is the only call to chain.proceed().
    if (this.httpCodec != null && calls > 1) {
      throw new IllegalStateException("network interceptor " + interceptors.get(index - 1)
          + " must call proceed() exactly once");
    }

    // Call the next interceptor in the chain.
	// 调用拦截链中的下一个拦截器，传递的index值加1
    RealInterceptorChain next = new RealInterceptorChain(
        interceptors, streamAllocation, httpCodec, connection, index + 1, request);
	// 获取指定的索引的拦截器，这里为获取索引为0的拦截器
    Interceptor interceptor = interceptors.get(index);
	// 调用拦截器的拦截方法
    Response response = interceptor.intercept(next);

    // Confirm that the next interceptor made its required call to chain.proceed().
    if (httpCodec != null && index + 1 < interceptors.size() && next.calls != 1) {
      throw new IllegalStateException("network interceptor " + interceptor
          + " must call proceed() exactly once");
    }

    // Confirm that the intercepted response isn't null.
    if (response == null) {
      throw new NullPointerException("interceptor " + interceptor + " returned null");
    }

    return response;
  }
	

	


	









	
	
## OkHttp简介

### 1.概述

OkHttp是一个Http Client，默认支持以下功能：

- 支持HTTP2，同一个主机所有的请求可以通过一个Socket来处理；
- **连接池**减少了请求的延迟；
- 透明的**压缩**减少下载的大小；
- **缓存响应**，避免重复请求；

OkHttp 处理了很多网络疑难杂症：会从很多常用的连接问题中自动恢复。如果您的服务器配置了多个IP地址，当第一个IP连接失败的时候，OkHttp会自动尝试下一个IP。OkHttp还处理了代理服务器问题和SSL握手失败问题。

### 2.OkHttp使用

使用OkHttp很简单。OkHttp请求和响应API都被采用灵活的Builder模型来构建；OkHttp支持同步和异步的调用。

官网上的实例：

1.获取一个URL对应的内容，并打印出来：

	OkHttpClient client = new OkHttpClient();

	String run(String url) throws IOException {
  		Request request = new Request.Builder()
      	.url(url)
      	.build();

  		Response response = client.newCall(request).execute();
  		return response.body().string();
	}

2.上传数据到一个服务器

	public static final MediaType JSON
    	= MediaType.parse("application/json; charset=utf-8");

	OkHttpClient client = new OkHttpClient();

	String post(String url, String json) throws IOException {
  		RequestBody body = RequestBody.create(JSON, json);
  		Request request = new Request.Builder()
      		.url(url)
      		.post(body)
      		.build();
  		Response response = client.newCall(request).execute();
  		return response.body().string();
	}


![OkHttp流程图](http://orbohk5us.bkt.clouddn.com/17-11-13/23463086.jpg)

### 3.源码分析

按照官网给出的例子，接下来分析一个Http请求的过程。

#### 3.1 同步请求处理过程

1.构建OkHttpClient对象

  	public OkHttpClient() {
    	this(new Builder());
  	}
这是一个简洁的OkHttpClient构造函数，其中Builder中的所有成员都是采用默认配置。

	public Builder() {
      dispatcher = new Dispatcher();//异步请求执行的策略
      protocols = DEFAULT_PROTOCOLS;//默认的支持的协议，有HTTP/1.1和HTTP2
      connectionSpecs = DEFAULT_CONNECTION_SPECS;//套接字连接配置
      eventListenerFactory = EventListener.factory(EventListener.NONE);
      proxySelector = ProxySelector.getDefault();
      cookieJar = CookieJar.NO_COOKIES;// 禁用cookies机制
      socketFactory = SocketFactory.getDefault();//创建Socket的工厂
      hostnameVerifier = OkHostnameVerifier.INSTANCE;
      certificatePinner = CertificatePinner.DEFAULT;
      proxyAuthenticator = Authenticator.NONE;
      authenticator = Authenticator.NONE;
      connectionPool = new ConnectionPool();//连接池
      dns = Dns.SYSTEM;// 使用系统的DNS服务
      followSslRedirects = true;
      followRedirects = true;
      retryOnConnectionFailure = true;//失败重传
      connectTimeout = 10_000;//连接超时为10s
      readTimeout = 10_000;//读取超时为10s
      writeTimeout = 10_000;//写超时为10s
      pingInterval = 0;
    }

最后都会调用到又Builder构建的OkHttpClient方法：

	//将builder里的值拷贝到OkHttpClient中对应的字段值
	OkHttpClient(Builder builder) {
    	this.dispatcher = builder.dispatcher;
    	this.proxy = builder.proxy;
    	this.protocols = builder.protocols;
    	this.connectionSpecs = builder.connectionSpecs;
    	this.interceptors = Util.immutableList(builder.interceptors);
    	this.networkInterceptors = Util.immutableList(builder.networkInterceptors);
    	this.eventListenerFactory = builder.eventListenerFactory;
    	this.proxySelector = builder.proxySelector;
    	this.cookieJar = builder.cookieJar;
    	this.cache = builder.cache;
    	this.internalCache = builder.internalCache;
    	this.socketFactory = builder.socketFactory;
		....
  	}

2.构建Request对象

构造Request对象是采用Builder模式构建的，这样提供了很大的灵活性。我们可以看到，可以通过如下方式来构造一个Request对象：

	Request request = new Request.Builder()
      .url(url)
      .build();

下面来Request的构造过程：

	public static class Builder {

		public Builder() {
      		this.method = "GET";//默认的方法为GET
      		this.headers = new Headers.Builder();//默认的头部
    	}
	}
Builder()方法是创建一个Builder对象，通过Builder对象可以灵活地设置Request的url、method、headers、body等参数。
	// 设置url参数
	public Builder url(String url) {
      if (url == null) throw new NullPointerException("url == null");

      // Silently replace web socket URLs with HTTP URLs.
      if (url.regionMatches(true, 0, "ws:", 0, 3)) {
        url = "http:" + url.substring(3);
      } else if (url.regionMatches(true, 0, "wss:", 0, 4)) {
        url = "https:" + url.substring(4);
      }

      HttpUrl parsed = HttpUrl.parse(url);
      if (parsed == null) throw new IllegalArgumentException("unexpected url: " + url);
      return url(parsed);
    }

	public Builder url(HttpUrl url) {
      if (url == null) throw new NullPointerException("url == null");
      this.url = url;
      return this;
    }

	// 设置method参数和请求体body
	public Builder method(String method, @Nullable RequestBody body) {
      if (method == null) throw new NullPointerException("method == null");
      if (method.length() == 0) throw new IllegalArgumentException("method.length() == 0");
      if (body != null && !HttpMethod.permitsRequestBody(method)) {
        throw new IllegalArgumentException("method " + method + " must not have a request body.");
      }
      if (body == null && HttpMethod.requiresRequestBody(method)) {
        throw new IllegalArgumentException("method " + method + " must have a request body.");
      }
      this.method = method;//保存method参数
      this.body = body;//保存请求体body
      return this;
    }

	// 其他参数设置方法略.....
可以看到上面的参数设置方法都是返回一个Builder对象，这样可以将整个构建过程串联起来，最后通过一个build()方法来完成构建Request对象的过程。

	public Request build() {
      if (url == null) throw new IllegalStateException("url == null");
      return new Request(this);//调用Request的构造函数方法
    }

	// Request对象的构造函数
	Request(Builder builder) {
    	this.url = builder.url;
    	this.method = builder.method;
    	this.headers = builder.headers.build();
    	this.body = builder.body;
    	this.tag = builder.tag != null ? builder.tag : this;
  	}

3.创建Call对象

OKHttpClient实现了Call.Factory接口，根据请求创建Call对象。

	public class OkHttpClient implements Cloneable, Call.Factory, WebSocket.Factory {
		...
		@Override 
		public Call newCall(Request request) {
    		return RealCall.newRealCall(this, request, false /* for web socket */);//调用RealCall的newRealCall()方法,见3.1
  		}
	}

RealCall实现了Call接口，负责具体创建Call对象。

3.1 RealCall.newRealCall()

	final class RealCall implements Call {

		static RealCall newRealCall(OkHttpClient client, Request originalRequest, boolean forWebSocket) {
    		// Safely publish the Call instance to the EventListener.
    		RealCall call = new RealCall(client, originalRequest, forWebSocket);//创建一个RealCall对象
    		call.eventListener = client.eventListenerFactory().create(call);//设置EventListener对象，默认为空实现
    		return call;
  		}
		....
	}
newRealCall()方法主要是创建一个RealCall对象，然后设置一个eventListener对象。

	private RealCall(OkHttpClient client, Request originalRequest, boolean forWebSocket) {
    	this.client = client;
    	this.originalRequest = originalRequest;//保存请求Request
    	this.forWebSocket = forWebSocket;//默认值为false
    	this.retryAndFollowUpInterceptor = new RetryAndFollowUpInterceptor(client, forWebSocket);//设置失败重传以及重定向的RetryAndFollowUpInterceptor拦截器
  	}

4.执行请求excute

执行请求是调用RealCall类的excute()的方法：

	@Override 
	public Response execute() throws IOException {
    	synchronized (this) {
      		if (executed) throw new IllegalStateException("Already Executed");
      		executed = true;// 1.检查是否已经执行过了请求
    	}
    	captureCallStackTrace();
    	eventListener.callStart(this);//在call入队列或者被执行时，会回调eventListener的方法通知执行开始
    	try {
      		client.dispatcher().executed(this);//2.执行实际的请求，见4.1
      		Response result = getResponseWithInterceptorChain();//3.获取Http返回结果
      		if (result == null) throw new IOException("Canceled");
      		return result;
    	} catch (IOException e) {
      		eventListener.callFailed(this, e);//出现异常时，调用eventListener的方法通知执行失败
      		throw e;
    	} finally {
      		client.dispatcher().finished(this);//4.通知请求已经执行完毕
    	}
  	}

该方法主要完成了4件事情：

- 1.检查请求是否已经执行过了，如果多次重复执行，将抛出异常；
- 2.通过Dispatcher的executed()方法执行实际的请求；
- 3.通过getResponseWithInterceptorChain()方法获取Http返回结果；
- 4.通过Dispatcher的finished()方法通知请求执行完成了；

4.1 Dispatcher.executed()

我们在构建OkHttpClient的时候，就已经构建了Dispatcher对象。

	synchronized void executed(RealCall call) {
    	runningSyncCalls.add(call);//将call对象添加到队列中
  	}
	// runningSyncCalls是一个双端队列
	private final Deque<RealCall> runningSyncCalls = new ArrayDeque<>();

可以看到，executed方法非常简单，主要将call对象添加到双端队列中，等待后续处理；

4.2 RealCall.getResponseWithInterceptorChain()

	Response getResponseWithInterceptorChain() throws IOException {
    	// Build a full stack of interceptors.
		// 构建一个拦截器链表
    	List<Interceptor> interceptors = new ArrayList<>();
    	interceptors.addAll(client.interceptors());//将OkHttpClient中所有的拦截器都添加到数组中
    	interceptors.add(retryAndFollowUpInterceptor);//添加失败重传以及重定向拦截器
    	interceptors.add(new BridgeInterceptor(client.cookieJar()));//添加转换拦截器
    	interceptors.add(new CacheInterceptor(client.internalCache()));//添加缓存拦截器
    	interceptors.add(new ConnectInterceptor(client));//添加建立连接拦截器
    	if (!forWebSocket) {
      		interceptors.addAll(client.networkInterceptors());//添加OkHttpClient类配置的拦截器
    	}
    	interceptors.add(new CallServerInterceptor(forWebSocket));//添加与服务器通信的拦截器
		
		// 构建一个拦截链,见4.3
    	Interceptor.Chain chain = new RealInterceptorChain(interceptors, null, null, null, 0,
        	originalRequest, this, eventListener, client.connectTimeoutMillis(),
        	client.readTimeoutMillis(), client.writeTimeoutMillis());

    	return chain.proceed(originalRequest);//调用拦截链处理过程
  	}
可以看到，在getResponseWithInterceptorChain()方法中，主要是构建一个拦截器链，由拦截器链上各个拦截器来处理请求。

在OkHttpClient中，Interceptor是一个比较核心的概念，它不只是拦截请求进行一些额外的处理(例如Cookie)，它还可以把实际的网络请求、缓存、透明压缩等功能都统一起来。每一个功能都是一个Interceptor，然后再将它们连接成一个Interceptor.Chain，环环相扣，最终完成一次网络请求。

在拦截器链中，使用到了一种常用设计模式—————**责任链模式**。

> 责任链模式包含了一些命令对象和一系列的处理对象，每一个处理对象决定它能处理哪些命令对象，它也知道如何将它不能处理的命令对象，传递给责任链中的下一个处理对象。该模式还描述了往该处理链的末尾添加新的处理对象的方法。

上面的每一个Interceptor对象都可以将**Request转变成Response**，我们沿着拦截链条让每个Interceptor自行决定能否完成任务以及怎样完成任务(自力更生或者交给下一个Interceptor)。在这里，**位置决定了功能**。可以看到最后一个Interceptor一定是与服务器通信的，而重定向、缓存等Interceptor一定是在于服务器通信之前完成的。

下面看看这个拦截链：

	OkHttpClient.interceptors --------------------------------1.
		retryAndFollowUpInterceptor --------------------------2.
			BridgeInterceptor --------------------------------3.
				CacheInterceptor -----------------------------4.
					ConnectInterceptor------------------------5.
						OkHttpClient.networkInterceptors------6.
							CallServerInterceptor-------------7.
1. 在OkHttpClient中设置的Interceptors；
2. 负责失败重传以及重定向的retryAndFollowUpInterceptor；
3. 负责把用户构造的请求转换为发送到服务器的请求，把服务器返回的响应转换为用户友好响应的BridgeInterceptor；
4. 负责读取缓存直接返回、更新缓存的CacheInterceptor；
5. 负责与服务器建立连接的ConnectInterceptor；
6. 在OkHttpClient中设置的networkInterceptors；
7. 负责向服务器发送请求数据、从服务器读取响应数据的CallServerInterceptor；

4.3 RealInterceptorChain()

	public RealInterceptorChain(List<Interceptor> interceptors, StreamAllocation streamAllocation,
      HttpCodec httpCodec, RealConnection connection, int index, Request request, Call call,
      EventListener eventListener, int connectTimeout, int readTimeout, int writeTimeout) {
    	this.interceptors = interceptors;//拦截链
    	this.connection = connection;
    	this.streamAllocation = streamAllocation;
    	this.httpCodec = httpCodec;
    	this.index = index;
    	this.request = request;//request请求
    	this.call = call;
    	this.eventListener = eventListener;
    	this.connectTimeout = connectTimeout;
    	this.readTimeout = readTimeout;
    	this.writeTimeout = writeTimeout;
  }
RealInterceptorChains类实现了Interceptor.Chain接口，在里面保存了拦截链以及请求等参数。

4.4 RealInterceptorChains.process()

	@Override 
	public Response proceed(Request request) throws IOException {
    	return proceed(request, streamAllocation, httpCodec, connection);
  	}

	
	public Response proceed(Request request, StreamAllocation streamAllocation, HttpCodec httpCodec,
      RealConnection connection) throws IOException {
		// index初始化的值为0，判断索引值是否大于拦截器链的数量
    	if (index >= interceptors.size()) throw new AssertionError();

    	calls++;// 调用的次数递增

    	// If we already have a stream, confirm that the incoming request will use it.
    	if (this.httpCodec != null && !this.connection.supportsUrl(request.url())) {
      		throw new IllegalStateException("network interceptor " + interceptors.get(index - 1)
         	 + " must retain the same host and port");
    	}

    	// If we already have a stream, confirm that this is the only call to chain.proceed().
    	if (this.httpCodec != null && calls > 1) {
      		throw new IllegalStateException("network interceptor " + interceptors.get(index - 1)
          + " must call proceed() exactly once");
    	}

		// 调用拦截链中的下一个拦截器，传递的index值加1
    	RealInterceptorChain next = new RealInterceptorChain(
        	interceptors, streamAllocation, httpCodec, connection, index + 1, request);//见4.3
		// 获取指定的索引的拦截器，这里为获取索引为0的拦截器
    	Interceptor interceptor = interceptors.get(index);
		// 调用拦截器的拦截方法，获取返回结果Response
    	Response response = interceptor.intercept(next);//见4.5

		// 确保下一个拦截器的请求是通过chain.proceed()方法来处理的。
    	if (httpCodec != null && index + 1 < interceptors.size() && next.calls != 1) {
      		throw new IllegalStateException("network interceptor " + interceptor
          + " must call proceed() exactly once");
    	}

		// 确保响应Response不为空
    	if (response == null) {
      		throw new NullPointerException("interceptor " + interceptor + " returned null");
    	}

    	return response;
  }
可以看到，proceed()方法的主要作用是将请求request交给拦截链中拦截器Interceptor处理intercept(),每一个拦截器都都可能返回响应Response。通过数组interceptors的索引值index来决定执行顺序，首先执行的索引值index = 0的拦截器，接着执行索引值index = 1的拦截器，直到有拦截器返回Response为止。

4.5 Interceptor.intercept()

Interceptor是一个接口，里面定义了intercept()方法，具体实现有在4.2中构建的拦截器。这里我们简单介绍下建立连接的ConnectInterceptor与服务器通信的CallServerInterceptor。

**ConnectInterceptor**

	public final class ConnectInterceptor implements Interceptor {
  		public final OkHttpClient client;

  		public ConnectInterceptor(OkHttpClient client) {
    		this.client = client;
  		}

  		@Override 
		public Response intercept(Chain chain) throws IOException {
    		RealInterceptorChain realChain = (RealInterceptorChain) chain;
    		Request request = realChain.request();//获取请求
    		StreamAllocation streamAllocation = realChain.streamAllocation();

    		// We need the network to satisfy this request. Possibly for validating a conditional GET.
    		boolean doExtensiveHealthChecks = !request.method().equals("GET");
    		HttpCodec httpCodec = streamAllocation.newStream(client, chain, doExtensiveHealthChecks);//构建一个HttpCodec对象
    		RealConnection connection = streamAllocation.connection();

    		return realChain.proceed(request, streamAllocation, httpCodec, connection);
  		}
	}

可以看到，该方法的主要作用是创建一个HttpCodeC对象，然后交给下一个拦截器处理。HttpCodec是对Http协议操作的抽象，有两个实现：Http1Codec和Http2Codec，分别对应HTTP/1.1和HTTP/1.2版本的实现。

**CallServerInterceptor**

	public final class CallServerInterceptor implements Interceptor {
  		private final boolean forWebSocket;

  		public CallServerInterceptor(boolean forWebSocket) {
    		this.forWebSocket = forWebSocket;
  		}

  		@Override 
		public Response intercept(Chain chain) throws IOException {
			RealInterceptorChain realChain = (RealInterceptorChain) chain;
    		HttpCodec httpCodec = realChain.httpStream();//获取HttpCodeC对象
    		StreamAllocation streamAllocation = realChain.streamAllocation();
    		RealConnection connection = (RealConnection) realChain.connection();
    		Request request = realChain.request();//获取Request对象
			
    		long sentRequestMillis = System.currentTimeMillis();
			realChain.eventListener().requestHeadersStart(realChain.call());
    		httpCodec.writeRequestHeaders(request);//发送请求
    		realChain.eventListener().requestHeadersEnd(realChain.call(), request);

			Response.Builder responseBuilder = null;//构造响应头部header
    		if (HttpMethod.permitsRequestBody(request.method()) && request.body() != null) {
      			if ("100-continue".equalsIgnoreCase(request.header("Expect"))) {
        		httpCodec.flushRequest();
        		realChain.eventListener().responseHeadersStart(realChain.call());
       			responseBuilder = httpCodec.readResponseHeaders(true);
      		}
			// 构建响应体body
      		if (responseBuilder == null) {
        		realChain.eventListener().requestBodyStart(realChain.call());
        		long contentLength = request.body().contentLength();
        		CountingSink requestBodyOut =
            		new CountingSink(httpCodec.createRequestBody(request, contentLength));
        		BufferedSink bufferedRequestBody = Okio.buffer(requestBodyOut);

        		request.body().writeTo(bufferedRequestBody);
        		bufferedRequestBody.close();
        		realChain.eventListener()
            	.requestBodyEnd(realChain.call(), requestBodyOut.successfulCount);
      		} else if (!connection.isMultiplexed()) {
        		streamAllocation.noNewStreams();
      		}
    	}

    	httpCodec.finishRequest();//结束请求

    	if (responseBuilder == null) {
      		realChain.eventListener().responseHeadersStart(realChain.call());
      		responseBuilder = httpCodec.readResponseHeaders(false);
    	}
		//构造响应
    	Response response = responseBuilder
        	.request(request)
        	.handshake(streamAllocation.connection().handshake())
        	.sentRequestAtMillis(sentRequestMillis)
        	.receivedResponseAtMillis(System.currentTimeMillis())
        	.build();

    	realChain.eventListener()
        	.responseHeadersEnd(realChain.call(), response);

    	int code = response.code();//获取响应码
    	if (forWebSocket && code == 101) {
      		response = response.newBuilder()
          		.body(Util.EMPTY_RESPONSE)
          		.build();
    	} else {
      		response = response.newBuilder()
          		.body(httpCodec.openResponseBody(response))
          		.build();
    	}

    	if ("close".equalsIgnoreCase(response.request().header("Connection"))
        	|| "close".equalsIgnoreCase(response.header("Connection"))) {
      		streamAllocation.noNewStreams();
    	}

    	if ((code == 204 || code == 205) && response.body().contentLength() > 0) {
      		throw new ProtocolException(
          "HTTP " + code + " had non-zero Content-Length: " + response.body().contentLength());
    	}

    	return response;
	}

可以看到，在该方法中，主要完成了以下几件事情：

- 1.向服务器发送Request header；
- 2.如果有Request body，则向服务发送Request body；
- 3.读取Response Header，构造一个Response对象；
- 4.如果有Response body，则在前面的基础上，重新构造一个新的Response对象。

可以看到，上面的核心工作都是由HttpCodec完成，而HttpCode实际上是利用Okio来完成读取操作，而Okio实际上还是用的Socket，所以只是层层嵌套调用。

#### 3.2 异步请求处理过程

异步请求是通过调用RealCall类的enqueue()方法，将一个请求放入队列中。

1.RealCall.enqueue()

	@Override 
	public void enqueue(Callback responseCallback) {
    	synchronized (this) {
      		if (executed) throw new IllegalStateException("Already Executed");
      		executed = true;
    	}
    	captureCallStackTrace();
    	eventListener.callStart(this);
    	client.dispatcher().enqueue(new AsyncCall(responseCallback));//将CallBack包装成AsyncCall，并放入到Dispatcher的队列中。
  	}
可以看到，RealCall的enqueue()的方法只是简单的将CallBack包装成AsyncCall，并放入Dispatcher中的队列中。AsyncCall是一个实现了Runnable接口的类，表示可运行的任务。

	final class AsyncCall extends NamedRunnable {
    	private final Callback responseCallback;

    	AsyncCall(Callback responseCallback) {
      		super("OkHttp %s", redactedUrl());
      		this.responseCallback = responseCallback;
    	}
		....
	}

2.Dispatcher.enqueue()

	synchronized void enqueue(AsyncCall call) {
    	if (runningAsyncCalls.size() < maxRequests && runningCallsForHost(call) < maxRequestsPerHost) {
      		runningAsyncCalls.add(call);
      		executorService().execute(call);
    	} else {
      		readyAsyncCalls.add(call);
    	}
  	}

	/** Ready async calls in the order they'll be run. */
  	private final Deque<AsyncCall> readyAsyncCalls = new ArrayDeque<>();

  	/** Running asynchronous calls. Includes canceled calls that haven't finished yet. */
  	private final Deque<AsyncCall> runningAsyncCalls = new ArrayDeque<>();


runningAsyncCalls表示当前正在执行异步任务的队列，如果队列中还可以容纳请求并且请求数目还没有达到最大请求数目，则将请求添加到该队列中，并通过ExecutorService框架执行请求。

readyAsyncCalls表示等待执行的异步任务队列，当时机成熟时，将会把readyAsyncCalls里面的任务转移到runningAsyncCalls中执行。

由前面知道，AsyncCall是一个Runnable任务，因此当由ExecutorService框架执行该任务时，会执行AsyncCall的run()方法。

3.NamedRunnable.run()
	@Override 
	public final void run() {
    	String oldName = Thread.currentThread().getName();
    	Thread.currentThread().setName(name);
    	try {
      		execute();//调用execute方法
    	} finally {
      		Thread.currentThread().setName(oldName);
    	}
  	}

在run()方法中，最终调用的是execute()方法，该方法是一个虚方法，因此由子类AsyncCall类来实现。

4.AsyncCall.execute()

	@Override 
	protected void execute() {
      	boolean signalledCallback = false;
      	try {
        	Response response = getResponseWithInterceptorChain();//通过拦截栏获取响应
        	if (retryAndFollowUpInterceptor.isCanceled()) {
          		signalledCallback = true;
          		responseCallback.onFailure(RealCall.this, new IOException("Canceled"));//调用回调接口的onFailure()方法
        	} else {
          		signalledCallback = true;
          		responseCallback.onResponse(RealCall.this, response);//调用回调的onResponse方法
        	}
      	} catch (IOException e) {
        	if (signalledCallback) {
          		// Do not signal the callback twice!
          		Platform.get().log(INFO, "Callback failure for " + toLoggableString(), e);
        	} else {
          		eventListener.callFailed(RealCall.this, e);
          		responseCallback.onFailure(RealCall.this, e);
        	}
      	} finally {
        	client.dispatcher().finished(this);//结束
      	}
    }

可以看到在异步请求过程中，也是通过getResponseWithInterceptorChain()方法来获取响应的，同步请求也是通过该方法获取响应的。异步请求在获取响应后，会回调相应的回调方法。异步请求的使用示例如下：

	client.newCall(request).enqueue(new Callback() {
    	@Override
    	public void onFailure(Call call, IOException e) {
    	}

    	@Override
    	public void onResponse(Call call, Response response) throws IOException {
        	System.out.println(response.body().string());
    	}
	});


#### 3.3 HTTP缓存

在分析前面的getResponseWithInterceptorChain()方法时，里面有设置CacheInterceptor拦截器，该拦截器主要是用来处理缓存相关的事情。在建立连接之前，我们检查响应是否已经被缓存、缓存是否可用；如果缓存可以直接使用，则直接返回缓存中的数据，否则就进行后面的流程。在返回之前，还会把网络的数据写入缓存，以备下次使用。

1.CacheInterceptor

	public final class CacheInterceptor implements Interceptor {
  		final InternalCache cache;

  		public CacheInterceptor(InternalCache cache) {
    	this.cache = cache;
  		}
	}
InternalCache是一个接口，里面有两个关键的方法get()和put(),用来获取响应和保存响应。

	public interface InternalCache {
  		Response get(Request request) throws IOException;//获取对应请求的响应
  		CacheRequest put(Response response) throws IOException;//保存响应
		void remove(Request request) throws IOException;//移除对应的响应
		void update(Response cached, Response network);//更新对应的响应
		void trackConditionalCacheHit();
		void trackResponse(CacheStrategy cacheStrategy);
	}

2.CacheInterceptor.intercept()

	@Override public Response intercept(Chain chain) throws IOException {
    	Response cacheCandidate = cache != null
        	? cache.get(chain.request())
        	: null;//首先从缓存中获取响应，根据request获取响应

    	long now = System.currentTimeMillis();//记录系统当前时间

    	CacheStrategy strategy = new CacheStrategy.Factory(now, chain.request(), cacheCandidate).get();//缓存策略，决定是否使用缓存还是网络请求
    	Request networkRequest = strategy.networkRequest;//网络请求
    	Response cacheResponse = strategy.cacheResponse;//缓存响应

    	if (cache != null) {
      		cache.trackResponse(strategy);
    	}

    	if (cacheCandidate != null && cacheResponse == null) {
      		closeQuietly(cacheCandidate.body()); // 缓存不合适，关闭它
    	}

		// 1.如果我们禁止使用网络获取响应，并且该缓存是无效的，则请求失败
    	if (networkRequest == null && cacheResponse == null) {
      		return new Response.Builder()
          	.request(chain.request())
          	.protocol(Protocol.HTTP_1_1)
          	.code(504)//失败码
          	.message("Unsatisfiable Request (only-if-cached)")
          	.body(Util.EMPTY_RESPONSE)//空的响应体
          	.sentRequestAtMillis(-1L)
          	.receivedResponseAtMillis(System.currentTimeMillis())
          	.build();
    	}

		// 2.如果我们不需要网络请求，则执行完成，返回缓存响应
    	if (networkRequest == null) {
      		return cacheResponse.newBuilder()
          		.cacheResponse(stripBody(cacheResponse))
          		.build();
    	}

    	Response networkResponse = null;
    	try {//3.通过网络请求获取响应
      		networkResponse = chain.proceed(networkRequest);
    	} finally {
      		// If we're crashing on I/O or otherwise, don't leak the cache body.
            // 发生了异常，则关闭了该缓存，避免内存泄漏
      		if (networkResponse == null && cacheCandidate != null) {
        		closeQuietly(cacheCandidate.body());
      		}
    	}

        // 4.如果我有一个缓存响应，则我们有条件的选取
    	if (cacheResponse != null) {
      		if (networkResponse.code() == HTTP_NOT_MODIFIED) {//响应码是304
        		Response response = cacheResponse.newBuilder()
            	.headers(combine(cacheResponse.headers(), networkResponse.headers()))
            	.sentRequestAtMillis(networkResponse.sentRequestAtMillis())
            	.receivedResponseAtMillis(networkResponse.receivedResponseAtMillis())
            	.cacheResponse(stripBody(cacheResponse))
            	.networkResponse(stripBody(networkResponse))
            	.build();
        		networkResponse.body().close();//关闭网络请求响应

				// 更新缓存
        		cache.trackConditionalCacheHit();
        		cache.update(cacheResponse, response);
        		return response;
      		} else {
        		closeQuietly(cacheResponse.body());
      		}
    	}
        
    	Response response = networkResponse.newBuilder()
        	.cacheResponse(stripBody(cacheResponse))
        	.networkResponse(stripBody(networkResponse))
        	.build();

    	if (cache != null) {
      		if (HttpHeaders.hasBody(response) && CacheStrategy.isCacheable(response, networkRequest)) {
        	// Offer this request to the cache.
        	CacheRequest cacheRequest = cache.put(response);//保存缓存
        	return cacheWritingResponse(cacheRequest, response);
      	}

      	if (HttpMethod.invalidatesCache(networkRequest.method())) {
        	try {
          		cache.remove(networkRequest);//移除网络请求对应的缓存
        	} catch (IOException ignored) {
          		// The cache cannot be written.
        	}
      	}
    	}

    	return response;
  	}

可以看到，在CacheInterceptor的intercept()方法中，对是否网络响应还是缓存响应进行了相应的判断。在这个过程中，CacheStrategy缓存策略决定了是通过网络请求获取响应，还是在缓存中获取响应。当从网络中获取到响应时，还需要考虑是否需要保存到缓存中，还是更新缓存中的响应。

如果OkHttpClient中内存的缓存Cache不能满足我们的需求，我们还可以实现InternalCache接口，然后在构造OkHttpClient的时候进行设置，这样就可以实现我们自定义的缓存策略了。

常见的缓存实现有DiskLruCache和LruCache，OkHttpClient中的Cache类使用的就是DiskLruCache类来实现缓存的。

### 4.小结

OKHttp类图如下：

![OkHttpClient类图](http://orbohk5us.bkt.clouddn.com/17-11-15/19567449.jpg)

- OKHttpClient实现了Call.Factory，负责为Request创建Call；
- RealCall是Call的具体实现类，其中包含了同步请求方法execute()和异步请求方法enqueue()方法。异步请求方法是通过ExecutorService来执行请求的，最终不管是同步请求还是异步请求，都是通过getResponseWithInterceptorChain()方法来获取响应。
- 在getResponseWithInterceptorChain()方法中，利用了Interceptor拦截链，分层实现了缓存、透明压缩、网络IO等功能。


参考：

[文加图, 理解Http请求与响应](http://www.jianshu.com/p/51a61845e66a#)

[OkHttp使用完全教程](http://www.jianshu.com/p/ca8a982a116b)


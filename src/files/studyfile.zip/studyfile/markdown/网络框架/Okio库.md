## Okio库
[TOC]

### 1.概述
> Okio补充了java.io和java.nio的内容，使得数据访问、存储和处理更加便捷。

Okio的主要功能都被封装在ByteString和Buffer这两个类中，整个库都是围绕这两个类展开的。

#### 1.1 ByteString


- **ByteString**： ByteString是一个**不可变的(immutable)字节序列**。对于字符数据，String是一个基础的类，但是在二进制数据的处理中，没有与之对应的存在。因此ByteString应用而生，其中Byte代表的是“字节”，而String代表的是“串”。ByteString使得处理二进制数据更加容易，它为我们提供了对串操作所需要的各种API，例如子串、判等、查找等。它也能把二进制数据编码为十六进制(hex)、base64和UTF-8格式。

ByteString为我们提供了和String非常类似的API：

- 获取字节：指定位置，或者整个数组；
- 编解码：hex，base64，UTF-8；
- 判等，查找，子串等操作；

#### 1.2 Buffer

- **Buffer**：Buffer 是一个**可变的字节序列**，就像 ArrayList 一样。我们使用时只管从它的头部读取数据，往它的尾部写入数据就行了，而无需考虑容量、大小、位置等其他因素。

Buffer内部使用一个双向Segment链表来保存数据，当你需要将数据从一个Buffer移动到另外一个Buffer时，只需要修改Segment的所属关系，即转让Segment，就可以完成数据的转移，这样就避免了数据拷贝的开销。

Segment是对一小段字节数组的封装，保存了这个字节数组的一些访问信息，**数据的移动通过Segment的转让完成**，避免了数据拷贝的开销。而且Okio还实现了一个 Segment对象池，以提高我们分配和释放字节数组的效率。



#### 1.3 Sources和Sinks

Okio吸收了java.io一个非常优雅的设计：**流(stream)**，流可以一层一层包装起来，不断扩充能力，最终完成像加密和压缩这样复杂的操作。

Okio有它自己的流类型，那就是Source和Sink，它们和InputStream和OutputStream类似，前者为输入流，后者为输出流。

Source和Sink与InputStream和OutputStream流的不同之处在于：

- 超时机制，所有的流都有超时机制；
- 易于实现，提供了一些简单的API，例如Source声明了read()、close()和timeout()等API。
- 易于使用，Source和Sink的API非常简洁，为了应对更复杂的需求，Okio还提供了BufferedSource和BufferedSink接口，便于使用。
- 不再区分字节流和字符流，它们都是数据，可以按照任意类型去读写；
- 便于测试，Buffer同时实现了BufferedSource和BufferedSink接口，便于测试；

我们可以把Source与InputStream等同对待，把Sink与OutputStream等同对待。


### 2.源码分析

#### 2.1.ByteString类

ByteString类代表一个不可变字节序列。

ByteString类实现了Serialable接口和Comparable接口

	public class ByteString implements Serializable, Comparable<ByteString> {
		static final char[] HEX_DIGITS =
      	{ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };//十六进制字符
		final byte[] data;//字节数据
		transient int hashCode;//hash值
		transient String utf8;//utf-8格式的字符
	}

2.1.1 ByteString的构造函数

	ByteString(byte[] data) {
    	this.data = data; // Trusted internal constructor doesn't clone data.
  	}
一般都不是直接通过ByteString的构造函数来获取ByteString对象，而是通过它的工厂函数of()来获取ByteString。

	/**
   	* Returns a new byte string containing a clone of the bytes of {@code data}.
   	*/
  	public static ByteString of(byte... data) {
    	if (data == null) throw new IllegalArgumentException("data == null");
    	return new ByteString(data.clone());
  	}

	/**
   	* Returns a new byte string containing a copy of {@code byteCount} bytes of {@code data} starting
   	* at {@code offset}.
   	*/
  	public static ByteString of(byte[] data, int offset, int byteCount) {
    	if (data == null) throw new IllegalArgumentException("data == null");
    	checkOffsetAndCount(data.length, offset, byteCount);

    	byte[] copy = new byte[byteCount];
    	System.arraycopy(data, offset, copy, 0, byteCount);
    	return new ByteString(copy);
  	}

	public static ByteString of(ByteBuffer data) {
    	if (data == null) throw new IllegalArgumentException("data == null");

    	byte[] copy = new byte[data.remaining()];
    	data.get(copy);
    	return new ByteString(copy);
  	}

2.1.2 返回一个带编码格式的ByteString

	/** Returns a new byte string containing the {@code UTF-8} bytes of {@code s}. */
 	public static ByteString encodeUtf8(String s) {
    	if (s == null) throw new IllegalArgumentException("s == null");
    	ByteString byteString = new ByteString(s.getBytes(Util.UTF_8));
    	byteString.utf8 = s;//将UTF-8的字符串保存在utf8变量中
    	return byteString;
  	}

	/** Returns a new byte string containing the {@code charset}-encoded bytes of {@code s}. */
  	public static ByteString encodeString(String s, Charset charset) {
    	if (s == null) throw new IllegalArgumentException("s == null");
    	if (charset == null) throw new IllegalArgumentException("charset == null");
    	return new ByteString(s.getBytes(charset));
  	}

返回指定编码格式的字符串

	/** Constructs a new {@code String} by decoding the bytes as {@code UTF-8}. */
  	public String utf8() {
    	String result = utf8;
    	// We don't care if we double-allocate in racy code.
    	return result != null ? result : (utf8 = new String(data, Util.UTF_8));
  	}

  	/** Constructs a new {@code String} by decoding the bytes using {@code charset}. */
  	public String string(Charset charset) {
    	if (charset == null) throw new IllegalArgumentException("charset == null");
    	return new String(data, charset);
  	}

2.1.3 compareTo()

	@Override 
	public int compareTo(ByteString byteString) {
    	int sizeA = size();//获取字节数组大小
    	int sizeB = byteString.size();
    	for (int i = 0, size = Math.min(sizeA, sizeB); i < size; i++) {
      		int byteA = getByte(i) & 0xff;//计算字节的大小
      		int byteB = byteString.getByte(i) & 0xff;
			//比较字节是否相等，如果相等则继续，否则返回-1或者1
      		if (byteA == byteB) continue;
      			return byteA < byteB ? -1 : 1;
    		}
    	if (sizeA == sizeB) return 0;
    	return sizeA < sizeB ? -1 : 1;
  }

2.1.4 decodeHex()

	/** Decodes the hex-encoded bytes and returns their value a byte string. */
  	public static ByteString decodeHex(String hex) {
    	if (hex == null) throw new IllegalArgumentException("hex == null");
    	if (hex.length() % 2 != 0) throw new IllegalArgumentException("Unexpected hex string: " + hex);

    	byte[] result = new byte[hex.length() / 2];
    	for (int i = 0; i < result.length; i++) {
      		int d1 = decodeHexDigit(hex.charAt(i * 2)) << 4;//左移4位，高字节
      		int d2 = decodeHexDigit(hex.charAt(i * 2 + 1));//
      		result[i] = (byte) (d1 + d2);
    	}
   	 	return of(result);
  	}

	private static int decodeHexDigit(char c) {
    	if (c >= '0' && c <= '9') return c - '0';
    	if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    	if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    	throw new IllegalArgumentException("Unexpected hex digit: " + c);
  	}

该函数的主要作用是根据十六进的字符串进行编码，返回一个ByteString。

可以看到它的实现原理是把每个字符所对应的十六进制值，保存到一个字节数组中，然后利用of这个工厂方法构造一个ByteString对象。


2.1.5 equals()

	@Override 
	public boolean equals(Object o) {
    	if (o == this) return true;
   	 	return o instanceof ByteString
        	&& ((ByteString) o).size() == data.length
        	&& ((ByteString) o).rangeEquals(0, data, 0, data.length);
  	}

	/**
   	* Returns true if the bytes of this in {@code [offset..offset+byteCount)} equal the bytes of
   	* {@code other} in {@code [otherOffset..otherOffset+byteCount)}. Returns false if either range is
   	* out of bounds.
   	*/
  	public boolean rangeEquals(int offset, byte[] other, int otherOffset, int byteCount) {
    	return offset >= 0 && offset <= data.length - byteCount
        	&& otherOffset >= 0 && otherOffset <= other.length - byteCount
        	&& arrayRangeEquals(data, offset, other, otherOffset, byteCount);
  	}

	public static boolean arrayRangeEquals(
      byte[] a, int aOffset, byte[] b, int bOffset, int byteCount) {
    	for (int i = 0; i < byteCount; i++) {
      		if (a[i + aOffset] != b[i + bOffset]) 
				return false;
    	}
    	return true;
  	}

equals方法的实现其实就是把指定范围内的字节逐个对比。


2.1.6 toAsciiLowercase()方法

	/**
   	* Returns a byte string equal to this byte string, but with the bytes 'A'
   	* through 'Z' replaced with the corresponding byte in 'a' through 'z'.
   	* Returns this byte string if it contains no bytes in 'A' through 'Z'.
   	*/
 	 public ByteString toAsciiLowercase() {
    	// Search for an uppercase character. If we don't find one, return this.
    	for (int i = 0; i < data.length; i++) {
      	byte c = data[i];
      	if (c < 'A' || c > 'Z') continue;

      	// If we reach this point, this string is not not lowercase. Create and
      	// return a new byte string.
      	byte[] lowercase = data.clone();
      	lowercase[i++] = (byte) (c - ('A' - 'a'));
      	for (; i < lowercase.length; i++) {
        	c = lowercase[i];
        	if (c < 'A' || c > 'Z') continue;
        	lowercase[i] = (byte) (c - ('A' - 'a'));
      	}
      	return new ByteString(lowercase);
    	}
    	return this;
  	}

ByteString中有两个高性能的实现技巧：

- 把一个 String 编码为 utf8 时，会引用原 String，后面解码时就可以直接返回了，具体见encodeUtf8()方法；
- 由于不可变，所以不怕被篡改，所以 toAsciiLowercase，toAsciiUppercase，substring 等函数的实现中，如果需要返回的内容和自身一样，那就会直接返回 this

	
#### 2.2 Segment和SegmentPool类

Segment可以理解为Buffer的一部分。

每个Segment在buffer中是以循环双向链表的形式来组织的。而每个Segment在Segment缓存池中是以单链表的形式存在。

2.2.1 Segment类变量解析：

	final class Segment {
		
		static final int SIZE = 8192;// 所有segment的大小，以字节为单位
		static final int SHARE_MINIMUM = 1024;// segment应该被共享的大小
		final byte[] data;//存放数据
		int pos;// 下一个字节读取的位置
		int limit;// 下一个字节写入的位置
		boolean shared;//是否被共享
		boolean owner;// 该Segment是否拥有这个byte数组
		Segment next;//指向下一个Segment
		Segment prev;//指向前一个Segment
	}

2.2.2 Segment类构造函数解析：

	Segment() {
    	this.data = new byte[SIZE];//创建SIZE大小的字节数组
    	this.owner = true;//该Segment拥有这个字节数组
    	this.shared = false;//没有被共享
  	}

	Segment(Segment shareFrom) {
    	this(shareFrom.data, shareFrom.pos, shareFrom.limit);
    	shareFrom.shared = true;//该字节数组被共享了
  	}

	Segment(byte[] data, int pos, int limit) {
    	this.data = data;
    	this.pos = pos;
    	this.limit = limit;
    	this.owner = false;
    	this.shared = true;
  	}

2.2.3 pop()和push()

	public @Nullable Segment pop() {
    	Segment result = next != this ? next : null;//下一个segment
    	prev.next = next;
    	next.prev = prev;
    	next = null;
    	prev = null;
    	return result;
  	}
pop()函数的主要作用是从双向循环链表中移除当前的segment，并且返回当前segment的下一个segment。

	public Segment push(Segment segment) {
    	segment.prev = this;
    	segment.next = next;
    	next.prev = segment;
    	next = segment;
    	return segment;
  	}
push函数的主要作用是在当前循环链表的后面，添加一个segment，并且返回添加的segment。


2.2.4 spit()和compact()函数

	public Segment split(int byteCount) {
    	if (byteCount <= 0 || byteCount > limit - pos) throw new IllegalArgumentException();
    		Segment prefix;

    	// We have two competing performance goals:
    	//  - Avoid copying data. We accomplish this by sharing segments.
    	//  - Avoid short shared segments. These are bad for performance because they are readonly and
    	//    may lead to long chains of short segments.
    	// To balance these goals we only share segments when the copy will be large.
   	 	if (byteCount >= SHARE_MINIMUM) {
      		prefix = new Segment(this);//如果byteCount大于最小共享大小1024，则创建一个新的segment。
    	} else {
      		prefix = SegmentPool.take();//从缓存池中获取一个segment
      		System.arraycopy(data, pos, prefix.data, 0, byteCount);
    	}

    	prefix.limit = prefix.pos + byteCount;//新segment的数据在[pos,pos+byteCount]区间
    	pos += byteCount;//当前segment的数据在[pos+byteCount,limit]区间
    	prev.push(prefix);//将新segment插入到当前循环链表的前面
    	return prefix;//返回循环链表的新的头节点
  	}

split()函数的主要作用是将循环链表的头结点segment分割成两个segment。第一个segment包含[pos,pos+byteCount]区间的数据；第二个segment包含[pos+byteCount,limit]区间的数据。该返回返回循环链表新的头结点。


  	public void compact() {
    	if (prev == this) throw new IllegalStateException();
    	if (!prev.owner) return; // Cannot compact: prev isn't writable.
    	int byteCount = limit - pos;//获取数据大小
    	int availableByteCount = SIZE - prev.limit + (prev.shared ? 0 : prev.pos);//可用的大小
    	if (byteCount > availableByteCount) //可用大小大于当前数据大小，即空闲空间大于一半
			return; // Cannot compact: not enough writable space.
    	writeTo(prev, byteCount);//将当前Segment的byteCount数据拷贝到前一个segment。
    	pop();// 从当前循环链表中移除该segment
    	SegmentPool.recycle(this);//回收该segment到缓存池中
  	}

当尾部segment与其前面的segment大小都小于一半大小，则进行合并，以便segment可以被回收利用。

2.2.5 writeTo()

   	public void writeTo(Segment sink, int byteCount) {
    	if (!sink.owner) throw new IllegalArgumentException();
		// 判断limit + byteCount是否大于Segment的大小
    	if (sink.limit + byteCount > SIZE) {
      	// We can't fit byteCount bytes at the sink's current position. Shift sink first.
      	if (sink.shared) throw new IllegalArgumentException();
		// 如果limit + byteCount - pos 大于SIZE，则说明当前Segment存放不下这么多数据，抛出异常；如果可以存放，则先将数据进行位移，腾出足够空间来容纳byteCount大小的数据
      	if (sink.limit + byteCount - sink.pos > SIZE) throw new IllegalArgumentException();
      	System.arraycopy(sink.data, sink.pos, sink.data, 0, sink.limit - sink.pos);//将pos到limit区间的数据前向移动pos个位置
      	sink.limit -= sink.pos;//更新limit的位置
      	sink.pos = 0;//更新pos的位置
    	}

    	System.arraycopy(data, pos, sink.data, sink.limit, byteCount);//将整个byteCount数据添加在[limit,limit+byteCount]区间
    	sink.limit += byteCount;//更新limit的位置
    	pos += byteCount;//更新当前segment的pos位置
  	}
该方法的主要作用是将byteCount的字节从当前segment转移到另外一个segment中。


2.2.6 SegmentPool类

SegmentPool是Segment缓存池，用来管理空闲的Segment。

	final class SegmentPool {
  		/** The maximum number of bytes to pool. */
  		// TODO: Is 64 KiB a good maximum size? Do we ever have that many idle segments?
  		static final long MAX_SIZE = 64 * 1024; // 缓存池的最大大小

  		/** Singly-linked list of segments. */
  		static @Nullable Segment next;//单链表中的下一个segment

  		/** Total bytes in this pool. */
  		static long byteCount;//缓存池字节大小

  		private SegmentPool() {
  		}

	/*从缓存中获取一个Segment，如果没有则创建一个新的Segment*/
  	static Segment take() {
    	synchronized (SegmentPool.class) {
      		if (next != null) {
        		Segment result = next;
        		next = result.next;
        		result.next = null;
        		byteCount -= Segment.SIZE;
        		return result;
      		}
    	}
    	return new Segment(); // Pool is empty. Don't zero-fill while holding a lock.
  	}

	/*回收segment到缓存池中*/
  	static void recycle(Segment segment) {
    	if (segment.next != null || segment.prev != null) throw new IllegalArgumentException();
    	if (segment.shared) return; // This segment cannot be recycled.
    		synchronized (SegmentPool.class) {
      		if (byteCount + Segment.SIZE > MAX_SIZE) return; // Pool is full.
      		byteCount += Segment.SIZE;//更新byteCount大小
      		segment.next = next;//将segment插入队列的头结点
      		segment.pos = segment.limit = 0;//初始化segment的pos和limit都为0
      		next = segment;
    		}
  		}
	}

Segment的组织方式如下图所示：

![Segment的组织方式](http://orbohk5us.bkt.clouddn.com/17-11-11/45631274.jpg)

#### 2.3 Okio类

Okio类提供必要的访问API接口给外层使用。

2.3.1 buffer()方法

	public static BufferedSource buffer(Source source) {
    	return new RealBufferedSource(source);
  	}

	public static BufferedSink buffer(Sink sink) {
    	return new RealBufferedSink(sink);
  	}
buffer()方法是一个重载方法，根据不同的参数，调用不同的方法。我们以参数为Source来看，buffer()方法返回的是RealBufferedSource对象，该对象实现了BufferedSource接口。

	final class RealBufferedSource implements BufferedSource {
		.....
		RealBufferedSource(Source source) {
    		if (source == null) throw new NullPointerException("source == null");
    		this.source = source;
  		}
		....
	}
buffer()方法主要的作用是对Source或Sink进行包装，返回一个带缓冲的Source和Sink。

2.3.2 sink()和source()方法

	// 返回一个写入到OutputStream的Sink
	public static Sink sink(OutputStream out) {
    	return sink(out, new Timeout());
  	}
	
	private static Sink sink(final OutputStream out, final Timeout timeout) {
    	if (out == null) throw new IllegalArgumentException("out == null");
    	if (timeout == null) throw new IllegalArgumentException("timeout == null");
		// 新建一个实现Sink()接口的内部类
    	return new Sink() {
      	@Override 
		public void write(Buffer source, long byteCount) throws IOException {
        	checkOffsetAndCount(source.size, 0, byteCount);
        	while (byteCount > 0) {
          		timeout.throwIfReached();//判断是否超时
          		Segment head = source.head;//获取Source头部的Segment
          		int toCopy = (int) Math.min(byteCount, head.limit - head.pos);//计算需要复制的大小
          		out.write(head.data, head.pos, toCopy);//写入到OutputStream中

          		head.pos += toCopy;//更新Segment中的pos位置
          		byteCount -= toCopy;//更新需要写入的byte数量
          		source.size -= toCopy;//更新Source中的字节大小

          		if (head.pos == head.limit) {//如果Segment中数据全部复制完成了，则将该segment回收到Segment缓存池中
            		source.head = head.pop();
            		SegmentPool.recycle(head);
          		}
        	}
      	}

      	@Override 
		public void flush() throws IOException {
        	out.flush();
      	}

      	@Override 
		public void close() throws IOException {
        	out.close();
      	}

      	@Override 
		public Timeout timeout() {
        	return timeout;
      	}

      	@Override 
		public String toString() {
        	return "sink(" + out + ")";
      	}
    	};
  	}
	
	// 返回一个写入到Socket的Sink
	public static Sink sink(Socket socket) throws IOException {
    	if (socket == null) throw new IllegalArgumentException("socket == null");
    	AsyncTimeout timeout = timeout(socket);//创建一个超时对象
    	Sink sink = sink(socket.getOutputStream(), timeout);//调用上面的方法创建一个Sink对象
    	return timeout.sink(sink);
  	}

	private static AsyncTimeout timeout(final Socket socket) {
    	return new AsyncTimeout() {
      	@Override 
		protected IOException newTimeoutException(@Nullable IOException cause) {
        	InterruptedIOException ioe = new SocketTimeoutException("timeout");
        	if (cause != null) {
          		ioe.initCause(cause);
        	}
        	return ioe;
      	}

      	@Override 
		protected void timedOut() {
        	try {
          		socket.close();//发生了超时，则关闭该Socket
        	} catch (Exception e) {
          		logger.log(Level.WARNING, "Failed to close timed out socket " + socket, e);
        	} catch (AssertionError e) {
          	if (isAndroidGetsocknameError(e)) {
            	// Catch this exception due to a Firmware issue up to android 4.2.2
            	// https://code.google.com/p/android/issues/detail?id=54072
            	logger.log(Level.WARNING, "Failed to close timed out socket " + socket, e);
          	} else {
            	throw e;
          	}
        	}
      	}
    	};
  	}
可以看到Sink()方法主要是返回一个写入到OutputStream或者是Socket的Sink对象，方便写入操作。

	// 返回一个从InputStream中读取数据的Source
	public static Source source(InputStream in) {
    	return source(in, new Timeout());
  	}

	private static Source source(final InputStream in, final Timeout timeout) {
    	if (in == null) throw new IllegalArgumentException("in == null");
    	if (timeout == null) throw new IllegalArgumentException("timeout == null");
		
		// 创建一个新的Source对象
    	return new Source() {
      	@Override 
		public long read(Buffer sink, long byteCount) throws IOException {
        	if (byteCount < 0) throw new IllegalArgumentException("byteCount < 0: " + byteCount);
        	if (byteCount == 0) return 0;
        	try {
          		timeout.throwIfReached();//超时
          		Segment tail = sink.writableSegment(1);//获取Sink中尾部的Segment
          		int maxToCopy = (int) Math.min(byteCount, Segment.SIZE - tail.limit);//计算需要复制的大小
          		int bytesRead = in.read(tail.data, tail.limit, maxToCopy);//从InputStream中读取数据
          		if (bytesRead == -1) return -1;
          		tail.limit += bytesRead;//更新Segment中的大小
          		sink.size += bytesRead;//更少Sink的大小
          		return bytesRead;
        	} catch (AssertionError e) {
          		if (isAndroidGetsocknameError(e)) throw new IOException(e);
          		throw e;
        	}
      	}

      	@Override 
		public void close() throws IOException {
        	in.close();
      	}

      	@Override 
		public Timeout timeout() {
        	return timeout;
      	}

      	@Override 
		public String toString() {
        	return "source(" + in + ")";
      	}
    	};
  	}
	
	// 返回一个从File中读取数据的Source
	public static Source source(File file) throws FileNotFoundException {
    	if (file == null) throw new IllegalArgumentException("file == null");
    	return source(new FileInputStream(file));
  	}

	public static Source source(Socket socket) throws IOException {
    	if (socket == null) throw new IllegalArgumentException("socket == null");
    	AsyncTimeout timeout = timeout(socket);
    	Source source = source(socket.getInputStream(), timeout);//构建一个Source对象
    	return timeout.source(source);
  	}

可以看到source()方法主要是返回一个从InputStream、File或者Socket中读取数据的Source对象，方便读取操作。

2.3.3 Okio类的使用

我们比较常见的输入输出是InputStream和OutputStream，对于需要从InputStream中读取数据时，我们可以首先通过Okio的source()方法，将InputStream包装成一个Source对象，然后再通过Okio的buffer()方法，将Source对象包装成一个BufferedSource对象，后续对输入流的操作都是通过BufferedSource对象。同样的，往输出流写入数据时，也是先通过Okio的Sink()方法，将OutputStream包装成一个Sink对象，然后再通过Okio的buffer()方法，将Sink对象包装成一个BufferedSink对象，后续对输出流的操作都是通过BufferedSink对象来完成的。例如：

	BufferedSource pngSource = Okio.buffer(Okio.source(in)；


#### 2.3 Buffer类

Buffer表示在内存中的一个字节集合。

从一个Buffer转移数据到另一个Buffer是非常快的。Buffer仅仅是修改字节数组的所属关系，而不是将数据从一个地方拷贝到另外一个地方。

Buffer是随着数据的增大而增加，就像ArrayList一样，每个Buffer开始的时候很小，它只消耗它所需要的内存。

怎样利用Okio从InputStream中读取数据？官方的例子：

	private static final ByteString PNG_HEADER = ByteString.decodeHex("89504e470d0a1a0a");

	public void decodePng(InputStream in) throws IOException {
  		try (BufferedSource pngSource = Okio.buffer(Okio.source(in))) {
    		ByteString header = pngSource.readByteString(PNG_HEADER.size());
    		if (!header.equals(PNG_HEADER)) {
      			throw new IOException("Not a PNG.");
    		}

   	 		while (true) {
      		Buffer chunk = new Buffer();

      		// Each chunk is a length, type, data, and CRC offset.
      		int length = pngSource.readInt();
      		String type = pngSource.readUtf8(4);
      		pngSource.readFully(chunk, length);
      		int crc = pngSource.readInt();

      		decodeChunk(type, chunk);
      		if (type.equals("IEND")) break;
    		}
  		}
	}

	private void decodeChunk(String type, Buffer chunk) {
  		if (type.equals("IHDR")) {
    		int width = chunk.readInt();
    		int height = chunk.readInt();
    		System.out.printf("%08x: %s %d x %d%n", chunk.size(), type, width, height);
  		} else {
    		System.out.printf("%08x: %s%n", chunk.size(), type);
  		}
	}


RealBufferedSource 和 RealBufferedSink 这两个类的实现逻辑是：读操作都是先把数据从 Source 读到 Buffer，再把数据从 Buffer 读到输出（返回值或传入的输出参数）；写操作都是先把数据从输入写到 Buffer，再把数据从 Buffer 写到 Sink。

**为什么要这么倒腾？**让我们从功能需求和设计方案来考虑。

BufferedSource 要提供各种形式的读取操作，还有查找与判等操作。大家可能会想，那我就在实现类中自己实现不就好了吗？干嘛要经过 Buffer 中转呢？这里我们实现的时候，需要考虑效率的问题，而且不仅 BufferedSource 需要高效实现，BufferedSink 也需要高效实现，这两者的高效实现技巧，很大部分都是共通的，所以为了避免同样的逻辑重复两遍，Okio 就直接把读写操作都实现在了 Buffer 这一个类中，这样逻辑更加紧凑，更加内聚。而且还能直接满足我们对于“两用数据缓冲区”的需求：既可以从头部读取数据，也能向尾部写入数据。至于我们单独的读写操作需求，Okio 就为 Buffer 分别提供了委托类：RealBufferedSource 和 RealBufferedSink，实现好 Buffer 之后，它们两者的实现将非常简洁

Okio库类图如下图所示：

![Okio库类图](http://orbohk5us.bkt.clouddn.com/17-11-11/78145281.jpg)

### 3. Retrofit，OkHttp是如何利用Okio

在 Retrofit/OkHttp 中，IO操作都是利用Okio实现的，像磁盘缓存，网络IO等。

![Retrofit，OkHttp，Okio进行网络IO的流程图](http://orbohk5us.bkt.clouddn.com/17-11-8/50965547.jpg)

## Retrofit简介

### 1.概述

Retrofit通过**注解**将一个Java 接口转换为一个Http请求。Retrofit通过Builder模式来构建，传递定义的接口给create()方法。例如：

	Retrofit retrofit = new Retrofit.Builder()
      .baseUrl("https://api.example.com/")
      .addConverterFactory(GsonConverterFactory.create())
      .build();

    MyApi api = retrofit.create(MyApi.class);
    Response<User> user = api.getUser().execute();
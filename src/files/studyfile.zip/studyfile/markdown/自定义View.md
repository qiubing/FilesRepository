## 自定义View

### 1.概述

View的绘制流程是从ViewRootImpl的performTraversal方法开始的，它经过measure、layout和draw三个过程才能最终将一个View绘制出来，其中measure用来测量View的宽和高，layout用来确定View在父容器中的放置位置，而draw则负责将View绘制在屏幕上。

measure过程决定了View的宽/高，Measure完成以后，可以通过getMeasureWidth和getMeasureHeight方法来获取到View测量后的宽/高,在几乎所有的情况下它都等同于View最终的宽/高。

Layout过程决定了View的四个顶点的坐标和实际的View的宽/高，完成以后，可以通过getTop、getBottom、getLeft和getRight来拿到View的四个顶点的位置，并可以通过getWidth和getHeight方法来拿到View的最终宽/高。

Draw过程则决定了View的显示，只有draw方法完成以后View的内容才能呈现在屏幕上。


### 2.View的工作流程

对于DecorView，其MeasureSpec由窗口的尺寸和其自身的LayoutParams来共同确定。对于普通的View，其MeasureSpec由父容器的MeasureSpec和自身的LayoutParams来共同决定，MeasureSpec一旦确定后，onMeasure中就可以确定View的测量宽/高。

当View采用固定宽/高的时候，不管父容器的MeasureSpec是什么，View的MeasureSpec都是精确模式并且其大小遵循LayoutParams中的大小。当View的宽/高是match\_parent时，如果父容器的模式是精确模式，那么View也是精确模式并且其大小是父容器的剩余空间；如果父容器是最大模式，那么View也是最大模式并且其大小不会超过父容器的剩余空间。

View的工作流程主要是指measure、layout、draw这三大流程，即测量、布局和绘制。其中measure确定View的测量宽/高，layout确定View的最终宽/高和四个顶点的位置，而Draw则将View绘制到屏幕上。

**1.measure过程**

measure过程分为：View的measure过程以及ViewGroup的measure过程。

1.1 View的measure过程

View的measure过程由其measure方法来完成，measure方法是一个final类型的方法，这意味着子类不能重写此方法，在View的measure方法中会去调用View的onMeasure方法，因此只需要看onMeasure的实现即可。

1.2 ViewGroup的measure过程

对于ViewGroup来说，除了完成自己的mesure过程以外，还会遍历去调用所有子元素的measure方法，各个子元素再递归去执行这个过程。ViewGroup是一个抽象类，因此它没有重写View的onMeasure方法，但它提供了一个叫measureChildren的方法。

为什么ViewGroup不像View一样对其onMeasure方法做统一的实现呢？那是因为不同的ViewGroup子类有不同的布局特性。

**2.layout过程**

Layout的作用是ViewGroup用来确定子元素的位置，当ViewGroup的位置被确定后，它在onLayout中会遍历所有的子元素并调用其layout方法，在layout方法中，onLayout方法又会被调用。layout方法确定View本身的位置，而onLayout方法则会确定所有子元素的位置。

**3.draw过程**

Draw过程就比较简单了，它的作用是将View绘制到屏幕上面。View的绘制过程遵循如下几步：

1. 绘制背景background.draw(canvas);
2. 绘制自己(onDraw)；
3. 绘制children(dispatchDraw)；
4. 绘制装饰(onDrawScrollBars)；

View的绘制过程的传递是通过dispatchDraw来实现的，dispatchDraw会遍历调用所有子元素的draw方法，如此draw事件就一层层地传递了下去。

### 3.自定义View

**1.继承View重写onDraw方法**

这种方法主要用于实现一些不规则的效果，即这种效果不方便通过布局的组合方式来达到。很显然这需要通过绘制的方式来实现，即重写onDraw方法。采用这种方式需要自己支持wrap_content，并且padding也需要自己处理。

**2.继承ViewGroup派生特殊的Layout**

这种方法主要用于实现自定义的布局。需要合适地处理ViewGroup的测量、布局这两个过程，并同时处理子元素的测量和布局过程。

**3.继承特定的View**

这种方法比较常见，一般是用于扩展某种已有的View的功能，比如TextView，这种方法比较容易实现，需要自己支持wrap_content和padding等。

**4.继承特定的ViewGroup**

这种方法比较常见，当某几种效果看起来很像几种View组合在一起的时候，可以采用这种方法来实现。采用这种方法不需要自己处理ViewGroup的策略和布局这两个过程。

自定义View的一些注意事项：

- 让View支持wrap\_content；这是因为直接继承View或者ViewGroup的控件，如果不在onMeasure中对wrap\_content做特殊处理，那么当外界在布局中使用wrap_content时就无法达到预期的效果。
- 如果有必要，让你的View支持padding；这是因为直接继承View的控件，如果不在draw方法中处理padding，那么padding属性是无法起作用的。另外，直接继承自ViewGroup的控件，需要在onMesure和onLayout中考虑padding和子元素的margin对其造成的影响，不然将导致padding和子元素的margin失效。
- 尽量不要在View中使用Handler，没有必要；因为View内部本身就提供了post系列的方法，完成可以替代Handler的作用。
- View中如果有线程或者动画，需要及时停止，参考View.onDetachedFromWindow；如果有线程或者动画需要停止时，那么OnDetachedFromWindow是一个很好的时机。当包含此View的Activity退出或者当前View被remove时，View的onDetachedFromWindow方法会被调用，和此方法对应的是onAttachedToWindow，当包含此View的Activity启动时，View的onAttachedToWindow方法会被调用。
- View带有滑动嵌套情形时，需要处理好滑动冲突；如果有滑动冲突的话，那么要合适地处理滑动冲突，否则会严重影响View的效果。


### 4.自定义View的示例

1.继承View重写onDraw方法












## Android输入系统概述
[TOC]

### 简介

在Android系统中，输入事件是由WindowManagerService服务来管理的，然后再以消息的形式来分发给应用程序处理。当用户触摸屏幕或者按键操作，首次触发的是硬件驱动，驱动收到事件后，将该相应事件写入到输入设备节点， 这便产生了最原生态的内核事件。接着，输入系统取出原生态的事件，经过层层封装后成为KeyEvent或者MotionEvent；最后，交付给相应的目标窗口(Window)来消费该输入事件。可见，输入系统在整个过程起到承上启下的衔接作用。

在系统启动的时候，system_server进程会启动窗口管理服务WindowManagerService，WindowManagerService在启动的时候就会通过系统输入管理器服务InputManagerService来负责监控输入消息。这些输入消息一般都是分发给当前激活的Activity窗口来处理的。因此，当前激活的Activity窗口在创建的时候，会到WindowManagerService中去注册一个接收输入消息的通道，表明它要处理输入消息。而当InputManagerService监控到有输入消息时，就会分发给激活的Activity处理。如果当前激活的Activity窗口不再处于激活状态时，它也会到WindowManagerService中去反注册之前的输入消息接收通道，这样，InputManagerService就不会再把输入消息分发给它来处理。

由于输入系统整个跨度比较大，下面将分为几个部分来介绍输入系统：

- InputManagerService服务的初始化；
- 应用程序注册输入事件通道；
- InputManagerService分发输入事件给应用程序；
- 应用程序注销输入事件通道；
- 输入事件ANR原理分析；



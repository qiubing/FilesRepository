## InputManagerService分发输入事件给应用程序(上)

[TOC]

### 1.简介

在InputManagerService服务初始化时，会在Native层创建两个线程：InputDispatcherThread和InputReaderThread。InputReader线程负责读取输入事件，并把输入事件传递给InputDispatcher线程，然后由InputDispatcher将输入事件分发给处于激活的窗口。

接下来将从源码的角度来分析输入事件的一个分发过程。

### 2.源码分析

在InputReaderThread线程中，将会循环执行其threadLoop()方法。

2.1 InputReaderThread.threadLoop()

	bool InputReaderThread::threadLoop() {
    	mReader->loopOnce();//调用InputReader的loopOnce()方法,见2.2
    	return true;
	}
当threadLoop()方法返回true时，代表将循环调用loopOnce()方法。当threadLoop()方法返回false时，代表退出循环。

2.2 InputReader.loopOnce()
	
	void InputReader::loopOnce() {
    	int32_t oldGeneration;
    	int32_t timeoutMillis;
    	bool inputDevicesChanged = false;
    	Vector<InputDeviceInfo> inputDevices;//输入设备列表
    	{ // acquire lock
        	AutoMutex _l(mLock);

        	oldGeneration = mGeneration;
        	timeoutMillis = -1;

        	uint32_t changes = mConfigurationChangesToRefresh;
        	if (changes) {
            	mConfigurationChangesToRefresh = 0;
            	timeoutMillis = 0;
            	refreshConfigurationLocked(changes);
        	} else if (mNextTimeout != LLONG_MAX) {
            	nsecs_t now = systemTime(SYSTEM_TIME_MONOTONIC);
            	timeoutMillis = toMillisecondTimeoutDelay(now, mNextTimeout);
        	}
    	} // release lock

    	size_t count = mEventHub->getEvents(timeoutMillis, mEventBuffer, EVENT_BUFFER_SIZE);// 1.从EventHub中获取输入事件，见2.3

    	{ // acquire lock
        	AutoMutex _l(mLock);
        	mReaderIsAliveCondition.broadcast();

        	if (count) {
            	processEventsLocked(mEventBuffer, count);//2.如果获取到了输入事件，则处理该输入事件，见2.4
        	}

        	if (mNextTimeout != LLONG_MAX) {
            	nsecs_t now = systemTime(SYSTEM_TIME_MONOTONIC);
            	if (now >= mNextTimeout) {
                	mNextTimeout = LLONG_MAX;
                	timeoutExpiredLocked(now);
            	}
        	}

        	if (oldGeneration != mGeneration) {
            	inputDevicesChanged = true;
            	getInputDevicesLocked(inputDevices);
        	}
    	} // release lock

    	if (inputDevicesChanged) {// 输入设备发生了变化
        	mPolicy->notifyInputDevicesChanged(inputDevices);
    	}

    	mQueuedListener->flush();// 3.发送输入事件到InputDispatcher，见2.12
	}

在loopOnce()方法中，主要做了三件事情：

1. 通过EventHub的getEvents()方法获取输入事件，该方法将返回准备好的输入事件；
2. 调用processEventsLocked()方法来处理输入事件；
3. 通过mQueuedListener的flush()方法将输入事件发送到InputDispatcher；

接下来将分别围绕这三个过程来讲解。

2.3 EventHub.getEvents()

	size_t EventHub::getEvents(int timeoutMillis, RawEvent* buffer, size_t bufferSize) {
		ALOG_ASSERT(bufferSize >= 1);
    	AutoMutex _l(mLock);
		struct input_event readBuffer[bufferSize];
		RawEvent* event = buffer;//原始事件
    	size_t capacity = bufferSize;//容量大小为256
    	bool awoken = false;
		for (;;) {
			nsecs_t now = systemTime(SYSTEM_TIME_MONOTONIC);// 当前时间
			// 是否需要重新打开设备
			if (mNeedToReopenDevices) {
            	mNeedToReopenDevices = false;

            	ALOGI("Reopening all input devices due to a configuration change.");

           	 	closeAllDevicesLocked();
            	mNeedToScanDevices = true;
            	break; 
        	}
			
			// 记录最近被删除的设备
			while (mClosingDevices) {
            Device* device = mClosingDevices;
            mClosingDevices = device->next;
            event->when = now;
            event->deviceId = device->id == mBuiltInKeyboardId ? BUILT_IN_KEYBOARD_ID : device->id;
            event->type = DEVICE_REMOVED;//事件类型为设备删除
            event += 1;
            delete device;
            mNeedToSendFinishedDeviceScan = true;
            if (--capacity == 0) {
                break;
            	}
        	}
			
			// 需要扫描设备
			if (mNeedToScanDevices) {
            	mNeedToScanDevices = false;
            	scanDevicesLocked();//扫描设备，扫描的路径为/dev/input
            	mNeedToSendFinishedDeviceScan = true;
        	}
			
			// 记录打开的设备
			while (mOpeningDevices != NULL) {
            Device* device = mOpeningDevices;
            mOpeningDevices = device->next;
            event->when = now;
            event->deviceId = device->id == mBuiltInKeyboardId ? 0 : device->id;
            event->type = DEVICE_ADDED;//事件类型为打开设备
            event += 1;
            mNeedToSendFinishedDeviceScan = true;
            if (--capacity == 0) {
                break;
            }
	
			//结束设备扫描
			if (mNeedToSendFinishedDeviceScan) {
            	mNeedToSendFinishedDeviceScan = false;
            	event->when = now;
            	event->type = FINISHED_DEVICE_SCAN;//事件类型为设备扫描结束
            	event += 1;
            	if (--capacity == 0) {
                	break;
            	}
        	}

			// 获取下一个输入事件
			bool deviceChanged = false;
        	while (mPendingEventIndex < mPendingEventCount) {
			const struct epoll_event& eventItem = mPendingEventItems[mPendingEventIndex++];//获取待处理的epoll事件
            if (eventItem.data.u32 == EPOLL_ID_INOTIFY) {//epoll数据类型为EPOLL_ID_INOTIFY
                if (eventItem.events & EPOLLIN) {//epoll事件类型为可读
                    mPendingINotify = true;//发送通知
                } else {
                    ALOGW("Received unexpected epoll event 0x%08x for INotify.", eventItem.events);
                }
                continue;
            	}
			}
			
			// epoll数据类型为EPOLL_ID_WAKE
			if (eventItem.data.u32 == EPOLL_ID_WAKE) {
                if (eventItem.events & EPOLLIN) {//epoll事件类型为可读
                    ALOGV("awoken after wake()");
                    awoken = true;//唤醒
                    char buffer[16];
                    ssize_t nRead;
                    do {
                        nRead = read(mWakeReadPipeFd, buffer, sizeof(buffer));//从mWakeReadPipeFd中读取数据
                    } while ((nRead == -1 && errno == EINTR) || nRead == sizeof(buffer));
                } else {
                    ALOGW("Received unexpected epoll event 0x%08x for wake read pipe.",
                            eventItem.events);
                }
                continue;
            }

			ssize_t deviceIndex = mDevices.indexOfKey(eventItem.data.u32);// 获取设备索引

			Device* device = mDevices.valueAt(deviceIndex);// 根据设备索引获取设备
			
			if (eventItem.events & EPOLLIN) {//如果epoll事件类型为可读
				int32_t readSize = read(device->fd, readBuffer,
                        sizeof(struct input_event) * capacity);//从设备文件描述符中读取数据到readBuffer

				if (readSize == 0 || (readSize < 0 && errno == ENODEV)) {
                    deviceChanged = true;
                    closeDeviceLocked(device);
                } else if (readSize < 0) {
                   .......
                } else if ((readSize % sizeof(struct input_event)) != 0) {
                    ......
                } else {
					int32_t deviceId = device->id == mBuiltInKeyboardId ? 0 : device->id;//设备ID
					size_t count = size_t(readSize) / sizeof(struct input_event);//获取读到的输入事件数量
					for (size_t i = 0; i < count; i++) {
						struct input_event& iev = readBuffer[i];//输入事件
						.......
						//将input_event事件，封装成RawEvent事件
						event->when = nsecs_t(iev.time.tv_sec) * 1000000000LL
                                + nsecs_t(iev.time.tv_usec) * 1000LL;
			         	event->deviceId = deviceId;
                        event->type = iev.type;
                        event->code = iev.code;
                        event->value = iev.value;
                        event += 1;
                        capacity -= 1;
						if (capacity == 0) {
                        mPendingEventIndex -= 1;
                        break;
                    }
				}
				.....
				// 如果获取到了输入事件或者需要唤醒，则立即返回
				if (event != buffer || awoken) {
            		break;
        		}
				mPendingEventIndex = 0;
				mLock.unlock();//释放锁
				release_wake_lock(WAKE_LOCK_ID);
				int pollResult = epoll_wait(mEpollFd, mPendingEventItems, EPOLL_MAX_EVENTS, timeoutMillis);//等待输入事件到来
				
				acquire_wake_lock(PARTIAL_WAKE_LOCK, WAKE_LOCK_ID);
        		mLock.lock();//获取锁
	
				if (pollResult == 0) {//发生了超时
            		mPendingEventCount = 0;
            		break;
        		}

				if (pollResult < 0) {
           			// 发生了错误
            		mPendingEventCount = 0;
					......
        		} else {
            	// 发生了一些输入事件
            	mPendingEventCount = size_t(pollResult);
        		}

			}
        }
			
		return event - buffer;//然后读取的输入事件
	}
在EventHub的getEvent方法中，如果是第一次调用的话，则需要先扫描/dev/input目录下的输入设备。接着用mPendingEventItems保存待处理的输入事件，如果以及有输入事件需要处理，则立即返回；否则通过epoll_wait等待输入事件到来。

从EventHub中获取到输入事件之后，接着调用processEventsLocked()方法进行事件处理。

2.4 InputReader.processEventsLocked()

	void InputReader::processEventsLocked(const RawEvent* rawEvents, size_t count) {
    	for (const RawEvent* rawEvent = rawEvents; count;) {
        	int32_t type = rawEvent->type;//获取输入事件类型
        	size_t batchSize = 1;
        	if (type < EventHubInterface::FIRST_SYNTHETIC_EVENT) {
            	int32_t deviceId = rawEvent->deviceId;//设备ID
            	while (batchSize < count) {
                	if (rawEvent[batchSize].type >= EventHubInterface::FIRST_SYNTHETIC_EVENT
                        	|| rawEvent[batchSize].deviceId != deviceId) {
                    	break;
                	}
                	batchSize += 1;
            	}
            	processEventsForDeviceLocked(deviceId, rawEvent, batchSize);// 处理设备事件，见2.7
        	} else {
            	switch (rawEvent->type) {
            	case EventHubInterface::DEVICE_ADDED:
                	addDeviceLocked(rawEvent->when, rawEvent->deviceId);//添加设备，见2.5
                	break;
            	case EventHubInterface::DEVICE_REMOVED:
                	removeDeviceLocked(rawEvent->when, rawEvent->deviceId);//移除设备
                	break;
            	case 	EventHubInterface::FINISHED_DEVICE_SCAN:
                	handleConfigurationChangedLocked(rawEvent->when);//设备扫描结束
                	break;
            	default:
                	ALOG_ASSERT(false); // can't happen
                	break;
            	}
        	}
        	count -= batchSize;//更新待处理的输入事件数量
        	rawEvent += batchSize;
    	}
	}

事件处理总共有以下几种类型：

- DEVICE_ADDED：设备添加；
- DEVICE_REMOVED：设备移除；
- FINISHED_DEVICE_SCAN：设备扫描完成；
- 输入事件处理

下面看下设备添加事件处理过程。

2.5 InputReader.addDeviceLocked()

	void InputReader::addDeviceLocked(nsecs_t when, int32_t deviceId) {
    	ssize_t deviceIndex = mDevices.indexOfKey(deviceId);//设备索引
    	if (deviceIndex >= 0) {
        	//设备已经添加了，则直接返回
        	return;
    	}

    	InputDeviceIdentifier identifier = mEventHub->getDeviceIdentifier(deviceId);
    	uint32_t classes = mEventHub->getDeviceClasses(deviceId);
    	int32_t controllerNumber = mEventHub->getDeviceControllerNumber(deviceId);

    	InputDevice* device = createDeviceLocked(deviceId, controllerNumber, identifier, classes);//创建设备，见2.6
    	device->configure(when, &mConfig, 0);
    	device->reset(when);

    	mDevices.add(deviceId, device);//添加设备到mDevices中
    	......
	}

2.6 InputReader.createDeviceLocked()

	InputDevice* InputReader::createDeviceLocked(int32_t deviceId, int32_t controllerNumber,
        const InputDeviceIdentifier& identifier, uint32_t classes) {
	
    	InputDevice* device = new InputDevice(&mContext, deviceId, bumpGenerationLocked(),
            controllerNumber, identifier, classes);//创建InputDevice对象

    	// 外部设备
    	if (classes & INPUT_DEVICE_CLASS_EXTERNAL) {
        	device->setExternal(true);
    	}

    	// 鼠标
    	if (classes & INPUT_DEVICE_CLASS_MIC) {
        	device->setMic(true);
    	}

		......

    	// 键盘类型
    	uint32_t keyboardSource = 0;
    	int32_t keyboardType = AINPUT_KEYBOARD_TYPE_NON_ALPHABETIC;
    	if (classes & INPUT_DEVICE_CLASS_KEYBOARD) {
        	keyboardSource |= AINPUT_SOURCE_KEYBOARD;
    	}
    	if (classes & INPUT_DEVICE_CLASS_ALPHAKEY) {
        	keyboardType = AINPUT_KEYBOARD_TYPE_ALPHABETIC;
    	}
    	if (classes & INPUT_DEVICE_CLASS_DPAD) {
        	keyboardSource |= AINPUT_SOURCE_DPAD;
    	}
    	if (classes & INPUT_DEVICE_CLASS_GAMEPAD) {
        	keyboardSource |= AINPUT_SOURCE_GAMEPAD;
    	}
  
		// 添加键盘类设备KeyboardInputMapper
    	if (keyboardSource != 0) {
        	device->addMapper(new KeyboardInputMapper(device, keyboardSource, keyboardType));
    	}

    	// 添加鼠标类设备CursorInputMapper
    	if (classes & INPUT_DEVICE_CLASS_CURSOR) {
        	device->addMapper(new CursorInputMapper(device));
    	}

    	// 添加触屏类设备MultiTouchInputMapper或者SingleTouchInputMapper
    	if (classes & INPUT_DEVICE_CLASS_TOUCH_MT) {
        	device->addMapper(new MultiTouchInputMapper(device));
    	} else if (classes & INPUT_DEVICE_CLASS_TOUCH) {
        	device->addMapper(new SingleTouchInputMapper(device));
    	}

    	.....
    	return device;
	}

该方法的主要功能是创建一个InputDevice对象，将InputReader的mContext对象赋值给InputDevice对象所对应的变量；根据设备的类型来创建并添加对应的InputMapper。

输入设备的类型有很多种，其中常见的包含以下几种：

- 键盘类设备：KeyboardInputMapper
- 触屏类设备：MultiTouchInputMapper或者SingleTouchInputMapper
- 鼠标类设备：CursorInputMapper

介绍完了设备的添加过程，接下来回到2.4处，继续分析设备输入事件的处理过程，该过程主要是调用processEventsForDeviceLocked()方法。

2.7 InputReader.processEventsForDeviceLocked()

	void InputReader::processEventsForDeviceLocked(int32_t deviceId,
        const RawEvent* rawEvents, size_t count) {
    	ssize_t deviceIndex = mDevices.indexOfKey(deviceId);//设备索引
    	if (deviceIndex < 0) {
			//如果设备不存在，则直接返回
        	return;
    	}

    	InputDevice* device = mDevices.valueAt(deviceIndex);//获取设备
    	if (device->isIgnored()) {
			//如果设备需要忽略，则直接返回
        	return;
    	}

    	device->process(rawEvents, count);//调用InputDevice的process方法来处理，见2.8
	}

2.8 InputDevice.process()
	
	void InputDevice::process(const RawEvent* rawEvents, size_t count) {
		size_t numMappers = mMappers.size();//mapper的数量
		// 处理所有的输入事件
		for (const RawEvent* rawEvent = rawEvents; count--; rawEvent++) {
			if (mDropUntilNextSync) {
				if (rawEvent->type == EV_SYN && rawEvent->code == SYN_REPORT) {
					mDropUntilNextSync = false;
				}
			} else if(rawEvent->type == EV_SYN && rawEvent->code == SYN_DROPPED){
				mDropUntilNextSync = true;
            	reset(rawEvent->when);
			}else {
				// 调用每个mapper依次处理该事件
				for (size_t i = 0; i < numMappers; i++) {
                	InputMapper* mapper = mMappers[i];//获取InputMapper
                	mapper->process(rawEvent);// 调用InputMapper的处理方法，见2.9
            	}
			}
		}
	}
针对每个mapper，顺序处理所有的输入事件。在前面的2.6过程中，创建了许多类型的InputMapper，这里我们将以KeyboardInputMapper(按键事件)为例来说明事件的传递过程。

2.9 KeyboardInputMapper.process()

	void KeyboardInputMapper::process(const RawEvent* rawEvent) {
    	switch (rawEvent->type) {
    		case EV_KEY: {
        		int32_t scanCode = rawEvent->code;
        		int32_t usageCode = mCurrentHidUsage;
        		mCurrentHidUsage = 0;

        		if (isKeyboardOrGamepadKey(scanCode)) {//按键事件
           			processKey(rawEvent->when, rawEvent->value != 0, scanCode, usageCode);//处理方法，见2.10
        		}
        		break;
    		}
    		......
    	}
	}
在KeyboardInputMapper方法中，首先会判断扫描码是否为键盘码，如果是的话，则调用processKey()方法处理。

2.10 KeyboardInputMapper.processKey()

	void KeyboardInputMapper::processKey(nsecs_t when, bool down, int32_t scanCode,int32_t usageCode) {
		int32_t keyCode;
    	int32_t keyMetaState;
    	uint32_t policyFlags;
		if (getEventHub()->mapKey(getDeviceId(), scanCode, usageCode, mMetaState,
                              &keyCode, &keyMetaState, &policyFlags)) {// 根据扫描码获取对应的keyCode
        	keyCode = AKEYCODE_UNKNOWN;
        	keyMetaState = mMetaState;
        	policyFlags = 0;
    	}
		
		if (down) {//处理按下的键
			// 根据方向需要旋转keyCode
			if (mParameters.orientationAware && mParameters.hasAssociatedDisplay) {
            	keyCode = rotateKeyCode(keyCode, mOrientation);
        	}
			// 添加key down事件
			ssize_t keyDownIndex = findKeyDown(scanCode);// key down索引
			if (keyDownIndex >= 0) {
				// key事件重复了，必须确保和之前的keyCode一致
				keyCode = mKeyDowns.itemAt(keyDownIndex).keyCode;
			} else {
				if ((policyFlags & POLICY_FLAG_VIRTUAL)
                    && mContext->shouldDropVirtualKey(when,
                            getDevice(), keyCode, scanCode)) {
                	return;
            	}
				
				if (policyFlags & POLICY_FLAG_GESTURE) {
                	mDevice->cancelTouch(when);
            	}
				// mKeyDowns记录着所有按下的键
				mKeyDowns.push();//压入栈顶
            	KeyDown& keyDown = mKeyDowns.editTop();
            	keyDown.keyCode = keyCode;
            	keyDown.scanCode = scanCode;
			}
			mDownTime = when;//记录按下时间
		}else{//处理抬起操作
			移除key down事件
			ssize_t keyDownIndex = findKeyDown(scanCode);// 查找key down事件
			if (keyDownIndex >= 0) {
				// key up操作，必须确保和之前的keyCode保持一致
				keyCode = mKeyDowns.itemAt(keyDownIndex).keyCode;
            	mKeyDowns.removeAt(size_t(keyDownIndex));
			} else {
				return;
			}
		}
		......

		nsecs_t downTime = mDownTime;
		
		......
		NotifyKeyArgs args(when, getDeviceId(), mSource, policyFlags,
            down ? AKEY_EVENT_ACTION_DOWN : AKEY_EVENT_ACTION_UP,
            AKEY_EVENT_FLAG_FROM_SYSTEM, keyCode, scanCode, keyMetaState, downTime);//创建NotifyKeyArgs对象，when记录eventTime，downTime记录按下时间。
    	getListener()->notifyKey(&args);//通知key事件，见2.11
	}
在processKey方法中，首先根据扫描码获取到对应的keyCode方法，构建NotifyKeyArgs对象，然后调用notifyKey()方法通知key事件。

NotifykeyArgs对象记录了key按下的时间，keyCode以及scanCode，定义如下：

	NotifyKeyArgs::NotifyKeyArgs(nsecs_t eventTime, int32_t deviceId, uint32_t source,
        uint32_t policyFlags,
        int32_t action, int32_t flags, int32_t keyCode, int32_t scanCode,
        int32_t metaState, nsecs_t downTime) :
        eventTime(eventTime), deviceId(deviceId), source(source), policyFlags(policyFlags),
        action(action), flags(flags), keyCode(keyCode), scanCode(scanCode),
        metaState(metaState), downTime(downTime) {
	}

getListener()方法获取的是mQueuedListener，而mQueuedListener的类型是QueuedInputListener。

	InputListenerInterface* 	InputReader::ContextImpl::getListener() {
    	return mReader->mQueuedListener.get();
	}
	
	sp<QueuedInputListener> mQueuedListener;


2.11 QueuedInputListener.notifyKey()

	void QueuedInputListener::notifyKey(const NotifyKeyArgs* args) {
    	mArgsQueue.push(new NotifyKeyArgs(*args));
	}
mArgsQueue的数据类型为Vector<NotifyArgs*>，notifyKey的操作是将该key事件压入栈顶。NotifyKeyArgs类继承自NotifyArgs类。
	
	struct NotifyKeyArgs : public NotifyArgs {
    	nsecs_t eventTime;
    	int32_t deviceId;
    	uint32_t source;
    	uint32_t policyFlags;
    	int32_t action;
    	int32_t flags;
    	int32_t keyCode;
    	int32_t scanCode;
    	int32_t metaState;
    	nsecs_t downTime;

    	inline NotifyKeyArgs() { }

    	NotifyKeyArgs(nsecs_t eventTime, int32_t deviceId, uint32_t source, uint32_t policyFlags,
            int32_t action, int32_t flags, int32_t keyCode, int32_t scanCode,
            int32_t metaState, nsecs_t downTime);

    	NotifyKeyArgs(const NotifyKeyArgs& other);

    	virtual ~NotifyKeyArgs() { }

    	virtual void notify(const sp<InputListenerInterface>& listener) const;
	};

QueuedInputListener类的定义如下：

	class QueuedInputListener : public InputListenerInterface {
	protected:
    	virtual ~QueuedInputListener();

	public:
    	QueuedInputListener(const sp<InputListenerInterface>& innerListener);

    	virtual void notifyConfigurationChanged(const NotifyConfigurationChangedArgs* args);
    	virtual void notifyKey(const NotifyKeyArgs* args);
    	virtual void notifyMotion(const NotifyMotionArgs* args);
    	virtual void notifySwitch(const NotifySwitchArgs* args);
    	virtual void notifyDeviceReset(const NotifyDeviceResetArgs* args);

    	void flush();

	private:
    	sp<InputListenerInterface> mInnerListener;
    	Vector<NotifyArgs*> mArgsQueue;
	};

至此，输入事件的加工处理已经完成了，接下来是将输入事件发送给InputDispatcher线程。

回到2.2的loopOnce()方法中，当通过EventHub的getEvents()方法获取到输入事件后，并通过processEventsLocked()方法对输入事件进行加工处理后，会调用mQueuedListener的flush()方法，将输入事件发送给InputDispatcher线程处理。mQueuedListener的类型为QueuedInputListener，所以后面将调用QueuedInputListener的flush()方法。

2.12 QueuedInputListener.flush()

	void QueuedInputListener::flush() {
    	size_t count = mArgsQueue.size();//获取输入事件数组的大小
    	for (size_t i = 0; i < count; i++) {
        	NotifyArgs* args = mArgsQueue[i];
        	args->notify(mInnerListener);//调用NotifyArgs的notify()方法，见2.13
        	delete args;
    	}
    	mArgsQueue.clear();//清空数组
	}
在遍历输入事件数组mArgsQueue的过程中，会把每个输入事件取出来，然后分别调用他们的notify()方法。NotifyArgs是一个输入事件的基类，其相应的子类有：

- NotifyKeyArgs(按键事件)；
- NotifyMotionArgs(触摸事件)；
- NotifySwitchArgs；
- NotifyDeviceResetArgs；
- NotifyConfigurationChangedArgs；

在2.11中，我们可以看到，压入mArgsQueue数组的输入事件是NotifyKeyArgs，所以此处将调用NotifyKeyArgs的notify()方法。而mInnerListener是指向InputDispatcher的，具体是在初始化InputReader的时候，由InputDispatcher初始化其mQueuedListener成员变量mInnerListener。其过程如下：

	InputManager::InputManager(
        const sp<EventHubInterface>& eventHub,
        const sp<InputReaderPolicyInterface>& readerPolicy,
        const sp<InputDispatcherPolicyInterface>& dispatcherPolicy) {
    	mDispatcher = new InputDispatcher(dispatcherPolicy);
   		mReader = new InputReader(eventHub, readerPolicy, mDispatcher);
    	initialize();
	}

	InputReader::InputReader(const sp<EventHubInterface>& eventHub,
        const sp<InputReaderPolicyInterface>& policy,
        const sp<InputListenerInterface>& listener) :
        mContext(this), mEventHub(eventHub), mPolicy(policy),
        mGlobalMetaState(0), mGeneration(1),
        mDisableVirtualKeysTimeout(LLONG_MIN), mNextTimeout(LLONG_MAX),
        mConfigurationChangesToRefresh(0) {
    	mQueuedListener = new QueuedInputListener(listener);
	......
	}

	QueuedInputListener::QueuedInputListener(const sp<InputListenerInterface>& innerListener) :
        mInnerListener(innerListener) {
	}

2.13 NotifyKeyArgs.notify()

	void NotifyKeyArgs::notify(const sp<InputListenerInterface>& listener) const {
    	listener->notifyKey(this);// 调用InputDispatcher的notifykey方法，见2.14
	}

这里的listener指向的是InputDispatcher，所有调用的是InputDispatcher的notifyKey()方法.

2.14 InputDispatcher.notifyKey()

	void InputDispatcher::notifyKey(const NotifyKeyArgs* args) {
		if (!validateKeyEvent(args->action)) {//验证key事件是否有效
        	return;
    	}
		// 获取key事件的一些参数
		uint32_t policyFlags = args->policyFlags;
    	int32_t flags = args->flags;
    	int32_t metaState = args->metaState;
		......
		policyFlags |= POLICY_FLAG_TRUSTED;
		int32_t keyCode = args->keyCode;//获取keyCode
		
		if (metaState & AMETA_META_ON && args->action == AKEY_EVENT_ACTION_DOWN) {//key down操作
        	int32_t newKeyCode = AKEYCODE_UNKNOWN;
        	if (keyCode == AKEYCODE_DEL) {
            	newKeyCode = AKEYCODE_BACK;//返回键
        	} else if (keyCode == AKEYCODE_ENTER) {
            	newKeyCode = AKEYCODE_HOME;//home键
        	}
        	if (newKeyCode != AKEYCODE_UNKNOWN) {
            	AutoMutex _l(mLock);
            	struct KeyReplacement replacement = {keyCode, args->deviceId};
            	mReplacedKeys.add(replacement, newKeyCode);
            	keyCode = newKeyCode;//更新为新的keyCode
            	metaState &= ~AMETA_META_ON;
        	}
    	} else if (args->action == AKEY_EVENT_ACTION_UP) {// key up操作
        	AutoMutex _l(mLock);
        	struct KeyReplacement replacement = {keyCode, args->deviceId};
        	ssize_t index = mReplacedKeys.indexOfKey(replacement);
        	if (index >= 0) {
            	keyCode = mReplacedKeys.valueAt(index);//还原keyCode
            	mReplacedKeys.removeItemsAt(index);
            	metaState &= ~AMETA_META_ON;
        	}
    	}
		
		KeyEvent event;//key事件
		event.initialize(args->deviceId, args->source, args->action,
            flags, keyCode, args->scanCode, metaState, 0,
            args->downTime, args->eventTime);//初始化key事件
		mPolicy->interceptKeyBeforeQueueing(&event, /*byref*/ policyFlags);//是否需要拦截key事件，mPolicy指向的是NativeInputManager对象，见2.15
		
		bool needWake;// 是否需要唤醒

		{ // acquire lock
        	mLock.lock();

        	if (shouldSendKeyToInputFilterLocked(args)) {
            	mLock.unlock();

            	policyFlags |= POLICY_FLAG_FILTERED;
				// 是否需要被Filter拦截，见2.19
            	if (!mPolicy->filterInputEvent(&event, policyFlags)) {
                	return; // event was consumed by the filter
            	}

            	mLock.lock();
        	}

        	int32_t repeatCount = 0;
        	KeyEntry* newEntry = new KeyEntry(args->eventTime,
                args->deviceId, args->source, policyFlags,
                args->action, flags, keyCode, args->scanCode,
                metaState, repeatCount, args->downTime);

        	needWake = enqueueInboundEventLocked(newEntry);//将keyEntry事件放入队列中，见2.20
        	mLock.unlock();
    	} // release lock
	
		if (needWake) {
        	mLooper->wake();//唤醒InputDispatcher线程，见2.21
    	}
	}

该方法主要做了以下几件事情：

1. 获取key事件的参数，构建KeyEvent对象；
2. 调用NativeInputManager的interceptKeyBeforeQueueing()方法进行加入队列前的拦截操作；
3. 如果需要，调用NativeInputManager的filterInputEvent()方法进入Filter过滤拦截。
4. 创建KeyEntry对象，并调用enqueueInboundEventLocked()方法将KeyEntry对象放入队列中。
5. 最后唤醒InputDispatcher线程进行处理；

2.15 NativeInputManager.interceptKeyBeforeQueueing()

	void NativeInputManager::interceptKeyBeforeQueueing(const KeyEvent* keyEvent,
        uint32_t& policyFlags) {
		
		bool interactive = mInteractive.load();
    	if (interactive) {
       		policyFlags |= POLICY_FLAG_INTERACTIVE;
    	}
		
		if ((policyFlags & POLICY_FLAG_TRUSTED)) {//可信的key事件
        	nsecs_t when = keyEvent->getEventTime();//获取key事件发生的事件
        	JNIEnv* env = jniEnv();
        	jobject keyEventObj = android_view_KeyEvent_fromNative(env, keyEvent);//获取Java层的keyEvent事件
        	jint wmActions;
        	if (keyEventObj) {
            	wmActions = env->CallIntMethod(mServiceObj,
                    gServiceClassInfo.interceptKeyBeforeQueueing,
                    keyEventObj, policyFlags);
            	if (checkAndClearExceptionFromCallback(env, "interceptKeyBeforeQueueing")) {
                wmActions = 0;
            	}// 调用Java层的InputManagerService的interceptKeyBeforeQueueing()方法，见2.16
            	android_view_KeyEvent_recycle(env, keyEventObj);
            	env->DeleteLocalRef(keyEventObj);
        	} else {
            	wmActions = 0;
        	}

        	handleInterceptActions(wmActions, when, /*byref*/ policyFlags);//处理拦截的操作
    	} else {
        	if (interactive) {
            	policyFlags |= POLICY_FLAG_PASS_TO_USER;
        	}
    	}
	}
	

该方法的主要作用是在key事件入队列前进行拦截操作。通过JNI调用Java层的InputManagerService的interceptKeyBeforeQueueing()方法进行拦截操作，并将拦截的结果返回给handleInterceptActions()方法处理。

2.16 InputManagerService.interceptKeyBeforeQueueing()

	// Native callback.
    private int interceptKeyBeforeQueueing(KeyEvent event, int policyFlags) {
        return mWindowManagerCallbacks.interceptKeyBeforeQueueing(event, policyFlags);// 调用InputMonitor的interceptKeyBeforeQueueing()方法，见2.17
    }

在初始化InputManagerService的时候，会在SystemServer的startOtherService()方法中，设置WindowManagerCallBack接口实现类。

		inputManager.setWindowManagerCallbacks(wm.getInputMonitor());
这里的mWindowManagerCallBack变量指向InputMonitor对象。

2.17 InputMonitor.interceptKeyBeforeQueueing()

	 @Override
    public int interceptKeyBeforeQueueing(KeyEvent event, int policyFlags) {
        return mService.mPolicy.interceptKeyBeforeQueueing(event, policyFlags);// 调用PhoneWindowManager的interceptKeyBeforeQueueing()方法，见2.18
    }
这里的mService变量是指WindowManagerService，mPolicy变量指向的是PhoneWindowManager类，代表窗口策略。真正实现拦截操作是在PhoneWindowManager的interceptKeyBeforeQueueing()方法中。

2.18 PhoneWindowManager.interceptKeyBeforeQueueing()

	public int interceptKeyBeforeQueueing(KeyEvent event, int policyFlags) {
		....
		final boolean interactive = (policyFlags & FLAG_INTERACTIVE) != 0;
        final boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        final boolean canceled = event.isCanceled();
        final int keyCode = event.getKeyCode();

		......
		int result;
		// 处理按键事件
		switch (keyCode) {
			case KeyEvent.KEYCODE_BACK:
				......
			case KeyEvent.KEYCODE_VOLUME_DOWN:
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_MUTE:
				.......
			case KeyEvent.KEYCODE_ENDCALL:
				.......
			case KeyEvent.KEYCODE_POWER:
				.......
			
		}
		.......
		return result;
	}

在interceptKeyBeforeQueueing()方法中，处理各种按键事件，并把处理结果返回到Native层。interceptKeyBeforeQueueing()方法的调用流程如下：

	NativeInputManager.interceptKeyBeforeQueueing()
		InputManagerService.interceptKeyBeforeQueueing()
			InputMonitor.interceptKeyBeforeQueueing()
				PhoneWindowManager.interceptKeyBeforeQueueing()

处理完interceptKeyBeforeQueueing()拦截操作后，回到2.14，继续处理filterInputEvent()过滤拦截操作。


2.19 NativeInputManager.filterInputEvent()

	bool NativeInputManager::filterInputEvent(const InputEvent* inputEvent, uint32_t policyFlags) {
		jobject inputEventObj;

    	JNIEnv* env = jniEnv();
		// 根据输入事件类型进行相应的处理
    	switch (inputEvent->getType()) {
    	case AINPUT_EVENT_TYPE_KEY://key按键事件
        	inputEventObj = android_view_KeyEvent_fromNative(env,
                static_cast<const KeyEvent*>(inputEvent));//转换成Java层的key按键事件
        	break;
    	case AINPUT_EVENT_TYPE_MOTION://触摸事件
        	inputEventObj = android_view_MotionEvent_obtainAsCopy(env,
                static_cast<const MotionEvent*>(inputEvent));//转换成Java层的触摸事件
        	break;
    	default:
        	return true; // 正常分发输入事件
    	}

    	if (!inputEventObj) {
        	return true; // 正常分发输入事件
    	}

    	jboolean pass = env->CallBooleanMethod(mServiceObj, gServiceClassInfo.filterInputEvent,
            	inputEventObj, policyFlags);//调用InputManagerService的filterInputEvent()方法
    	if (checkAndClearExceptionFromCallback(env, "filterInputEvent")) {
        	pass = true;
    	}
    	env->DeleteLocalRef(inputEventObj);
    	return pass;
	}
在filterInputEvent()方法中，首先根据输入事件的类型，构建不同类型的Java层输入事件。然后通过JNI调用Java层的InputManagerService的filterInputEvent()方法进行过滤拦截操作。

	// Native callback.
    final boolean filterInputEvent(InputEvent event, int policyFlags) {
        synchronized (mInputFilterLock) {
            if (mInputFilter != null) {
                try {
                    mInputFilter.filterInputEvent(event, policyFlags);//调用对应的InputFilter的filterInputEvent()方法进行拦截
                } catch (RemoteException e) {
                    /* ignore */
                }
                return false;
            }
        }
        event.recycle();
        return true;
    }

在InputManagerService调用filterInputEvent()方法之后，会返回过滤拦截结果返回到Native层，接着回到2.14，继续执行enqueueInboundEventLocked()方法，将KeyEntry对象放入队列中。

2.20 InputDispatcher.enqueueInboundEventLocked()

	bool InputDispatcher::enqueueInboundEventLocked(EventEntry* entry) {
		bool needWake = mInboundQueue.isEmpty();//如果队列为空，则需要唤醒
    	mInboundQueue.enqueueAtTail(entry);//将输入事件放入队列的尾部
    	traceInboundQueueLengthLocked();
		switch (entry->type) {
			case EventEntry::TYPE_KEY: {//key按键输入事件
				KeyEntry* keyEntry = static_cast<KeyEntry*>(entry);
				if (isAppSwitchKeyEventLocked(keyEntry)) {//应用程序切换
					if (keyEntry->action == AKEY_EVENT_ACTION_DOWN) {
                		mAppSwitchSawKeyDown = true;
            		} else if (keyEntry->action == AKEY_EVENT_ACTION_UP) {
                		if (mAppSwitchSawKeyDown) {
							mAppSwitchDueTime = keyEntry->eventTime + APP_SWITCH_TIMEOUT;//应用切换超时时间为500ms
                    		mAppSwitchSawKeyDown = false;
                    		needWake = true;//需要唤醒
						}
					}
					break；
				}
			}
			
			case EventEntry::TYPE_MOTION: {//触摸输入事件
				MotionEntry* motionEntry = static_cast<MotionEntry*>(entry);
				if (motionEntry->action == AMOTION_EVENT_ACTION_DOWN
                && (motionEntry->source & AINPUT_SOURCE_CLASS_POINTER)
                && mInputTargetWaitCause == INPUT_TARGET_WAIT_CAUSE_APPLICATION_NOT_READY
                && mInputTargetWaitApplicationHandle != NULL) {//应用程序还为准备好，用户切换到另外一个窗口
            	int32_t displayId = motionEntry->displayId;
            	int32_t x = int32_t(motionEntry->pointerCoords[0].
                    	getAxisValue(AMOTION_EVENT_AXIS_X));
            	int32_t y = int32_t(motionEntry->pointerCoords[0].
                    	getAxisValue(AMOTION_EVENT_AXIS_Y));
            	sp<InputWindowHandle> touchedWindowHandle = findTouchedWindowAtLocked(displayId, x, y);//根据触摸的坐标查找接收窗口
            	if (touchedWindowHandle != NULL
                    && touchedWindowHandle->inputApplicationHandle
                            != mInputTargetWaitApplicationHandle) {//如果查找到的窗口不是原来等待处理的窗口
                	mNextUnblockedEvent = motionEntry;
                	needWake = true;//需要唤醒
            	}
        	}
        	break;
			}	
		}
		return needWake；
	}
在enqueueInboundEventLocked()方法中，有三种情况需要被唤醒：

1. mInboundQueue队列为空时，需要唤醒。因为队列为空，说明当前没有输入事件处理，则可以立即处理；如果队列不为空，说明当前正在处理输入事件，需要等待下一次来处理；
2. 如果输入事件是key按键事件，并且正在发生应用切换过程，则设置一个应用切换超时时间500ms，然后唤醒；
3. 如果输入事件是触摸事件，并且当前应用程序还没有响应，而用户选择了另外一个应用程序的窗口，根据触摸坐标查找接收窗口；如果接收窗口与之前等待处理该触摸事件的窗口不一致，则需要唤醒。

mInboundQueue的数据类型为Queue<EventEntry>，确保了事件的处理顺序。

	Queue<EventEntry> mInboundQueue;

当需要唤醒操作时，我们返回到2.14中，继续调用mLooper->wake()方法，唤醒InputDispatcher线程。mLooper变量指向是Looper对象，它是在创建InputDispatcher实例的时候被初始化的。

2.21 Looper.wake()

	void Looper::wake() {
    	uint64_t inc = 1;
    	ssize_t nWrite = TEMP_FAILURE_RETRY(write(mWakeEventFd, &inc, sizeof(uint64_t)));//往mWakeEventFd文件描述符写入数字1
    	if (nWrite != sizeof(uint64_t)) {
        	if (errno != EAGAIN) {
            	ALOGW("Could not write wake signal, errno=%d", errno);
        	}
    	}
	}

通过往mWakeEventFd文件描述符写入数字1，唤醒在Looper.pollOnce()方法中poll_wait等待操作。线程执行Looper->pollOnce(timeoutMillis)方法，会进入epoll_wait等待状态，当发生以下任意情况则退出等待状态：

1. callback：通过回调方法来唤醒；
2. timeout：通过超时时间唤醒；
3. wake：主动调用Looper的wake()方法；

在InputDispatcherThread线程中，会循环调用其threadLoop()方法。在threadLoop()方法中，又会调用InputDispatcher的dispatchOnce()方法。
在dispatchOnce()方法中会调用Looper->pollOnce()方法，因此InputDispatcherThread线程会睡眠在epoll_wait等待状态上。当通过Looper->wait()方法，会唤醒InputDispatcherThread线程，继续执行threadLoop()方法。

	bool InputDispatcherThread::threadLoop() {
   		mDispatcher->dispatchOnce();
    	return true;
	}

	void InputDispatcher::dispatchOnce() {
    	nsecs_t nextWakeupTime = LONG_LONG_MAX;
    	{ // acquire lock
        	AutoMutex _l(mLock);
        	mDispatcherIsAliveCondition.broadcast();

        	if (!haveCommandsLocked()) {
            	dispatchOnceInnerLocked(&nextWakeupTime);// 
        	}

        	if (runCommandsLockedInterruptible()) {
            	nextWakeupTime = LONG_LONG_MIN;
        	}
    	} // release lock

    		nsecs_t currentTime = now();
    		int timeoutMillis = toMillisecondTimeoutDelay(currentTime, nextWakeupTime);
    		mLooper->pollOnce(timeoutMillis);// 调用Looper的pollOnce()方法，进入epoll_wait等待状态
	}

### 3.小结

InputReader的核心工作就是从EventHub获取数据后生成EventEntry事件，然后加入到InputDispatcher的mInboundQueue队列，最后唤醒InputDispatcherThread线程进行处理。InputReader整个工作流程包含以下三个部分：

1. 调用EventHub.getEvents()方法，获取原始的输入事件；通过EventHub监听输入设备(/dev/input)，并从中读取输入事件到mEventBuffer数组，mEventBuffer数组大小为256，然后将输入事件input_event转换为RawEvent。具体过程见2.3。
2. 调用processEventsLocked()方法，对输入事件进行加工处理，不同类型的输入事件，转换为不同的NotifyArgs子类。例如，键盘类的输入事件转换为NotifykeyArgs类。具体过程见2.4~2.10。
3. 调用QueuedListener的flush()方法，将输入事件传递到InputDispatcher处理。通过InputDispatcher的notifyKey()方法，对输入事件先拦截和过滤处理，然后将输入事件放入mInboundQueue队列中。如果需要唤醒的话，则通过InputDispatcher的mLooper->wake()方法，唤醒InputDispatcherThread线程来处理输入事件。具体过程见2.11~2.21。

InputReader的调用过程如下：
	
	InputReaderThread.threadLoop()
		InputReader.loopOnce()
			EventHub.getEvents() 
			InputReader.processEventsLocked()  
				InputReader.addDeviceLocked()
					InputReader.createDeviceLocked()
				InputReader.processEventsForDeviceLocked()
					InputDevice.process()
						KeyboardInputMapper.process()
							KeyboardInputMapper.processKey()
								QueuedInputListener.notifyKey()
			QueuedInputListener.flush()
				NotifyKeyArgs.notify()
					InputDispatcher.notifyKey()
						NativeInputManager.interceptKeyBeforeQueueing()
							InputManagerService.interceptKeyBeforeQueueing()
								InputMonitor.interceptKeyBeforeQueueing()
									PhoneWindowManager.interceptKeyBeforeQueueing()
						NativeInputManager.filterInputEvent()
						InputDispatcher.enqueueInboundEventLocked()
							Looper.wake()

InputManagerService分发输入事件消息给应用程序(下)将从InputDispatcherThread线程开始分析，InputDispatcher如何将输入事件分发到应用程序激活的Activity窗口。



/*
* Bitmap配置，描述位图的一个像素是如何存储的
*/
public enum Config {
       
		/*
		* 每个像素存储透明度alpha，没有存储颜色信息
		* 每个像素需要一个字节（8bit）的内存
		*/
        ALPHA_8     (1),

        /**
		 * 每个像素存储RGB颜色信息，不包含透明度信息
		 * 每个像素占用2个字节存储空间，红色占用5bit内存，绿色占用6bit内存，蓝色占用5bit内存
		 * 该配置适用于不需要高质量图片的地方，节省内存空间
         */
        RGB_565     (3),

        /**
		 * 每个像素存储ARGB信息，包含透明度信息
		 * 每个像素占用2个字节存储空间，透明度占用4bit空间，各个颜色值分别占用4bit空间
		 * 该配置适用于对图片质量要求不高，并且需要透明度信息的场景，主要是为了节省内存。如果条件允许，尽量使用ARGB_8888格式
         */
        @Deprecated
        ARGB_4444   (4),

        /**
		 * 每个像素存储了ARGB信息，包含透明度信息
		 * 每个像素占用4个字节存储空间，透明度和颜色值信息分别占用8bit存储空间
		 * 该配置提供比较高的图片质量，是首选配置。
         */
        ARGB_8888   (5);

        final int nativeInt;

        @SuppressWarnings({"deprecation"})
        private static Config sConfigs[] = {
            null, ALPHA_8, null, RGB_565, ARGB_4444, ARGB_8888
        };
        
        Config(int ni) {
            this.nativeInt = ni;
        }

        static Config nativeToConfig(int ni) {
            return sConfigs[ni];
        }
    }
	
	
	
	private static native Bitmap nativeDecodeStream(InputStream is, byte[] storage,
            Rect padding, Options opts);
    private static native Bitmap nativeDecodeFileDescriptor(FileDescriptor fd,
            Rect padding, Options opts);
    private static native Bitmap nativeDecodeAsset(long nativeAsset, Rect padding, Options opts);
    private static native Bitmap nativeDecodeByteArray(byte[] data, int offset,
            int length, Options opts);

	public static Bitmap decodeResource(Resources res, int id, Options opts) {
        Bitmap bm = null;
        InputStream is = null; 
        
        try {
            final TypedValue value = new TypedValue();
            is = res.openRawResource(id, value);

            bm = decodeResourceStream(res, value, is, null, opts);
        } catch (Exception e) {
            .......
        } finally {
           .......
        }
       ......
        return bm;
    }
	
	public static Bitmap decodeResourceStream(Resources res, TypedValue value,
            InputStream is, Rect pad, Options opts) {

        if (opts == null) {
            opts = new Options();
        }

        if (opts.inDensity == 0 && value != null) {
            final int density = value.density;
            if (density == TypedValue.DENSITY_DEFAULT) {
                opts.inDensity = DisplayMetrics.DENSITY_DEFAULT;
            } else if (density != TypedValue.DENSITY_NONE) {
                opts.inDensity = density;
            }
        }
        
        if (opts.inTargetDensity == 0 && res != null) {
            opts.inTargetDensity = res.getDisplayMetrics().densityDpi;
        }
        
        return decodeStream(is, pad, opts);
    }
	
	
	public static Bitmap createBitmap(Bitmap source, int x, inty, int width,int height, Matrix m,boolean filter)  
	public static Bitmap createBitmap(Bitmap source, int x, inty, int width,int height)  
	public static Bitmap createScaledBitmap(Bitmap src, int dstWidth, int dstHeight,boolean filter)
	
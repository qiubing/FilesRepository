
	 /*
	 * 加载libname指定的本地库
	 */
	public static void loadLibrary(String libName) {
        Runtime.getRuntime().loadLibrary(libName, VMStack.getCallingClassLoader());
    }
	
	/*
	* 通过给定的ClassLoader搜索和加载指定的共享库文件
	*/
	void loadLibrary(String libraryName, ClassLoader loader) {
		//loader不为空，进入该分支处理
        if (loader != null) {
			//查找库所在路径
            String filename = loader.findLibrary(libraryName);
            if (filename == null) {
                throw new UnsatisfiedLinkError(loader + " couldn't find \"" +
                                               System.mapLibraryName(libraryName) + "\"");
            }
			//加载库文件
            String error = doLoad(filename, loader);
            if (error != null) {
                throw new UnsatisfiedLinkError(error);
            }
            return;
        }

		//loader为空，则进入该分支处理
		// 返回平台相关库文件名字，在Android中，如果共享库为MyLibrary，则返回的共享库名字为“libMyLibrary.so”。
        String filename = System.mapLibraryName(libraryName);
        List<String> candidates = new ArrayList<String>();
        String lastError = null;
        for (String directory : mLibPaths) {
			//在/system/lib/和/vendor/lib/下查找指定的filename文件
            String candidate = directory + filename;
            candidates.add(candidate);

            if (IoUtils.canOpenReadOnly(candidate)) {
				// 找了对应的库文件，加载库文件
                String error = doLoad(candidate, loader);
                if (error == null) {
                    return; // We successfully loaded the library. Job done.
                }
                lastError = error;
            }
        }

        if (lastError != null) {
            throw new UnsatisfiedLinkError(lastError);
        }
        throw new UnsatisfiedLinkError("Library " + libraryName + " not found; tried " + candidates);
    }
	
	/**
     * Holds the library paths, used for native library lookup.
     */
	// mLibPaths是保存库文件路径，用来查找native库文件
    private final String[] mLibPaths = initLibPaths();

    private static String[] initLibPaths() {
		// 搜索JNI库文件的路径，通过"java.library.path"读取出来的属性值为/vendor/lib:/system/lib/。
		// 其中/system/lib/路径存放的是系统应用使用的so库文件，/vendor/lib/路径存放的是第三方应用的so库文件。
        String javaLibraryPath = System.getProperty("java.library.path");
        if (javaLibraryPath == null) {
            return EmptyArray.STRING;
        }
        String[] paths = javaLibraryPath.split(":");
        // Add a '/' to the end of each directory so we don't have to do it every time.
        for (int i = 0; i < paths.length; ++i) {
            if (!paths[i].endsWith("/")) {
                paths[i] += "/";
            }
        }
        return paths;
    }
	
	private String doLoad(String name, ClassLoader loader) {
        String ldLibraryPath = null;
        if (loader != null && loader instanceof BaseDexClassLoader) {
            ldLibraryPath = ((BaseDexClassLoader) loader).getLdLibraryPath();
        }
        // nativeLoad should be synchronized so there's only one LD_LIBRARY_PATH in use regardless
        // of how many ClassLoaders are in the system, but dalvik doesn't support synchronized
        // internal natives.
        synchronized (this) {
			//最后调用nativeLoad方法加载库文件
            return nativeLoad(name, loader, ldLibraryPath);
        }
    }
	
static jstring Runtime_nativeLoad(JNIEnv* env, jclass, jstring javaFilename, jobject javaLoader,
                                  jstring javaLdLibraryPathJstr) {
  ScopedUtfChars filename(env, javaFilename);
  if (filename.c_str() == nullptr) {
    return nullptr;
  }
  SetLdLibraryPath(env, javaLdLibraryPathJstr);
  std::string error_msg;
  {
    JavaVMExt* vm = Runtime::Current()->GetJavaVM();
    bool success = vm->LoadNativeLibrary(env, filename.c_str(), javaLoader, &error_msg);
    if (success) {
      return nullptr;
    }
  }
  // Don't let a pending exception from JNI_OnLoad cause a CheckJNI issue with NewStringUTF.
  env->ExceptionClear();
  return env->NewStringUTF(error_msg.c_str());
}


	
	
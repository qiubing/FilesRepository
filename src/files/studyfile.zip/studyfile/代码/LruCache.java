
int cacheSize = 4 * 1024 * 1024; // 4MiB
LruCache<String, Bitmap> bitmapCache = new LruCache<String, Bitmap>(cacheSize) {
	protected int sizeOf(String key, Bitmap value) {
		return value.getByteCount();
		}
}

synchronized (cache) {
    if (cache.get(key) == null) {
         cache.put(key, value); 
		} 
}

public class LruCache<K, V> {
	//采用LinkedHashMap来存储缓存元素，底层是基于双向链表来实现的。
	private final LinkedHashMap<K, V> map;
	
	private int size;//当前缓存大小
    private int maxSize;//缓存的最大值
	
	
	/*
	* maxSize表示在缓存中可以保存的entry最大数量，或者是所有entry大小和的最大值
	*/
	public LruCache(int maxSize) {
        if (maxSize <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        this.maxSize = maxSize;
		//LinkedHashMap以访问顺序来访问元素，即最近访问的元素最先返回。
        this.map = new LinkedHashMap<K, V>(0, 0.75f, true);
    }
	
	
	/*
	* 返回key对应的value
	* 如果key对应的value存在，则直接返回，否则通过crate方法创建。
	* 如果返回了一个值，则将该值移至到队列的首部中
	* 如果返回了一个NULL值，则表示该缓存不存在或者create失败了。
	*/
	
	public final V get(K key) {
        if (key == null) {
            throw new NullPointerException("key == null");
        }

        V mapValue;
		//同步方法
        synchronized (this) {
            mapValue = map.get(key);
            if (mapValue != null) {
                hitCount++;
                return mapValue;
            }
            missCount++;
        }

        /*
         * Attempt to create a value. This may take a long time, and the map
         * may be different when create() returns. If a conflicting value was
         * added to the map while create() was working, we leave that value in
         * the map and release the created value.
         */

		//如果缓存丢失了，则尝试调用create方法创建一个value
        V createdValue = create(key);
        if (createdValue == null) {
            return null;
        }

		//同步方法
        synchronized (this) {
            createCount++;
			//将crate方法创建的value存入到map中
            mapValue = map.put(key, createdValue);

			//如果有冲突的话，则保留原来的值
            if (mapValue != null) {
                // There was a conflict so undo that last put
                map.put(key, mapValue);
            } else {
				//更新缓存的大小
                size += safeSizeOf(key, createdValue);
            }
        }

		//移除冲突的createdValue值，并返回原来的值
        if (mapValue != null) {
            entryRemoved(false, key, createdValue, mapValue);
            return mapValue;
        } else {
			//修正缓存的大小为maxSize，并返回新创建的值
            trimToSize(maxSize);
            return createdValue;
        }
    }
	
	/*
	* 当缓存丢失时，会调用该方法。
	* 通过key值返回一个value或者null，默认实现是返回一个null值
	*/
	protected V create(K key) {
        return null;
    }
	
	/*
	* 返回entry占用的大小
	*/
	private int safeSizeOf(K key, V value) {
        int result = sizeOf(key, value);
        if (result < 0) {
            throw new IllegalStateException("Negative size: " + key + "=" + value);
        }
        return result;
    }
	
	/*
	* 自定义每个entrykey和value所占用的大小。
	* 默认实现是返回为1，这样size就表示能存储entry的数量，maxSize表示能够存储entry的最大数量
	*/
	protected int sizeOf(K key, V value) {
        return 1;
    }
	
	/*
	* 当缓存中entry被移除或者丢弃时，触发调用该方法。
	* 当调用remove移除一个元素时，或者调用put替换一个元素时，会触发调用该方法。
	* 默认实现是空的。
	* @param evicted 为true，表示该元素是被移除，用来释放空间的。为false，表示是通过remove或者put方法触发的移除操作。
	* @param newValue 如果newValue是存在的话，则表示key对应的value值。如果newValue非空，则表示是put方法触发的移除操作；否则表示回收或者remove触发的移除操作。
	*/
	protected void entryRemoved(boolean evicted, K key, V oldValue, V newValue) {}
	
	
	/*
	* 修改缓存的大小为maxSize
	*/
	private void trimToSize(int maxSize) {
        while (true) {
            K key;
            V value;
            synchronized (this) {
                if (size < 0 || (map.isEmpty() && size != 0)) {
                    throw new IllegalStateException(getClass().getName()
                            + ".sizeOf() is reporting inconsistent results!");
                }

				//如果当前缓存大小maxSize，则退出返回
                if (size <= maxSize) {
                    break;
                }

                // BEGIN LAYOUTLIB CHANGE
                // get the last item in the linked list.
                // This is not efficient, the goal here is to minimize the changes
                // compared to the platform version.
                Map.Entry<K, V> toEvict = null;
                for (Map.Entry<K, V> entry : map.entrySet()) {
                    toEvict = entry;
                }
                // END LAYOUTLIB CHANGE

				//如果队列的最后一个元素为空，则直接返回
                if (toEvict == null) {
                    break;
                }

				// 移除队列的最后一个entry，同时更新缓存的大小
                key = toEvict.getKey();
                value = toEvict.getValue();
                map.remove(key);
				//更新缓存的大小
                size -= safeSizeOf(key, value);
                evictionCount++;
            }
            //回掉entry被移除的方法，newValue值为null
            entryRemoved(true, key, value, null);
        }
    }
	
	
	/*
	* 缓存key对应的value值，该value值被移至队列的首部。
	*/
	public final V put(K key, V value) {
		//key和value都不可以为空
        if (key == null || value == null) {
            throw new NullPointerException("key == null || value == null");
        }

        V previous;
		//同步方法
        synchronized (this) {
            putCount++;
            size += safeSizeOf(key, value);
            previous = map.put(key, value);
			//如果previous不为空，则说明已经存在key值映射到该Value值了
            if (previous != null) {
                size -= safeSizeOf(key, previous);
            }
        }

        if (previous != null) {
			//移除了旧的previous值，添加了新的value值
            entryRemoved(false, key, previous, value);
        }
        
		//修正缓存的大小为maxSize
        trimToSize(maxSize);
        return previous;
    }
	
	/*
	* 删除key值对应的Value值
	*/
	public final V remove(K key) {
        if (key == null) {
            throw new NullPointerException("key == null");
        }

        V previous;
		//同步方法
        synchronized (this) {
            previous = map.remove(key);
            if (previous != null) {
				//更新缓存的大小
                size -= safeSizeOf(key, previous);
            }
        }

		//回调entryRemoved方法
        if (previous != null) {
            entryRemoved(false, key, previous, null);
        }

        return previous;
    }
	
	/*
	* 返回当前缓存的大小
	*/
	public synchronized final int size() {
        return size;
    }
	
	/*
	* 返回缓存的最大大小
	*/
	public synchronized final int maxSize() {
        return maxSize;
    }
}
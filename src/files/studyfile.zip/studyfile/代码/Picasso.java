
Picasso.with(context).load("http://i.imgur.com/DvpvklR.png").into(imageView);

@Override 
public void getView(int position, View convertView, ViewGroup parent) {
  SquaredImageView view = (SquaredImageView) convertView;
  if (view == null) {
    view = new SquaredImageView(context);
  }
  String url = getItem(position);
  Picasso.with(context).load(url).into(view);
}

Picasso.with(context)
  .load(url)
  .resize(50, 50)
  .centerCrop()
  .into(imageView);
  
 Picasso.with(context)
    .load(url)
    .placeholder(R.drawable.user_placeholder)
    .error(R.drawable.user_placeholder_error)
    .into(imageView);
	
Picasso.with(context).load(R.drawable.landing_screen).into(imageView1);
Picasso.with(context).load(new File(...)).into(imageView2);

/*********************************Picasso.java********************************/
/*
* 构造一个全局的Picasso实例对象，默认实现；
* 该实例自动初始化默认的配置，适用于大多数场景：
* 1，LRU内存缓存占用应用RAM的15%
* 2，磁盘缓存占用外置存储空间的2%，至少5MB，至多50MB。只在API 14以上才可以，或者是提供磁盘缓存的独立库，如OKHttp。
* 3，三个下载线程用来访问磁盘或者网络元素。
*
* 如果上面的配置满足不了你的需求，则可以通过Picasso.Builder来自定义创建一个Picasso对象。
*/
public static Picasso with(@NonNull Context context) {
    if (context == null) {
      throw new IllegalArgumentException("context == null");
    }
    if (singleton == null) {
      synchronized (Picasso.class) {
        if (singleton == null) {
          singleton = new Builder(context).build();
        }
      }
    }
    return singleton;
  }
  
  /*
  * 创建一个Picasso实例对象
  */
  public Picasso build() {
      Context context = this.context;

      if (downloader == null) {
		//网络下载
        downloader = new OkHttp3Downloader(context);
      }
      if (cache == null) {
		//内存缓存，使用1/8的可用堆内存作为内存缓存
        cache = new LruCache(context);
      }
      if (service == null) {
		//ExecutorService服务，默认由3个线程组成
        service = new PicassoExecutorService();
      }
      if (transformer == null) {
		//请求转换器，默认是不作任何处理
        transformer = RequestTransformer.IDENTITY;
      }
      //状态管理器
      Stats stats = new Stats(cache);
      //分发器
      Dispatcher dispatcher = new Dispatcher(context, service, HANDLER, downloader, cache, stats);

      return new Picasso(context, dispatcher, cache, listener, transformer, requestHandlers, stats,
          defaultBitmapConfig, indicatorsEnabled, loggingEnabled);
    }
	
	Builder可以组装构建Picasso的各种参数，例如设置定义内存缓存的大小：
	/*
	* 自定义内存缓存
	*/
	public Builder memoryCache(@NonNull Cache memoryCache) {
      if (memoryCache == null) {
        throw new IllegalArgumentException("Memory cache must not be null.");
      }
      if (this.cache != null) {
        throw new IllegalStateException("Memory cache already set.");
      }
      this.cache = memoryCache;
      return this;
    }
	
	
	/*
	* Picasso的构造函数
	*/
	Picasso(Context context, Dispatcher dispatcher, Cache cache, Listener listener,
      RequestTransformer requestTransformer, List<RequestHandler> extraRequestHandlers, Stats stats,
      Bitmap.Config defaultBitmapConfig, boolean indicatorsEnabled, boolean loggingEnabled) {
    this.context = context;
    this.dispatcher = dispatcher;
    this.cache = cache;
    this.listener = listener;
    this.requestTransformer = requestTransformer;
    this.defaultBitmapConfig = defaultBitmapConfig;

    int builtInHandlers = 7; // 内部处理请求的Hanlder数量
    int extraCount = (extraRequestHandlers != null ? extraRequestHandlers.size() : 0);
    List<RequestHandler> allRequestHandlers = new ArrayList<>(builtInHandlers + extraCount);

    //ResourceRequestHandler必须放置在第一个位置
    allRequestHandlers.add(new ResourceRequestHandler(context));
    if (extraRequestHandlers != null) {
      allRequestHandlers.addAll(extraRequestHandlers);
    }
    allRequestHandlers.add(new ContactsPhotoRequestHandler(context));
    allRequestHandlers.add(new MediaStoreRequestHandler(context));
    allRequestHandlers.add(new ContentStreamRequestHandler(context));
    allRequestHandlers.add(new AssetRequestHandler(context));
    allRequestHandlers.add(new FileRequestHandler(context));
    allRequestHandlers.add(new NetworkRequestHandler(dispatcher.downloader, stats));
    requestHandlers = Collections.unmodifiableList(allRequestHandlers);

    this.stats = stats;
    this.targetToAction = new WeakHashMap<>();
    this.targetToDeferredRequestCreator = new WeakHashMap<>();
    this.indicatorsEnabled = indicatorsEnabled;
    this.loggingEnabled = loggingEnabled;
    this.referenceQueue = new ReferenceQueue<>();
    this.cleanupThread = new CleanupThread(referenceQueue, HANDLER);
    this.cleanupThread.start();
  }
  
  
  /*
  * 利用指定的Uri来加载图片
  */
  public RequestCreator load(@Nullable Uri uri) {
    return new RequestCreator(this, uri, 0);
  }
  
  /*
  * 通过指定的图片文件来加载图片
  * 等价于调用load(Uri)方法
  */
  public RequestCreator load(@NonNull File file) {
    if (file == null) {
      return new RequestCreator(this, null, 0);
    }
    return load(Uri.fromFile(file));
  }
  
  /*
  * 通过指定的路径来加载图片
  * 该方法等价调用Load（Uri）
  */
  public RequestCreator load(@Nullable String path) {
    if (path == null) {
      return new RequestCreator(this, null, 0);
    }
    if (path.trim().length() == 0) {
      throw new IllegalArgumentException("Path must not be empty.");
    }
    return load(Uri.parse(path));
  }
  
   /*
   * 通过指定的ResourceID加载图片
   */
   public RequestCreator load(@DrawableRes int resourceId) {
    if (resourceId == 0) {
      throw new IllegalArgumentException("Resource ID must not be zero.");
    }
    return new RequestCreator(this, null, resourceId);
  }
  
  /*
  * RequestCreator的构造函数
  */
   RequestCreator(Picasso picasso, Uri uri, int resourceId) {
    if (picasso.shutdown) {
      throw new IllegalStateException(
          "Picasso instance already shut down. Cannot submit new requests.");
    }
    this.picasso = picasso;
    this.data = new Request.Builder(uri, resourceId, picasso.defaultBitmapConfig);
  }
  
  /*
  * 存储请求的Uri和Resource Id以及Bitmap的配置
  */
  Builder(Uri uri, int resourceId, Bitmap.Config bitmapConfig) {
      this.uri = uri;
      this.resourceId = resourceId;
      this.config = bitmapConfig;
  }
  
  
  /*************into方法***************/
  public void into(ImageView target) {
    into(target, null);
  }
  
  /*
  * 异步执行请求，请求执行完成后回调callback
  **/
  public void into(ImageView target, Callback callback) {
    long started = System.nanoTime();
    checkMain();

    if (target == null) {
      throw new IllegalArgumentException("Target must not be null.");
    }

	//如果没有请求数据，即uri为null或者resourceID为0时，则取消请求。
    if (!data.hasImage()) {
      picasso.cancelRequest(target);
	  //加载placeHolder照片
      if (setPlaceholder) {
        setPlaceholder(target, getPlaceholderDrawable());
      }
      return;
    }

	
    if (deferred) {
      if (data.hasSize()) {
        throw new IllegalStateException("Fit cannot be used with resize.");
      }
      int width = target.getWidth();
      int height = target.getHeight();
      if (width == 0 || height == 0 || target.isLayoutRequested()) {
        if (setPlaceholder) {
          setPlaceholder(target, getPlaceholderDrawable());
        }
        picasso.defer(target, new DeferredRequestCreator(this, target, callback));
        return;
      }
      data.resize(width, height);
    }

	//创建请求以及请求的key
    Request request = createRequest(started);
    String requestKey = createKey(request);

	//从内存缓存中加载图片
    if (shouldReadFromMemoryCache(memoryPolicy)) {
      Bitmap bitmap = picasso.quickMemoryCacheCheck(requestKey);
      if (bitmap != null) {
        picasso.cancelRequest(target);
        setBitmap(target, picasso.context, bitmap, MEMORY, noFade, picasso.indicatorsEnabled);
        if (picasso.loggingEnabled) {
          log(OWNER_MAIN, VERB_COMPLETED, request.plainId(), "from " + MEMORY);
        }
        if (callback != null) {
          callback.onSuccess();
        }
        return;
      }
    }

    if (setPlaceholder) {
      setPlaceholder(target, getPlaceholderDrawable());
    }

	//创建加载图片的Action
    Action action =
        new ImageViewAction(picasso, target, request, memoryPolicy, networkPolicy, errorResId,
            errorDrawable, requestKey, tag, callback, noFade);

    //将请求入队列，并提交执行请求
    picasso.enqueueAndSubmit(action);
  }
  
  /*
  * 
  */
  void enqueueAndSubmit(Action action) {
    Object target = action.getTarget();
	//取消先前的任务，并将任务将入任务队列中
    if (target != null && targetToAction.get(target) != action) {
      // This will also check we are on the main thread.
      cancelExistingRequest(target);
      targetToAction.put(target, action);
    }
	//提交任务
    submit(action);
  }
  
  /*
  * 提交任务
  */
  void submit(Action action) {
    dispatcher.dispatchSubmit(action);
  }
  
  
  void dispatchSubmit(Action action) {
    handler.sendMessage(handler.obtainMessage(REQUEST_SUBMIT, action));
  }
  
  public void handleMessage(final Message msg) {
      switch (msg.what) {
        case REQUEST_SUBMIT: {
          Action action = (Action) msg.obj;
          dispatcher.performSubmit(action);
          break;
	    }
	}
	

void performSubmit(Action action) {
    performSubmit(action, true);
}

/*
* 执行提交任务
*/
void performSubmit(Action action, boolean dismissFailed) {
	//暂停标志
    if (pausedTags.contains(action.getTag())) {
      pausedActions.put(action.getTarget(), action);
      if (action.getPicasso().loggingEnabled) {
        log(OWNER_DISPATCHER, VERB_PAUSED, action.request.logId(),
            "because tag '" + action.getTag() + "' is paused");
      }
      return;
    }

    BitmapHunter hunter = hunterMap.get(action.getKey());
    if (hunter != null) {
      hunter.attach(action);
      return;
    }

	//服务关闭了
    if (service.isShutdown()) {
      if (action.getPicasso().loggingEnabled) {
        log(OWNER_DISPATCHER, VERB_IGNORED, action.request.logId(), "because shut down");
      }
      return;
    }

	//构建一个hunter，并提交一个任务，返回一个Future
    hunter = forRequest(action.getPicasso(), this, cache, stats, action);
    hunter.future = service.submit(hunter);
    hunterMap.put(action.getKey(), hunter);
    if (dismissFailed) {
      failedActions.remove(action.getTarget());
    }

    if (action.getPicasso().loggingEnabled) {
      log(OWNER_DISPATCHER, VERB_ENQUEUED, action.request.logId());
    }
  }
  
  
  
  
  
	
  

public class SparseArray<E> implements Cloneable {
	//标记需要删除的元素为DELETED的
	private static final Object DELETED = new Object();
	//是否需要垃圾回收
    private boolean mGarbage = false;

	//保存key的int数组
    private int[] mKeys;
	//保存value的Object数组
    private Object[] mValues;
	//元素数组的大小
    private int mSize;
	
	/*
	* 构造一个初始容量为10的SparseArray
	*/
	public SparseArray() {
        this(10);
    }
	
	/*
	* 初始化容量为initialCapacity的SparseArray
	*/
	public SparseArray(int initialCapacity) {
        if (initialCapacity == 0) {
            mKeys = EmptyArray.INT;
            mValues = EmptyArray.OBJECT;
        } else {
            mValues = ArrayUtils.newUnpaddedObjectArray(initialCapacity);
            mKeys = new int[mValues.length];
        }
        mSize = 0;
    }
	
	/*
	* 添加一个key-value映射到数组中，如果已经存在，则更新旧的值
	*/
	public void put(int key, E value) {
		//二分查找
        int i = ContainerHelpers.binarySearch(mKeys, mSize, key);

		//已经存在对应的key值
        if (i >= 0) {
			//更新该key值对应的value
            mValues[i] = value;
        } else {
			//没有对应的key存在，则将index转为正的
            i = ~i;

			//如果key对应的index小于当前数组的大小，并且该index对应的value已经标记为DELETE了，则直接将key-value保存在数组的inndex位置
            if (i < mSize && mValues[i] == DELETED) {
                mKeys[i] = key;
                mValues[i] = value;
                return;
            }

			//如果需要垃圾回收，并且当前数组大小大于key数组的大小时，将DELETE对象占用的位置回收
            if (mGarbage && mSize >= mKeys.length) {
                gc();

                // Search again because indices may have changed.
				//重新查找key对应的index值，因为元素的位置在回收DELETE对象的时候，可能已经发生了变化
                i = ~ContainerHelpers.binarySearch(mKeys, mSize, key);
            }
            //将key值插入到key数组中，可能会重新分配一个新的数组
            mKeys = GrowingArrayUtils.insert(mKeys, mSize, i, key);
			//将value值插入到value数组中
            mValues = GrowingArrayUtils.insert(mValues, mSize, i, value);
			//更新数组的容量
            mSize++;
        }
    }
	
	/*
	* 二分查找，如果找到返回一个正的index，如果没有找到，则返回一个负的index
	*/
	static int binarySearch(int[] array, int size, int value) {
        int lo = 0;
        int hi = size - 1;

        while (lo <= hi) {
            final int mid = (lo + hi) >>> 1;
            final int midVal = array[mid];

            if (midVal < value) {
                lo = mid + 1;
            } else if (midVal > value) {
                hi = mid - 1;
            } else {
                return mid;  // value found
            }
        }
        return ~lo;  // value not present
    }
	
	/*
	* 将标记为DELETE对象回收，并更新数组的大小
	*/
	private void gc() {
       
        int n = mSize;
        int o = 0;
        int[] keys = mKeys;
        Object[] values = mValues;

        for (int i = 0; i < n; i++) {
            Object val = values[i];

            if (val != DELETED) {
                if (i != o) {
                    keys[o] = keys[i];
                    values[o] = val;
                    values[i] = null;
                }

                o++;
            }
        }

        mGarbage = false;
        mSize = o;
    }
	
	/*
	* 返回key对应的Value值，如果不存在，则返回null
	*/
	public E get(int key) {
        return get(key, null);
    }
	
	@SuppressWarnings("unchecked")
    public E get(int key, E valueIfKeyNotFound) {
		//二分查找key对应的索引index
        int i = ContainerHelpers.binarySearch(mKeys, mSize, key);

		//如果没有找到返回一个null
        if (i < 0 || mValues[i] == DELETED) {
            return valueIfKeyNotFound;
        } else {
			//找到，返回value值
            return (E) mValues[i];
        }
    }
	
	/*
	* 删除一个元素
	*/
	public void remove(int key) {
        delete(key);
    }
	
	
	public void delete(int key) {
		//二分查找key对应的索引index
        int i = ContainerHelpers.binarySearch(mKeys, mSize, key);
		//如果找到，并且该value存在，则将该value标记为DELETED，等gc的时候，真正去回收
        if (i >= 0) {
            if (mValues[i] != DELETED) {
                mValues[i] = DELETED;
				//标记为需要垃圾回收
                mGarbage = true;
            }
        }
    }
	
	/*
	* 返回index下的key值
	*/
	 public int keyAt(int index) {
        if (mGarbage) {
            gc();
        }

        return mKeys[index];
    }
	
	/*
	* 返回index下的value值
	*/
	public E valueAt(int index) {
        if (mGarbage) {
            gc();
        }

        return (E) mValues[index];
    }
}
     
	 /**
     * 状态机的构建函数
     *
     * @param name 状态机的名字
     */
    protected StateMachine(String name) {
		//通过HandlerThread来处理消息
        mSmThread = new HandlerThread(name);
        mSmThread.start();
        Looper looper = mSmThread.getLooper();

        initStateMachine(name, looper);
    }
	
	/**
     * 初始化状态机
     *
     * @param looper 状态机使用的Looper
     * @param name 状态机名字
     */
    private void initStateMachine(String name, Looper looper) {
        mName = name;
        mSmHandler = new SmHandler(looper, this);
    }
	
	/*
	* SmHandler继承自Handler
	*/
	private SmHandler(Looper looper, StateMachine sm) {
            super(looper);
            mSm = sm;//持有一个状态机的引用

			//将Halting和Quitting状态添加到状态列表中
            addState(mHaltingState, null);
            addState(mQuittingState, null);
    }
	
	     /**
		 * 添加一个新的状态到状态机
         * 
         *
         * @param 需要添加的状态
         * @param parent the 状态的父状态
         * @return stateInfo 返回当前状态的信息
         */
        private final StateInfo addState(State state, State parent) {
           
            StateInfo parentStateInfo = null;
            if (parent != null) {
                parentStateInfo = mStateInfo.get(parent);
                if (parentStateInfo == null) {
					//如果parent状态还未添加，则先添加parent状态
                    parentStateInfo = addState(parent, null);
                }
            }
            StateInfo stateInfo = mStateInfo.get(state);
            if (stateInfo == null) {
                stateInfo = new StateInfo();
				//将状态添加到状态集合中
                mStateInfo.put(state, stateInfo);
            }

			//验证是否存在相同的状态，不同parent的情况，保证一个状态只有一个parent状态存在
            if ((stateInfo.parentStateInfo != null)
                    && (stateInfo.parentStateInfo != parentStateInfo)) {
                throw new RuntimeException("state already added");
            }
            stateInfo.state = state;
            stateInfo.parentStateInfo = parentStateInfo;
            stateInfo.active = false;
            return stateInfo;
        }
		
	    /*
		* 状态信息
		*/
		private class StateInfo {
            /** 状态 */
            State state;

            /** 父类状态信息，如果没有父类状态，则为空 */
            StateInfo parentStateInfo;

            /** True when the state has been entered and on the stack */
            boolean active;

            /**
             * Convert StateInfo to string
             */
            @Override
            public String toString() {
                return "state=" + state.getName() + ",active=" + active + ",parent="
                        + ((parentStateInfo == null) ? "null" : parentStateInfo.state.getName());
            }
        }
		//保存状态机中所有的状态
		private HashMap<State, StateInfo> mStateInfo = new HashMap<State, StateInfo>();
		
		/*
		* 设置状态机的初始化状态
		*/
		public final void setInitialState(State initialState) {
			mSmHandler.setInitialState(initialState);
        }
		
		private final void setInitialState(State initialState) {
            if (mDbg) mSm.log("setInitialState: initialState=" + initialState.getName());
            mInitialState = initialState;
        }
		
		//状态机的初始状态，将处理第一个消息
		private State mInitialState;
		
		
		
		/*
		* 启动状态机
		*/
		public void start() {
        SmHandler smh = mSmHandler;
        if (smh == null) return;

        smh.completeConstruction();
        }
		
		/*
		* 完成状态机的构建
		*/
		private final void completeConstruction() {

			 /*
			 * 获取状态树最大的高度
			 */
            int maxDepth = 0;
            for (StateInfo si : mStateInfo.values()) {
                int depth = 0;
                for (StateInfo i = si; i != null; depth++) {
                    i = i.parentStateInfo;
                }
                if (maxDepth < depth) {
                    maxDepth = depth;
                }
            }
            
			//根据状态树最大高度穿件StateStack数组和TempStateStack数组
            mStateStack = new StateInfo[maxDepth];
            mTempStateStack = new StateInfo[maxDepth];
            setupInitialStateStack();

            /** Sending SM_INIT_CMD message to invoke enter methods asynchronously */
            sendMessageAtFrontOfQueue(obtainMessage(SM_INIT_CMD, mSmHandlerObj));

        }

		/*
		* 初始化StateStack数组
		*/
		private final void setupInitialStateStack() {
            //获取初始状态的状态信息
            StateInfo curStateInfo = mStateInfo.get(mInitialState);
			//将初始状态以及初始状态的父状态和祖先状态放入TempStateStack数组中
            for (mTempStateStackCount = 0; curStateInfo != null; mTempStateStackCount++) {
                mTempStateStack[mTempStateStackCount] = curStateInfo;
                curStateInfo = curStateInfo.parentStateInfo;
            }

            // StateStack的索引，初始化时为-1，表示是一个空数组
            mStateStackTopIndex = -1;

            moveTempStateStackToStateStack();
        }
		
		/*
		* 将TempStackState数组中的状态转移到StateStack数组中，转移的顺序是反序的。
		*/
		private final int moveTempStateStackToStateStack() {
			//StateStack数组的起始索引，这里为0
            int startingIndex = mStateStackTopIndex + 1;
			//TempStateStack数组最后一个元素的索引
            int i = mTempStateStackCount - 1;
            int j = startingIndex;
			//循环将TempStateStack数组中的元素以倒序的方式存入StateStack数组中
            while (i >= 0) {
                mStateStack[j] = mTempStateStack[i];
                j += 1;
                i -= 1;
            }
            //StateStack数组的索引指向最后一个元素
            mStateStackTopIndex = j - 1;
  
            return startingIndex;
        }
		
		
		 /*
		 * 通过调用当前状态的processMessage方法处理消息
		 * 调用状态的enter/exit方法
		 * 将deferred的消息放入到消息队列的首部，在新的状态中处理
		 *
		 */
        @Override
        public final void handleMessage(Message msg) {
			//状态机还未停止
            if (!mHasQuit) {
                if (mSm != null && msg.what != SM_INIT_CMD && msg.what != SM_QUIT_CMD) {
					//可以覆写onPreHandleMessage方法，在消息处理前做一些工作
                    mSm.onPreHandleMessage(msg);
                }


                //保存当前消息
                mMsg = msg;

				//保存处理当前信息的状态
                State msgProcessedState = null;
                if (mIsConstructionCompleted) {
                    // 1.调用processMessage处理消息
                    msgProcessedState = processMsg(msg);
                } else if (!mIsConstructionCompleted && (mMsg.what == SM_INIT_CMD)
                        && (mMsg.obj == mSmHandlerObj)) {
                    //初始化第一次时调用到这里
                    mIsConstructionCompleted = true;
                    invokeEnterMethods(0);
                } else {
                    throw new RuntimeException("StateMachine.handleMessage: "
                            + "The start method not called, received msg: " + msg);
                }
				// 2.调用状态的enter/exit方法，将deferred的消息放入消息队列的首部
                performTransitions(msgProcessedState, msg);

                if (mSm != null && msg.what != SM_INIT_CMD && msg.what != SM_QUIT_CMD) {
					//可以覆写onPostHandleMessage方法，在消息处理完成后做一些工作
                    mSm.onPostHandleMessage(msg);
                }
            }
        }
		
		当收到SM_INIT_CMD消息，并且Message的obj为mSmHandlerObj时，表示这是第一次初始化状态。
		/*
		* 触发StateStack数组中元素进入enter状态，从stateStackEnteringIndex到mStateStackTopIndex之间的状态都将进入enter状态，并将active设置为true。
		*/
		private final void invokeEnterMethods(int stateStackEnteringIndex) {
            for (int i = stateStackEnteringIndex; i <= mStateStackTopIndex; i++) {
                if (stateStackEnteringIndex == mStateStackTopIndex) {
                    mTransitionInProgress = false;
                }
                mStateStack[i].state.enter();
                mStateStack[i].active = true;
            }
            mTransitionInProgress = false; 
        }
		
		
		public void sendMessage(int what) {
			SmHandler smh = mSmHandler;
			if (smh == null) return;

			smh.sendMessage(obtainMessage(what));
		}
		
		
		public final void handleMessage(Message msg) {
            if (!mHasQuit) {
                if (mSm != null && msg.what != SM_INIT_CMD && msg.what != SM_QUIT_CMD) {
                    mSm.onPreHandleMessage(msg);
                }
               
                mMsg = msg;

                State msgProcessedState = null;
                if (mIsConstructionCompleted) {
                    msgProcessedState = processMsg(msg);
                } else if (!mIsConstructionCompleted && (mMsg.what == SM_INIT_CMD)
                        && (mMsg.obj == mSmHandlerObj)) {
                    mIsConstructionCompleted = true;
                    invokeEnterMethods(0);
                } else {
                    throw new RuntimeException("StateMachine.handleMessage: "
                            + "The start method not called, received msg: " + msg);
                }
                performTransitions(msgProcessedState, msg);


                if (mSm != null && msg.what != SM_INIT_CMD && msg.what != SM_QUIT_CMD) {
                    mSm.onPostHandleMessage(msg);
                }
            }
        }
		
		/*
		* 处理该消息，如果当前状态不能处理该消息，则交由其父状态处理以及祖先处理。
		* 如果该消息最终还未被处理，则交由状态机的unhandleMessage方法来处理。
		*/
		private final State processMsg(Message msg) {
			//获取当前状态信息
            StateInfo curStateInfo = mStateStack[mStateStackTopIndex];
            
            if (isQuit(msg)) {
				//如果是终止消息，则转移到终止状态
                transitionTo(mQuittingState);
            } else {
                while (!curStateInfo.state.processMessage(msg)) {
                    获取当前状态的父状态信息
                    curStateInfo = curStateInfo.parentStateInfo;
                    if (curStateInfo == null) {
                        /**
                         * No parents left so it's not handled
                         */
                        mSm.unhandledMessage(msg);
                        break;
                    }
                }
            }
			//返回处理该消息的状态
            return (curStateInfo != null) ? curStateInfo.state : null;
        }
		
		/*
		* 状态转移操作
		*/
		private void performTransitions(State msgProcessedState, Message msg) {
            .........
			//目标状态，通过transitionTo方法设置目标状态
            State destState = mDestState;
            if (destState != null) {

                while (true) {
        
					//获取当前状态和目标状态共同的祖先状态
                    StateInfo commonStateInfo = setupTempStateStackWithStatesToEnter(destState);
                    mTransitionInProgress = true;
					//从当前状态到公共祖先状态之间的状态都执行exit方法
                    invokeExitMethods(commonStateInfo);
					//获取进入enter状态的索引
                    int stateStackEnteringIndex = moveTempStateStackToStateStack();
					//从公共祖先状态到目标状态之间的状态都执行enter方法
                    invokeEnterMethods(stateStackEnteringIndex);

                    
					//将deferred的消息放入到消息队列的首部，在新的状态中处理
                    moveDeferredMessageAtFrontOfQueue();

                    if (destState != mDestState) {
                        // A new mDestState so continue looping
                        destState = mDestState;
                    } else {
                        // No change in mDestState so we're done
                        break;
                    }
                }
                mDestState = null;
            }

			//如果目标状态是quit状态，则执行onQuitting操作，如果是halt状态，则执行onHalting操作
            if (destState != null) {
                if (destState == mQuittingState) {
                    mSm.onQuitting();
                    cleanupAfterQuitting();
                } else if (destState == mHaltingState) {
                    mSm.onHalting();
                }
            }
        }
		
		
		/*
		* 将需要执行enter操作的状态保存到TempStateStack数组中
		* 返回当前状态与目标状态的共同祖先状态，如果没有则返回目标状态信息
		*/
		private final StateInfo setupTempStateStackWithStatesToEnter(State destState) {
            mTempStateStackCount = 0;
			//获取目标状态信息
            StateInfo curStateInfo = mStateInfo.get(destState);
            do {
                mTempStateStack[mTempStateStackCount++] = curStateInfo;
				//父状态信息
                curStateInfo = curStateInfo.parentStateInfo;
            } while ((curStateInfo != null) && !curStateInfo.active);

            return curStateInfo;
        }
		
		/*
		* 将当前状态到共同祖先状态之间的状态执行exit方法
		*/
		private final void invokeExitMethods(StateInfo commonStateInfo) {
			//从StateStack数组尾部索引开始查找，直到公共祖先状态，但不包含公共祖先状态，都执行exit方法
            while ((mStateStackTopIndex >= 0)
                    && (mStateStack[mStateStackTopIndex] != commonStateInfo)) {
                State curState = mStateStack[mStateStackTopIndex].state;
                curState.exit();
                mStateStack[mStateStackTopIndex].active = false;
                mStateStackTopIndex -= 1;
            }
        }
		
		/*
		* 将TempStackState数组中的状态转移到StateStack数组中，转移的顺序是反序的。
		*/
		private final int moveTempStateStackToStateStack() {
            int startingIndex = mStateStackTopIndex + 1;
            int i = mTempStateStackCount - 1;
            int j = startingIndex;
            while (i >= 0) {
                mStateStack[j] = mTempStateStack[i];
                j += 1;
                i -= 1;
            }

            mStateStackTopIndex = j - 1;
            return startingIndex;
        }
		
		/*
		* 从stateStackEnteringIndex索引开始，将StateStack数组中的状态执行enter操作
		*/
		private final void invokeEnterMethods(int stateStackEnteringIndex) {
            for (int i = stateStackEnteringIndex; i <= mStateStackTopIndex; i++) {
                if (stateStackEnteringIndex == mStateStackTopIndex) {
                    mTransitionInProgress = false;
                }
                mStateStack[i].state.enter();
                mStateStack[i].active = true;
            }
            mTransitionInProgress = false; 
        }
		
		/*
		* 将deferred的消息放入到消息队列的首部
		*/
		private final void moveDeferredMessageAtFrontOfQueue() {
           
		    //将deferred数组中消息放入消息队列的首部，最早放入的数组的消息，在消息队列的最前面
            for (int i = mDeferredMessages.size() - 1; i >= 0; i--) {
                Message curMsg = mDeferredMessages.get(i);
                sendMessageAtFrontOfQueue(curMsg);
            }
            mDeferredMessages.clear();
        }
		
		
		

		/*
		* 转移到目标状态
		*/
		public final void transitionTo(IState destState) {
			mSmHandler.transitionTo(destState);
        }
		
		private final void transitionTo(IState destState) {
            mDestState = (State) destState;
        }

		/*
		* 转移到终止状态
		*/
		public final void transitionToHaltingState() {
			mSmHandler.transitionTo(mSmHandler.mHaltingState);
        }
		
		public final void quit() {
        SmHandler smh = mSmHandler;
        if (smh == null) return;

        smh.quit();
        }
		
		private final void quit() {
            sendMessage(obtainMessage(SM_QUIT_CMD, mSmHandlerObj));
        }

		
		

		
		
		
		
		
		
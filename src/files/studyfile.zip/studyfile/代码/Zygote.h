int main(int argc, char* const argv[])
{
    AppRuntime runtime(argv[0], computeArgBlockSize(argc, argv));
    // Process command line arguments
    // ignore argv[0]
    argc--;
    argv++;

    // Everything up to '--' or first non '-' arg goes to the vm.
    //
    // The first argument after the VM args is the "parent dir", which
    // is currently unused.
    //
    // After the parent dir, we expect one or more the following internal
    // arguments :
    //
    // --zygote : Start in zygote mode
    // --start-system-server : Start the system server.
    // --application : Start in application (stand alone, non zygote) mode.
    // --nice-name : The nice name for this process.
    //
    // For non zygote starts, these arguments will be followed by
    // the main class name. All remaining arguments are passed to
    // the main method of this class.
    //
    // For zygote starts, all remaining arguments are passed to the zygote.
    // main function.
    //
    // Note that we must copy argument string values since we will rewrite the
    // entire argument block when we apply the nice name to argv0.
    //
    // As an exception to the above rule, anything in "spaced commands"
    // goes to the vm even though it has a space in it.
    const char* spaced_commands[] = { "-cp", "-classpath" };
    // Allow "spaced commands" to be succeeded by exactly 1 argument (regardless of -s).
    bool known_command = false;

    int i;
    for (i = 0; i < argc; i++) {
        if (known_command == true) {
          runtime.addOption(strdup(argv[i]));
          ALOGV("app_process main add known option '%s'", argv[i]);
          known_command = false;
          continue;
        }

        for (int j = 0;
             j < static_cast<int>(sizeof(spaced_commands) / sizeof(spaced_commands[0]));
             ++j) {
          if (strcmp(argv[i], spaced_commands[j]) == 0) {
            known_command = true;
            ALOGV("app_process main found known command '%s'", argv[i]);
          }
        }

        if (argv[i][0] != '-') {
            break;
        }
        if (argv[i][1] == '-' && argv[i][2] == 0) {
            ++i; // Skip --.
            break;
        }

        runtime.addOption(strdup(argv[i]));
        ALOGV("app_process main add option '%s'", argv[i]);
    }

    // Parse runtime arguments.  Stop at first unrecognized option.
    bool zygote = false;
    bool startSystemServer = false;
    bool application = false;
    String8 niceName;
    String8 className;

    ++i;  // Skip unused "parent dir" argument.
    while (i < argc) {
        const char* arg = argv[i++];
        if (strcmp(arg, "--zygote") == 0) {
            zygote = true;
            niceName = ZYGOTE_NICE_NAME;
        } else if (strcmp(arg, "--start-system-server") == 0) {
            startSystemServer = true;
        } else if (strcmp(arg, "--application") == 0) {
            application = true;
        } else if (strncmp(arg, "--nice-name=", 12) == 0) {
            niceName.setTo(arg + 12);
        } else if (strncmp(arg, "--", 2) != 0) {
            className.setTo(arg);
            break;
        } else {
            --i;
            break;
        }
    }

    Vector<String8> args;
    if (!className.isEmpty()) {
        // We're not in zygote mode, the only argument we need to pass
        // to RuntimeInit is the application argument.
        //
        // The Remainder of args get passed to startup class main(). Make
        // copies of them before we overwrite them with the process name.
        args.add(application ? String8("application") : String8("tool"));
        runtime.setClassNameAndArgs(className, argc - i, argv + i);

        if (!LOG_NDEBUG) {
          String8 restOfArgs;
          char* const* argv_new = argv + i;
          int argc_new = argc - i;
          for (int k = 0; k < argc_new; ++k) {
            restOfArgs.append("\"");
            restOfArgs.append(argv_new[k]);
            restOfArgs.append("\" ");
          }
          ALOGV("Class name = %s, args = %s", className.string(), restOfArgs.string());
        }
    } else {
        // We're in zygote mode.
        maybeCreateDalvikCache();

        if (startSystemServer) {
            args.add(String8("start-system-server"));
        }

        char prop[PROP_VALUE_MAX];
        if (property_get(ABI_LIST_PROPERTY, prop, NULL) == 0) {
            LOG_ALWAYS_FATAL("app_process: Unable to determine ABI list from property %s.",
                ABI_LIST_PROPERTY);
            return 11;
        }

        String8 abiFlag("--abi-list=");
        abiFlag.append(prop);
        args.add(abiFlag);

        // In zygote mode, pass all remaining arguments to the zygote
        // main() method.
        for (; i < argc; ++i) {
            args.add(String8(argv[i]));
        }
    }

    if (!niceName.isEmpty()) {
        runtime.setArgv0(niceName.string(), true /* setProcName */);
    }

    if (zygote) {
        runtime.start("com.android.internal.os.ZygoteInit", args, zygote);
    } else if (className) {
        runtime.start("com.android.internal.os.RuntimeInit", args, zygote);
    } else {
        fprintf(stderr, "Error: no class name or --zygote supplied.\n");
        app_usage();
        LOG_ALWAYS_FATAL("app_process: no class name or --zygote supplied.");
    }
}

class AppRuntime : public AndroidRuntime
{
public:
    AppRuntime(char* argBlockStart, const size_t argBlockLength)
        : AndroidRuntime(argBlockStart, argBlockLength)
        , mClass(NULL)
    {
}
}

AndroidRuntime::AndroidRuntime(char* argBlockStart, const size_t argBlockLength) :
        mExitWithoutCleanup(false),
        mArgBlockStart(argBlockStart),
        mArgBlockLength(argBlockLength)
{
    SkGraphics::Init();
    mOptions.setCapacity(20);
    assert(gCurRuntime == NULL);        // one per process
    gCurRuntime = this;
}
static AndroidRuntime* gCurRuntime = NULL;
AndroidRuntime* AndroidRuntime::getRuntime()
{
    return gCurRuntime;
}

/*
 * Start the Android runtime.  This involves starting the virtual machine
 * and calling the "static void main(String[] args)" method in the class
 * named by "className".
 *
 * Passes the main function two arguments, the class name and the specified
 * options string.
 */
void AndroidRuntime::start(const char* className, const Vector<String8>& options, bool zygote)
{
     ...
    static const String8 startSystemServer("start-system-server");

    ...
	// 1.启动虚拟机VM
    /* start the virtual machine */
    JniInvocation jni_invocation;
    jni_invocation.Init(NULL);
    JNIEnv* env;
    if (startVm(&mJavaVM, &env, zygote) != 0) {
        return;
    }
    onVmCreated(env);
	
    //2.注册JNI函数
    /*
     * Register android functions.
     */
    if (startReg(env) < 0) {
        ALOGE("Unable to register all android natives\n");
        return;
    }

    /*
     * We want to call main() with a String array with arguments in it.
     * At present we have two arguments, the class name and an option string.
     * Create an array to hold them.
     */
    jclass stringClass;
    jobjectArray strArray;
    jstring classNameStr;

    stringClass = env->FindClass("java/lang/String");
    assert(stringClass != NULL);
    strArray = env->NewObjectArray(options.size() + 1, stringClass, NULL);
    assert(strArray != NULL);
    classNameStr = env->NewStringUTF(className);
    assert(classNameStr != NULL);
    env->SetObjectArrayElement(strArray, 0, classNameStr);

    for (size_t i = 0; i < options.size(); ++i) {
        jstring optionsStr = env->NewStringUTF(options.itemAt(i).string());
        assert(optionsStr != NULL);
        env->SetObjectArrayElement(strArray, i + 1, optionsStr);
    }

	
	// 3.启动Zygote进程，调用ZygoteInit.main（）方法。
    /*
     * Start VM.  This thread becomes the main thread of the VM, and will
     * not return until the VM exits.
     */
    char* slashClassName = toSlashClassName(className);
    //通过JNI调用java方法，具体是通过找到ZygoteInit类，以及ZygoteInit类的静态方法main，
	//最后通过CallStaticVoidMethod调用ZygoteInit类的main方法。
	// "com.android.internal.os.ZygoteInit"是通过app_main中main方法传递过来的参数。
    jclass startClass = env->FindClass(slashClassName);
    if (startClass == NULL) {
        ALOGE("JavaVM unable to locate class '%s'\n", slashClassName);
        /* keep going */
    } else {
        jmethodID startMeth = env->GetStaticMethodID(startClass, "main",
            "([Ljava/lang/String;)V");
        if (startMeth == NULL) {
            ALOGE("JavaVM unable to find main() in '%s'\n", className);
            /* keep going */
        } else {
            env->CallStaticVoidMethod(startClass, startMeth, strArray);
        }
    }
    free(slashClassName);

	// 虚拟机退出了才会执行到这里
    ALOGD("Shutting down VM\n");
    if (mJavaVM->DetachCurrentThread() != JNI_OK)
        ALOGW("Warning: unable to detach main thread\n");
    if (mJavaVM->DestroyJavaVM() != 0)
        ALOGW("Warning: VM did not shut down cleanly\n");
}


/*
 * Start the Dalvik Virtual Machine.
 *
 * Various arguments, most determined by system properties, are passed in.
 * The "mOptions" vector is updated.
 *
 * Returns 0 on success.
 */
int AndroidRuntime::startVm(JavaVM** pJavaVM, JNIEnv** pEnv, bool zygote)
{
    JavaVMInitArgs initArgs;
	//准备J创建VM的参数
	...
	// 初始化VM
	 /*
     * Initialize the VM.
     *
     * The JavaVM* is essentially per-process, and the JNIEnv* is per-thread.
     * If this call succeeds, the VM is ready, and we can start issuing
     * JNI calls.
     */
    if (JNI_CreateJavaVM(pJavaVM, pEnv, &initArgs) < 0) {
        ALOGE("JNI_CreateJavaVM failed\n");
        return -1;
    }

    return 0;
}

/*
 * Register android native functions with the VM.
 */
/*static*/ int AndroidRuntime::startReg(JNIEnv* env)
{
    ATRACE_NAME("RegisterAndroidNatives");
    /*
     * This hook causes all future threads created in this process to be
     * attached to the JavaVM.  (This needs to go away in favor of JNI
     * Attach calls.)
     */
	 // 设置创建线程的方法为javaCreateThreadEtc，该方法定义在AndroidRuntime.h中
    androidSetCreateThreadFunc((android_create_thread_fn) javaCreateThreadEtc);

    ALOGV("--- registering native functions ---\n");

    /*
     * Every "register" function calls one or more things that return
     * a local reference (e.g. FindClass).  Because we haven't really
     * started the VM yet, they're all getting stored in the base frame
     * and never released.  Use Push/Pop to manage the storage.
     */
    env->PushLocalFrame(200);
	//注册gRegJNI中的函数
    if (register_jni_procs(gRegJNI, NELEM(gRegJNI), env) < 0) {
        env->PopLocalFrame(NULL);
        return -1;
    }
    env->PopLocalFrame(NULL);
    return 0;
}

#ifdef NDEBUG
    #define REG_JNI(name)      { name }
    struct RegJNIRec {
        int (*mProc)(JNIEnv*);
    };
#else
    #define REG_JNI(name)      { name, #name }
    struct RegJNIRec {
        int (*mProc)(JNIEnv*);
        const char* mName;
    };
#endif

//一个包含JNI函数的数组
static const RegJNIRec gRegJNI[] = {
    REG_JNI(register_com_android_internal_os_RuntimeInit),
    REG_JNI(register_com_android_internal_os_ZygoteInit),
    REG_JNI(register_android_os_SystemClock),
    REG_JNI(register_android_util_EventLog),
    REG_JNI(register_android_util_Log),
	REG_JNI(register_android_util_MemoryIntArray),
	....
}

//循环调用gRegJNI数组中的JNI函数，每一个方法都对应于一个类的jni映射。
static int register_jni_procs(const RegJNIRec array[], size_t count, JNIEnv* env)
{
    for (size_t i = 0; i < count; i++) {
        if (array[i].mProc(env) < 0) {
            return -1;
        }
    }
    return 0;
}

int register_com_android_internal_os_RuntimeInit(JNIEnv* env)
{
    const JNINativeMethod methods[] = {
        { "nativeFinishInit", "()V",
            (void*) com_android_internal_os_RuntimeInit_nativeFinishInit },
        { "nativeSetExitWithoutCleanup", "(Z)V",
            (void*) com_android_internal_os_RuntimeInit_nativeSetExitWithoutCleanup },
    };
    return jniRegisterNativeMethods(env, "com/android/internal/os/RuntimeInit",
        methods, NELEM(methods));
}


int register_com_android_internal_os_ZygoteInit(JNIEnv* env)
{
    const JNINativeMethod methods[] = {
        { "nativeZygoteInit", "()V",
            (void*) com_android_internal_os_ZygoteInit_nativeZygoteInit },
    };
    return jniRegisterNativeMethods(env, "com/android/internal/os/ZygoteInit",
        methods, NELEM(methods));
}

typedef struct {
    const char* name;
    const char* signature;
    void*       fnPtr;
} JNINativeMethod;


JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved);
jint JNI_OnLoad(JavaVM* vm, void* /* reserved */)
{
    JNIEnv* env = NULL;
    jint result = -1;
	// 1.通过JavaVM获取JNIEnv，指定JNI的版本为1.4。
    if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK) {
        ALOGE("ERROR: GetEnv failed\n");
        goto bail;
    }
    assert(env != NULL);

    ...
	// 2.注册JNI方法
    if (register_android_media_MediaPlayer(env) < 0) {
        ALOGE("ERROR: MediaPlayer native registration failed\n");
        goto bail;
    }

    ...
    /* success -- return valid version number */
	// 3.返回JNI版本号
    result = JNI_VERSION_1_4;

bail:
    return result;
}

// 调用registerNativeMethods方法注册本地方法
static int register_android_media_MediaPlayer(JNIEnv *env)
{
    return AndroidRuntime::registerNativeMethods(env,
                "android/media/MediaPlayer", gMethods, NELEM(gMethods));
}

static const JNINativeMethod gMethods[] = {
    ...
    {"_prepare",            "()V",                              (void *)android_media_MediaPlayer_prepare},
    {"_start",              "()V",                              (void *)android_media_MediaPlayer_start},
    {"_stop",               "()V",                              (void *)android_media_MediaPlayer_stop},
    {"seekTo",              "(I)V",                             (void *)android_media_MediaPlayer_seekTo},
    {"_pause",              "()V",                              (void *)android_media_MediaPlayer_pause},
    {"isPlaying",           "()Z",                              (void *)android_media_MediaPlayer_isPlaying},
    {"getCurrentPosition",  "()I",                              (void *)android_media_MediaPlayer_getCurrentPosition},
    {"getDuration",         "()I",                              (void *)android_media_MediaPlayer_getDuration},
    {"_release",            "()V",                              (void *)android_media_MediaPlayer_release},
    {"_reset",              "()V",                              (void *)android_media_MediaPlayer_reset},
    {"setParameter",        "(ILandroid/os/Parcel;)Z",          (void *)android_media_MediaPlayer_setParameter},
    {"native_setup",        "(Ljava/lang/Object;)V",            (void *)android_media_MediaPlayer_native_setup},
    ....
};

typedef struct {
    const char* name;//Java方法名字
    const char* signature;//方法签名
    void*       fnPtr;//Java方法对应的本地函数指针
} JNINativeMethod;

在framework/core/jni/AndroidRuntime.cpp文件中实现了registerNativeMethods方法，并最终调用jniRegisterNativeMethods方法。
/*
 * Register native methods using JNI.
 */
/*static*/ int AndroidRuntime::registerNativeMethods(JNIEnv* env,
    const char* className, const JNINativeMethod* gMethods, int numMethods)
{
    return jniRegisterNativeMethods(env, className, gMethods, numMethods);
}

在/libnativehelper/JNIHelp.cpp文件中实现了jniRegisterNativeMethods方法
extern "C" int jniRegisterNativeMethods(C_JNIEnv* env, const char* className,
    const JNINativeMethod* gMethods, int numMethods)
{
    JNIEnv* e = reinterpret_cast<JNIEnv*>(env);

    scoped_local_ref<jclass> c(env, findClass(env, className));
    ...
	// 调用RegisterNatives()方法完成注册
    if ((*env)->RegisterNatives(e, c.get(), gMethods, numMethods) < 0) {
       ...
    }
    return 0;
}

RegisterNatives方法在jni.h文件中实现。
struct _JNIEnv {
    /* do not rename this; it does not seem to be entirely opaque */
    const struct JNINativeInterface* functions;
	    ...
	jint RegisterNatives(jclass clazz, const JNINativeMethod* methods,jint nMethods){
		return functions->RegisterNatives(this, clazz, methods, nMethods); 
	}
	....
}

functions是一个JNINativeInterface的指针，也将调用RegisterNatives()方法，再往下面就是虚拟机的内部实现了，在此不再详述。
struct JNINativeInterface {
    void*       reserved0;
    void*       reserved1;
    void*       reserved2;
    void*       reserved3;
	....
    jint  (*RegisterNatives)(JNIEnv*, jclass, const JNINativeMethod*,jint);
	....
}


jint        (*UnregisterNatives)(JNIEnv*, jclass);

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved);
/*******************JNI引用****************/
jobject     (*NewLocalRef)(JNIEnv*, jobject);
void        (*DeleteLocalRef)(JNIEnv*, jobject);

jobject     (*NewGlobalRef)(JNIEnv*, jobject);
void        (*DeleteGlobalRef)(JNIEnv*, jobject);

jweak       (*NewWeakGlobalRef)(JNIEnv*, jobject);
void        (*DeleteWeakGlobalRef)(JNIEnv*, jweak);


jstring Jstring2CStr(JNIEnv*   env,   jstring   jstr)
{
     ....
     jclass   clsstring   =   env->FindClass(env,"java/lang/String");//局部引用
	 jstring native_desc = env->NewStringUTF(" I am Native");//局部引用
     ...
}

jstring getNewName(JNIEnv* env, jstring str){
	...
	jclass localRef = env->FindClass(env,"java/lang/String");//创建局部引用
	jclass globalRef = env->NewGlobalRef(env,localRef);//创建全局引用并指向局部引用
	env->DeleteLocalRef(env,localRef);//删除本地引用
	env->DeleteGlobalRef(env,globalRef);//删除全局引用
	...
}

JNIMediaPlayerListener::JNIMediaPlayerListener(JNIEnv* env, jobject thiz, jobject weak_thiz)
{   ....
    jclass clazz = env->GetObjectClass(thiz);//局部引用
	....
    mClass = (jclass)env->NewGlobalRef(clazz);//创建全局引用并指向局部引用
	...
    mObject  = env->NewGlobalRef(weak_thiz);//创建全局弱引用
}

JNIMediaPlayerListener::~JNIMediaPlayerListener()
{
    // remove global references
    JNIEnv *env = AndroidRuntime::getJNIEnv();
    env->DeleteGlobalRef(mObject);//移除全局引用
    env->DeleteGlobalRef(mClass);//移除全局弱引用
}


static void android_media_MediaPlayer_native_init(JNIEnv *env,jobject obj)
{   ....
    jclass clazz;
    clazz = env->FindClass("android/media/MediaPlayer");//获取MediaPlayer类
	jfieldID name = env->GetFieldID(clazz,"name","Ljava/lang/String;");//获取MediaPlayer类的域name的ID
	jstring newName = env->NewStringUTF("media player");//创建一个新的字符串
	env->setObjectField(obj,name,newName);//将MediaPlayer类中的name属性更新
    ....
}
static void
android_media_MediaPlayer_start(JNIEnv *env, jobject obj)
{
	....
    jclass clazz;
	clazz = env->FindClass("android/media/MediaPlayer");//获取MediaPlayer类
	jfieldID name = env->GetFieldID(clazz,"name","Ljava/lang/String;");//获取MediaPlayer类的域name的ID
	jstring mediaName = (jstring)env->getObjectField(obj,name);//读取在android_media_MediaPlayer_native_init方法中更新的name对象值
	...
}


public class JavaToNative{
	static{
		System.loadLibrary(“java_to_native”);  // 通过System.loadLibrary()来加载本地代码库
		}
		private static native String hello();    // 声明native方法
		public static void main(String args[]){
			System.out.println(JavaToNative.hello()); // 调用native方法
		}
}

/*************************Native访问Java成员****************/
jclass FindClass(const char* name);
jclass GetObjectClass(jobject obj);
struct _jfieldID;                       /* opaque structure */
typedef struct _jfieldID* jfieldID;     /* field IDs */
struct _jmethodID;                      /* opaque structure */
typedef struct _jmethodID* jmethodID;   /* method IDs */

//获取Java对象的属性ID
jfieldID GetFieldID(jclass clazz, const char* name, const char* sig);
//获取Java类的静态属性ID
jfieldID GetStaticFieldID(jclass clazz, const char* name, const char* sig)

//获取Java对象的方法ID
jmethodID GetMethodID(jclass clazz, const char* name, const char* sig)
//获取Java类的静态方法ID
jmethodID GetStaticMethodID(jclass clazz, const char* name, const char* sig);


jclass clazz = env->FindClass("android/media/MediaPlayer");//获取MediaPlayer类class
jfieldID name = env->GetFieldID(clazz,"name","Ljava/lang/String;");//获取MediaPlayer对象的属性name的ID
jmethodID getHost = env->GetMethodID(clazz, "getHost", "(V)Ljava/lang/String;");//获取MediaPlayer对象方法getHost()的ID

jfieldID port =  env->GetStaticFieldID(clazz,"port","I");//获取MediaPlayer类的静态属性port的ID
jmethodID getPort = env->GetStaticMethodID(clazz,"getPort","(V)I");//获取MediaPlayer类的静态方法getPort()的ID


jobject GetObjectField(jobject obj, jfieldID fieldID);
jboolean GetBooleanField(jobject obj, jfieldID fieldID);
jint GetIntField(jobject obj, jfieldID fieldID);
...

void SetObjectField(jobject obj, jfieldID fieldID, jobject value);
void SetBooleanField(jobject obj, jfieldID fieldID, jboolean value);
void SetIntField(jobject obj, jfieldID fieldID, jint value);
...
Java对象获取属性的方法为j<类型> Get<类型>Field(jobject obj,jfieldID fieldID);
Java对象设置属性的方法为void Set<类型>Field(jobject obj,jfieldID fieldID,j<类型> value);

jobject GetStaticObjectField(jclass clazz, jfieldID fieldID);
jboolean GetStaticBooleanField(jclass clazz, jfieldID fieldID);
jint GetStaticIntField(jclass clazz, jfieldID fieldID);
...
void SetStaticObjectField(jclass clazz, jfieldID fieldID, jobject value);
void SetStaticBooleanField(jclass clazz, jfieldID fieldID, jboolean value);
void SetStaticIntField(jclass clazz, jfieldID fieldID, jint value);
....
Java类静态属性的获取方法为j<类型> GetStatic<类型>Field(jclass clazz,jfieldID fieldID); 
Java类静态属性的设置方法为void SetStatic<类型>Field(jclass clazz,jfieldID fieldID,j<类型> value);

static void android_media_MediaPlayer_native_setup(JNIEnv *env, jobject thiz, jobject weak_this)
{
	...
jclass clazz = env->getObjectClass(thiz);//获取MediaPlayer类class
//获取和设置Java对象的属性
jfieldID name = env->GetFieldID(clazz,"name","Ljava/lang/String;");//获取MediaPlayer对象的属性name的ID
jstring newStr = env->NewStringUTF("local media player");
env->SetObjectField(thiz,name,newStr);//设置MediaPlayer对象的属性name的值

//获取和设置类的静态属性
jfieldID port =  env->GetStaticFieldID(clazz,"port","I");//获取MediaPlayer类的静态属性port的ID
jint portNum = env->GetStaticIntField(claszz,port);//获取MediaPlayer类静态属性port的值
env->SetStaticIntField(clazz,port,portNum + 100);//设置MediaPlayer类静态属性port的值
	...
}



 调用Java对象的成员方法：
 Call<类型>Method(jobject obj,jmethodID methodID,...);
 Call<类型>MethodV(jobject obj, jmethodID methodID, va_list args);
 Call<类型>MethodA(jobject obj, jmethodID methodID, jvalue* args);
 
 调用Java类的静态方法：
 CallStatic<类型>Method(jobject obj,jmethodID methodID,...);
 CallStatic<类型>MethodV(jobject obj, jmethodID methodID, va_list args);
 CallStatic<类型>MethodA(jobject obj, jmethodID methodID, jvalue* args);
 
 其中类型为Java的基本类型，例如int、char等，代表方法的返回值类型；
 obj为成员方法所属的对象；
 methodID为通过GetMethodID方法获取到的方法ID；
 最后一项参数表示方法的参数列表，...表示的是变长参数，以“V”结束的方法名表示以向量形式提供参数列表，以“A”结尾的方法名表示以jvalue数组形式提供参数列表，这两种方式调用比较少。
 例如调用返回值为Void类型的Java对象的成员方法
 void CallVoidMethod(jobject obj, jmethodID methodID, ...);
 void CallVoidMethodV(jobject obj, jmethodID methodID, va_list args);
 void CallVoidMethodA(jobject obj, jmethodID methodID, jvalue* args);
 
 调用返回值为Void类型的Java类的静态方法
 void CallStaticVoidMethod(jclass clazz, jmethodID methodID, ...);
 void CallStaticVoidMethodV(jclass clazz, jmethodID methodID, va_list args);
 void CallStaticVoidMethodA(jclass clazz, jmethodID methodID, jvalue* args);
 
 
 static void android_media_MediaPlayer_native_setup(JNIEnv *env, jobject thiz, jobject weak_this)
{
	...
jclass clazz = env->FindClass("android/media/MediaPlayer");//获取MediaPlayer类class
jmethodID getHost = env->GetMethodID(clazz, "getHost", "(V)Ljava/lang/String;");//获取MediaPlayer对象方法getHost()的ID
jmethodID getPort = env->GetStaticMethodID(clazz,"getPort","(V)I");//获取MediaPlayer类的静态方法getPort()的ID
env->CallObjectMethod(this,getHost);//调用MediaPlayer的成员方法getHost()
env->CallStaticIntMethod(clazz,getPort);//调用MediaPlayer类的静态方法getPort()
	...
}

jobject NewObject(jclass clazz, jmethodID methodID, ...);
jobject NewObjectV(jclass clazz, jmethodID methodID, va_list args);
jobject NewObjectA(jclass clazz, jmethodID methodID, jvalue* args);
和Java方法调用一样，创建对象也有三种形式。
其中clazz参数代表需要创建对象的class类
methodID表示创建对象的构造方法ID
最后一项参数表示方法的参数列表，...表示的是变长参数，以“V”结束的方法名表示以向量形式提供参数列表，以“A”结尾的方法名表示以jvalue数组形式提供参数列表。
由于构造方法比较特别，与类名一样，并且没有返回值，所以通过GetMethodID来获取构造方法的ID时，第二个参数name固定为类名或者用"<init>"代替类名，第三个参数sig与构造函数有关，默认的构造函数是没有参数的。
例如，调用MediaPlayer的默认构造函数，方法如下:
jclass clazz = env->FindClass("android/media/MediaPlayer");//获取MediaPlayer类class
jmethodID ctor = env->GetMethodID(clazz,"<init>","(V)V");//获取默认构造方法ID
jobject mediaPlayer = env->NewObject(clazz,ctor);//调用构造函数创建MediaPlayer对象

jstring NewString(const jchar* unicodeChars, jsize len)；
jstring NewStringUTF(const char* bytes)；

const char* GetStringUTFChars(jstring string, jboolean* isCopy);
const jchar* GetStringChars(jstring string, jboolean* isCopy);
typedef unsigned short  jchar;          /* unsigned 16 bits */

void ReleaseStringChars(jstring string, const jchar* chars);
void ReleaseStringUTFChars(jstring string, const char* utf);

const char *tmp = env->GetStringUTFChars(path, NULL);
env->ReleaseStringUTFChars(path, tmp);

jsize GetArrayLength(jarray array);//获取数组的长度
jobjectArray NewObjectArray(jsize length, jclass elementClass,jobject initialElement);
jobject GetObjectArrayElement(jobjectArray array, jsize index);//相当于array[index]
void SetObjectArrayElement(jobjectArray array, jsize index, jobject value);//相当于arry[index] = value

j<类型>  New<类型>Array(jsize length);//创建基本类型的数组
j<类型>* Get<类型>ArrayElements(j<类型>Array,jboolean* isCopy);//返回C/C++中的基本类型数组
void Release<类型>ArrayElements(j<类型>Array array, jboolean* elems,jint mode);//释放基本数组所占用的内存资源

jcharArray NewCharArray(jsize length);
jchar* GetCharArrayElements(jcharArray array, jboolean* isCopy);
void ReleaseCharArrayElements(jcharArray array, jchar* elems,jint mode);


static void android_media_MediaPlayer_release(JNIEnv *env, jobject thiz)
{
	 jclass clazz = env->FindClass("android/media/MediaPlayer");//获取MediaPlayer类class
     jfieldID arrayID = env->GetFieldID(clazz,"arrays", "[I");
     jintArray array = (jintArray)(env->GetObjectField(thiz, arrayID));
     jint*  int_array = env->GetIntArrayElements(arr, NULL);
     jsize  len = env->GetArrayLength(array);
     env->ReleaseIntArrayElements(array, int_array, JNI_ABORT);
}
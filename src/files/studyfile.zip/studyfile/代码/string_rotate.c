#include <stdio.h>
int main(){
	printf("hello world");
	return 0;
}

//翻转字符串
void RotateSubString(char *s,int start,int end){
	while(start < end){
		char t = s[start];
		s[start++] = s[end];
		s[end--] = t; 
	}
}

void RotateAllString(char *s){
	int len = strlen(s);
	int m = 0;
	int n = 0;
	for(int i = 0; i < len;i++){
		//空格
		if(i < len && s[i] == '' && s[i+1] != ''){
			m = i + 1;
		}
		if(i > 0 && s[i] == '' && s[i-1] != ''){
			n = i - 1;
		}
		if(m < n){
			RotateSubString(s,m,n);
		}
	}
	RotateSubString(s,m,len - 1);
	RotateSubString(s,0,len -1);
}